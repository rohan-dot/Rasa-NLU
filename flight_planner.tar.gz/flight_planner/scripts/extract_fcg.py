#!/usr/bin/env python3
"""BUILD STEP 1 — Extract structured constraints from FCG HTML files.

Examples
--------
# Air-gapped, with a running vLLM/Gemma endpoint:
python scripts/extract_fcg.py --fcg-dir /path/FCG/full --out data/constraints_db.json \
    --base-url http://localhost:8000 --model google/gemma-3-27b-it

# No model available (heuristic extraction, for plumbing tests):
python scripts/extract_fcg.py --fcg-dir /path/FCG/full --out data/constraints_db.json --mock
"""
import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flight_planner.constraints.extract import build_db
from flight_planner.llm.client import VLLMClient, MockLLM


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fcg-dir", required=True, help="dir of *.cfm.html FCG files")
    ap.add_argument("--out", default="data/constraints_db.json")
    ap.add_argument("--base-url", default=None, help="vLLM OpenAI-compatible base url")
    ap.add_argument("--model", default="google/gemma-3-27b-it")
    ap.add_argument("--mock", action="store_true", help="use offline heuristic instead of an LLM")
    args = ap.parse_args()

    if args.mock or not args.base_url:
        llm = MockLLM()
        print("[extract] using MockLLM (no model)")
    else:
        llm = VLLMClient(args.base_url, args.model)
        print(f"[extract] using vLLM at {args.base_url} model={args.model}")

    n = build_db(llm, args.fcg_dir, args.out)
    print(f"[extract] wrote {n} country records -> {args.out}")


if __name__ == "__main__":
    main()
