#!/usr/bin/env python3
"""VERIFY mode — score a PROPOSED route. If infeasible, generate the optimized
alternative automatically.

Example (proposed route forced straight through the fictional XAA zone):
python scripts/verify_route.py --aircraft C17 --lead-days 14 \
    --waypoints "38.26,-121.93;57,-30;49.44,7.60"
"""
import argparse
from _common import load_airports, resolve, build_engine
from flight_planner.schema import FlightQuery


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--waypoints", required=True,
                    help="semicolon-separated 'lat,lon' or ICAO idents, origin..dest")
    ap.add_argument("--aircraft", default="C17")
    ap.add_argument("--lead-days", type=int, default=None)
    ap.add_argument("--hazmat", action="store_true")
    ap.add_argument("--geojson", default=None)
    ap.add_argument("--db", default=None)
    args = ap.parse_args()

    airports = load_airports()
    wps = [resolve(tok, airports) for tok in args.waypoints.split(";")]
    q = FlightQuery(
        origin=wps[0], destination=wps[-1], aircraft=args.aircraft,
        lead_days_available=args.lead_days, carrying_hazmat=args.hazmat,
        proposed_waypoints=wps,
    )
    eng = build_engine(args.geojson, args.db)
    print(eng.verify(q).summary())


if __name__ == "__main__":
    main()
