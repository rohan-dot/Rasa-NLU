import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flight_planner.schema import LatLon
from flight_planner.airspace.base import CountryProvider
from flight_planner.constraints.base import FCGConstraintProvider
from flight_planner.agent.engine import Engine

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load_airports(path=None):
    path = path or os.path.join(ROOT, "data", "airports.csv")
    d = {}
    with open(path) as f:
        for row in csv.DictReader(f):
            d[row["ident"].upper()] = LatLon(float(row["lat"]), float(row["lon"]))
    return d


def resolve(token, airports):
    """Accept an ICAO ident (KSUU) or 'lat,lon'."""
    token = token.strip()
    if token.upper() in airports:
        return airports[token.upper()]
    lat, lon = token.split(",")
    return LatLon(float(lat), float(lon))


def build_engine(geojson=None, db=None, use_openap=False, wind_grib=None):
    geojson = geojson or os.path.join(ROOT, "data", "countries.geojson")
    db = db or os.path.join(ROOT, "data", "constraints_db.json")
    return Engine(
        airspace=CountryProvider(geojson),
        constraints=FCGConstraintProvider(db),
        use_openap=use_openap, wind_grib=wind_grib,
    )
