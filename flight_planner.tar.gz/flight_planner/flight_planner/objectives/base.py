"""SEAM #3 — Objective registry. The optimizer composes a list of objective
terms. Each declares whether it is HARD (impassable mask) or SOFT (cost).

v1: FeasibilityConstraint(hard) + FuelCost(soft). Add TimeCost, ThreatAvoidance,
ContrailCost later as new Objective subclasses — no core change. Flip a rule from
ignored->hard->soft by config.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from ..schema import Route, Constraints
from ..geo import path_length_km


class Objective(ABC):
    hard: bool = False
    name: str = "objective"

    @abstractmethod
    def cost(self, route: Route, constraints_by_id: dict[str, Constraints],
             ids_crossed: list[str]) -> float:
        """Soft objectives return a cost to minimize; hard ones return inf when
        violated, 0 otherwise."""
        ...


class FuelCost(Objective):
    """Crude fuel model: distance * per-km burn. SWAP for openap-top (see
    routing/optimize.py) to get wind- and altitude-aware fuel."""
    hard = False
    name = "fuel"

    # very rough cruise burn (kg/km); placeholder coefficients
    BURN = {"C17": 8.5, "C5": 13.0, "KC135": 7.0, "A320": 3.0, "DEFAULT": 8.0}

    def __init__(self, weight: float = 1.0):
        self.weight = weight

    def cost(self, route, constraints_by_id, ids_crossed) -> float:
        burn = self.BURN.get(route.aircraft, self.BURN["DEFAULT"])
        return self.weight * path_length_km(route.waypoints) * burn


class FeasibilityConstraint(Objective):
    """HARD: any overflown region with overflight_allowed is False is impassable.
    (Routing already masks these out; this is the belt-and-suspenders check so an
    externally PROPOSED route in verify mode is also rejected.)"""
    hard = True
    name = "diplomatic_feasibility"

    def cost(self, route, constraints_by_id, ids_crossed) -> float:
        for rid in ids_crossed:
            c = constraints_by_id.get(rid)
            if c is not None and c.overflight_allowed is False:
                return float("inf")
        return 0.0
