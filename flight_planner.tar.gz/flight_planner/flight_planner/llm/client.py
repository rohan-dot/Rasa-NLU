"""LLM client for a self-hosted vLLM endpoint serving Gemma (OpenAI-compatible).

Uses `requests` only (no `openai` package needed), so it drops into an air-gapped
box. `guided_json` forces structured output — this is vLLM's schema-constrained
decoding (xgrammar/outlines backend) and is the single biggest reliability win for
the extraction step.

If no endpoint is reachable, MockLLM provides a deterministic heuristic so the
pipeline still runs and is testable.
"""
from __future__ import annotations

import json
import re
from typing import Optional

try:
    import requests
except Exception:  # pragma: no cover
    requests = None


class VLLMClient:
    def __init__(self, base_url: str, model: str = "google/gemma-3-27b-it",
                 api_key: str = "EMPTY", timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout

    def extract_json(self, system: str, user: str, schema: dict) -> dict:
        if requests is None:
            raise RuntimeError("requests not available")
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.0,
            "max_tokens": 1024,
            # vLLM structured-output: constrain the decode to this JSON schema.
            "guided_json": schema,
            "guided_decoding_backend": "xgrammar",
        }
        r = requests.post(
            f"{self.base_url}/v1/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}",
                     "Content-Type": "application/json"},
            data=json.dumps(payload), timeout=self.timeout,
        )
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        return json.loads(content)


class MockLLM:
    """Offline stand-in. Pulls a few obvious fields out of FCG-style text with
    regexes so extract_fcg.py produces *something* without a model. Replace with
    VLLMClient in your env."""

    def extract_json(self, system: str, user: str, schema: dict) -> dict:
        text = user.lower()
        out: dict = {}
        # visa / overflight cues
        out["overflight_allowed"] = "overflight prohibited" not in text and "no overflight" not in text
        out["landing_allowed"] = "landing prohibited" not in text
        m = re.search(r"(\d+)\s*(?:days|day)\s*prior", text)
        if m:
            out["dip_clearance_lead_days"] = int(m.group(1))
        out["hazmat_allowed"] = "hazmat prohibited" not in text and "no hazmat" not in text
        out["air_card_or_cash_required"] = "air card" in text or "cash payment" in text
        return out
