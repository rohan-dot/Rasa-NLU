"""Agentic flight-planning: deterministic geometry/routing/optimization + LLM
extraction & verification, behind three pluggable seams (airspace, constraints,
objectives)."""
__version__ = "0.1.0"
