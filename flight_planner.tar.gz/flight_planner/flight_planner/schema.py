"""Typed data contracts shared across the system.

These dataclasses are the *interfaces between layers*. As long as new data
sources (FIR boundaries, new objectives, new constraint sources) populate these
same shapes, the rest of the pipeline does not change.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional


@dataclass(frozen=True)
class LatLon:
    lat: float
    lon: float

    def as_tuple(self) -> tuple[float, float]:
        return (self.lat, self.lon)


@dataclass
class Constraints:
    """Extracted, structured rules for ONE airspace region (country or FIR).

    The schema is the contract. The FCG extractor fills this in; new sources
    just have to produce the same object. Unknown fields stay None -> 'REVIEW'.
    """
    region_id: str                          # ISO3 (v1) or FIR code (future)
    overflight_allowed: Optional[bool] = None      # hard feasibility driver
    landing_allowed: Optional[bool] = None
    dip_clearance_lead_days: Optional[int] = None  # diplomatic clearance lead time
    hazmat_allowed: Optional[bool] = None
    customs_immigration_notes: Optional[str] = None
    ops_hours_notes: Optional[str] = None
    country_specific_forms: list[str] = field(default_factory=list)
    air_card_or_cash_required: Optional[bool] = None
    source: str = "unknown"                  # provenance, e.g. "FCG:BLZ.cfm.html"
    raw_excerpts: dict = field(default_factory=dict)  # audit trail of where each field came from

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Constraints":
        known = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**known)


@dataclass
class Region:
    """A polygon plus its id. The id is opaque downstream."""
    region_id: str
    rings: list[list[LatLon]]   # outer ring(s); supports MultiPolygon as multiple Regions


@dataclass
class Route:
    waypoints: list[LatLon]
    aircraft: str = "C17"

    @property
    def origin(self) -> LatLon:
        return self.waypoints[0]

    @property
    def destination(self) -> LatLon:
        return self.waypoints[-1]


@dataclass
class FlightQuery:
    """Everything the planner needs to know about the mission."""
    origin: LatLon
    destination: LatLon
    aircraft: str = "C17"
    departure_iso: Optional[str] = None     # ISO date of intended departure
    lead_days_available: Optional[int] = None  # days from now to departure
    carrying_hazmat: bool = False
    proposed_waypoints: Optional[list[LatLon]] = None  # set this for VERIFY mode


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    REVIEW = "REVIEW"   # data missing -> human must look
    NA = "NA"


@dataclass
class ChecklistItem:
    item_id: str
    title: str
    status: Status
    detail: str


@dataclass
class PlanResult:
    feasible: bool
    route: Optional[Route]
    countries_overflown: list[str]
    forbidden_encountered: list[str]
    distance_km: float
    fuel_kg: float
    checklist: list[ChecklistItem]
    messages: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = []
        lines.append(f"FEASIBLE: {self.feasible}")
        if self.route:
            wps = " -> ".join(f"({w.lat:.2f},{w.lon:.2f})" for w in self.route.waypoints)
            lines.append(f"Route ({len(self.route.waypoints)} wpts): {wps}")
        lines.append(f"Distance: {self.distance_km:,.0f} km   Fuel (est): {self.fuel_kg:,.0f} kg")
        lines.append(f"Overflown: {', '.join(self.countries_overflown) or '(none resolved)'}")
        if self.forbidden_encountered:
            lines.append(f"Avoided (forbidden): {', '.join(self.forbidden_encountered)}")
        lines.append("Checklist:")
        for it in self.checklist:
            lines.append(f"  [{it.status.value:6}] {it.item_id} {it.title} — {it.detail}")
        for m in self.messages:
            lines.append(f"NOTE: {m}")
        return "\n".join(lines)
