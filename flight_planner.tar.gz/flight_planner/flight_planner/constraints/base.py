"""SEAM #2 — Constraint provider: 'given a region id, what are the rules?'

v1 = FCGConstraintProvider, which reads the structured DB produced offline by
scripts/extract_fcg.py. Adding a new source = another provider that returns the
same Constraints object (or a MergedProvider that overlays several).
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Optional

from ..schema import Constraints


class ConstraintProvider(ABC):
    @abstractmethod
    def constraints_for(self, region_id: str) -> Optional[Constraints]:
        ...


class FCGConstraintProvider(ConstraintProvider):
    def __init__(self, db_path: str):
        with open(db_path) as f:
            raw = json.load(f)
        self._db: dict[str, Constraints] = {
            k: Constraints.from_dict(v)
            for k, v in raw.items()
            if not k.startswith("_") and isinstance(v, dict)
        }

    def constraints_for(self, region_id: str) -> Optional[Constraints]:
        return self._db.get(region_id)

    def all_ids(self) -> list[str]:
        return list(self._db)

    def forbidden_overflight_ids(self) -> set[str]:
        """The hard mask: every region whose overflight is explicitly disallowed."""
        return {
            rid for rid, c in self._db.items()
            if c.overflight_allowed is False
        }


class MergedConstraintProvider(ConstraintProvider):
    """Overlay multiple providers; earlier ones win on conflict. Future-proofing
    for when FIR-level or theater-specific sources arrive alongside the FCG."""
    def __init__(self, providers: list[ConstraintProvider]):
        self.providers = providers

    def constraints_for(self, region_id: str) -> Optional[Constraints]:
        for p in self.providers:
            c = p.constraints_for(region_id)
            if c is not None:
                return c
        return None
