"""Offline batch: FCG HTML files -> structured Constraints DB.

This is BUILD-ORDER STEP 1. Run it once over your FCG/full/*.cfm.html files to
produce data/constraints_db.json. At query time the planner reads the DB; the LLM
is NOT in the routing loop.
"""
from __future__ import annotations

import json
import os
import re
from glob import glob

from ..schema import Constraints

# JSON schema handed to vLLM guided decoding. Mirrors Constraints' extractable
# fields. Keep this in sync with schema.Constraints.
EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "overflight_allowed": {"type": ["boolean", "null"]},
        "landing_allowed": {"type": ["boolean", "null"]},
        "dip_clearance_lead_days": {"type": ["integer", "null"]},
        "hazmat_allowed": {"type": ["boolean", "null"]},
        "customs_immigration_notes": {"type": ["string", "null"]},
        "ops_hours_notes": {"type": ["string", "null"]},
        "country_specific_forms": {"type": "array", "items": {"type": "string"}},
        "air_card_or_cash_required": {"type": ["boolean", "null"]},
    },
    "required": ["overflight_allowed"],
}

SYSTEM_PROMPT = (
    "You extract diplomatic-clearance and overflight rules from a Foreign Clearance "
    "Guide country page. Return ONLY the JSON object matching the schema. If a field "
    "is not stated, use null. Do not guess."
)


def _html_to_text(html: str) -> str:
    html = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", html)
    text = re.sub(r"&nbsp;|&amp;|&#\d+;", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _iso3_from_filename(path: str) -> str:
    # BLZ.cfm.html -> BLZ
    return os.path.basename(path).split(".")[0].upper()


def extract_one(llm, html_text: str, iso3: str, source: str) -> Constraints:
    user = f"Country page (ISO3 {iso3}):\n\n{html_text[:12000]}"
    fields = llm.extract_json(SYSTEM_PROMPT, user, EXTRACTION_SCHEMA)
    fields["region_id"] = iso3
    fields["source"] = source
    return Constraints.from_dict(fields)


def build_db(llm, fcg_dir: str, out_path: str) -> int:
    files = sorted(glob(os.path.join(fcg_dir, "*.html")))
    db: dict[str, dict] = {}
    for fp in files:
        iso3 = _iso3_from_filename(fp)
        with open(fp, encoding="utf-8", errors="ignore") as f:
            text = _html_to_text(f.read())
        c = extract_one(llm, text, iso3, source=f"FCG:{os.path.basename(fp)}")
        db[iso3] = c.to_dict()
    with open(out_path, "w") as f:
        json.dump(db, f, indent=2)
    return len(db)
