"""Rule-based checklist verification.

Each item from the planner's checklist maps to extracted Constraints fields.
PASS/FAIL where data is decisive; REVIEW where the data is missing (so a human
looks) ; NA where it belongs to a layer we don't model yet (airfield suitability).
The LLM is used elsewhere for justification text; the gating logic stays
deterministic and auditable.
"""
from __future__ import annotations

from ..schema import (Constraints, ChecklistItem, Status, FlightQuery)


def _worst(statuses: list[Status]) -> Status:
    order = [Status.FAIL, Status.REVIEW, Status.PASS, Status.NA]
    for s in order:
        if s in statuses:
            return s
    return Status.NA


def verify(query: FlightQuery, ids_crossed: list[str],
           cons: dict[str, Constraints]) -> list[ChecklistItem]:
    items: list[ChecklistItem] = []

    # Top of checklist: FCG checked for ALL landing + overflight countries
    missing = [rid for rid in ids_crossed if rid not in cons]
    items.append(ChecklistItem(
        "FCG", "Check FCG for landing and overflight countries",
        Status.REVIEW if missing else Status.PASS,
        f"resolved {len(ids_crossed) - len(missing)}/{len(ids_crossed)} countries"
        + (f"; missing FCG data: {', '.join(missing)}" if missing else ""),
    ))

    # Overflight feasibility (the hard driver)
    blocked = [rid for rid in ids_crossed
               if cons.get(rid) and cons[rid].overflight_allowed is False]
    items.append(ChecklistItem(
        "OVFL", "Overflight permitted for all crossed countries",
        Status.FAIL if blocked else Status.PASS,
        f"blocked: {', '.join(blocked)}" if blocked else "all permitted",
    ))

    # 29.7 Diplomatic Clearance Lead Time / HazMat
    lead_statuses, hazmat_statuses, details = [], [], []
    for rid in ids_crossed:
        c = cons.get(rid)
        if not c:
            lead_statuses.append(Status.REVIEW)
            continue
        if c.dip_clearance_lead_days is None:
            lead_statuses.append(Status.REVIEW)
        elif query.lead_days_available is None:
            lead_statuses.append(Status.REVIEW)
        elif query.lead_days_available >= c.dip_clearance_lead_days:
            lead_statuses.append(Status.PASS)
        else:
            lead_statuses.append(Status.FAIL)
            details.append(f"{rid} needs {c.dip_clearance_lead_days}d lead, "
                           f"have {query.lead_days_available}d")
        if query.carrying_hazmat:
            if c.hazmat_allowed is False:
                hazmat_statuses.append(Status.FAIL)
                details.append(f"{rid} forbids hazmat")
            elif c.hazmat_allowed is True:
                hazmat_statuses.append(Status.PASS)
            else:
                hazmat_statuses.append(Status.REVIEW)
    status_297 = _worst(lead_statuses + hazmat_statuses) if (lead_statuses or hazmat_statuses) else Status.REVIEW
    items.append(ChecklistItem(
        "29.7", "Diplomatic Clearance Lead Time / HazMat Requirements",
        status_297, "; ".join(details) if details else "lead times within window"))

    # 29.8 Aircraft Entry/Exit Airfield Restrictions  (airfield layer — not modeled v1)
    items.append(ChecklistItem(
        "29.8", "Aircraft Entry / Exit Airfield Restrictions", Status.NA,
        "airfield-suitability layer (IMR/GDSS/STIF) not modeled in v1"))

    # 29.9 Ops Hrs / Holiday Closures
    notes = [rid for rid in ids_crossed if cons.get(rid) and cons[rid].ops_hours_notes]
    items.append(ChecklistItem(
        "29.9", "Ops Hrs / Holiday Closures",
        Status.REVIEW if notes else Status.REVIEW,
        f"see notes for: {', '.join(notes)}" if notes else "no ops-hours data captured"))

    # 29.10 Customs / Ag / Immigration
    cust = [rid for rid in ids_crossed if cons.get(rid) and cons[rid].customs_immigration_notes]
    items.append(ChecklistItem(
        "29.10", "Customs / Ag / Immigration",
        Status.REVIEW, f"review notes for: {', '.join(cust)}" if cust else "no customs data captured"))

    # 25.16 Country Specific Forms
    forms = {rid: cons[rid].country_specific_forms for rid in ids_crossed
             if cons.get(rid) and cons[rid].country_specific_forms}
    items.append(ChecklistItem(
        "25.16", "Country Specific Forms",
        Status.REVIEW if forms else Status.PASS,
        "; ".join(f"{k}: {', '.join(v)}" for k, v in forms.items()) if forms else "none required"))

    # 29.11 AIR Card / Cash Payment
    pay = [rid for rid in ids_crossed if cons.get(rid) and cons[rid].air_card_or_cash_required]
    items.append(ChecklistItem(
        "29.11", "AIR Card / Cash Payment Requirement",
        Status.REVIEW if pay else Status.PASS,
        f"payment arrangements needed: {', '.join(pay)}" if pay else "none flagged"))

    # 56.71 AMC Policy Matrix (Overseas Msns) — sourced from MAWG-A on SIPR
    items.append(ChecklistItem(
        "56.71", "AMC Policy Matrix (Overseas Msns) — check MAWG-A on SIPR", Status.NA,
        "SIPR-sourced; wire a SIPRPolicyProvider (separate network) to enable"))

    # 10.39 / 10.42 Airfield suitability / WBC / runway  (separate layer)
    items.append(ChecklistItem(
        "10.39/10.42", "Airfield Suitability / WBC / Runway length+width", Status.NA,
        "airfield layer (FLIP/IMR/GDSS) — wire an AirfieldProvider to enable"))

    return items
