"""Self-contained geodesy + 2D polygon geometry.

Pure Python so it runs anywhere (incl. an air-gapped box with no shapely/pyproj).
For PRODUCTION accuracy you can swap these for pyproj.Geod (geodesics) and
shapely (robust polygon ops) behind the same function names — see README.
"""
from __future__ import annotations

import math
from .schema import LatLon

EARTH_KM = 6371.0088


def haversine_km(a: LatLon, b: LatLon) -> float:
    p1, p2 = math.radians(a.lat), math.radians(b.lat)
    dphi = math.radians(b.lat - a.lat)
    dlmb = math.radians(b.lon - a.lon)
    h = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * EARTH_KM * math.asin(min(1.0, math.sqrt(h)))


def great_circle_points(a: LatLon, b: LatLon, n: int = 64) -> list[LatLon]:
    """n points along the great circle from a to b (inclusive)."""
    lat1, lon1 = math.radians(a.lat), math.radians(a.lon)
    lat2, lon2 = math.radians(b.lat), math.radians(b.lon)
    d = haversine_km(a, b) / EARTH_KM
    if d == 0:
        return [a, b]
    out = []
    for i in range(n + 1):
        f = i / n
        A = math.sin((1 - f) * d) / math.sin(d)
        B = math.sin(f * d) / math.sin(d)
        x = A * math.cos(lat1) * math.cos(lon1) + B * math.cos(lat2) * math.cos(lon2)
        y = A * math.cos(lat1) * math.sin(lon1) + B * math.cos(lat2) * math.sin(lon2)
        z = A * math.sin(lat1) + B * math.sin(lat2)
        lat = math.atan2(z, math.sqrt(x * x + y * y))
        lon = math.atan2(y, x)
        out.append(LatLon(math.degrees(lat), math.degrees(lon)))
    return out


def path_length_km(waypoints: list[LatLon]) -> float:
    return sum(haversine_km(waypoints[i], waypoints[i + 1]) for i in range(len(waypoints) - 1))


# ---------- planar polygon ops (lat/lon treated as x/y for visibility tests) ----------
# Good enough for planning over simplified polygons. Note the antimeridian caveat
# in the README; production should test against great-circle arcs via shapely on a
# projected CRS or via spherical predicates.

def point_in_ring(pt: LatLon, ring: list[LatLon]) -> bool:
    """Ray-casting point-in-polygon. ring is a closed or open list of LatLon."""
    x, y = pt.lon, pt.lat
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i].lon, ring[i].lat
        xj, yj = ring[j].lon, ring[j].lat
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-15) + xi):
            inside = not inside
        j = i
    return inside


def _seg_intersect(p1: LatLon, p2: LatLon, p3: LatLon, p4: LatLon) -> bool:
    """Do segments p1p2 and p3p4 cross? (lon=x, lat=y)"""
    def ccw(a, b, c):
        return (c.lat - a.lat) * (b.lon - a.lon) - (b.lat - a.lat) * (c.lon - a.lon)
    d1 = ccw(p3, p4, p1)
    d2 = ccw(p3, p4, p2)
    d3 = ccw(p1, p2, p3)
    d4 = ccw(p1, p2, p4)
    if ((d1 > 0) != (d2 > 0)) and ((d3 > 0) != (d4 > 0)):
        return True
    return False


def segment_crosses_ring(a: LatLon, b: LatLon, ring: list[LatLon]) -> bool:
    n = len(ring)
    for i in range(n):
        if _seg_intersect(a, b, ring[i], ring[(i + 1) % n]):
            return True
    return False


def visible(a: LatLon, b: LatLon, obstacles: list[list[LatLon]], samples: int = 24) -> bool:
    """True if the great-circle arc a->b avoids every obstacle ring.

    We densify the arc and check (1) no sample point lies inside an obstacle and
    (2) no sub-segment crosses an obstacle edge. Catches concave intrusions.
    """
    arc = great_circle_points(a, b, samples)
    for ring in obstacles:
        for p in arc:
            if point_in_ring(p, ring):
                return False
        for i in range(len(arc) - 1):
            if segment_crosses_ring(arc[i], arc[i + 1], ring):
                return False
    return True
