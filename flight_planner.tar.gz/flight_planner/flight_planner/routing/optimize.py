"""Stage 2 — fuel along a FIXED feasible lateral track.

Default: crude distance-based estimate (no deps), so the pipeline runs anywhere.
Production: set use_openap=True to optimize the vertical/speed profile per leg
with openap-top (wind-aware). Same return contract either way.
"""
from __future__ import annotations

from ..schema import Route
from ..geo import path_length_km
from ..objectives.base import FuelCost


def estimate_fuel_kg(route: Route, use_openap: bool = False,
                     wind_grib: str | None = None) -> float:
    if use_openap:
        try:
            return _openap_fuel(route, wind_grib)
        except Exception as e:  # fall back, but surface why
            print(f"[optimize] openap-top unavailable ({e}); using crude estimate")
    return FuelCost().cost(route, {}, [])


def _openap_fuel(route: Route, wind_grib: str | None) -> float:
    """Optimize each leg with openap-top and sum fuel.

    Requires: pip install openap openap-top  (+ cartopy, casadi, cfgrib).
    """
    from openap import top  # noqa: F401  (import here so absence is non-fatal)

    total = 0.0
    for i in range(len(route.waypoints) - 1):
        a, b = route.waypoints[i], route.waypoints[i + 1]
        opt = top.CompleteFlight(route.aircraft, (a.lat, a.lon), (b.lat, b.lon), m0=0.85)
        if wind_grib:
            from openap.top import wind
            opt.enable_wind(wind.read_grib(wind_grib))
        flight = opt.trajectory(objective="fuel")  # pandas DataFrame
        total += float(flight["fuel"].iloc[-1]) if "fuel" in flight else 0.0
    return total
