"""Stage 1 — lateral routing with HARD obstacle avoidance via a visibility graph.

Nodes  = origin, destination, and vertices of every forbidden polygon (pushed
         slightly outward so the path doesn't graze the border).
Edges  = pairs of nodes whose great-circle arc avoids ALL forbidden polygons,
         weighted by great-circle distance.
Search = Dijkstra/A* (networkx).

Result is the shortest ground track that overflies only permitted airspace.
"""
from __future__ import annotations

import math

import networkx as nx

from ..schema import LatLon
from ..geo import haversine_km, visible, point_in_ring


def _centroid(ring: list[LatLon]) -> LatLon:
    return LatLon(sum(p.lat for p in ring) / len(ring),
                  sum(p.lon for p in ring) / len(ring))


def _push_out(v: LatLon, c: LatLon, deg: float = 0.4) -> LatLon:
    """Move a polygon vertex outward from the polygon centroid by `deg` degrees
    so visibility edges can touch it without being flagged as crossing."""
    dlat, dlon = v.lat - c.lat, v.lon - c.lon
    n = math.hypot(dlat, dlon) or 1.0
    return LatLon(v.lat + deg * dlat / n, v.lon + deg * dlon / n)


def plan_lateral(origin: LatLon, destination: LatLon,
                 forbidden_rings: list[list[LatLon]]) -> list[LatLon] | None:
    """Return waypoints origin..destination avoiding all forbidden rings, or None
    if origin/destination is inside a forbidden region (infeasible)."""
    for ring in forbidden_rings:
        if point_in_ring(origin, ring) or point_in_ring(destination, ring):
            return None

    # If the direct arc is already clear, take it.
    if visible(origin, destination, forbidden_rings):
        return [origin, destination]

    nodes: list[LatLon] = [origin, destination]
    for ring in forbidden_rings:
        c = _centroid(ring)
        for v in ring:
            nodes.append(_push_out(v, c))

    G = nx.Graph()
    for i, a in enumerate(nodes):
        G.add_node(i, pt=a)
    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            if visible(nodes[i], nodes[j], forbidden_rings):
                G.add_edge(i, j, weight=haversine_km(nodes[i], nodes[j]))

    try:
        idx = nx.shortest_path(G, 0, 1, weight="weight")  # A*-ready; Dijkstra here
    except nx.NetworkXNoPath:
        return None
    return [nodes[i] for i in idx]
