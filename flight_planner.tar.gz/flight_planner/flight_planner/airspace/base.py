"""SEAM #1 — Airspace provider: 'what regions does this path cross?'

v1 implementation = CountryProvider (political borders, ISO3 keys).
To add FIRs later, write a FIRProvider that returns the same Region objects with
FIR codes as region_id. Nothing downstream changes.
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod

from ..schema import LatLon, Region
from ..geo import point_in_ring, great_circle_points


class AirspaceProvider(ABC):
    @abstractmethod
    def all_regions(self) -> list[Region]:
        ...

    def region_ids_crossed(self, waypoints: list[LatLon], samples_per_leg: int = 48) -> list[str]:
        """Ordered, de-duplicated list of region ids the route passes through."""
        regions = self.all_regions()
        seen: list[str] = []
        for i in range(len(waypoints) - 1):
            arc = great_circle_points(waypoints[i], waypoints[i + 1], samples_per_leg)
            for p in arc:
                for r in regions:
                    if any(point_in_ring(p, ring) for ring in r.rings):
                        if r.region_id not in seen:
                            seen.append(r.region_id)
        return seen

    def rings_for(self, region_ids: set[str]) -> list[list[LatLon]]:
        out: list[list[LatLon]] = []
        for r in self.all_regions():
            if r.region_id in region_ids:
                out.extend(r.rings)
        return out


class CountryProvider(AirspaceProvider):
    """Loads country polygons from a GeoJSON FeatureCollection.

    Each feature needs properties.iso3 (or properties.ADM0_A3 — Natural Earth's
    field). Coordinates are GeoJSON [lon, lat]. Polygon and MultiPolygon supported.

    PRODUCTION: convert Natural Earth 'ne_110m_admin_0_countries' to GeoJSON and
    point --geojson at it. Simplify first (shapely.simplify ~0.3 deg) so the
    visibility graph stays small.
    """

    def __init__(self, geojson_path: str):
        with open(geojson_path) as f:
            gj = json.load(f)
        self._regions: list[Region] = []
        for feat in gj["features"]:
            props = feat.get("properties", {})
            iso3 = props.get("iso3") or props.get("ADM0_A3") or props.get("ISO_A3")
            if not iso3:
                continue
            geom = feat["geometry"]
            rings = self._extract_rings(geom)
            if rings:
                self._regions.append(Region(region_id=iso3, rings=rings))

    @staticmethod
    def _ring(coords) -> list[LatLon]:
        return [LatLon(lat=c[1], lon=c[0]) for c in coords]

    def _extract_rings(self, geom) -> list[list[LatLon]]:
        t = geom["type"]
        rings: list[list[LatLon]] = []
        if t == "Polygon":
            rings.append(self._ring(geom["coordinates"][0]))   # outer ring only
        elif t == "MultiPolygon":
            for poly in geom["coordinates"]:
                rings.append(self._ring(poly[0]))
        return rings

    def all_regions(self) -> list[Region]:
        return self._regions
