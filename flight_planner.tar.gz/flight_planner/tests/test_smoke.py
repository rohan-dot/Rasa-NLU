import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flight_planner.schema import LatLon, FlightQuery, Status
from flight_planner.airspace.base import CountryProvider
from flight_planner.constraints.base import FCGConstraintProvider
from flight_planner.agent.engine import Engine

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GEO = os.path.join(ROOT, "data", "countries.geojson")
DB = os.path.join(ROOT, "data", "constraints_db.json")

KSUU = LatLon(38.2627, -121.9272)
ETAR = LatLon(49.4369, 7.6003)


def engine():
    return Engine(CountryProvider(GEO), FCGConstraintProvider(DB))


def test_generate_is_feasible_and_avoids_forbidden():
    res = engine().plan(FlightQuery(KSUU, ETAR, aircraft="C17", lead_days_available=14))
    assert res.feasible
    assert "XAA" not in res.countries_overflown          # routed around the forbidden zone
    assert res.distance_km > 8000                          # sanity: transatlantic
    assert res.fuel_kg > 0


def test_verify_infeasible_route_then_offers_alternative():
    # straight through the fictional XAA box (mid-Atlantic ~57N,30W)
    proposed = [KSUU, LatLon(57, -30), ETAR]
    q = FlightQuery(KSUU, ETAR, aircraft="C17", lead_days_available=14,
                    proposed_waypoints=proposed)
    res = engine().verify(q)
    assert not res.feasible
    ovfl = [i for i in res.checklist if i.item_id == "OVFL"][0]
    assert ovfl.status == Status.FAIL
    assert any("alternative" in m.lower() for m in res.messages)


def test_hazmat_gate():
    # GBR forbids hazmat in demo data; force a route that crosses it by hazmat flag
    res = engine().plan(FlightQuery(KSUU, ETAR, aircraft="C17",
                                    lead_days_available=14, carrying_hazmat=True))
    # at minimum, 29.7 should be decided (PASS/FAIL/REVIEW), never crash
    item = [i for i in res.checklist if i.item_id == "29.7"][0]
    assert item.status in (Status.PASS, Status.FAIL, Status.REVIEW)


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_"):
            fn()
            print(f"PASS {name}")
    print("all smoke tests passed")
