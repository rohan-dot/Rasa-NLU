"""
static_analysis.py — Real static analysis tools feeding the LLM scanner.

Runs flawfinder and cppcheck if available, normalizes their output into
a single findings list. Degrades gracefully: if neither tool is
installed (common on a bare standalone box), returns an empty list
instead of crashing. The pipeline works with or without it.
"""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("gemma-fuzzer.static")


@dataclass
class StaticFinding:
    tool: str
    file: str
    line: int
    severity: str          # "high", "medium", "low"
    cwe: str               # "CWE-120" or ""
    function: str          # best-effort, may be ""
    message: str


def run_all(src_dir: str) -> list[StaticFinding]:
    """Run all available static analysis tools. Never raises."""
    findings: list[StaticFinding] = []

    if shutil.which("flawfinder"):
        try:
            findings.extend(_run_flawfinder(src_dir))
        except Exception as exc:
            logger.warning("[static] flawfinder failed: %s", exc)
    else:
        logger.info("[static] flawfinder not installed — skipping.")

    if shutil.which("cppcheck"):
        try:
            findings.extend(_run_cppcheck(src_dir))
        except Exception as exc:
            logger.warning("[static] cppcheck failed: %s", exc)
    else:
        logger.info("[static] cppcheck not installed — skipping.")

    sev_order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda f: sev_order.get(f.severity, 9))
    logger.info("[static] %d total findings from static tools.", len(findings))
    return findings


def findings_to_context(findings: list[StaticFinding], max_findings: int = 15) -> str:
    """Format findings as LLM context."""
    if not findings:
        return ""
    lines = [f"## Static Analysis Findings ({len(findings)} total)\n"]
    for f in findings[:max_findings]:
        cwe = f" {f.cwe}" if f.cwe else ""
        lines.append(f"[{f.severity.upper()}] {f.tool}: {f.file}:{f.line}{cwe} — {f.message}")
    if len(findings) > max_findings:
        lines.append(f"\n... and {len(findings) - max_findings} more.")
    return "\n".join(lines)


# ── flawfinder ────────────────────────────────────────────────────

def _run_flawfinder(src_dir: str) -> list[StaticFinding]:
    # CSV output is the most stable to parse
    result = subprocess.run(
        ["flawfinder", "--csv", "--minlevel=2", src_dir],
        capture_output=True, text=True, timeout=300,
    )
    findings = []
    import csv, io
    reader = csv.DictReader(io.StringIO(result.stdout))
    for row in reader:
        try:
            level = int(row.get("Level", "0"))
        except ValueError:
            level = 0
        sev = "high" if level >= 4 else "medium" if level >= 3 else "low"
        cwe = row.get("CWEs", "") or ""
        if cwe and not cwe.startswith("CWE"):
            cwe = f"CWE-{cwe}"
        findings.append(StaticFinding(
            tool="flawfinder",
            file=row.get("File", ""),
            line=int(row.get("Line", "0") or 0),
            severity=sev,
            cwe=cwe.split(",")[0].strip() if cwe else "",
            function=row.get("Function", "") or "",
            message=(row.get("Warning", "") or "")[:120],
        ))
    return findings


# ── cppcheck ──────────────────────────────────────────────────────

def _run_cppcheck(src_dir: str) -> list[StaticFinding]:
    # Template gives us parseable single-line output
    result = subprocess.run(
        ["cppcheck", "--enable=warning,portability",
         "--template={file}:{line}:{severity}:{id}:{message}",
         "--quiet", src_dir],
        capture_output=True, text=True, timeout=300,
    )
    findings = []
    # cppcheck writes results to stderr
    for line in (result.stderr or "").splitlines():
        parts = line.split(":", 4)
        if len(parts) < 5:
            continue
        fpath, lineno, severity, check_id, message = parts
        sev = "high" if severity == "error" else "medium" if severity == "warning" else "low"
        # Map a few common cppcheck ids to CWEs
        cwe = ""
        if "bufferoverflow" in check_id.lower() or "arrayindex" in check_id.lower():
            cwe = "CWE-787"
        elif "null" in check_id.lower():
            cwe = "CWE-476"
        elif "uninit" in check_id.lower():
            cwe = "CWE-457"
        try:
            ln = int(lineno)
        except ValueError:
            ln = 0
        findings.append(StaticFinding(
            tool="cppcheck", file=fpath, line=ln, severity=sev,
            cwe=cwe, function="", message=message[:120],
        ))
    return findings
