"""
triage.py — Skeptical triage, faithful to AISLE's nano-analyzer design.

A finding from the scanner is challenged over multiple rounds by a
skeptical reviewer that can grep the codebase to verify or refute claimed
defenses. Each round votes VALID / INVALID. An arbiter reads all rounds
and makes the final call. Confidence = fraction of rounds that said VALID,
shown as e.g. "80% [VVIVV→V]".

Key idea (AISLE "System over Model"): no agentic navigation, just a tight
skeptical loop with grep. This filters the scanner's false positives,
which is where naive LLM scanners fall apart.

This does NOT execute code. It judges whether a reported bug is real and
whether claimed defenses actually exist in the codebase.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("gemma-fuzzer.triage")

VERDICT_EMOJI = {"VALID": "V", "INVALID": "I", "UNCERTAIN": "?"}


@dataclass
class TriageVerdict:
    verdict: str               # VALID / INVALID / UNCERTAIN
    confidence: float          # fraction of rounds that said VALID (0..1)
    rounds_str: str            # "[VVIVV→V]"
    grep_evidence: list = field(default_factory=list)
    reasoning: str = ""


REVIEWER_PROMPT = """\
You are a skeptical security reviewer. A scanner reported a possible
vulnerability. Your job is to determine if it is REAL or a FALSE POSITIVE.

Be adversarial toward the finding. Most reported bugs are false positives
because a defense exists somewhere (a bounds check, a length validation,
an early return, a caller that constrains the input). Your task is to find
that defense — or confirm none exists.

You may request a grep of the codebase to check for defenses. To do so,
emit a line EXACTLY like:
GREP: <pattern>

You will be shown the results and may grep again. When you have enough
evidence, give your verdict as JSON:
{"verdict": "VALID" | "INVALID" | "UNCERTAIN",
 "reasoning": "one or two sentences citing specific evidence"}

VALID   = the bug is real and no adequate defense exists.
INVALID = a defense exists, or the bug cannot actually occur.
UNCERTAIN = genuinely cannot tell from available evidence.

Find NEW evidence each round — do not just restate prior arguments."""

ARBITER_PROMPT = """\
You are the arbiter. Multiple skeptical reviewers examined a reported
vulnerability over several rounds, with grep access to the codebase.
Read their verdicts and reasoning, then make the FINAL call.

Output JSON only:
{"verdict": "VALID" | "INVALID" | "UNCERTAIN",
 "reasoning": "final judgment citing the strongest evidence"}"""


def skeptical_triage(llm, finding, code_context: str, src_dir: str,
                     rounds: int = 3, repo_dir: str = None) -> TriageVerdict:
    """Run multi-round skeptical triage on a single finding."""
    if not llm.is_available():
        return TriageVerdict("UNCERTAIN", 0.0, "[?]", reasoning="LLM unavailable")

    repo_dir = repo_dir or src_dir
    finding_desc = _describe_finding(finding)
    round_verdicts = []
    all_evidence = []
    prior_args = ""

    for rn in range(1, rounds + 1):
        verdict, reasoning, evidence = _one_round(
            llm, finding_desc, code_context, repo_dir, prior_args,
        )
        round_verdicts.append(verdict)
        all_evidence.extend(evidence)
        prior_args += f"\nRound {rn} ({verdict}): {reasoning}"
        logger.info("[triage] Round %d/%d: %s — %s",
                    rn, rounds, verdict, reasoning[:80])

    # Arbiter
    final_verdict, final_reason = _arbiter(llm, finding_desc, prior_args)

    valid_count = sum(1 for v in round_verdicts if v == "VALID")
    confidence = valid_count / len(round_verdicts) if round_verdicts else 0.0
    rounds_str = "[" + "".join(VERDICT_EMOJI.get(v, "?") for v in round_verdicts) \
                 + "→" + VERDICT_EMOJI.get(final_verdict, "?") + "]"

    logger.info("[triage] FINAL: %s  %.0f%% %s",
                final_verdict, confidence * 100, rounds_str)

    return TriageVerdict(
        verdict=final_verdict, confidence=confidence, rounds_str=rounds_str,
        grep_evidence=all_evidence, reasoning=final_reason,
    )


def _one_round(llm, finding_desc, code_context, repo_dir, prior_args):
    """One skeptical review round. Reviewer may grep up to 3 times."""
    user = f"## Reported finding\n{finding_desc}\n\n## Code\n```c\n{code_context[:5000]}\n```\n"
    if prior_args:
        user += f"\n## Prior rounds (find NEW evidence)\n{prior_args[:2000]}\n"

    evidence = []
    for _ in range(3):  # up to 3 grep iterations
        response = llm.chat(system=REVIEWER_PROMPT, user=user,
                            max_tokens=600, temperature=0.2)
        if not response:
            return "UNCERTAIN", "no response", evidence

        grep_match = re.search(r'GREP:\s*(.+)', response)
        verdict = _parse_verdict(response)

        if verdict and "GREP:" not in response:
            return verdict[0], verdict[1], evidence

        if grep_match:
            pattern = grep_match.group(1).strip()
            results = _do_grep(pattern, repo_dir)
            evidence.append({"pattern": pattern, "results": results[:500]})
            user += f"\n## GREP '{pattern}' results:\n{results[:800]}\n\nContinue or give verdict."
            continue

        if verdict:
            return verdict[0], verdict[1], evidence
        break

    # Force a verdict if reviewer kept grepping
    response = llm.chat(
        system=REVIEWER_PROMPT,
        user=user + "\n\nYou must now give a JSON verdict.",
        max_tokens=400, temperature=0.1,
    )
    v = _parse_verdict(response or "")
    return (v[0], v[1], evidence) if v else ("UNCERTAIN", "inconclusive", evidence)


def _arbiter(llm, finding_desc, prior_args):
    response = llm.chat(
        system=ARBITER_PROMPT,
        user=f"## Finding\n{finding_desc}\n\n## All rounds\n{prior_args[:3000]}",
        max_tokens=400, temperature=0.1,
    )
    v = _parse_verdict(response or "")
    return v if v else ("UNCERTAIN", "arbiter inconclusive")


def _do_grep(pattern: str, repo_dir: str) -> str:
    """Run ripgrep if available, else grep. Returns matching lines."""
    # sanitize: single token/pattern, no shell metacharacters
    pattern = pattern.strip().strip('"').strip("'")
    if not pattern or len(pattern) > 200:
        return "(invalid pattern)"
    tool = ["rg", "-n", "--no-heading", "-e", pattern, repo_dir] \
        if _have("rg") else ["grep", "-rn", "-e", pattern, repo_dir]
    try:
        r = subprocess.run(tool, capture_output=True, text=True, timeout=20)
        out = r.stdout.strip()
        return out if out else "(no matches — claimed defense not found)"
    except Exception as exc:
        return f"(grep error: {exc})"


def _have(cmd):
    import shutil
    return shutil.which(cmd) is not None


def _parse_verdict(text: str):
    s, e = text.find("{"), text.rfind("}")
    if s != -1 and e != -1:
        try:
            obj = json.loads(text[s:e + 1])
            v = obj.get("verdict", "").upper()
            if v in ("VALID", "INVALID", "UNCERTAIN"):
                return (v, obj.get("reasoning", ""))
        except json.JSONDecodeError:
            pass
    # fallback: keyword scan
    up = text.upper()
    if "INVALID" in up:
        return ("INVALID", text[:150])
    if "VALID" in up:
        return ("VALID", text[:150])
    return None


def _describe_finding(finding) -> str:
    if isinstance(finding, dict):
        return (f"Function: {finding.get('function', '?')}\n"
                f"Bug type: {finding.get('bug_type', '?')}\n"
                f"Description: {finding.get('description', '')}\n"
                f"Data flow: {finding.get('data_flow', '')}")
    # ScanFinding dataclass
    return (f"Function: {getattr(finding, 'function', '?')}\n"
            f"Bug type: {getattr(finding, 'bug_type', '?')}\n"
            f"Description: {getattr(finding, 'description', '')}\n"
            f"Data flow: {getattr(finding, 'data_flow', '')}")
