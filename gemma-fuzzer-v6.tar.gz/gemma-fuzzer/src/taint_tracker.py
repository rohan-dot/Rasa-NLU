"""
taint_tracker.py — Source-to-sink taint analysis via tree-sitter.

Traces data flow from SOURCES (function parameters) to SINKS (memcpy,
malloc, sprintf, strcpy, ...) within each function. Real static analysis,
not LLM guessing. Intra-procedural (within one function); cross-function
flows are out of scope here.

Degrades to a regex scan if tree-sitter isn't installed.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("gemma-fuzzer.taint")

HAS_TREE_SITTER = False
_parser = None
try:
    import tree_sitter_c as tsc
    from tree_sitter import Language, Parser
    _parser = Parser(Language(tsc.language()))
    HAS_TREE_SITTER = True
except Exception:
    pass


# sink function -> dangerous argument indices
SINKS = {
    "memcpy": [2], "memmove": [2], "memset": [2],
    "strncpy": [2], "strncat": [2],
    "strcpy": [0], "strcat": [0], "sprintf": [0], "gets": [0],
    "malloc": [0], "calloc": [0, 1], "realloc": [1],
    "alloca": [0],
    "snprintf": [2], "fread": [2], "fwrite": [2],
}

_SKIP = (".git", "/test", "example", "aflplusplus", "honggfuzz",
         "libfuzzer", "qemu_mode", "cmakefiles")


@dataclass
class TaintFlow:
    source: str
    sink: str
    sink_function: str
    variable_chain: list
    function: str
    file: str
    line: int
    severity: str


@dataclass
class TaintResult:
    flows: list = field(default_factory=list)
    functions_analyzed: int = 0
    files_analyzed: int = 0


def analyze_codebase(src_dir: str) -> TaintResult:
    result = TaintResult()
    src_path = Path(src_dir)

    for fpath in src_path.rglob("*.c"):
        if any(s in str(fpath).lower() for s in _SKIP):
            continue
        try:
            content = fpath.read_text(errors="replace")
            rel = str(fpath.relative_to(src_path))
        except Exception:
            continue
        result.files_analyzed += 1
        flows = (_analyze_treesitter(content, rel) if HAS_TREE_SITTER
                 else _analyze_regex(content, rel))
        result.flows.extend(flows)
        result.functions_analyzed += len(set(f.function for f in flows))

    order = {"high": 0, "medium": 1, "low": 2}
    result.flows.sort(key=lambda f: order.get(f.severity, 9))
    logger.info("[taint] %d files, %d source→sink flows.",
                result.files_analyzed, len(result.flows))
    return result


def flows_to_context(flows: list, max_flows: int = 15) -> str:
    if not flows:
        return ""
    lines = [f"## Source-to-Sink Taint Flows ({len(flows)} total)\n"]
    for f in flows[:max_flows]:
        lines.append(f"[{f.severity.upper()}] {f.file}:{f.function}:{f.line} — "
                     f"{f.source} → {f.sink}")
    if len(flows) > max_flows:
        lines.append(f"\n... and {len(flows) - max_flows} more flows.")
    return "\n".join(lines)


# ── tree-sitter ───────────────────────────────────────────────────

def _walk(node):
    yield node
    for c in node.children:
        yield from _walk(c)


def _child(node, t):
    for c in node.children:
        if c.type == t:
            return c
    return None


def _desc(node, t):
    for c in node.children:
        if c.type == t:
            return c
        r = _desc(c, t)
        if r:
            return r
    return None


def _analyze_treesitter(content: str, filename: str) -> list:
    if not _parser:
        return []
    data = content.encode("utf-8", errors="replace")
    tree = _parser.parse(data)
    flows = []
    for node in _walk(tree.root_node):
        if node.type == "function_definition":
            flows.extend(_analyze_func(node, data, filename))
    return flows


def _analyze_func(func_node, data, filename) -> list:
    flows = []
    decl = _desc(func_node, "function_declarator")
    if not decl:
        return []
    name_node = _child(decl, "identifier")
    if not name_node:
        return []
    func_name = data[name_node.start_byte:name_node.end_byte].decode()

    params = _child(decl, "parameter_list")
    param_names = set()
    if params:
        for c in _walk(params):
            if c.type == "identifier" and c.parent and \
               c.parent.type in ("parameter_declaration", "pointer_declarator"):
                nm = data[c.start_byte:c.end_byte].decode()
                if nm not in ("void", "const", "unsigned", "int", "char"):
                    param_names.add(nm)
    if not param_names:
        return []

    body = _child(func_node, "compound_statement")
    if not body:
        return []

    # FIX: this must be a set, not dict(param_names)
    tainted_vars = set(param_names)

    # propagate taint through assignments / declarations
    for node in _walk(body):
        if node.type in ("assignment_expression", "init_declarator"):
            lhs_node = _child(node, "identifier") or _desc(node, "identifier")
            if not lhs_node:
                continue
            lhs = data[lhs_node.start_byte:lhs_node.end_byte].decode()
            txt = data[node.start_byte:node.end_byte].decode()
            for tv in list(tainted_vars):
                if re.search(r'\b' + re.escape(tv) + r'\b', txt):
                    tainted_vars.add(lhs)
                    break

    # find tainted data reaching sinks
    for node in _walk(body):
        if node.type != "call_expression":
            continue
        callee_node = _child(node, "identifier")
        if not callee_node:
            continue
        callee = data[callee_node.start_byte:callee_node.end_byte].decode()
        if callee not in SINKS:
            continue
        arg_list = _child(node, "argument_list")
        if not arg_list:
            continue
        args = [c for c in arg_list.children if c.type not in ("(", ")", ",")]
        for idx in SINKS[callee]:
            if idx >= len(args):
                continue
            arg_txt = data[args[idx].start_byte:args[idx].end_byte].decode()
            for tv in tainted_vars:
                if re.search(r'\b' + re.escape(tv) + r'\b', arg_txt):
                    sev = ("high" if callee in ("strcpy", "strcat", "sprintf", "gets",
                                                "malloc", "realloc", "calloc", "alloca")
                           else "medium")
                    flows.append(TaintFlow(
                        source=(f"parameter '{tv}'" if tv in param_names
                                else f"value derived from input ('{tv}')"),
                        sink=f"{callee}() arg {idx + 1}",
                        sink_function=callee,
                        variable_chain=[tv],
                        function=func_name, file=filename,
                        line=node.start_point[0] + 1, severity=sev,
                    ))
                    break
    return flows


# ── regex fallback ────────────────────────────────────────────────

def _analyze_regex(content: str, filename: str) -> list:
    flows = []
    func_re = re.compile(r'(\w+)\s*\(([^)]*)\)\s*\{', re.MULTILINE)
    for m in func_re.finditer(content):
        fname = m.group(1)
        if fname in ("if", "while", "for", "switch"):
            continue
        params = set()
        for p in m.group(2).split(","):
            toks = p.strip().split()
            if toks:
                nm = toks[-1].strip("*")
                if nm and nm not in ("void", "const"):
                    params.add(nm)
        if not params:
            continue
        body = content[m.end():m.end() + 8000]
        for sink, idxs in SINKS.items():
            for call in re.finditer(re.escape(sink) + r'\s*\(([^)]*)\)', body):
                args = [a.strip() for a in call.group(1).split(",")]
                for idx in idxs:
                    if idx >= len(args):
                        continue
                    for pn in params:
                        if re.search(r'\b' + re.escape(pn) + r'\b', args[idx]):
                            ln = content[:m.end() + call.start()].count("\n") + 1
                            flows.append(TaintFlow(
                                source=f"parameter '{pn}'",
                                sink=f"{sink}() arg {idx + 1}",
                                sink_function=sink, variable_chain=[pn],
                                function=fname, file=filename, line=ln,
                                severity="high" if sink in ("strcpy", "sprintf", "gets") else "medium",
                            ))
                            break
    return flows
