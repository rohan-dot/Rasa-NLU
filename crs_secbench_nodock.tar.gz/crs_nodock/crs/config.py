"""
crs/config.py — Configuration (no Docker, no LiteLLM).
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CRSConfig:
    LLM_BASE_URL: str = field(
        default_factory=lambda: os.environ.get(
            "OPENAI_BASE_URL",
            "http://g52lambda02.llan.ll.mit.edu:8000/v1",
        )
    )
    LLM_API_KEY: str = field(
        default_factory=lambda: os.environ.get("OPENAI_API_KEY", "EMPTY")
    )
    LLM_MODEL: str = field(
        default_factory=lambda: os.environ.get("LLM_MODEL", "gemma-3-27b-it")
    )
    MAX_TOKENS: int = 4096
    MAX_RETRIES: int = 3
    BUILD_TIMEOUT: int = 300
    RUN_TIMEOUT: int = 60
    WORK_DIR: Path = field(
        default_factory=lambda: Path(
            os.environ.get("CRS_WORK_DIR", "/tmp/crs_workdir")
        )
    )

    def __post_init__(self) -> None:
        self.WORK_DIR = Path(self.WORK_DIR)
        self.WORK_DIR.mkdir(parents=True, exist_ok=True)

    def task_work_dir(self, task_id: str) -> Path:
        safe = task_id.replace(":", "_").replace("/", "_").replace("__", "_")
        d = self.WORK_DIR / safe
        d.mkdir(parents=True, exist_ok=True)
        return d


cfg = CRSConfig()
