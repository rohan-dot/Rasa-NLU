"""
crs/runner.py — Feed PoC bytes/files to a target binary, detect sanitizer crashes.
"""
from __future__ import annotations
import re, subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

from crs.byte_gen import PoCCandidate
from crs.config import cfg


@dataclass
class RunResult:
    poc: PoCCandidate
    triggered: bool
    crash_type: str
    sanitizer_output: str
    return_code: int


def detect_crash(return_code: int, output: str) -> Tuple[bool, str]:
    """Check if output indicates a sanitizer or crash trigger."""
    for pat in [r"ERROR: AddressSanitizer", r"heap-buffer-overflow",
                r"stack-buffer-overflow", r"heap-use-after-free",
                r"SUMMARY: AddressSanitizer", r"AddressSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            m = re.search(r"ERROR: AddressSanitizer: (\S+)", output)
            return True, m.group(1) if m else "asan"
    for pat in [r"runtime error:", r"UndefinedBehaviorSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "ubsan"
    for pat in [r"MemorySanitizer", r"use-of-uninitialized-value"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "msan"
    for pat in [r"Segmentation fault", r"Aborted", r"double free"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "crash"
    if return_code not in (0, 1) and return_code < 0:
        return True, f"signal_{abs(return_code)}"
    return False, ""


def run_poc_stdin(poc: PoCCandidate, binary: Path) -> RunResult:
    """Feed PoC bytes via stdin."""
    print(f"  [run] {poc.name}: {len(poc.data)} bytes via stdin -> {binary.name}")
    try:
        r = subprocess.run(
            [str(binary)], input=poc.data, capture_output=True,
            timeout=cfg.RUN_TIMEOUT, cwd=str(binary.parent),
        )
        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        triggered, crash_type = detect_crash(r.returncode, output)
        status = f"\033[92mTRIGGERED ({crash_type})\033[0m" if triggered else "clean"
        print(f"  [run]   -> {status}  rc={r.returncode}")
        if triggered:
            for line in output.split("\n"):
                if any(k in line for k in ["ERROR:", "SUMMARY:", "runtime error"]):
                    print(f"  [run]   {line.strip()}")
        return RunResult(poc, triggered, crash_type, output[:8000], r.returncode)
    except subprocess.TimeoutExpired:
        return RunResult(poc, False, "timeout", "", -1)
    except Exception as e:
        return RunResult(poc, False, "error", str(e), -1)


def run_poc_file(poc: PoCCandidate, binary: Path, args_template: str = "{poc}") -> RunResult:
    """Feed PoC as a file argument. args_template uses {poc} as placeholder."""
    # Write PoC to a temp file
    poc_file = binary.parent / f"_poc_{poc.name}.bin"
    poc_file.write_bytes(poc.data)

    cmd_str = args_template.replace("{poc}", str(poc_file))
    cmd = [str(binary)] + cmd_str.split()
    # Remove the binary from cmd if it's already in args_template
    if str(binary) in cmd_str:
        cmd = cmd_str.split()

    print(f"  [run] {poc.name}: {len(poc.data)} bytes as file -> {' '.join(cmd[-3:])}")
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=cfg.RUN_TIMEOUT,
            cwd=str(binary.parent),
        )
        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        triggered, crash_type = detect_crash(r.returncode, output)
        status = f"\033[92mTRIGGERED ({crash_type})\033[0m" if triggered else "clean"
        print(f"  [run]   -> {status}  rc={r.returncode}")
        if triggered:
            for line in output.split("\n"):
                if any(k in line for k in ["ERROR:", "SUMMARY:", "runtime error"]):
                    print(f"  [run]   {line.strip()}")
        return RunResult(poc, triggered, crash_type, output[:8000], r.returncode)
    except subprocess.TimeoutExpired:
        return RunResult(poc, False, "timeout", "", -1)
    except Exception as e:
        return RunResult(poc, False, "error", str(e), -1)


def run_all(binary: Path, pocs: List[PoCCandidate],
            mode: str = "stdin", args_template: str = "{poc}",
            stop_on_trigger: bool = True) -> List[RunResult]:
    """Run all PoCs. mode='stdin' pipes bytes, mode='file' passes as argument."""
    results = []
    print(f"\n  Testing {len(pocs)} candidate(s) against {binary}")
    for i, poc in enumerate(pocs):
        print(f"\n  [{i+1}/{len(pocs)}]")
        if mode == "file":
            r = run_poc_file(poc, binary, args_template)
        else:
            r = run_poc_stdin(poc, binary)
        results.append(r)
        if r.triggered and stop_on_trigger:
            print(f"\n  *** TRIGGERED: {r.crash_type} ***")
            break
    return results
