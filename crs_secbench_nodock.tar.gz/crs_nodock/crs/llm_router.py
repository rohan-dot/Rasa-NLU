"""
crs/llm_router.py — Direct vLLM via openai client. No LiteLLM.
"""
from __future__ import annotations
import re, time, json, logging
from typing import Optional

try:
    import openai
except ImportError:
    openai = None  # type: ignore

from crs.config import cfg

logger = logging.getLogger(__name__)


class LLMRouter:
    def __init__(self, model=cfg.LLM_MODEL, base_url=cfg.LLM_BASE_URL, api_key=cfg.LLM_API_KEY):
        if openai is None:
            raise ImportError("pip install openai")
        self.model = model
        self._calls = 0
        self._client = openai.OpenAI(base_url=base_url, api_key=api_key, timeout=300.0)

    def chat(self, system_prompt: str, user_prompt: str,
             max_tokens: int = cfg.MAX_TOKENS, temperature: float = 0.2) -> str:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ]
        last_err = None
        for attempt in range(1, cfg.MAX_RETRIES + 1):
            try:
                r = self._client.chat.completions.create(
                    model=self.model, messages=messages,
                    max_tokens=max_tokens, temperature=temperature,
                )
                self._calls += 1
                return r.choices[0].message.content or ""
            except Exception as e:
                last_err = e
                wait = 2 ** (attempt - 1)
                print(f"  [LLM] Error (attempt {attempt}): {e} — wait {wait}s")
                time.sleep(wait)
        raise RuntimeError(f"LLM retries exhausted: {last_err}")

    def log_stats(self):
        print(f"[LLM] Total calls: {self._calls}")
