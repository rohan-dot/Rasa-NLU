#!/usr/bin/env python3
"""
run_task.py — Build a SEC-bench task with ASAN and run the CRS against it.

Usage:
    # After fetching a task with fetch_task.py:
    python run_task.py --task-dir ./secbench_tasks/faad2__faad2-CVE-2023-38857

    # With your vLLM endpoint:
    python run_task.py --task-dir ./secbench_tasks/faad2__faad2-CVE-2023-38857 \
        --base-url http://g52lambda02.llan.ll.mit.edu:8000/v1 \
        --model gemma-3-27b-it

    # Without LLM (patterns only):
    python run_task.py --task-dir ./secbench_tasks/faad2__faad2-CVE-2023-38857 --no-llm

    # If you know the binary and how to invoke it:
    python run_task.py --task-dir ./secbench_tasks/faad2__faad2-CVE-2023-38857 \
        --binary ./repo/frontend/faad \
        --run-mode file \
        --run-args "-w {poc}"

Requires: pip install openai  (only if using LLM)
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys, time
from pathlib import Path

# Add parent to path so we can import crs
sys.path.insert(0, str(Path(__file__).parent))

from crs.config import cfg
from crs.byte_gen import generate_all, PoCCandidate
from crs.runner import run_all, run_poc_stdin, run_poc_file, RunResult


# ── Build ──────────────────────────────────────────────────────────────────

def build_project(repo: Path, harness_commands: str = "") -> tuple[bool, str]:
    """
    Build the project with ASAN. Uses harness_commands if available,
    otherwise auto-detects the build system.
    """
    env = os.environ.copy()
    san = "-fsanitize=address,undefined -g -O1"
    env["CFLAGS"] = san
    env["CXXFLAGS"] = san
    env["LDFLAGS"] = "-fsanitize=address,undefined"
    log_parts: list[str] = []

    # If SEC-bench harness commands exist, extract build commands from them
    if harness_commands:
        print("[build] Using SEC-bench harness build commands")
        # Parse harness for build-related lines (skip run/test commands)
        build_lines = []
        for line in harness_commands.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Skip lines that look like PoC execution
            if any(k in line.lower() for k in ["/poc", "poc.bin", "exit code"]):
                continue
            build_lines.append(line)

        if build_lines:
            # Inject ASAN flags into configure/make commands
            script = "\n".join(build_lines)
            # Replace CC/CFLAGS in the script
            script = script.replace('CC="gcc"', f'CC="gcc" CFLAGS="{san}"')
            if "CFLAGS" not in script and "configure" in script:
                script = script.replace("./configure",
                    f'./configure CFLAGS="{san}" LDFLAGS="-fsanitize=address,undefined"')

            print(f"[build] Running harness build script:\n{script[:500]}")
            try:
                r = subprocess.run(
                    ["bash", "-c", script], capture_output=True,
                    timeout=cfg.BUILD_TIMEOUT, cwd=str(repo), env=env,
                )
                output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
                log_parts.append(output)
                if r.returncode == 0:
                    print("[build] Harness build SUCCESS")
                    return True, "\n".join(log_parts)
                else:
                    print(f"[build] Harness build failed (rc={r.returncode}), trying auto-detect...")
            except subprocess.TimeoutExpired:
                print("[build] Harness build timed out, trying auto-detect...")

    # Auto-detect build system
    build_type = _detect_build(repo)
    print(f"[build] Auto-detected: {build_type}")

    try:
        if build_type == "autotools":
            if (repo / "configure.ac").exists():
                r = subprocess.run(["autoreconf", "-fi"], capture_output=True,
                                   timeout=120, cwd=str(repo), env=env)
                log_parts.append(r.stderr.decode(errors="replace"))

            if (repo / "configure").exists():
                r = subprocess.run(
                    ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
                     f"LDFLAGS=-fsanitize=address,undefined",
                     "--enable-static", "--disable-shared"],
                    capture_output=True, timeout=180, cwd=str(repo), env=env,
                )
                log_parts.append(r.stderr.decode(errors="replace"))
                if r.returncode != 0:
                    # Simpler retry
                    r = subprocess.run(
                        ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}"],
                        capture_output=True, timeout=180, cwd=str(repo), env=env,
                    )
                    log_parts.append(r.stderr.decode(errors="replace"))

            r = subprocess.run(["make", "-j4"], capture_output=True,
                               timeout=300, cwd=str(repo), env=env)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return False, "\n".join(log_parts)

        elif build_type == "cmake":
            bdir = repo / "build"
            bdir.mkdir(exist_ok=True)
            r = subprocess.run(
                ["cmake", "-B", str(bdir), "-S", str(repo),
                 f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
                 "-DBUILD_TESTING=OFF", "-DBUILD_SHARED_LIBS=OFF"],
                capture_output=True, timeout=120, cwd=str(repo), env=env,
            )
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return False, "\n".join(log_parts)
            r = subprocess.run(["cmake", "--build", str(bdir), "-j4"],
                               capture_output=True, timeout=300, cwd=str(repo), env=env)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return False, "\n".join(log_parts)

        else:  # make
            r = subprocess.run(["make", "-j4"], capture_output=True,
                               timeout=300, cwd=str(repo), env=env)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return False, "\n".join(log_parts)

        print("[build] Build SUCCESS")
        return True, "\n".join(log_parts)

    except subprocess.TimeoutExpired:
        return False, "\n".join(log_parts) + "\nBuild timed out"
    except Exception as e:
        return False, "\n".join(log_parts) + f"\n{e}"


def _detect_build(repo: Path) -> str:
    # Sort configure.ac by depth (shallowest first)
    configs = sorted(repo.rglob("configure.ac"), key=lambda p: len(p.parts))
    if configs or (repo / "configure").exists():
        return "autotools"
    cmakes = sorted(repo.rglob("CMakeLists.txt"), key=lambda p: len(p.parts))
    if cmakes:
        return "cmake"
    return "make"


def find_binary(repo: Path, description: str = "") -> list[Path]:
    """Find ELF binaries in the repo after building."""
    candidates: list[Path] = []
    skip = {"test", "tests", ".git", "doc", "docs"}

    for f in sorted(repo.rglob("*")):
        if not f.is_file():
            continue
        if {p.lower() for p in f.parts} & skip:
            continue
        # Check if it's executable
        try:
            if not os.access(f, os.X_OK):
                continue
            # Check if it's an ELF binary (not a script)
            with open(f, "rb") as fh:
                magic = fh.read(4)
            if magic == b"\x7fELF":
                candidates.append(f)
        except (OSError, PermissionError):
            continue

    # Sort: prefer binaries whose name appears in the description
    desc_lower = description.lower()
    def score(p):
        name = p.stem.lower()
        if name in desc_lower: return 0
        if "fuzz" in name: return 1
        return 2

    candidates.sort(key=score)
    return candidates


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(description="Run CRS on a SEC-bench task (no Docker)")
    p.add_argument("--task-dir", required=True, help="Path from fetch_task.py")
    p.add_argument("--binary", default=None, help="Path to pre-built binary (skip build)")
    p.add_argument("--run-mode", choices=["stdin", "file"], default="file",
                   help="How to feed PoC: stdin or file argument (default: file)")
    p.add_argument("--run-args", default="{poc}",
                   help="Args template for file mode, {poc} = PoC path (default: '{poc}')")
    p.add_argument("--model", default=cfg.LLM_MODEL)
    p.add_argument("--base-url", default=cfg.LLM_BASE_URL)
    p.add_argument("--api-key", default=cfg.LLM_API_KEY)
    p.add_argument("--no-llm", action="store_true", help="Skip LLM, use patterns only")
    p.add_argument("--skip-build", action="store_true", help="Skip building the project")
    p.add_argument("--output-dir", default="./crs_results")
    args = p.parse_args()

    task_dir = Path(args.task_dir).resolve()
    repo_dir = task_dir / "repo"

    # Load metadata
    desc_file = task_dir / "description.txt"
    if not desc_file.exists():
        print(f"ERROR: {desc_file} not found. Run fetch_task.py first.")
        sys.exit(1)
    description = desc_file.read_text().strip()
    task_id = task_dir.name

    harness_commands = ""
    harness_file = task_dir / "harness_commands.txt"
    if harness_file.exists():
        harness_commands = harness_file.read_text()

    print(f"\n{'='*60}")
    print(f"  CRS — SEC-bench (no Docker)")
    print(f"{'='*60}")
    print(f"  Task:  {task_id}")
    print(f"  Repo:  {repo_dir}")
    print(f"  Desc:  {description[:100]}...")
    print(f"  LLM:   {'disabled' if args.no_llm else args.model}")
    t0 = time.time()

    # Step 1: Build
    if args.binary:
        binary = Path(args.binary).resolve()
        if not binary.exists():
            print(f"ERROR: Binary not found: {binary}")
            sys.exit(1)
        print(f"\n  Step 1: Using pre-built binary: {binary}")
    else:
        if not args.skip_build:
            print(f"\n  Step 1: Building project with ASAN...")
            if not repo_dir.exists():
                print(f"ERROR: Repo not found at {repo_dir}")
                print(f"  Run fetch_task.py first, or use --binary")
                sys.exit(1)
            ok, log = build_project(repo_dir, harness_commands)
            if not ok:
                print(f"\n  BUILD FAILED. Last 500 chars of log:")
                print(log[-500:])
                print(f"\n  Tip: check harness_commands.txt for the correct build steps")
                print(f"  Tip: you may need to install deps (apt-get install ...)")
                print(f"  Tip: build manually then re-run with --binary <path>")
                sys.exit(1)
        else:
            print(f"\n  Step 1: Build skipped (--skip-build)")

        # Find binary
        print(f"\n  Finding binary...")
        binaries = find_binary(repo_dir, description)
        if not binaries:
            print(f"  No ELF binaries found after build!")
            print(f"  Build manually and re-run with --binary <path>")
            sys.exit(1)

        binary = binaries[0]
        print(f"  Found {len(binaries)} binary(ies), using: {binary}")
        if len(binaries) > 1:
            print(f"  Others: {[str(b) for b in binaries[1:5]]}")
            print(f"  Use --binary <path> to pick a specific one")

    # Step 2: Generate PoCs
    print(f"\n  Step 2: Generating PoC candidates...")
    router = None
    if not args.no_llm:
        try:
            from crs.llm_router import LLMRouter
            router = LLMRouter(args.model, args.base_url, args.api_key)
            print(f"  LLM connected: {args.model} @ {args.base_url}")
        except Exception as e:
            print(f"  LLM init failed: {e}")
            print(f"  Continuing with patterns + seed mutation only")

    # Create a run_func for iterative refinement
    def _run_for_refine(poc, bin_path):
        if args.run_mode == "file":
            return run_poc_file(poc, bin_path, args.run_args)
        return run_poc_stdin(poc, bin_path)

    pocs = generate_all(
        task_id=task_id,
        description=description,
        repo_path=repo_dir,
        router=router,
        binary_name=binary.name,
        binary=binary,
        run_func=_run_for_refine,
    )

    if not pocs:
        print(f"  No PoC candidates generated!")
        sys.exit(1)

    # Step 3: Test
    print(f"\n  Step 3: Testing PoCs against {binary.name}...")
    results = run_all(binary, pocs, mode=args.run_mode,
                      args_template=args.run_args, stop_on_trigger=True)

    # Report
    elapsed = time.time() - t0
    triggered = [r for r in results if r.triggered]

    print(f"\n{'='*60}")
    if triggered:
        best = triggered[0]
        print(f"  \033[92mSUCCESS\033[0m — {best.crash_type}")
        print(f"  Strategy: {best.poc.name}")
        print(f"  PoC size: {len(best.poc.data)} bytes")
        print(f"  PoC path: {best.poc.path}")
        print(f"\n  Sanitizer output:")
        for line in best.sanitizer_output.split("\n"):
            if any(k in line for k in ["ERROR:", "SUMMARY:", "READ", "WRITE",
                                        "freed by", "allocated by", "#0 ", "#1 ", "#2 "]):
                print(f"    {line.strip()}")
    else:
        print(f"  \033[91mNO TRIGGER\033[0m — tested {len(results)} PoC(s)")
        print(f"  Tips:")
        print(f"    - Check that the binary was built with ASAN")
        print(f"    - Try --run-mode file --run-args '-w {{poc}}'")
        print(f"    - Try --run-mode stdin")
        print(f"    - Build manually and use --binary <path>")
        print(f"    - Check harness_commands.txt for the correct invocation")

    print(f"  Time: {elapsed:.1f}s")
    print(f"{'='*60}")

    # Save results
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    results_data = []
    for r in results:
        results_data.append({
            "poc_name": r.poc.name,
            "triggered": r.triggered,
            "crash_type": r.crash_type,
            "poc_size": len(r.poc.data),
            "poc_path": str(r.poc.path),
            "return_code": r.return_code,
        })
    (out / f"results_{task_id}.json").write_text(json.dumps(results_data, indent=2))
    print(f"\n  Results: {out / f'results_{task_id}.json'}")

    return 0 if triggered else 1


if __name__ == "__main__":
    sys.exit(main())
