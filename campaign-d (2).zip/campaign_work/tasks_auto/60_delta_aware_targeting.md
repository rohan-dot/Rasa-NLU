# Task 60 — delta mode: aim the budget at the changed code first

## Goal
CRSBench `atlanta-imaging-delta-01` runs discver in **delta** mode (`trial_metrics.csv`: run_mode=delta): the task supplies
a diff, the known vulnerabilities live in the changed code, and the summary shows recall 0.50 (3 of 6 known vulns) with
~3 h per trial and the first known vuln found only after ~32–37 min. Nothing in discver reads the diff today. Make the
delta the first-class input it is: when a diff (or base ref + head) is available, rank entry points, static scanning,
seeds/dictionary and the confirmation stage (task 59) toward the functions the diff touches — and say so in the log.
In full-scan mode (no diff) behaviour is unchanged.

## Study first
- `crsbench_*/orchestrator_logs/*.log` and `crsbench_*/support/*` (`benchmark-suite.yaml`, `framework.json`,
  `experiment.yaml`): how the delta is exposed to the CRS — a diff file path, `ref`/`head` commits, env vars, a
  `delta/` directory in the task — quote the lines. If the logs show no diff reaching discver, find how OSS-CRS passes
  it (`grep -rn "delta\|diff\|ref_commit\|base_commit" refs/*/ 2>/dev/null | head`) and state what is missing;
  if it genuinely cannot be obtained, implement the module against a `DISCVER_DELTA_DIFF` env/path and finish with that
  limitation stated — do NOT finish with NO_EDITS.
- repo: `rank_entry_points` (task 19/36), the static passes' target selection, the seed/dictionary generators,
  `confirm_findings` (task 59) if present; the call graph API (functions by file:line range).

## Change (src/delta.py + hooks)
- `load_delta(task_dir, env) -> Delta | None`: parse unified diff → changed files, hunks, and the functions whose line
  ranges intersect the hunks (via the call graph); plus the callers of those functions up to depth 2 (the reachable
  surface). Log `[delta] <n> files, <m> hunks, <k> changed functions, <c> reachable entry points`.
- Hooks: entry-point ranking gets a large prior for changed functions and their callers (`harness-gen: prior +<n> (delta)`);
  static passes scan changed files first and tag findings `in_delta=true`; seeds/dictionary include string and numeric
  literals added by the diff; the confirmation stage orders findings `in_delta` first; the probe/deep-phase budget split
  reserves `DISCVER_DELTA_BUDGET_PCT` (default 60) for harnesses/entry points that reach the delta while a delta exists.
- Report: a "Delta" block (changed functions, which were reached, which crashed) in REPORT.md and the final summary.
- Safety: wrapped; `[delta] failed: <error>` → full-scan behaviour.

## Tests to add (tests/test_delta.py) — fake diff + fake call graph
- hunks map to the right functions and callers; ranking prior applied only to them; static ordering and `in_delta` tag;
  literals extracted into the dictionary; no diff → no change in any hook's output; the report block.

## Acceptance
```
python -m pytest -q tests/test_delta.py
```

## Do not touch
The gate, health verdicts, crash dedup, sidecar; anything outside src/ and tests/.
