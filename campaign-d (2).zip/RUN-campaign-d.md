# Campaign D — benchmark recall (45–46), language-agnostic core (50–54, 57), workshop + strategy (55–56), triage + confirmation (58–59)

Everything below runs from /exp/FY26/AIxCC/ro31337. Nothing is downloaded by the agent at run time:
datasets are cloned by you into refs/ beforehand (step 1); scanner binaries are baked into the image by Ashok
from the manifest task 54 writes (src/tools/manifest.yaml + src/tools/Dockerfile.snippet).

## 1. Reference data (once; only the first clone is required, the others improve 46 and 55)
cd /exp/FY26/AIxCC/ro31337/campaign_work/refs
git clone --depth 1 https://github.com/google/oss-fuzz-vulns            # how ~10k real bugs were found (task 55)
git clone --depth 1 https://github.com/n132/ARVO-Meta                   # reproducible C/C++ OSS-Fuzz bugs (optional)
# CWE XML: https://cwe.mitre.org/data/xml/cwec_latest.xml.zip -> unzip into refs/cwe/   (manual if the box can't reach it)
# CRSBench: copy your coworker's benchmark repo or its ground-truth files into refs/crsbench/   (task 46 reads it)
cd /exp/FY26/AIxCC/ro31337

## 2. Install
unzip -o campaign-d.zip                       # tasks_auto/45,46,50..57 + tasks/00_map.md
rm -f campaign_work/tasks_auto/*-[0-9].md
ls campaign_work/tasks_auto/                  # one file per number

## 3. Results folder (optional but recommended): stage the newest run as results/latest the same way as before
#    (move the old latest to prev_<date>, unzip the run under latest/run, flat-copy LOG_DIR/auto/discver/*, cp -r its
#     crashes/ generated_harnesses/ patches/ unique_bugs/, write INVENTORY.txt and the three *_listing.txt files)

## 3b. CRSBench evidence (the coworker's results zip) — stage it next to results/latest; the map and tasks 45/46/58/59 read it
mkdir -p campaign_work/results/crsbench_20261029
unzip -q <the 20261029-193424-409094 zip> -d campaign_work/results/crsbench_20261029
cd campaign_work/results/crsbench_20261029
[ -d 20261029-193424-409094 ] && mv 20261029-193424-409094/* . && rmdir 20261029-193424-409094   # flatten if the zip has a top folder
mv "orchestrator logs" orchestrator_logs 2>/dev/null; rm -rf __MACOSX .DS_Store
find . -type f -printf '%s\t%P\n' | sort -k2 > INVENTORY.txt
grep -l "FINAL RESULTS" orchestrator_logs/* | wc -l            # runs that reached the end (vs timed out)
head -3 csv/*.csv                                             # the outcome columns the map will cross-reference
cd /exp/FY26/AIxCC/ro31337

## 4. Run: the agent reads the whole codebase first (map), then the ten tasks, all automated
export LITELLM_BASE_URL=https://llai-proxy.llan.ll.mit.edu/v1 LITELLM_API_KEY=<key> AGENT_MODEL=claude-opus-5-5 AGENT_REASONING_EFFORT=high AGENT_TLS_VERIFY=false
python3 campaign_work/campaign.py --work campaign_work --tasks campaign_work/tasks --only 00 --max-turns 200 > campaign_work/map_d.log 2>&1 && nohup python3 campaign_work/campaign.py --work campaign_work --tasks campaign_work/tasks_auto --only 45,46,50,51,52,53,54,55,56,57,58,59,60 --max-turns 120 > campaign_work/campaign_d.log 2>&1 &
tail -f campaign_work/map_d.log               # Ctrl-C leaves tail; the campaign keeps running (~15–20 h)

Order is numeric: 45 46 50 51 52 53 54 55 56 57 58 59 60. 60 = delta-aware targeting (CRSBench runs in delta mode). 58 = triage grounded in the KB + deterministic CWE table; 59 = directed fuzzing to confirm static/LLM findings as PoV-backed. Tasks 52–54 and 57 check for src/lang/ (51), and 56 for
src/workshop/ (55); if a prerequisite did not land they finish with NO_EDITS and say so — nothing half-applied.

## 5. After
tail -14 campaign_work/CAMPAIGN.md
cd campaign_work/discver && python -m pytest -q tests | tail -3             # failed must stay <= baseline
python3 src/workshop/build_kb.py --osv ../refs/oss-fuzz-vulns --out ../kb --dry-run-target <a project root>   # the real KB + the plan it would emit
python3 src/score_replay.py ../results/latest ../refs/crsbench/<ground truth>                                 # pick DISCVER_SUBMIT_MIN_CONFIDENCE
zip -r ../../discver-src-tests-FULL.zip src tests -x '*/__pycache__/*' '*.pyc' '*/.pytest_cache/*'
cd .. && zip -j ../discver-src-tests-FULL.zip CAMPAIGN.md DIAGNOSIS.md HANDOFF.md

## 6. Ashok (once each)
- Build the image with all language toolchains + the scanners from src/tools/manifest.yaml (Dockerfile.snippet is copy-paste) + kb/ at /opt/discver/kb
- Fix the runner sidecar /run-pov route (blocks patch validation in every language)
- Stand up one target per language in OSS-CRS (OSS-Fuzz / ARVO / CyberGym) and run
