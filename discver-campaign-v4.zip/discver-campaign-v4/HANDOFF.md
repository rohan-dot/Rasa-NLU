# HANDOFF — discver fix package (for the person running the container)

## What to do (three steps, nothing to configure)
1. Replace `src/` and `tests/` in the discver repo with the files in `discver-fix.zip` (every other file unchanged).
2. Build and run discver exactly as before.
3. Send back the whole results folder (orchestrator.log, health.json, patches/, report_run_*.md).

Optional, after the run: `python3 src/check_run.py <results folder or zip>` prints PASS / FAIL / NOT SEEN per change
with the log line that decided it — no log reading needed. (If `check_run.py` is not in the zip, that task did not land;
use the grep below instead.)

## What the log should show in the first five minutes
`CAMPAIGN.md` in the zip lists which changes landed (PASS) — only those will show. For each:

| change | expect this line | if it did not take effect |
|---|---|---|
| no-op guard (task 10) | `fuzz thresholds: … AND no observed crashes` at startup; for X509Fuzzer `coverage flat at <cov> but <n> crash(es) — saturated, not no-op; left to deep phase` | a `… no-op or uninstrumented; stopped` line for X509Fuzzer after a `NEW CRASH` — the same DEAD outcome as last run |
| keep-going (task 11) | `harness X509Fuzzer: probe <n> execs, <k> crash(es), cov <c> — SATURATED → deep phase (keep_going=1000, form=arg|env)` then `[lead] …` / `[replay] …` lines | the probe line says `not saturated` for a ~300-exec harness, or no probe line at all |
| seeds (task 12) | `harness X509Fuzzer: seeds mined=<a> format=<b> llm=<c> dropped=<d> → <dir>` with a non-zero total | a WARNING with "0 seeds", or no seeds line |
| dictionary (task 13) | `harness X509Fuzzer: dict <n> entries → <path>` and one `deep-phase cmd: …` containing `-dict=` | `[dict] failed:` or no dict line |
| exec rate (task 14) | health block rates are not `0.0/s` next to millions of executions | `@ 0.0/s` still printed |
| health block (task 15) | `[WEAK] X509Fuzzer … saturated by X509Utils.getCnFromDn; continuing past it — coverage 2043→<b>` (HEALTHY only if b grew) | the old single-phase block |
| harness gate (tasks 16–17) | `harness GenFuzzer0: … does not reach target → regenerating (1/1)` or `… → dropped`; `harness <name>: covers <n> target methods (…)` | GenFuzzer0 runs its full budget at cov 10→10 again |
| fix loop (tasks 20–24) | `[patch-turn] finding=<id> turn=<k> tool=<name>` lines; patch_index.json entries with `parse_failures`, `read_only_turns`, `tool_histogram`; `[sidecar] … exit=<rc> class=<…>` | entries with attempts=15, test_calls=0 and no counters |

One grep that shows the fuzzing side at a glance:
```
grep -nE 'fuzz thresholds|probe .* execs|SATURATED →|not saturated|no-op or uninstrumented|saturated, not no-op|seeds mined=|dict [0-9]+ entries|\[lead\]|\[replay\]|does not reach target|covers [0-9]+ target|NEW CRASH.*getCnFromDn|stopped' orchestrator.log | head -60
```
And for the fix loop:
```
grep -nE '\[patch-turn\]|\[sidecar\]|UNVALIDATED|validated' orchestrator.log | head -40 ; python3 -c "import json;[print(k,v.get('status'),v.get('attempts'),v.get('test_calls'),v.get('parse_failures'),v.get('reason','')[:120]) for k,v in json.load(open('patches/patch_index.json')).items()]"
```
