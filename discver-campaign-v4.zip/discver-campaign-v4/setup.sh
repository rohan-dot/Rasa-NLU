#!/usr/bin/env bash
# setup.sh — build the work folder for the discver campaign.
#   bash setup.sh <WORK> <path-to-discver-repo> <results-folder> [existing-refs-dir]
# <WORK> is a NEW folder. Your repo is COPIED into <WORK>/discver (the original is never touched).
# <results-folder> must contain two subfolders: latest/ (the DEAD run) and prev/ (the WEAK run before it),
#   each holding orchestrator.log, health.json, patches/, report_run_*.md.
# References are cloned into <WORK>/refs (or symlinked from existing-refs-dir if it has atlantis/ buttercup/ there).
set -euo pipefail
WORK=${1:?work dir}; REPO=${2:?discver repo dir (contains src/)}; RESULTS=${3:?results folder with latest/ and prev/}; EXISTING=${4:-}
KIT=$(cd "$(dirname "$0")" && pwd)
[ -d "$REPO/src" ] || { echo "ERROR: $REPO has no src/ — pass the directory that CONTAINS src/"; exit 1; }
[ -d "$RESULTS" ] || { echo "ERROR: results dir $RESULTS not found"; exit 1; }
[ -f "$RESULTS/latest/orchestrator.log" ] || echo "WARN: $RESULTS/latest/orchestrator.log not found — the tasks expect results/latest/ and results/prev/"
[ -f "$RESULTS/prev/orchestrator.log" ]   || echo "WARN: $RESULTS/prev/orchestrator.log not found — the fix-loop tasks read prev/patches/patch_index.json"
mkdir -p "$WORK/refs" "$WORK/runs"
cp -n "$KIT"/microagent.py "$KIT"/campaign.py "$KIT"/EVIDENCE.md "$KIT"/HANDOFF.md "$WORK"/ 2>/dev/null || true
[ -d "$WORK/tasks" ] || cp -r "$KIT/tasks" "$WORK/tasks"
if [ ! -d "$WORK/discver" ]; then
  rsync -a --exclude '.git' --exclude '__pycache__' --exclude '.pytest_cache' --exclude 'output' --exclude 'oss-crs' --exclude '.microagent*' --exclude '.crew' "$REPO/" "$WORK/discver/" 2>/dev/null \
    || cp -r "$REPO" "$WORK/discver"
  echo "copied repo -> $WORK/discver"
fi
[ -d "$WORK/results" ] || { cp -r "$RESULTS" "$WORK/results"; echo "copied results -> $WORK/results"; }
link_or_clone() {  # name url [sparse-dir]
  local name=$1 url=$2 sparse=${3:-}
  if [ -d "$WORK/refs/$name" ]; then echo "ref $name: present"; return; fi
  if [ -n "$EXISTING" ] && [ -d "$EXISTING/$name" ]; then ln -s "$(cd "$EXISTING/$name" && pwd)" "$WORK/refs/$name"; echo "ref $name: linked from $EXISTING/$name"; return; fi
  echo "ref $name: cloning $url"
  if [ -n "$sparse" ]; then
    git clone --depth 1 --filter=blob:none --sparse "$url" "$WORK/refs/$name" && (cd "$WORK/refs/$name" && git sparse-checkout set $sparse) || echo "WARN: clone of $name failed — continue without it"
  else
    git clone --depth 1 "$url" "$WORK/refs/$name" || echo "WARN: clone of $name failed — continue without it"
  fi
}
link_or_clone buttercup      https://github.com/trailofbits/afc-buttercup
link_or_clone fuzzing-brain  https://github.com/o2lab/afc-crs-all-you-need-is-a-fuzzing-brain
link_or_clone jazzer         https://github.com/CodeIntelligenceTesting/jazzer "docs README.md"
link_or_clone atlantis       https://github.com/Team-Atlanta/aixcc-afc-atlantis "example-crs-webservice"
echo
echo "layout:"; ls "$WORK"; echo "refs:"; ls "$WORK/refs"
echo
echo "next:"
echo "  export LITELLM_BASE_URL=... LITELLM_API_KEY=... AGENT_MODEL=claude-opus-5-5 AGENT_TLS_VERIFY=false   # model id as your gateway lists it"
echo "  python3 $WORK/microagent.py --verify"
echo "  cd $WORK/discver && python -m pytest -q tests | tail -3      # know your baseline"
echo "  nohup python3 $WORK/campaign.py --work $WORK > $WORK/campaign.log 2>&1 &  ;  tail -f $WORK/campaign.log"
