# Task 30 — a method sweep without harnesses, as UNVERIFIED leads only (C6) — conditional

## Condition
Only if MAP.md shows that BOTH the Jazzer launch command AND the built target's classpath are available inside src/.
If either is not, finish() with the file:line evidence and make NO edits (that is a correct outcome for this task).

## Goal
Jazzer Autofuzz can drive a public method directly without a harness. Sweep the public methods of the target package's
classes for a short slice each and report what throws, as leads — never as reproducers for the provided harness, because
only inputs that crash through the provided harness count as reproducers. Budget: at most 5% of the total fuzzing budget,
after the provided harness has had its probe.

## Study first
- jazzer (docs root): `grep -rnE "autofuzz|autofuzz_ignore" docs/ *.md` → flag spelling (`--autofuzz=<Class>::<method>`),
  how reproducers and exceptions are reported, `--autofuzz_ignore`.
- repo: MAP.md "fuzzer launch" and "harness generation" (classpath, target package name).
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- `src/method_sweep.py` (new): list public methods of the target package's classes (from the built jar via `javap -p`,
  else from the sources by a conservative regex); for each, run Autofuzz for a short fixed slice with `--autofuzz_ignore`
  limited to exceptions that method itself declares; parse `== Java Exception` + `DEDUP_TOKEN`; dedupe; emit leads through
  task 11's lead path (UNVERIFIED). Log `sweep: <n> methods, <m> leads` and one `[lead] sweep <Class::method> <token> <exception> UNVERIFIED` per lead.
- Any failure logs `[sweep] failed: <error>` and the run continues as today.

## Tests to add (tests/test_method_sweep.py) — fakes only
- a fake `javap -p` output yields the public method list (constructors, private and synthetic members excluded).
- a fake Autofuzz log with two tokens → two UNVERIFIED leads; the same token twice → one; the sweep summary line is correct.
- the sweep's budget never exceeds 5% of the total (fake budget 10,000 s → sweep ≤ 500 s).

## Acceptance
```
python -m pytest -q tests/test_method_sweep.py
```

## Do not touch
The provided harness's launch; sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
