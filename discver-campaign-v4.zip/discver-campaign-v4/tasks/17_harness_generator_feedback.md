# Task 17 — tell the harness generator what went wrong, reject harnesses that hide crashes, budget by reach (C4 + C5)

## Goal
A regenerated harness (task 16) must be better than the one it replaces, not a re-roll. When regenerating, the generator
prompt includes: the signature of the target entry point, how the provided harness calls into the code (its relevant
lines), what the rejected harness did reach (its coverage report or probe summary), and the rejection reason. A static
check rejects any generated harness that wraps the target call in a broad `catch (Throwable | Exception)` — that hides
exactly the crashes being hunted — allowing only the checked exceptions the called API declares. Compile failures are
counted per harness. After the probes, each generated harness's remaining budget is proportional to its distinct
target-method count (zero → dropped by task 16); the provided harness always keeps its full budget.

## Study first
- buttercup: `grep -rnE "harness|generate|catch|Throwable" seed-gen/ program-model/ --include=*.py | head -40`;
  fuzzing-brain: `grep -rnE "harness|generate_harness|catch" --include=*.py | head -40` → how generated harnesses are
  prompted and validated; file:line.
- repo: MAP.md "harness generation" (the generator prompt builder, the compile step) and "harness selection" (budget split).
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- Generator prompt builder: accept an optional `feedback` block (entry-point signature, provided-harness call lines,
  previous reach summary, rejection reason) and include it verbatim under a "Previous attempt" heading.
- Static check `harness_static_check(source) -> (ok, reason)`: reject `catch (Throwable` / `catch (Exception` /
  `catch (RuntimeException` around the target call; allow declared checked exceptions; log
  `harness <name>: rejected by static check — <reason> (line <n>)`. Count compile failures: `harness <name>: compile failed (<k>/<max>)`.
- Budget: after probes, `budget_share(harness) ∝ distinct target methods covered` for generated harnesses; the provided
  harness keeps its full budget; the health block prints the allocation (task 15 renderer).
- Any failure in the feedback or budget code logs `[harness_feedback] failed: <error>` and the run continues as today.

## Tests to add (tests/test_harness_feedback.py) — fakes only
- the regenerated prompt contains the four feedback items verbatim.
- a harness source with `catch (Throwable t) {}` around the target call → rejected with the line number; one with
  `catch (CertificateException e)` where the API declares it → accepted.
- compile failure counter increments and is logged; a third failure drops the harness.
- budget: harnesses covering 0 / 3 / 9 target methods get shares 0 / 25% / 75% of the generated-harness budget; the
  provided harness's budget is unchanged.

## Acceptance
```
python -m pytest -q tests/test_harness_feedback.py
```

## Do not touch
The primary harness; sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
