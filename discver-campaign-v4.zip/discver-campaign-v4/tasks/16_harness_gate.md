# Task 16 — gate generated harnesses on whether they reach the target (H3 + C3 + H1)

## Goal
GenFuzzer0 ran 27.6M executions with coverage 10→10: it never executed the target code, yet it consumed a full budget.
Before a generated harness gets its full budget, probe it (the same short probe as task 11). Decide "reaches the target"
from a Jazzer coverage report when one can be produced, else from flat coverage. A harness that does not reach the target
is discarded with a logged reason and regenerated once (task 17 improves what the generator is told); if the second one
is also flat it is dropped and its budget released (task 10's release path). The provided harness (X509Fuzzer) is never
gated, edited, or regenerated — only how it is driven changes.

## Study first
- jazzer (docs root): `grep -rnE "coverage_report|coverage_dump|instrumentation_includes" docs/ *.md` → the report flag and what the report lists (classes / methods covered) and when it is written (at exit).
- atlantis: `grep -rnE "reach|reachab|coverage_report|jacoco" --include=*.py` under the Java CRS; fuzzing-brain: same → how they decide a harness reaches a target; file:line.
- repo: MAP.md "harness generation" (where generated harnesses are compiled and launched; is the launch command built in src/?) and "harness selection" (budget split).
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- `src/harness_reach.py` (new): for a generated harness's probe, add `--coverage_report=<workdir>/cov/<harness>.txt` to
  ITS launch (Jazzer writes it at exit, which `-max_total_time` guarantees); parse it; reaches_target = at least one method
  of the target package appears as covered. If the report is missing or its format is not what the parser expects, log its
  first 5 lines and fall back to: reaches_target = coverage moved from the first stats line during the probe.
  Log `harness <name>: covers <n> target methods (<top 3 by name>)` or `harness <name>: probe cov <c> flat over <execs> execs — does not reach target → regenerating (1/1)` / `… → dropped`.
- Gate: a generated harness that does not reach the target after its probe is terminated (existing stop path), regenerated
  once, probed again; a second failure drops it and releases the budget. Only generated harnesses are gated; the primary
  (provided) harness skips the gate entirely.
- Any failure inside harness_reach logs `[harness_reach] failed: <error>` and the run continues exactly as today (no gate).

## Tests to add (tests/test_harness_gate.py) — fakes only
- a fake coverage report listing `mil.disa.common.util.agentmanager.X509Utils.getCnFromDn` as covered → reaches_target True, log names the method.
- a fake report with no target-package method → reaches_target False → the harness is stopped and regenerated once; a second flat probe → dropped, budget released, both log lines present.
- missing report + flat probe coverage → fallback path used, first-5-lines log absent (no file), "does not reach target" logged.
- the provided harness (name from MAP.md "harness selection", e.g. X509Fuzzer) is never gated even with a flat probe.
- an exception inside harness_reach → `[harness_reach] failed:` logged, harness keeps running as today.

## Acceptance
```
python -m pytest -q tests/test_harness_gate.py
```

## Do not touch
The primary harness's launch command; sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
If the generated-harness launch command is built outside src/, say so in finish() with file:line, implement the parser
and the gate decision as pure functions with tests, and leave the launch untouched.
