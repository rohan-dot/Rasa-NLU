# Task 31 — fuzz the provided harness again on the patched build (C7) — conditional

## Condition
Only if MAP.md shows that the sidecar's `apply-patch-build` leaves a runnable patched build (a fuzzer output directory)
that src/ can locate after a validated patch. If it does not, finish() with the file:line evidence and make NO edits.

## Goal
Once the fix loop validates a patch for the provided harness's crash, the crash that saturated the harness is gone, and
the honest way to find what is behind it is to run the same harness against the patched build for the remaining budget
(same seeds, dictionary and corpus). Report it as a separate health block titled `<harness> (patched build)`. A crash found
there is a new finding that names the patch it was found on. The unpatched verdict is never replaced by the patched one.

## Study first
- repo: MAP.md "sidecar/oracle" (read-only: where the patched build's output lands) and "fuzzer launch".
- atlantis / buttercup: `grep -rnE "patched|re-?fuzz|after_patch" --include=*.py | head -20` → whether and how they re-fuzz after a patch; file:line.
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- `src/post_patch_refuzz.py` (new): given a validated patch record and the patched build's output dir, launch the provided
  harness (the same launch builder as task 11, pointing at the patched binaries) for the remaining budget; collect stats and
  crashes through the existing paths; render a second health block `<harness> (patched build)`; tag findings with the
  patch id. Log `[refuzz] <harness> on patch <id>: <execs> execs, cov <a>→<b>, <crashes> crash(es)`.
- Any failure logs `[refuzz] failed: <error>` and the run continues as today.

## Tests to add (tests/test_post_patch_refuzz.py) — fakes only
- with a fake validated patch and a fake patched build dir, the launch uses the patched dir and the same seed/dict/corpus paths.
- the report contains both blocks; the unpatched verdict text is unchanged by the refuzz result.
- a crash found on the patched build appears as a finding tagged with the patch id.

## Acceptance
```
python -m pytest -q tests/test_post_patch_refuzz.py
```

## Do not touch
The sidecar invocation (apply-patch-build / run-pov / run-test) and crash_dedup._get_crash_signature; anything outside src/ and tests/.
