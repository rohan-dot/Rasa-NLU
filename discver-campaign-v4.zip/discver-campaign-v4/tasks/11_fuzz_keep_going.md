# Task 11 — probe, then a deep phase that keeps fuzzing past the known crash (F1 + H2) — the change that decides the next run

## Goal
The primary harness is SATURATED: nearly every input hits the same throw and the process restarts (~300 execs per run,
coverage never moves). Two-phase launch: a short PROBE exactly as today; if the probe shows saturation, relaunch for the
rest of the budget with Jazzer keep-going so the known finding is deduplicated by stack-trace hash and fuzzing CONTINUES;
record new distinct findings as UNVERIFIED leads; at the end replay the deep-phase corpus through the NORMAL harness,
one input per run, so any crashing input becomes an ordinary crash artifact in the unchanged dedup / reproducer pipeline.
The startup line already prints `probe=120s … keep_going=1000`, so part of this may exist: FIRST establish from MAP.md
whether the deep phase is reachable from the normal run path, then fix or complete that code — never add a second copy.

## Study first
- jazzer (docs root): `grep -rnE "keep_going|DEDUP_TOKEN|ignore_crashes|JAZZER_" docs/ *.md` → exact flag spelling, the
  environment-variable form (JAZZER_KEEP_GOING), what is printed per finding.
- buttercup: `grep -rnE "keep_going|ignore_crashes|-fork|DEDUP_TOKEN|dedup" fuzzer/`; fuzzing-brain: same pattern;
  atlantis: same pattern under the Java CRS. Read each hit's function; note file:line and how they re-launch.
- repo: MAP.md "fuzzer launch", "probe / deep phase", "stats parsing", "health checker", and the crash-artifact / replay path.
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- Probe: run each harness as today for PROBE_SECONDS (constant, 120). Saturation = (execs < 5000 and crashes >= 1) or
  crashes/execs >= 0.5. Log: `harness <name>: probe <execs> execs, <crashes> crash(es), cov <c> — SATURATED → deep phase (keep_going=1000, form=<arg|env>)`
  or `… — not saturated, continuing normally`.
- Deep phase: relaunch with `--keep_going=1000` placed BEFORE the corpus dirs (Jazzer options are `--`, libFuzzer options
  are `-`), same corpus and seed dirs, remaining budget. If the driver script does not forward options, set
  `JAZZER_KEEP_GOING=1000` in the child process environment (that is the orchestrator's choice, not an operator switch)
  and log `form=env`. libFuzzer fork-mode alternative if the launch must stay in fork mode: `-fork=N -ignore_crashes=1`.
- Leads: parse `== Java Exception:` blocks and `DEDUP_TOKEN: <hex>` from the deep-phase output into distinct leads
  (repeats collapse). Log each once: `[lead] <harness> <token> <exception class> UNVERIFIED`. A lead with a trace but no
  reproducing input after replay stays UNVERIFIED in the report — never counted as a confirmed crash.
- Replay: for each input in the deep-phase corpus, run the normal harness on that single input; non-zero exit → hand the
  input to the EXISTING crash handler (the same path a normal crash artifact takes). Never batch inputs — a batched replay
  stops at the first, known, crash. Log `[replay] <harness> <n> inputs → <m> crash(es) handed to the crash handler`.
- Health: verdict text `saturated by <sink>; continuing past it — coverage <a>→<b>`; HEALTHY only if deep-phase coverage
  grew; the block shows both phases (task 15 finishes the rendering; here make the data available).

## Tests to add (tests/test_keep_going.py) — fake runner, no Jazzer
- probe stats 299 execs / 1 crash → deep phase launched; argv contains `--keep_going=1000` before the corpus dir and the
  same corpus/seed dirs (or env has JAZZER_KEEP_GOING=1000 when the fake driver drops options); the SATURATED log line
  names the form used.
- healthy probe (2M execs, 0 crashes) → no deep phase; one launch only; the "not saturated" line is present.
- a deep-phase log with two different DEDUP_TOKENs yields two UNVERIFIED leads; the same token twice yields one.
- replay: corpus {ok, empty}; fake harness crashes on `empty` → the existing crash handler is called exactly once with that
  input; the [replay] line reports 2 inputs → 1 crash.
- the deep phase is reachable from the normal run path: a fake end-to-end run of the primary harness (probe saturated)
  reaches the deep launch without any flag or environment variable set by the test.

## Acceptance
```
python -m pytest -q tests/test_keep_going.py
```

## Do not touch
crash_dedup._get_crash_signature and the sidecar; the normal (probe) launch command stays what it is today — only the
deep-phase relaunch adds options; anything outside src/ and tests/.
