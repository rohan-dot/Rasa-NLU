# Task 40 — check_run.py: grade the next real run from its results folder, no log reading by hand

## Goal
Write `src/check_run.py` (stdlib only, no imports from discver, runnable from anywhere):
`python3 src/check_run.py <results dir or zip>` prints one line per change — `PASS` / `FAIL` / `NOT SEEN` — with the log
line that decided it, then a summary: the primary harness's probe and deep-phase execs, coverage before→after, verdict;
leads and replay crashes; and the fix loop's outcome per finding from `patches/patch_index.json` (status, attempts,
test_calls, parse_failures, reason). This is how the next run is graded by someone with five minutes.

## Study first
- repo: the exact log lines emitted by tasks 10–17 (grep src/ for `fuzz thresholds|SATURATED →|not saturated|no-op or uninstrumented|saturated, not no-op|seeds mined=|dict <|covers <|does not reach target|\[lead\]|\[replay\]|\[patch-turn\]|\[sidecar\]`) — use the real format strings, not guesses.
- results: `prev/orchestrator.log` and `prev/patches/patch_index.json` for the file layout.

## Change (src/)
- Checks (each: success pattern, failure pattern, where to look):
  thresholds line present and ends with `AND no observed crashes`; primary harness probe decision line present;
  no-op rule never stopped a harness that had a crash (FAIL if a stop line and a NEW CRASH exist for the same harness);
  deep phase launched when the probe was saturated; seeds line with non-zero total; dictionary line; leads/replay lines;
  coverage grew in the deep phase; generated-harness gate lines; `[patch-turn]` lines present; every patch_index entry has
  the accounting fields; no entry with attempts ≥ 15 and test_calls = 0.
- Accept a directory or a zip (zipfile); locate `orchestrator.log`, `health.json`, `patches/patch_index.json` anywhere
  under it; print `NOT SEEN` with "file missing" when a file is absent. Exit code 0 always (it is a report, not a gate).

## Tests to add (tests/test_check_run.py)
- a fake results dir built from the expected log lines → every check PASS; the summary has the right numbers.
- a fake dir reproducing the DEAD run (stop line after NEW CRASH, no deep phase, no patch-turn lines) → those checks FAIL with the deciding lines quoted.
- a zip of the fake dir gives the same output as the dir; a dir with no patch_index.json prints NOT SEEN for the patch checks.

## Acceptance
```
python -m pytest -q tests/test_check_run.py
```

## Do not touch
Everything else in src/; anything outside src/ and tests/.
