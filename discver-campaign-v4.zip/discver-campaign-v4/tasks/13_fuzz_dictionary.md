# Task 13 — a dictionary of the strings the target compares against (C2)

## Goal
For a parser-style target (DN strings: `CN=`, `,`, `=`, `OU=`, escapes), a libFuzzer dictionary is the cheapest coverage
win there is: the fuzzer stops guessing separators byte by byte. Build one per harness from the string literals and
constant values in the target package reachable from the harness, and pass it on the deep-phase relaunch and on
generated-harness launches only — never on the normal probe launch, which stays what it is today.

## Study first
- jazzer (docs root): `grep -rnE "\-dict|use_value_profile|dictionary" docs/ *.md` → flag spelling and the dictionary file format (`"CN="` one entry per line, C-style escapes).
- buttercup: `grep -rnE "dict|dictionary" fuzzer/ seed-gen/`; fuzzing-brain: same → how they build dictionaries; file:line.
- repo: MAP.md "fuzzer launch" (where the deep-phase argv is built — task 11) and "seeds" (the mined-literal helper from task 12 — reuse it).
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- `src/fuzz_dict.py` (new, stdlib): collect string literals (length ≥ 2) and `static final String` values from the Java
  files reachable from the harness (reuse task 12's mining); write `<workdir>/dict/<harness>.dict` in libFuzzer format
  (quoted, escaped); dedupe; cap at a few hundred entries, longest-common first.
- Launch: add `-dict=<path>` and `-use_value_profile=1` to the deep-phase argv and to generated-harness launches only.
  Log `harness <name>: dict <n> entries → <path>` and, once per harness, `deep-phase cmd: <argv>`.
- Any failure inside the dictionary module logs `[dict] failed: <error>` and the launch proceeds without a dictionary.

## Tests to add (tests/test_fuzz_dict.py) — fakes only
- a fake Java file with `"CN="`, `","`, `"="` and a `static final String SEP = ";"` yields a dictionary file with exactly
  those entries, quoted and escaped, no duplicates, no 1-byte-literal noise except the separators listed.
- the deep-phase argv (fake runner from task 11) contains `-dict=<path>` and `-use_value_profile=1`; the probe argv does not.
- an unreadable source tree → `[dict] failed:` logged, launch argv unchanged.

## Acceptance
```
python -m pytest -q tests/test_fuzz_dict.py
```

## Do not touch
The normal (probe) launch command; sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
