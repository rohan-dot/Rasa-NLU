# Task 18 — harness discovery is generic: no target names in src/, provided harnesses found from the build output

## Goal
discver must work unchanged on the next codebase. A project ships its own harnesses (here `X509Fuzzer`; elsewhere other
names); discver must discover them from the fuzzer build output or the project's build configuration — never by a
hardcoded name — and classify them: provided (from the project) vs generated (by discver). The provided ones are
primary. Audit `src/` for target-specific strings and move any that exist into tests as fixtures.

## Study first
- repo: MAP.md "harness selection" and "fuzzer launch"; then `grep -rnE "X509|getCnFromDn|CN=|agentmanager|disa" src/`
  — every hit is either a bug (hardcoded target knowledge) or a comment; list them with file:line in finish().
- repo: how harnesses are enumerated today: `grep -rnE "listdir|glob|iterdir|/out|fuzzer_dir|harness(es)?\b" src/`.
- buttercup: `grep -rnE "harness|fuzz_target|targets" orchestrator/ fuzzer/ --include=*.py | head -30`;
  atlantis: `grep -rnE "harness" --include=*.py | head -30` → how they enumerate a project's harnesses; file:line.
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- `discover_harnesses(out_dir) -> list[Harness(name, kind, path)]`: a provided harness is an executable wrapper in the
  fuzzer output directory that is not a known helper (`llvm-symbolizer`, `jazzer_driver`, `jazzer_agent_deploy.jar`,
  `*.jar`, `*.class`, `*.dict`, `*_seed_corpus.zip`, `*.options`); generated harnesses are the ones discver compiled itself
  (tracked where they are created). Log at startup: `harnesses: provided=[<names>] generated=[<names>]`; zero provided
  harnesses is an ERROR line naming the directory scanned.
- Primary = all provided harnesses (each gets the probe → deep-phase treatment from task 11); generated harnesses get the
  gate from task 16.
- Remove every hardcoded target string from src/ found in the audit; where the code needs an example (seed prompts,
  dictionary seeds), derive it from the harness source and the target package found at runtime.

## Tests to add (tests/test_harness_discovery.py)
- a fake output dir with `X509Fuzzer`, `OtherFuzzer`, `jazzer_driver`, `X509Fuzzer_seed_corpus.zip`, `x.jar` → provided =
  [X509Fuzzer, OtherFuzzer] only; the startup line lists them.
- an empty dir → ERROR line names the directory; the run does not pretend to have a harness.
- `grep -rnE "X509|getCnFromDn|CN=|agentmanager" src/` returns no code hits (comments allowed) — assert from the test by
  scanning src/ files, excluding comment lines.

## Acceptance
```
python -m pytest -q tests/test_harness_discovery.py
```

## Do not touch
Sidecar; crash_dedup._get_crash_signature; the normal launch command; anything outside src/ and tests/.
