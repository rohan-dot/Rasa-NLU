# Task 15 — truthful two-phase health block and one startup thresholds line (F5)

## Goal
The health block must show, per harness: probe execs / crashes / cov; deep-phase execs and coverage growth (when task 11
ran a deep phase); UNVERIFIED leads; replay crashes; which harnesses received a released budget (task 10); and a verdict
that names the sink being fuzzed past. HEALTHY only when coverage actually grew in the deep phase. Harnesses that never
entered a deep phase render exactly as today. All thresholds logged once at startup. Verdicts never more lenient than today.

## Study first
- repo: MAP.md "health checker"; `grep -nE "WARNING: \[|Overall:|SATURATED|peak coverage|liveness" src/` and read the renderer.
- results: `grep -nA3 "run health" prev/orchestrator.log` to see today's exact format — keep it recognisable (same `[VERDICT] name` header).

## Change (src/)
- Extend the renderer with the two-phase fields when present; keep today's single-phase output otherwise.
- Verdict for a saturated harness fuzzing past its crash: `WEAK — saturated by <sink>; continuing past it — coverage <a>→<b>`
  while coverage is flat; `HEALTHY — saturated by <sink>; fuzzing past it — coverage <a>→<b>` only when b > a in the deep phase.
- One startup INFO line:
  `fuzz thresholds: probe=<s>s saturated_if_execs<<n>&crash>=1 or crash_rate>=<r>; keep_going=<N>; noop_if_flat_for>=<s>s or >=<execs> AND no observed crashes`.

## Tests to add (tests/test_health_block.py)
- single-phase harness renders exactly today's shape (snapshot against a string built from the current code's output for a fake harness).
- two-phase harness renders probe + deep lines, leads, replay count and the sink in the verdict; flat deep coverage → WEAK; grown → HEALTHY.
- a harness that received released budget is named in the block.
- the startup thresholds line is present exactly once and ends with `AND no observed crashes`.

## Acceptance
```
python -m pytest -q tests/test_health_block.py
```

## Do not touch
Oracle/sidecar; anything outside src/ and tests/.
