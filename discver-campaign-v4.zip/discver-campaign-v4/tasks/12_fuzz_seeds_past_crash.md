# Task 12 — seeds that get PAST the known shallow crash, in the layout the harness actually reads (F2 + C1)

## Goal
`src/pb_seeds.py` produced 181 LLM seeds in the previous run, yet the primary harness's corpus went 0→4 and every input
died at the front door (getCnFromDn on empty / CN-less input). First AUDIT — establish from the code and the logs which of
these happened, with file:line and log lines in finish(): (a) seeds written to a directory the runner never reads;
(b) seeds consumed but all dying at the known crash; (c) seeds in the wrong byte layout for how the harness consumes its
input; (d) nothing learnable because the harness was saturated. Then fix pb_seeds.py, or replace it with a seed module
(`src/seed_factory.py` is allowed) that produces seeds three ways, each counted in the log, excludes seeds that reproduce
the known crash, and writes into the directory the runner reads before launch.

## Study first
- buttercup: `grep -rnE "def .*seed|corpus|write_bytes|open\(" seed-gen/` → how seeds are produced per harness and written; file:line.
- fuzzing-brain: `grep -rnE "seed|corpus" --include=*.py -l` then grep inside the top hits for the function that writes seeds for a harness.
- repo: MAP.md "seeds" + "harness selection"; read the seed writer and the runner's corpus-dir argument; confirm they agree.
  Read how the primary harness consumes input (MAP.md "seeds": FuzzedDataProvider calls, or raw bytes / consumeRemainingAsString).
- results: `grep -nE "seed|corpus" prev/orchestrator.log | head -40`.
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- Three sources, each counted: (1) mined — string literals (length ≥ 2, deduped) and test resources from the target repo in
  files reachable from the harness; (2) format-aware — read the harness source, list its `FuzzedDataProvider` `consume*`
  calls in order and encode each seed so every consumed field lands where the harness reads it; when the harness uses only
  `consumeRemainingAsString` / `consumeRemainingAsBytes` or raw bytes, seeds are plain strings; (3) LLM — keep the existing
  generation, but the primary harness's prompt must yield well-formed inputs that do not trigger the known crash (for this
  target, DN strings with a `CN=` component and other well-formed variants).
- Exclusion: before writing, drop seeds that are empty or byte-equal to the known reproducer, and run each remaining seed
  through the known-crash check already in the repo (the PoV replay / crash reproduction helper — reuse it, do not duplicate)
  when that helper is available offline; excluded seeds get the reason `reproduces the known shallow crash`.
- Wiring: write into the exact corpus dir the runner reads (from MAP.md), before launch; cap and dedupe.
  Log `harness <name>: seeds mined=<a> format=<b> llm=<c> dropped=<d> → <dir>`; when the total is 0 log a WARNING with the
  specific reason (no seeds generated / all excluded / dir mismatch). Any failure inside the seed module logs
  `[seeds] failed: <error>` and the run continues exactly as it would today.

## Tests to add (tests/test_seeds_past_crash.py) — fakes only
- with a fake known-crash check (empty input → crash), seeds [b"", b"CN=agent1,O=DISA", b"O=x"] wire only the
  non-reproducing ones and log the exclusion reason and counts.
- format-aware: a fake harness source with `consumeInt()` then `consumeRemainingAsString()` yields seeds whose leading
  bytes decode as the int and whose tail is the string; a harness with only `consumeRemainingAsString()` yields plain strings.
- mined: a fake repo tree with a Java file containing literals "CN=" and "," yields those as seeds (deduped, length ≥ 2).
- all seeds excluded → the WARNING names the reason; no silent zero.
- the seeds are written into the same directory the runner is launched with (assert path equality in a fake run).
- an exception inside the seed module → `[seeds] failed:` is logged and the launch still happens.

## Acceptance
```
python -m pytest -q tests/test_seeds_past_crash.py
```

## Do not touch
crash_dedup._get_crash_signature (call it, do not change it); sidecar; the launch command; anything outside src/ and tests/.
