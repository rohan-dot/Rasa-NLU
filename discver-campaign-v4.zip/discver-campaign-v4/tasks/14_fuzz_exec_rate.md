# Task 14 — fix the executions-per-second calculation (F4)

## Goal
Every harness prints `@ 0.0/s` next to millions of executions. Make the rate = executions ÷ elapsed seconds, make `0.0`
appear only when no time has elapsed (and log why), and make sure the rate does not feed the DEAD/WEAK verdict wrongly.

## Study first
- repo: MAP.md "stats parsing"; `grep -nE "exec/s|execs|elapsed|rate" src/` and read the function.
- results: `grep -nE "@ [0-9.]+/s" prev/orchestrator.log | head` to see the printed lines and what feeds them.

## Change (src/)
- Compute the rate from the stats line's own field when present (libFuzzer prints `exec/s: N`), else execs ÷ (now − start);
  never divide by zero; when elapsed is unknown log one WARNING naming the cause.
- If the verdict logic reads the rate, prove with a test that a correct rate does not flip a HEALTHY harness to WEAK or vice versa.

## Tests to add (tests/test_exec_rate.py)
- rate(27_603_427 execs, 3600 s) ≈ 7667.6/s; elapsed 0 → 0.0 and a warning is logged (caplog).
- parsing `#1000000  NEW cov: 3400 ft: 5000 corp: 800/40Kb exec/s: 8000 rss: 300Mb` yields exec/s 8000.
- the health block renders the computed rate (not 0.0) for a fake harness with 1_000_000 execs over 100 s.

## Acceptance
```
python -m pytest -q tests/test_exec_rate.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar/oracle code; anything outside src/ and tests/.
