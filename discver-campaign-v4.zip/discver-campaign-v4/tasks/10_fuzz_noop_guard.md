# Task 10 — the no-op harness rule must never stop a crashing harness (F3) — the regression fix; do it first

## Goal
The latest run went DEAD because a "no-op harness" detector stopped the primary harness X509Fuzzer right after its first
`NEW CRASH`. Its coverage is flat (2043→2043) *because* nearly every input crashes and the process restarts — not because
the harness is a no-op. The rule must fire only on flat coverage AND zero observed crashes. GenFuzzer0 (27M execs,
cov 10→10, no crashes) is a real no-op and must still be stopped, with its budget released to the other harnesses.

## Study first
- repo: MAP.md "no-op detector" — read the condition and the stop path; find where crashes per harness are counted
  (`NEW CRASH` events / crash artifacts / `== Java Exception` blocks) so the guard can read that count.
- results: `grep -nE "NEW CRASH|noop|no-op|stopped|flat|fuzz thresholds" latest/orchestrator.log` — the exact sequence that
  stopped X509Fuzzer; quote it in finish().
(skip any reference root that is not listed in ROOTS)

## Change (src/)
- Condition: `coverage unchanged since the first stats line for >= NOOP_BUDGET_SECONDS or >= NOOP_BUDGET_EXECS` AND
  `crashes_observed == 0`. If nothing tracks crashes per harness yet, add the counter in the stats-consuming loop.
- True no-op: stop path unchanged; log
  `harness <name>: coverage flat at <cov> after <execs> execs / <s>s AND no observed crashes — no-op or uninstrumented; stopped, budget released`
  and release its remaining budget to the other harnesses (the health block names which harnesses received it).
- Flat but crashing: do NOT stop; log once
  `harness <name>: coverage flat at <cov> but <n> crash(es) — saturated, not no-op; left to deep phase`.
- The startup thresholds line must end with `… AND no observed crashes` (the old wording `— whichever first.` goes away).
- If the repo has NO no-op detector at all (clean checkout): add it with the guard above; budgets are module constants
  (e.g. 300 s / 1,000,000 execs), logged at startup. No flags, no environment switches.

## Tests to add (tests/test_noop_guard.py) — fake stats sequences, no real fuzzer
- regression: X509Fuzzer sequence = [first stats cov 2043, NEW CRASH, flat cov 2043 past the budget] → NOT flagged, NOT
  stopped, the "saturated, not no-op" line is logged. Write this test first; it must fail on the current code if the
  current code stops that harness.
- GenFuzzer0 sequence = [flat cov 10 past the budget, zero crashes] → flagged, stopped, log line present, budget released.
- growing cov (2063→3417) → not flagged. Flat within budget → not flagged yet.
- a harness flagged no-op renders `DEAD — no-op or uninstrumented (coverage flat at <cov>)`; a saturated harness is never
  rendered DEAD by this rule.
- the startup thresholds line contains `AND no observed crashes`.

## Acceptance
```
python -m pytest -q tests/test_noop_guard.py
```

## Do not touch
Oracle/sidecar; the SATURATED verdict and the deep phase (task 11 handles them); anything outside src/ and tests/.
