# discver campaign kit v4 — runbook

There is no prompt to paste. The files in `tasks/` ARE the prompts; `campaign.py` feeds them to the model one at a
time, verifies each with tests it runs itself, keeps what passes, and reverts what fails. You run commands; you do not
talk to the model.

## What is in the kit
- `microagent.py`  the agent (stdlib; LiteLLM chat/completions with tools; model-agnostic — set AGENT_MODEL)
- `campaign.py`    the runner: baseline → tasks in order → py_compile + task test + full suite → one repair pass → restore on FAIL
- `setup.sh`       builds the work folder (copies your repo and results; clones or links the reference repos)
- `tasks/`         the prompts, in execution order (see the table below)
- `EVIDENCE.md`    the facts of the last two real runs, injected into every task
- `HANDOFF.md`     what the container operator does with the result, and which log lines prove each change

## Step by step
1. Gather three things on the box that reaches your LiteLLM gateway:
   - this kit, unzipped
   - your discver repo: the folder that contains `src/` and `tests/`. Use the code as it was BEFORE the first campaign's edits if you have it; if your only copy already contains the bad no-op detector, that is fine — task 10 corrects it and a regression test guards it.
   - a `results/` folder with two subfolders: `results/latest/` = the DEAD run (Oct 13), `results/prev/` = the WEAK run (Sep 15/17). Each holds `orchestrator.log`, `health.json`, `patches/`, `report_run_*.md`.
2. Build the work folder (a NEW folder; your repo is copied, never edited in place):
   ```
   bash setup.sh ~/campaign_v4 /path/to/discver /path/to/results
   ```
   Optional 4th argument: a folder that already has `atlantis/` and `buttercup/` clones, to link instead of cloning.
   If the clones fail (no network), the campaign still runs; the tasks just skip the reference-reading step.
3. Point the agent at your gateway:
   ```
   export LITELLM_BASE_URL=https://llai-proxy.llan.ll.mit.edu/v1
   export LITELLM_API_KEY=<your key>
   export AGENT_TLS_VERIFY=false            # or AGENT_CA_BUNDLE=/path/to/ca.pem
   curl -s $LITELLM_BASE_URL/models -H "Authorization: Bearer $LITELLM_API_KEY" | grep -o '"id":"[^"]*opus[^"]*"'
   export AGENT_MODEL=claude-opus-5-5       # exactly as the curl line prints it
   export AGENT_REASONING_EFFORT=high       # optional; dropped automatically if the gateway rejects it
   ```
4. Check the gateway answers, and learn the baseline:
   ```
   python3 ~/campaign_v4/microagent.py --verify
   cd ~/campaign_v4/discver && python -m pytest -q tests | tail -3
   ```
5. Run the campaign (all tasks, in order, unattended):
   ```
   cd ~/campaign_v4
   nohup python3 campaign.py --work ~/campaign_v4 > campaign.log 2>&1 &
   tail -f campaign.log
   ```
   Subsets: `--only 00,10,11` (map + the two run-deciding fuzz tasks) · `--from 20` (resume at the fix-loop tasks).
   If your suite is not `python -m pytest -q tests`, add `--test-cmd "<your command>"`.
6. Read `~/campaign_v4/CAMPAIGN.md`: one section per task with PASS / FAIL / NO_EDITS, the verification output, and the agent's summary. FAIL tasks were reverted; the tree is green.
7. Send `~/campaign_v4/discver-fix.zip` to the container operator with `HANDOFF.md` (it is inside the zip too).
   The operator replaces `src/` and `tests/`, runs as usual, sends the results folder back.
8. Grade the run: `python3 src/check_run.py <results folder or zip>` (from the zip's `src/`), or the greps in `HANDOFF.md`.

## The tasks (= the prompts), in execution order
| task | change | the log line that proves it in the next run |
|---|---|---|
| 00 map | read-only; writes MAP.md (file:line for everything) for the later tasks | — |
| 10 fuzz_noop_guard | no-op rule = flat coverage AND zero crashes; never stops a crashing harness; budget release | `… AND no observed crashes` / `saturated, not no-op; left to deep phase` |
| 11 fuzz_keep_going | probe → deep phase with keep-going; UNVERIFIED leads; per-input replay into the existing crash path | `SATURATED → deep phase (keep_going=1000, form=…)` / `[lead]` / `[replay]` |
| 12 fuzz_seeds_past_crash | audit pb_seeds; mined + format-aware + LLM seeds; known-crash seeds excluded; right directory | `seeds mined=<a> format=<b> llm=<c> dropped=<d> → <dir>` |
| 13 fuzz_dictionary | dictionary from the target's string literals; `-dict` + `-use_value_profile=1` on deep phase only | `dict <n> entries → <path>` / `deep-phase cmd:` |
| 14 fuzz_exec_rate | execs ÷ elapsed; 0.0 only when no time elapsed | rates in the health block are not `0.0/s` |
| 15 fuzz_health_block | two-phase health block naming the sink; HEALTHY only if deep coverage grew; one thresholds line | `saturated by <sink>; continuing past it — coverage a→b` |
| 16 harness_gate | generated harnesses probed; reachability from the coverage report; regenerate once, then drop + release | `does not reach target → regenerating (1/1)` / `covers <n> target methods` |
| 17 harness_generator_feedback | regeneration prompt carries the failure; broad `catch` rejected; budget by reach | `rejected by static check` / allocation in the health block |
| 18 harness_discovery | provided harnesses found from the build output, never by name; no target-specific strings in src/ — works unchanged on the next codebase | `harnesses: provided=[…] generated=[…]` at startup |
| 20 patch_action_parser | lenient reply parsing + repair message + minimal protocol + read-only nudge + forced test | `[patch-turn] … tool=<name>` |
| 21 patch_accounting | parse_failures / read_only_turns / tool_histogram / last_parse_error in patch_index.json | counters in every entry |
| 22 patch_static_cap_and_dedup | static findings capped at 2, UNVALIDATED "no reproducer"; one bug patched once | no entry with attempts=15, test_calls=0 |
| 23 patch_rca_context | stack trace + ±60-line slice + reproducer path + harness in the brief; root_cause filled | root_cause non-empty |
| 24 patch_sidecar_classify | sidecar command/exit/stderr logged; failure classified; stop after 2 build failures | `[sidecar] … class=<…>` |
| 30 autofuzz_sweep (conditional) | Autofuzz each public method briefly; leads only; ≤5% budget | `sweep: <n> methods, <m> leads` |
| 31 post_patch_refuzz (conditional) | after a validated patch, fuzz the provided harness on the patched build | `[refuzz] … on patch <id>` |
| 40 check_run | `src/check_run.py` grades a results folder: PASS/FAIL/NOT SEEN per change | — |

Tasks 30 and 31 make no edits when their condition is not met in this repo; that is a correct outcome, and CAMPAIGN.md says why.

## What you will see while it runs
- `[campaign] baseline suite: exit 0 {passed: N, failed: M}` — pre-existing failures are recorded, never blamed on a task.
- `[agent] 7: str_replace(path='src/...')` — the agent working; `NO-OP` / `REFUSED` / `REJECTED` lines are the guard rails doing their job.
- `[campaign] 11_fuzz_keep_going.md: PASS (2 file(s) kept)` or `FAIL — repo restored to the state before this task`.
- At the end: `CAMPAIGN.md`, `patch.diff`, `changed_files.txt`, `discver-fix.zip`.

## Honest limits
A green campaign means: compiles, each task's test passes, no regression in the suite. It is not a real run — only the
container can run the fuzzer against the real target. What the campaign buys you is changes that are correct by spec and
guarded against the failures you already hit; the container run is the judge, and `check_run.py` reads its verdict.
