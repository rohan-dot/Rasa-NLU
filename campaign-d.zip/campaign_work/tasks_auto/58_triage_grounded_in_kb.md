# Task 58 — triage grounded in evidence: deterministic CWE from the crash, and the historical record shown to the triage LLM

## Condition
Only if `src/lang/__init__.py` exists (task 51/52). The KB parts degrade gracefully when `src/workshop/` or the KB is absent.

## Goal
Today a finding's class and confidence come from an LLM judgement alone, and an "arbiter" pass overrules leads as WEAK with
no external evidence (`LLM analysis findings: 4 … of which 2 are WEAK arbiter-overruled leads`). Two changes:
1. **Deterministic classification first.** From the adapter's `CrashInfo` (task 52): sanitizer + crash type → CWE and
   severity by a fixed table — ASan heap/stack-buffer-overflow READ → CWE-125, WRITE → CWE-787, heap-use-after-free →
   CWE-416, double-free → CWE-415, null-deref → CWE-476, UBSan signed-integer-overflow → CWE-190, shift → CWE-1335,
   MSan → CWE-908, LeakSanitizer → CWE-401, timeout → CWE-400/835, OOM → CWE-770; Jazzer IndexOutOfBounds → CWE-129/125,
   NPE → CWE-476, the Jazzer bug-detector names (SqlInjection → CWE-89, OsCommandInjection → 78, PathTraversal → 22,
   LdapInjection → 90, XXE → 611, Deserialization → 502); Go panics and Rust panics by message; Python exceptions by type.
   The table is data (`src/triage_table.yaml` or a dict), logged per finding: `[triage] <id> class=CWE-125 (from ASan READ) severity=high`.
2. **Evidence for the LLM.** When a KB is present, the triage prompt receives the k=5 nearest historical findings
   (crash type, crash state, project, CWE, fixed yes/no) and must cite which ones support its verdict; the record keeps
   `confidence_llm`, `class_deterministic`, `evidence_ids`. The arbiter may lower confidence but cannot overrule a finding
   whose deterministic class comes from a sanitizer report (a real crash is a real crash); it may still overrule
   LLM-only static findings. Log `[arbiter] <id> kept: sanitizer-backed` / `overruled: <reason>`.
No change to what counts as PoV-backed; task 45's submission tiers consume the recorded confidence as before.

## Study first
- `triage.py`, `crash_analyzer.py`, the arbiter (`grep -rn "arbiter\|triage-VALID\|confidence" src/`), how the
  finding record is written; `src/lang/*.py` CrashInfo; `src/workshop/retrieve.py` if present.

## Change (src/triage_table.py + triage.py call sites)
- `classify(crash_info) -> (cwe, severity, source)`; unknown combinations → `(None, "unknown", "no table entry")`, never a guess.
- The evidence block builder (≤ 1,500 chars); a fake-KB path for tests.

## Tests to add (tests/test_triage_grounded.py)
- every table row maps the fixture reports from task 52 to the stated CWE; an unknown combination yields None; the
  arbiter keeps a sanitizer-backed finding and can still overrule an LLM-only one; the prompt contains the evidence
  block when a fake KB is present and omits it (with a log line) when not; the record fields are written.

## Acceptance
```
python -m pytest -q tests/test_triage_grounded.py
```

## Do not touch
`_get_crash_signature`; PoV confirmation; sidecar; anything outside src/ and tests/.
