# Task 45 — bug candidates are submitted only when crash-derived: add a confidence tier for LLM/static findings

## Goal
Latest runs: `Crash bug reports: 1 (bugs/bug-*.json; crash-derived only)` and `LLM analysis findings: 4 (triage-VALID, NOT
PoV-backed / NOT fuzz-confirmed — of which 2 are WEAK arbiter-overruled leads; see /output/bugs/llm_findings.json)`, with
`DISCVER_TRIAGE_MIN_CONFIDENCE=0.00(default)` at startup. Only PoV-backed crashes become bug candidates in the submit dir;
triage-valid findings from the LLM/static passes never do, so on a benchmark that scores reported vulnerabilities discver
under-reports. Add a second submission tier: a triage-VALID finding with confidence ≥ `DISCVER_SUBMIT_MIN_CONFIDENCE`
(default 0.67) is submitted as a bug candidate carrying `evidence: "llm"` or `"static"` and its confidence; PoV-backed
ones keep `evidence: "pov"`. Arbiter-overruled ("WEAK") leads need `DISCVER_SUBMIT_WEAK_MIN_CONFIDENCE` (default 0.85).
Nothing about health verdicts, crash confirmation or patch validation changes — this is reporting policy, labelled honestly.

## Study first
- results: `grep -nE "llm_findings|arbiter|crash-derived|bug-candidate|TRIAGE_MIN_CONFIDENCE|\[submit|Bug reports" latest/orchestrator.log`;
  `latest/bugs/llm_findings.json` if present (fields: confidence, verdict, arbiter, location, cwe); `latest/submit_dir_listing.txt`.
- repo: where `bugs/bug-*.json` are written and copied to the submit dir (`grep -rn "bug-candidate\|bug_candidate\|crash-derived\|llm_findings\|arbiter\|TRIAGE_MIN_CONFIDENCE" src/`);
  the finding record (what confidence is, 0–1 or 0–100; what the arbiter writes); the final-summary lines.

## Change (src/ — new `submission_policy.py`, one call site where bug candidates are written)
- `decide(finding) -> (submit: bool, tier: "pov"|"llm"|"static"|"llm-weak", reason)`; thresholds from env with the defaults
  above; PoV-backed findings always submit (unchanged). Log one line per finding:
  `[submit] <id> tier=<tier> conf=<c> → submitted` / `→ held (<c> < <threshold>)`.
- Submitted non-PoV candidates use the same JSON shape as today plus `evidence`, `confidence`, `tier`, `arbiter` fields;
  the summary gains `Bug candidates: pov=<n> llm=<n> static=<n> held=<n> (min confidence <t>)`; the startup flags line
  prints both thresholds.
- Safety: wrapped; `[submission_policy] failed: <error>` → today's behaviour (PoV-only).

## Tests to add (tests/test_submission_policy.py) — fakes only
- confidence 0.71 triage-VALID → submitted tier llm with the fields; 0.40 → held with the reason; PoV-backed at any
  confidence → submitted tier pov; arbiter-WEAK at 0.80 → held, at 0.90 → submitted tier llm-weak; env overrides honoured;
  the summary counts; the log lines.

## Acceptance
```
python -m pytest -q tests/test_submission_policy.py
```

## Do not touch
Crash confirmation / dedup (`_get_crash_signature`), health verdicts, patch validation, sidecar; anything outside src/ and tests/.
