# Task 46 — score_replay.py: pick the submission threshold from numbers, not guesses

## Goal
`python3 src/score_replay.py <results dir> <ground truth>` prints, for thresholds 0.50–1.00 in steps of 0.05, how many of
the run's findings (PoV-backed plus LLM/static with confidence ≥ t) match the ground truth: TP / FP / FN / precision /
recall / F1 — and, when the benchmark's own scoring code is available under a reference root, its score. One run's
findings are enough to choose `DISCVER_SUBMIT_MIN_CONFIDENCE` (task 45) without re-running anything.

## Study first
- ROOTS: if a `crsbench` / `oss-crs` reference root exists, find the benchmark's ground-truth format and its matching
  rule (file + function? CWE? line ranges?) and the scoring function — reuse the rule exactly; quote file:line.
  If no such root exists, implement the generic format below and say so in the report.
- results: `latest/bugs/*.json`, `latest/bugs/llm_findings.json`, `latest/unique_bugs/summary.json` — the finding fields
  available (location file/function/line, cwe, confidence, evidence).

## Change (src/score_replay.py — stdlib only, no imports from discver, runnable from anywhere)
- Load findings from the results dir (crash-derived bug JSON + llm_findings.json); load ground truth: the benchmark format
  when recognised, else generic JSON `[{"file":..., "function":..., "cwe":..., "lines":[a,b]}]`.
- Match rule (generic): same file (suffix match) and same function, or same file and a line inside the range; CWE
  compared when both sides have one and reported separately (`cwe-exact` column).
- Print the threshold table, the best-F1 threshold, and the list of FN with their closest finding (why it was missed:
  not found / found but held / found with the wrong location). Exit code 0 always.

## Tests to add (tests/test_score_replay.py)
- fake findings (2 PoV, 4 LLM at 0.9/0.7/0.6/0.3) + fake ground truth of 5 → the table's TP/FP/FN at 0.5, 0.67, 1.0 are
  the hand-computed values; best-F1 threshold reported; FN explanations.
- a benchmark-format ground truth file (when a root was found) is parsed the same way the benchmark does.

## Acceptance
```
python -m pytest -q tests/test_score_replay.py
```

## Do not touch
Everything else in src/; anything outside src/ and tests/.
