#!/usr/bin/env python3
"""
rag_index.py — corpus -> overlapping word chunks -> BM25 index, cached on disk.

Only numpy is required. Chunk texts live in one flat file and are read on demand, so memory
stays small even for a large corpus. Optional dense retrieval (sentence-transformers + a
local embedding model, `--embed-model`) is fused with BM25 by reciprocal-rank fusion.

  python rag_index.py --corpus /path/to/af_epubs --index-dir rag_outputs/index --query "who approves waivers"
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import threading
import time
import zipfile
from array import array
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable

import numpy as np

INDEX_VERSION = 2
TEXT_EXT = {".txt", ".md", ".text"}
SKIP_DIRS = {".git", "__pycache__", ".ipynb_checkpoints", "node_modules"}
K1, B = 1.5, 0.75

_TOKEN_RE = re.compile(r"[a-z0-9]+")
STOPWORDS = frozenset(
    """a an and are as at be been being by for from had has have in is it its of on or that the this to was were will with
    which what who whom whose when where why how do does did not no can could should would may might must shall than then
    there these those their they them he she his her you your we our us i me my if but so such into about over under
    between within without per also any all each other more most some only own same too very s t""".split()
)


def tokenize(text: str) -> list[str]:
    """Lowercased alphanumeric tokens without stopwords / single letters (single digits are kept)."""
    return [t for t in _TOKEN_RE.findall(text.lower()) if (len(t) > 1 and t not in STOPWORDS) or t.isdigit()]


# --------------------------------------------------------------------------------------
# reading documents
# --------------------------------------------------------------------------------------

_BLOCK_TAGS = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "title", "td", "th"}


class _HTMLText(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "head"):
            self._skip += 1
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style", "head"):
            self._skip = max(0, self._skip - 1)
        elif tag in _BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def _natural_key(s: str) -> list:
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", s)]


def read_epub(path: Path) -> str:
    """Plain text of an EPUB (a zip of XHTML files), standard library only."""
    out: list[str] = []
    with zipfile.ZipFile(path) as z:
        names = sorted((n for n in z.namelist() if n.lower().endswith((".xhtml", ".html", ".htm"))), key=_natural_key)
        for n in names:
            parser = _HTMLText()
            try:
                parser.feed(z.read(n).decode("utf-8", errors="replace"))
            except Exception:  # noqa: BLE001 — a malformed chapter should not lose the book
                continue
            out.append("".join(parser.parts))
    return "\n".join(out)


def read_document(path: Path) -> str:
    if path.suffix.lower() == ".epub":
        return read_epub(path)
    return path.read_text(encoding="utf-8", errors="replace")


def list_corpus_files(roots: list[str | Path]) -> list[tuple[str, Path]]:
    """(doc name, path) for every indexable file. An .epub is skipped when a text file with the
    same stem exists in that corpus root (already extracted)."""
    out: list[tuple[str, Path]] = []
    roots_res = [Path(r).expanduser().resolve() for r in roots]
    for root in roots_res:
        if not root.is_dir():
            raise SystemExit(f"corpus directory not found: {root}")
        prefix = f"{root.name}/" if len(roots_res) > 1 else ""
        files: list[Path] = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.startswith("."))
            for fn in sorted(filenames):
                p = Path(dirpath) / fn
                if p.suffix.lower() in TEXT_EXT or p.suffix.lower() == ".epub":
                    files.append(p)
        text_stems = {p.stem.lower() for p in files if p.suffix.lower() in TEXT_EXT}
        for p in files:
            if p.suffix.lower() == ".epub" and p.stem.lower() in text_stems:
                continue
            out.append((prefix + p.relative_to(root).as_posix(), p))
    return out


def chunk_text(text: str, size: int, overlap: int) -> list[str]:
    """Sliding windows of `size` words with `overlap` words shared between neighbours."""
    words = text.split()
    n = len(words)
    if n == 0:
        return []
    stride = max(1, size - overlap)
    chunks: list[str] = []
    start = 0
    while start < n:
        if start > 0 and (n - start) <= overlap:
            break  # the tail is already inside the previous chunk
        end = min(n, start + size)
        chunks.append(" ".join(words[start:end]))
        if end >= n:
            break
        start += stride
    return chunks


def corpus_fingerprint(files: list[tuple[str, Path]], chunk_words: int, chunk_overlap: int) -> str:
    h = hashlib.sha1(f"v{INDEX_VERSION}|{chunk_words}|{chunk_overlap}\n".encode())
    for name, p in files:
        st = p.stat()
        h.update(f"{name}|{st.st_size}|{int(st.st_mtime)}\n".encode())
    return h.hexdigest()[:16]


# --------------------------------------------------------------------------------------
# building
# --------------------------------------------------------------------------------------


def build_index(files: list[tuple[str, Path]], index_dir: Path, chunk_words: int, chunk_overlap: int, fingerprint: str, log: Callable[[str], None]) -> dict:
    index_dir.mkdir(parents=True, exist_ok=True)
    for stale in ("meta.json", "emb.npy"):
        (index_dir / stale).unlink(missing_ok=True)
    vocab: dict[str, int] = {}
    post_term, post_doc, post_tf = array("i"), array("i"), array("f")
    chunk_doc, chunk_pos, chunk_len = array("i"), array("i"), array("f")
    offsets = array("q", [0])
    docs: list[str] = []
    n_bytes = 0
    skipped = 0
    t0 = last = time.time()
    with open(index_dir / "chunks.bin", "wb") as fout:
        for fi, (name, path) in enumerate(files):
            try:
                chunks = chunk_text(read_document(path), chunk_words, chunk_overlap)
            except Exception as e:  # noqa: BLE001
                skipped += 1
                log(f"skipping unreadable file {name}: {type(e).__name__}: {e}")
                continue
            if not chunks:
                skipped += 1
                continue
            doc_idx = len(docs)
            docs.append(name)
            for ci, ch in enumerate(chunks):
                data = ch.encode("utf-8")
                fout.write(data)
                n_bytes += len(data)
                offsets.append(n_bytes)
                cid = len(chunk_doc)
                chunk_doc.append(doc_idx)
                chunk_pos.append(ci)
                toks = tokenize(ch)
                chunk_len.append(len(toks))
                counts: dict[int, int] = {}
                for t in toks:
                    tid = vocab.get(t)
                    if tid is None:
                        tid = vocab[t] = len(vocab)
                    counts[tid] = counts.get(tid, 0) + 1
                for tid, tf in counts.items():
                    post_term.append(tid)
                    post_doc.append(cid)
                    post_tf.append(tf)
            if time.time() - last > 5:
                last = time.time()
                log(f"indexing: {fi + 1}/{len(files)} files, {len(chunk_doc)} chunks")
    n_chunks = len(chunk_doc)
    if n_chunks == 0:
        raise SystemExit("no text found in the corpus (looked for .txt/.md/.epub files) — check --corpus")
    term = np.frombuffer(post_term, dtype=np.intc)
    doc = np.frombuffer(post_doc, dtype=np.intc)
    tf = np.frombuffer(post_tf, dtype=np.float32)
    n_vocab = len(vocab)
    order = np.argsort(term, kind="stable")
    term_s, doc_s, tf_s = term[order], doc[order].astype(np.int32), tf[order]
    df = np.bincount(term, minlength=n_vocab)
    ptr = np.zeros(n_vocab + 1, dtype=np.int64)
    np.cumsum(df, out=ptr[1:])
    dl = np.frombuffer(chunk_len, dtype=np.float32)
    avgdl = max(float(dl.mean()), 1.0)
    idf = np.log(1.0 + (n_chunks - df + 0.5) / (df + 0.5)).astype(np.float32)
    norm = K1 * (1.0 - B + B * dl[doc_s] / avgdl)
    weights = (idf[term_s] * tf_s * (K1 + 1.0) / (tf_s + norm)).astype(np.float32)
    np.savez(
        index_dir / "arrays.npz",
        offsets=np.frombuffer(offsets, dtype=np.int64),
        chunk_doc=np.frombuffer(chunk_doc, dtype=np.intc).astype(np.int32),
        chunk_pos=np.frombuffer(chunk_pos, dtype=np.intc).astype(np.int32),
        term_ptr=ptr,
        post_doc=doc_s,
        post_w=weights,
    )
    (index_dir / "vocab.txt").write_text("\n".join(sorted(vocab, key=vocab.__getitem__)), encoding="utf-8")
    (index_dir / "docs.json").write_text(json.dumps(docs), encoding="utf-8")
    meta = {
        "version": INDEX_VERSION,
        "fingerprint": fingerprint,
        "n_files": len(files),
        "n_docs": len(docs),
        "n_chunks": n_chunks,
        "n_vocab": n_vocab,
        "text_bytes": n_bytes,
        "skipped_files": skipped,
        "chunk_words": chunk_words,
        "chunk_overlap": chunk_overlap,
        "build_seconds": round(time.time() - t0, 1),
        "embed_model": None,
    }
    (index_dir / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")  # written last = index complete
    return meta


# --------------------------------------------------------------------------------------
# searching
# --------------------------------------------------------------------------------------


class Retriever:
    def __init__(self, index_dir: str | Path):
        self.index_dir = Path(index_dir)
        self.meta = json.loads((self.index_dir / "meta.json").read_text(encoding="utf-8"))
        with np.load(self.index_dir / "arrays.npz") as arr:
            self.offsets = arr["offsets"]
            self.chunk_doc = arr["chunk_doc"]
            self.chunk_pos = arr["chunk_pos"]
            self.term_ptr = arr["term_ptr"]
            self.post_doc = arr["post_doc"]
            self.post_w = arr["post_w"]
        terms = (self.index_dir / "vocab.txt").read_text(encoding="utf-8").split("\n")
        self.vocab = {t: i for i, t in enumerate(terms) if t}
        self.docs: list[str] = json.loads((self.index_dir / "docs.json").read_text(encoding="utf-8"))
        self.n_chunks = int(self.chunk_doc.shape[0])
        self._fd = os.open(self.index_dir / "chunks.bin", os.O_RDONLY)
        self._lock = threading.Lock()
        self.emb = None
        self._embedder = None

    # -- construction --------------------------------------------------------------------
    @classmethod
    def build_or_load(
        cls,
        corpus: list[str | Path],
        index_dir: str | Path,
        *,
        chunk_words: int = 200,
        chunk_overlap: int = 40,
        embed_model: str | None = None,
        rebuild: bool = False,
        log: Callable[[str], None] | None = None,
    ) -> "Retriever":
        log = log or (lambda m: print(f"[index] {m}", file=sys.stderr, flush=True))
        index_dir = Path(index_dir)
        files = list_corpus_files(corpus)
        if not files:
            raise SystemExit(f"no .txt/.md/.epub files under {', '.join(str(c) for c in corpus)}")
        fp = corpus_fingerprint(files, chunk_words, chunk_overlap)
        meta_path = index_dir / "meta.json"
        meta = None
        if meta_path.exists() and not rebuild:
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                meta = None
        if meta and meta.get("fingerprint") == fp:
            log(f"using cached index: {meta['n_docs']} docs, {meta['n_chunks']} chunks ({index_dir})")
        else:
            log(f"building BM25 index over {len(files)} files ({chunk_words}-word chunks, {chunk_overlap} overlap) ...")
            meta = build_index(files, index_dir, chunk_words, chunk_overlap, fp, log)
            log(f"index built in {meta['build_seconds']}s: {meta['n_docs']} docs, {meta['n_chunks']} chunks, {meta['n_vocab']} terms")
        r = cls(index_dir)
        if embed_model:
            r.enable_dense(embed_model, log)
        return r

    # -- text access ---------------------------------------------------------------------
    def text(self, cid: int) -> str:
        s, e = int(self.offsets[cid]), int(self.offsets[cid + 1])
        if hasattr(os, "pread"):
            data = os.pread(self._fd, e - s, s)
        else:  # pragma: no cover (non-POSIX)
            with self._lock:
                os.lseek(self._fd, s, os.SEEK_SET)
                data = os.read(self._fd, e - s)
        return data.decode("utf-8", errors="replace")

    def get(self, cid: int, score: float | None = None) -> dict:
        cid = int(cid)
        if not 0 <= cid < self.n_chunks:
            raise KeyError(f"unknown chunk id {cid}")
        d = {"id": cid, "doc": self.docs[int(self.chunk_doc[cid])], "pos": int(self.chunk_pos[cid]), "text": self.text(cid)}
        if score is not None:
            d["score"] = round(float(score), 4)
        return d

    def neighbors(self, cid: int) -> list[dict]:
        cid = int(cid)
        out = []
        for j in (cid - 1, cid + 1):
            if 0 <= j < self.n_chunks and self.chunk_doc[j] == self.chunk_doc[cid]:
                out.append(self.get(j))
        return out

    # -- ranking -------------------------------------------------------------------------
    def _doc_mask(self, doc_filter: str | None):
        if not doc_filter:
            return None
        needle = doc_filter.lower().replace(" ", "")
        ids = [i for i, d in enumerate(self.docs) if needle in d.lower().replace(" ", "")]
        if not ids:
            return np.zeros(self.n_chunks, dtype=bool)
        return np.isin(self.chunk_doc, np.asarray(ids, dtype=self.chunk_doc.dtype))

    def _bm25(self, query: str, n: int, mask) -> tuple[np.ndarray, np.ndarray]:
        tids = {self.vocab[t] for t in tokenize(query) if t in self.vocab}
        empty = (np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.float32))
        if not tids:
            return empty
        scores = np.zeros(self.n_chunks, dtype=np.float32)
        for tid in tids:
            s, e = int(self.term_ptr[tid]), int(self.term_ptr[tid + 1])
            scores[self.post_doc[s:e]] += self.post_w[s:e]
        if mask is not None:
            scores[~mask] = 0.0
        n = min(n, self.n_chunks)
        idx = np.argpartition(-scores, n - 1)[:n] if n < self.n_chunks else np.arange(self.n_chunks)
        idx = np.sort(idx)  # ties are broken by chunk id, so results are reproducible
        idx = idx[np.argsort(-scores[idx], kind="stable")]
        idx = idx[scores[idx] > 0]
        return idx, scores[idx]

    def _dense(self, query: str, n: int, mask) -> np.ndarray:
        with self._lock:
            q = self._embedder.encode([query], normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False)[0]
        sims = np.asarray(self.emb @ np.asarray(q, dtype=np.float32))
        if mask is not None:
            sims = np.where(mask, sims, -np.inf)
        n = min(n, self.n_chunks)
        idx = np.argpartition(-sims, n - 1)[:n] if n < self.n_chunks else np.arange(self.n_chunks)
        idx = np.sort(idx)
        idx = idx[np.argsort(-sims[idx], kind="stable")]
        return idx[np.isfinite(sims[idx])]

    def search(self, query: str, k: int = 8, doc_filter: str | None = None) -> list[dict]:
        """Top-k chunks for a query: BM25, or BM25 + dense fused by reciprocal rank when dense is enabled."""
        k = max(1, int(k))
        mask = self._doc_mask(doc_filter)
        if self.emb is None:
            idx, sc = self._bm25(query, k, mask)
            return [self.get(i, s) for i, s in zip(idx.tolist(), sc.tolist())]
        depth = max(50, 4 * k)
        bm_idx, _ = self._bm25(query, depth, mask)
        de_idx = self._dense(query, depth, mask)
        fused: dict[int, float] = {}
        for lst in (bm_idx.tolist(), de_idx.tolist()):
            for rank, cid in enumerate(lst):
                fused[cid] = fused.get(cid, 0.0) + 1.0 / (60 + rank + 1)
        top = sorted(fused, key=lambda c: (-fused[c], c))[:k]
        return [self.get(c, fused[c]) for c in top]

    # -- optional dense retrieval --------------------------------------------------------
    def enable_dense(self, embed_model: str, log: Callable[[str], None]) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise SystemExit("--embed-model needs the sentence-transformers package in this Python environment") from e
        device = "cpu"
        try:
            import torch

            if torch.cuda.is_available():
                device = "cuda"
        except ImportError:
            pass
        self._embedder = SentenceTransformer(embed_model, device=device)
        emb_path = self.index_dir / "emb.npy"
        if self.meta.get("embed_model") == embed_model and emb_path.exists():
            self.emb = np.load(emb_path, mmap_mode="r")
            if self.emb.shape[0] == self.n_chunks:
                log(f"using cached embeddings ({self.emb.shape[1]} dims)")
                return
        log(f"embedding {self.n_chunks} chunks with {embed_model} on {device} ...")
        t0 = time.time()
        out = None
        step = 256
        for start in range(0, self.n_chunks, step):
            texts = [self.text(i) for i in range(start, min(self.n_chunks, start + step))]
            vecs = np.asarray(self._embedder.encode(texts, batch_size=64, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False), dtype=np.float32)
            if out is None:
                out = np.lib.format.open_memmap(emb_path, mode="w+", dtype=np.float32, shape=(self.n_chunks, vecs.shape[1]))
            out[start : start + len(texts)] = vecs
        out.flush()
        del out
        self.emb = np.load(emb_path, mmap_mode="r")
        self.meta["embed_model"] = embed_model
        (self.index_dir / "meta.json").write_text(json.dumps(self.meta, indent=1), encoding="utf-8")
        log(f"embeddings done in {time.time() - t0:.0f}s")

    def describe(self) -> str:
        m = self.meta
        kind = f"BM25 + dense ({m.get('embed_model')}) with reciprocal-rank fusion" if self.emb is not None else "BM25"
        return f"{kind}; {m['n_docs']} documents, {m['n_chunks']} chunks of {m['chunk_words']} words ({m['chunk_overlap']} overlap)"


def format_hits(hits: list[dict], max_chars_each: int = 1400) -> str:
    """Search results as the retrieval agent sees them."""
    if not hits:
        return "no results — try other terms (official titles, publication numbers, exact phrases)"
    out = []
    for h in hits:
        text = h["text"] if len(h["text"]) <= max_chars_each else h["text"][:max_chars_each] + " ..."
        score = f" score={h['score']}" if "score" in h else ""
        out.append(f"[c{h['id']}] doc={h['doc']} part={h['pos']}{score}\n{text}")
    return "\n\n".join(out)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Build (or load) the retrieval index and optionally run a query")
    p.add_argument("--corpus", action="append", required=True, help="directory of .txt/.md/.epub documents (repeatable)")
    p.add_argument("--index-dir", default="rag_outputs/index")
    p.add_argument("--chunk-words", type=int, default=200)
    p.add_argument("--chunk-overlap", type=int, default=40)
    p.add_argument("--embed-model", default=None, help="local sentence-transformers model directory for hybrid retrieval (optional)")
    p.add_argument("--rebuild", action="store_true")
    p.add_argument("--query", default=None)
    p.add_argument("-k", type=int, default=5)
    args = p.parse_args(argv)
    r = Retriever.build_or_load(args.corpus, args.index_dir, chunk_words=args.chunk_words, chunk_overlap=args.chunk_overlap, embed_model=args.embed_model, rebuild=args.rebuild)
    print(r.describe())
    if args.query:
        print(format_hits(r.search(args.query, args.k)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
