#!/usr/bin/env python3
"""
rag_compare.py — does the LoRA fine-tuned model answer better than its base model when both sit
inside the same agentic RAG pipeline?

  python rag_compare.py --lora-root /path/to/lora_project --corpus /path/to/documents --out-dir rag_outputs

Stages (each one caches its output in --out-dir, so a re-run continues where it stopped):
  setup     the runner model reads the LoRA project and writes rag_config.json
            (adapter, base model, held-out questions, the prompt format the adapter was trained on)
  index     BM25 index over the corpus (optional dense hybrid with --embed-model)
  retrieve  per question the runner searches / rewrites / selects passages   -> evidence.jsonl
  generate  both models answer from the SAME passages                         -> predictions_<arm>.jsonl
  judge     the runner scores every answer against the reference, blind       -> judgments.jsonl
  report    metrics, paired statistics, examples                              -> comparison.md

  python rag_compare.py --check ...       # verify runner endpoint, GPU stack, paths; no work done
  python rag_compare.py ... --limit 5     # a 5-question end-to-end pass before the real run
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from agent_core import add_llm_args, llm_from_args
from rag_agents import (
    find_adapters,
    find_eval_candidates,
    judge_all,
    load_config,
    load_judgments,
    merge_config,
    render_setup_notes,
    retrieve_all,
    run_setup,
    save_config,
    schema_overrides_for,
    validate_config,
    write_analysis,
)
from rag_eval import ARM_LABELS, METRIC_ROWS, build_comparison, build_examples, load_records, read_jsonl, select_examples, verdict, write_outputs
from rag_generate import ARMS, evidence_hash, load_predictions, parse_arm, run_generation
from rag_index import Retriever, list_corpus_files

STAGES = ["setup", "index", "retrieve", "generate", "judge", "report"]
RUNNER_ENV = ("LLM_MODEL", "AGENT_MODEL", "LITELLM_MODEL", "OPENAI_MODEL")


def log(msg: str) -> None:
    print(f"[rag] {msg}", file=sys.stderr, flush=True)


def stage_log(stage: str):
    return lambda m: print(f"[{stage}] {m}", file=sys.stderr, flush=True)


class Runner:
    """The runner model, created on first use so stages that do not need it run without it."""

    def __init__(self, args: argparse.Namespace):
        self.args = args
        self._llm = None

    @property
    def configured(self) -> bool:
        return bool(self.args.model or any(os.environ.get(k) for k in RUNNER_ENV))

    @property
    def model(self) -> str:
        return self.args.model or next((os.environ[k] for k in RUNNER_ENV if os.environ.get(k)), "")

    def get(self):
        if self._llm is None:
            llm = llm_from_args(self.args)  # exits with a clear message when nothing is configured
            eff = (self.args.reasoning_effort or os.environ.get("LLM_REASONING_EFFORT") or "low").lower()
            llm.cfg.reasoning_effort = None if eff in ("none", "default", "off") else eff
            t0 = time.time()
            # one call before any threads start: settles parameters the endpoint rejects (temperature, max_tokens name, ...)
            llm.chat([{"role": "user", "content": "Reply with the single word: ready"}], tools=None, max_tokens=512)
            log(f"runner model {llm.cfg.model} reachable ({time.time() - t0:.1f}s)")
            self._llm = llm
        return self._llm

    def usage(self) -> dict:
        return dict(self._llm.usage) if self._llm else {}


# --------------------------------------------------------------------------------------
# argument handling
# --------------------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="LoRA vs base model inside the same agentic RAG pipeline", allow_abbrev=False, formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    g = p.add_argument_group("what to compare")
    g.add_argument("--lora-root", help="the LoRA fine-tuning project directory (training script, adapter output, eval data)")
    g.add_argument("--root", action="append", default=[], metavar="LABEL=DIR", help="another directory the setup agent may read, e.g. --root data=/path/with/eval/file (repeatable)")
    g.add_argument("--corpus", action="append", default=[], help="directory of documents to retrieve from (.txt/.md/.epub; repeatable)")
    g.add_argument("--out-dir", default="rag_outputs")
    g.add_argument("--config", default=None, help="use this rag_config.json instead of <out-dir>/rag_config.json")
    g.add_argument("--adapter", default=None, help="override: adapter directory (adapter_config.json + adapter_model.*)")
    g.add_argument("--base-model", default=None, help="override: base model path or hub id")
    g.add_argument("--eval-file", default=None, help="override: evaluation questions (.json/.jsonl/.csv/.tsv/.parquet)")
    g.add_argument("--question-field", default=None)
    g.add_argument("--answer-field", default=None)
    g.add_argument("--base-prompt", choices=["auto", "same"], default=None, help="base model prompt: auto = its own chat template (default), same = identical string to the adapter's")
    g.add_argument("--arms", default="lora_rag,base_rag", help=f"comma list from: {', '.join(ARMS)}")
    g.add_argument("--with-closed-book", action="store_true", help="also answer without retrieval (adds lora_closed, base_closed): shows what retrieval itself contributes")
    g.add_argument("--limit", type=int, default=200, help="number of questions (seeded sample); 0 = the whole evaluation set. Default 200")
    g.add_argument("--seed", type=int, default=0)

    g = p.add_argument_group("retrieval")
    g.add_argument("--retrieval", choices=["agentic", "single"], default="agentic", help="agentic: the runner searches/rewrites/selects per question; single: one BM25 query, no runner")
    g.add_argument("--ctx-k", type=int, default=5, help="passages handed to the answering model")
    g.add_argument("--search-k", type=int, default=6, help="hits per search shown to the runner")
    g.add_argument("--max-searches", type=int, default=4, help="searches the runner may run per question")
    g.add_argument("--chunk-words", type=int, default=200)
    g.add_argument("--chunk-overlap", type=int, default=40)
    g.add_argument("--embed-model", default=None, help="local sentence-transformers model dir: adds dense retrieval fused with BM25")
    g.add_argument("--workers", type=int, default=6, help="parallel runner calls (retrieval and judging)")

    g = p.add_argument_group("generation")
    g.add_argument("--gen-backend", choices=["hf", "openai"], default="hf", help="hf: transformers+peft in this process; openai: an OpenAI-compatible server such as vLLM")
    g.add_argument("--batch-size", type=int, default=8)
    g.add_argument("--max-new-tokens", type=int, default=None, help="override the configured value")
    g.add_argument("--max-prompt-tokens", type=int, default=6000, help="passages are dropped from the end of a prompt that exceeds this")
    g.add_argument("--load-in-4bit", action="store_true", help="bitsandbytes 4-bit loading for small GPUs")
    g.add_argument("--allow-cpu", action="store_true")
    g.add_argument("--trust-remote-code", action="store_true")
    g.add_argument("--gen-base-url", default=None, help="openai backend: e.g. http://localhost:8000/v1")
    g.add_argument("--gen-api-key", default=None)
    g.add_argument("--gen-lora-model", default=None, help="openai backend: served name of the adapter (vLLM --lora-modules NAME=path)")
    g.add_argument("--gen-base-model", default=None, help="openai backend: served name of the base model")

    g = p.add_argument_group("run control")
    g.add_argument("--stages", default=",".join(STAGES), help=f"comma list from: {', '.join(STAGES)} (default: all)")
    g.add_argument("--redo", default="", help="stages whose cached output is discarded first, e.g. --redo setup or --redo retrieve,generate")
    g.add_argument("--no-agent-setup", action="store_true", help="setup from filename heuristics + your overrides only (no runner calls)")
    g.add_argument("--no-judge", action="store_true")
    g.add_argument("--no-analysis", action="store_true", help="skip the runner's written reading of the results")
    g.add_argument("--check", action="store_true", help="verify the runner endpoint, the GPU stack and the paths, then exit")
    g.add_argument("--runner-model", default=None, help="same as --model: the runner (e.g. your gpt-5.6 name on LiteLLM)")
    add_llm_args(p)
    return p


def parse_roots(args: argparse.Namespace) -> dict[str, Path]:
    roots: dict[str, Path] = {}
    if args.lora_root:
        p = Path(args.lora_root).expanduser().resolve()
        if not p.is_dir():
            raise SystemExit(f"--lora-root is not a directory: {args.lora_root}")
        roots["lora"] = p
    for spec in args.root:
        label, sep, path = spec.partition("=")
        if not sep or not label.strip() or "/" in label:
            raise SystemExit(f"--root expects LABEL=DIR, got: {spec}")
        p = Path(path).expanduser().resolve()
        if not p.is_dir():
            raise SystemExit(f"--root {label}: not a directory: {path}")
        if label.strip() in roots:
            raise SystemExit(f"--root label '{label}' is used twice")
        roots[label.strip()] = p
    return roots


def cli_overrides(args: argparse.Namespace) -> dict:
    o: dict[str, Any] = {}
    if args.adapter:
        o["adapter_path"] = str(Path(args.adapter).expanduser().resolve())
    if args.base_model:
        b = os.path.expanduser(args.base_model)
        o["base_model"] = str(Path(b).resolve()) if os.path.isdir(b) else args.base_model
    ev: dict[str, Any] = {}
    if args.eval_file:
        ev["path"] = str(Path(args.eval_file).expanduser().resolve())
    if args.question_field:
        ev["question_field"] = args.question_field
    if args.answer_field:
        ev["answer_field"] = args.answer_field
    if ev:
        o["eval"] = ev
    if args.max_new_tokens:
        o["gen"] = {"max_new_tokens": args.max_new_tokens}
    if args.base_prompt:
        o["prompt"] = {"base_style": args.base_prompt}
    return o


# --------------------------------------------------------------------------------------
# --check
# --------------------------------------------------------------------------------------


def run_check(args: argparse.Namespace, runner: Runner, out_dir: Path, cfg_path: Path) -> int:
    rows: list[tuple[str, str, str]] = []

    def add(name: str, status: str, detail: str) -> None:
        rows.append((name, status, detail))

    add("python", "OK", f"{sys.version.split()[0]} ({sys.executable})")
    try:
        import numpy

        add("numpy", "OK", numpy.__version__)
    except ImportError:
        add("numpy", "FAIL", "pip install numpy")

    if runner.configured:
        try:
            llm = runner.get()
            ping = [{"type": "function", "function": {"name": "ping", "description": "Call this tool once.", "parameters": {"type": "object", "properties": {"x": {"type": "integer"}}}}}]
            try:
                r = llm.chat([{"role": "user", "content": "Call the ping tool with x=1."}], tools=ping, max_tokens=512)
                tools = "native tool calls" if r.tool_calls else "no tool call returned (the json fallback will be used if needed)"
            except Exception as e:  # noqa: BLE001
                tools = f"tool call failed: {type(e).__name__} (the json text protocol will be used)"
            add("runner model", "OK", f"{llm.cfg.model} via {llm.cfg.base_url or 'api.openai.com'}; {tools}; reasoning_effort={llm.cfg.reasoning_effort if 'reasoning_effort' not in llm._dropped_params else 'not supported by this endpoint'}")
        except SystemExit as e:
            add("runner model", "FAIL", str(e).splitlines()[0])
    else:
        add("runner model", "WARN", "not configured (export LLM_BASE_URL / LLM_API_KEY / LLM_MODEL): setup would use heuristics, and agentic retrieval + judging are unavailable")

    if args.gen_backend == "hf":
        try:
            import torch

            if torch.cuda.is_available():
                gpus = ", ".join(f"{torch.cuda.get_device_name(i)} {torch.cuda.get_device_properties(i).total_memory / 2**30:.0f}GB" for i in range(torch.cuda.device_count()))
                add("torch", "OK", f"{torch.__version__}; CUDA: {gpus}")
            else:
                add("torch", "FAIL", f"{torch.__version__} but no CUDA GPU visible — run the generate stage on a GPU node")
        except ImportError:
            add("torch", "FAIL", "not importable in this Python — run `--stages generate` in the environment the adapter was trained in; every other stage works here")
        for mod in ("transformers", "peft"):
            try:
                m = __import__(mod)
                add(mod, "OK", getattr(m, "__version__", "?"))
            except ImportError:
                add(mod, "FAIL", f"not importable in this Python (needed by the generate stage only)")
    else:
        ok = all([args.gen_base_url, args.gen_lora_model, args.gen_base_model])
        add("generation server", "OK" if ok else "FAIL", f"{args.gen_base_url} lora={args.gen_lora_model} base={args.gen_base_model}" if ok else "needs --gen-base-url, --gen-lora-model, --gen-base-model")

    roots = parse_roots(args)
    cfg = None
    if cfg_path.exists():
        cfg = merge_config(load_config(cfg_path), cli_overrides(args))
        errors, warnings, info = validate_config(cfg, None)
        add("config", "FAIL" if errors else "OK", f"{cfg_path}" + ("; " + "; ".join(errors) if errors else ""))
        if not errors:
            a = info.get("adapter", {})
            add("adapter", "OK", f"{cfg['adapter_path']} ({a.get('peft_type')}, r={a.get('r')}, alpha={a.get('lora_alpha')})")
            add("base model", "OK", cfg["base_model"])
            add("eval set", "OK", f"{cfg['eval']['path']}: {info.get('n_examples')} questions")
        for w in warnings:
            add("config", "WARN", w)
    elif roots:
        adapters = find_adapters(roots)
        evals = find_eval_candidates(roots)
        add("adapters", "OK" if adapters else "FAIL", f"{len(adapters)} found" + (f"; best guess {adapters[0]['path']} (base {adapters[0]['base_model']})" if adapters else " — pass --adapter DIR"))
        add("eval files", "OK" if evals else "WARN", f"{len(evals)} candidate(s)" + (f"; best guess {evals[0]['path']} ({evals[0]['n_records']} records)" if evals else " — the setup agent will look in the code, or pass --eval-file"))
    else:
        add("project", "WARN", "no --lora-root and no rag_config.json yet")

    if args.corpus:
        try:
            files = list_corpus_files(args.corpus)
            size = sum(p.stat().st_size for _, p in files)
            add("corpus", "OK" if files else "FAIL", f"{len(files)} text files, {size / 1e6:.1f} MB" if files else "no .txt/.md/.epub files found")
        except SystemExit as e:
            add("corpus", "FAIL", str(e))
    elif any(parse_arm(a)[1] == "rag" for a in selected_arms(args)):
        add("corpus", "WARN", "no --corpus given (needed by the index stage)")

    width = max(len(n) for n, _, _ in rows)
    for name, status, detail in rows:
        print(f"{name.ljust(width)}  {status:<4}  {detail}")
    failed = [n for n, s, _ in rows if s == "FAIL"]
    print("\n" + ("all good — run the same command without --check (add --limit 5 for a first pass)" if not failed else f"fix first: {', '.join(failed)}"))
    return 1 if failed else 0


def selected_arms(args: argparse.Namespace) -> list[str]:
    arms = [a.strip() for a in args.arms.split(",") if a.strip()]
    if args.with_closed_book:
        arms += [a for a in ("lora_closed", "base_closed") if a not in arms]
    for a in arms:
        parse_arm(a)
    return [a for a in ARMS if a in arms]


# --------------------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.runner_model:
        args.model = args.runner_model
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg_path = Path(args.config) if args.config else out_dir / "rag_config.json"
    runner = Runner(args)
    if args.check:
        return run_check(args, runner, out_dir, cfg_path)

    stages = [s.strip() for s in args.stages.split(",") if s.strip()]
    redo = [s.strip() for s in args.redo.split(",") if s.strip()]
    for s in stages + redo:
        if s not in STAGES:
            raise SystemExit(f"unknown stage '{s}'. Stages: {', '.join(STAGES)}")
    arms = selected_arms(args)
    need_rag = any(parse_arm(a)[1] == "rag" for a in arms)
    if "generate" in stages and args.gen_backend == "hf":
        import importlib.util

        def importable(mod: str) -> bool:
            if mod in sys.modules:
                return True
            try:
                return importlib.util.find_spec(mod) is not None
            except (ImportError, ValueError):
                return False

        missing = [m for m in ("torch", "transformers", "peft") if not importable(m)]
        if missing and len(stages) > 1:
            log(
                f"NOTE: {', '.join(missing)} not importable in this Python, so this run will stop at the generate stage (everything before it is cached). "
                "Then run `--stages generate` in the environment the adapter was trained in, and this command once more to judge and report."
            )
    state_path = out_dir / "run_state.json"
    state: dict[str, Any] = json.loads(state_path.read_text()) if state_path.exists() else {}
    timings: dict[str, float] = {}
    evidence_path, judgments_path = out_dir / "evidence.jsonl", out_dir / "judgments.jsonl"

    for s in redo:
        targets = {
            "setup": [cfg_path, out_dir / "setup_notes.md"],
            "index": [out_dir / "index" / "meta.json"],
            "retrieve": [evidence_path],
            "generate": [out_dir / f"predictions_{a}.jsonl" for a in ARMS],
            "judge": [judgments_path],
            "report": [],
        }[s]
        for t in targets:
            if t.exists():
                t.unlink()
                log(f"--redo {s}: removed {t}")

    # ---- setup ------------------------------------------------------------------------
    overrides = cli_overrides(args)
    t0 = time.time()
    if cfg_path.exists():
        cfg = merge_config(load_config(cfg_path), overrides)
        if args.eval_file and not (args.question_field and args.answer_field) and load_config(cfg_path)["eval"].get("path") != cfg["eval"]["path"]:
            cfg["eval"].update({k: v for k, v in schema_overrides_for(cfg["eval"]["path"]).items() if k not in overrides.get("eval", {})})
        errors, warnings, info = validate_config(cfg, None)
        if errors:
            raise SystemExit(f"{cfg_path} is not usable:\n- " + "\n- ".join(errors) + "\nFix the file (or the overrides), or re-run the setup agent with --redo setup.")
        if overrides:
            cfg["notes"]["source"] = f"{cfg['notes'].get('source', '?')} + command-line overrides"
            save_config(cfg_path, cfg)
        log(f"using {cfg_path} (delete it or pass --redo setup to run the setup agent again)")
    else:
        if "setup" not in stages:
            raise SystemExit(f"{cfg_path} does not exist yet — include the setup stage (it is part of the default run).")
        roots = parse_roots(args)
        if not roots:
            raise SystemExit("--lora-root is required for the setup stage (the LoRA project directory with the training code and the adapter)")
        use_agent = not args.no_agent_setup and runner.configured
        if not use_agent and not args.no_agent_setup:
            log("no runner model configured (LLM_MODEL unset): setup falls back to filename heuristics")
        extra_allowed = [Path(c).expanduser().resolve() for c in args.corpus]
        if args.eval_file:
            extra_allowed.append(Path(args.eval_file).expanduser().resolve().parent)
        if args.adapter:
            extra_allowed.append(Path(args.adapter).expanduser().resolve())
        cfg, report = run_setup(roots, runner.get() if use_agent else None, overrides=overrides, extra_allowed=extra_allowed, trace_path=out_dir / "trace_setup.jsonl", log=stage_log("setup"))
        warnings, info = report["warnings"], report["info"]
        save_config(cfg_path, cfg)
        (out_dir / "setup_notes.md").write_text(render_setup_notes(cfg, report), encoding="utf-8")
        log(f"wrote {cfg_path} and {out_dir / 'setup_notes.md'}")
        timings["setup"] = time.time() - t0
    for w in warnings:
        log(f"WARNING: {w}")
    acfg = info.get("adapter", {})
    log(f"adapter: {cfg['adapter_path']}  |  base: {cfg['base_model']}  |  eval: {cfg['eval']['path']} ({info.get('n_examples')} questions)")

    # ---- questions --------------------------------------------------------------------
    all_examples, _ = build_examples(load_records(cfg["eval"]["path"]), cfg["eval"])
    examples = select_examples(all_examples, args.limit, args.seed)
    if len(examples) < len(all_examples):
        log(f"evaluating a seeded sample of {len(examples)} of {len(all_examples)} questions (--limit 0 for all)")
    else:
        log(f"evaluating all {len(examples)} questions")

    # ---- index + retrieve --------------------------------------------------------------
    evidence: dict[str, dict] = {}
    if need_rag and ("index" in stages or "retrieve" in stages):
        if not args.corpus:
            raise SystemExit("--corpus is required for the index/retrieve stages (the directory of documents to search)")
        t0 = time.time()
        retriever = Retriever.build_or_load(args.corpus, out_dir / "index", chunk_words=args.chunk_words, chunk_overlap=args.chunk_overlap, embed_model=args.embed_model, log=stage_log("index"))
        timings["index"] = time.time() - t0
        state["retrieval_desc"] = retriever.describe()
        if "retrieve" in stages:
            t0 = time.time()
            if args.retrieval == "agentic" and not runner.configured:
                raise SystemExit(
                    "agentic retrieval needs the runner model: export LLM_BASE_URL / LLM_API_KEY / LLM_MODEL (or pass --model),\n"
                    "or run without it: --retrieval single --no-judge"
                )
            llm = runner.get() if args.retrieval == "agentic" else None
            evidence = retrieve_all(examples, retriever, evidence_path, mode=args.retrieval, llm=llm, ctx_k=args.ctx_k, search_k=args.search_k, max_searches=args.max_searches, workers=args.workers, log=stage_log("retrieve"))
            timings["retrieve"] = time.time() - t0
            state["retrieval_mode"] = args.retrieval
            state["ctx_k"] = args.ctx_k
    if need_rag and not evidence:
        wanted = {e.id: e for e in examples}
        evidence = {r["id"]: r for r in read_jsonl(evidence_path) if r.get("id") in wanted and r.get("qhash") == wanted[r["id"]].qhash}
    if len({json.dumps(r.get("signature"), sort_keys=True) for r in evidence.values()}) > 1:
        log("WARNING: the selected questions have evidence from more than one retrieval setting — run the retrieve stage again so every question uses the same one")

    # ---- generate ---------------------------------------------------------------------
    if "generate" in stages:
        t0 = time.time()
        meta: dict[str, Any] = {}
        api = {"base_url": args.gen_base_url, "api_key": args.gen_api_key, "lora_model": args.gen_lora_model, "base_model": args.gen_base_model, "workers": args.workers}
        done = run_generation(
            arms=arms, examples=examples, evidence=evidence, cfg=cfg, out_dir=out_dir, backend=args.gen_backend, batch_size=args.batch_size,
            max_prompt_tokens=args.max_prompt_tokens, load_in_4bit=args.load_in_4bit, allow_cpu=args.allow_cpu, trust_remote_code=args.trust_remote_code,
            api=api, meta=meta, log=stage_log("generate"),
        )
        timings["generate"] = time.time() - t0
        state["styles"] = meta.get("styles", {})
        state["gen_desc"] = f"{args.gen_backend} backend{', 4-bit' if args.load_in_4bit else ''}; greedy decoding; max_new_tokens={cfg['gen']['max_new_tokens']}"
        log("generated: " + ", ".join(f"{a} {n}" for a, n in done.items()))

    # ---- collect predictions (and drop any that were generated from other evidence) -----
    preds: dict[str, dict[str, dict]] = {}
    wanted_ids = {e.id for e in examples}
    for arm in arms:
        got = {i: r for i, r in load_predictions(out_dir, arm).items() if i in wanted_ids}
        if parse_arm(arm)[1] == "rag":
            stale = [i for i, r in got.items() if r.get("ehash") != evidence_hash(evidence.get(i))]
            if stale:
                log(f"WARNING: {len(stale)} {arm} prediction(s) were generated from different retrieved passages and are ignored — re-run the generate stage")
                for i in stale:
                    got.pop(i)
        preds[arm] = got

    # ---- judge ------------------------------------------------------------------------
    judgments: dict[tuple[str, str], dict] | None = None
    if not args.no_judge and runner.configured:
        ex_by_id = {e.id: e for e in examples}
        items = [{"id": i, "arm": arm, "question": ex_by_id[i].query, "reference": ex_by_id[i].answer, "prediction": r.get("prediction", "")} for arm in arms for i, r in preds[arm].items()]
        if "judge" in stages and items:
            t0 = time.time()
            judgments = judge_all(items, runner.get(), judgments_path, workers=args.workers, log=stage_log("judge"))
            timings["judge"] = time.time() - t0
            state["judge_model"] = runner.model
        elif judgments_path.exists():
            judgments = load_judgments(items, judgments_path)
    elif not args.no_judge and "judge" in stages:
        log("no runner model configured: skipping the judge (primary metric will be token F1)")

    # ---- report -----------------------------------------------------------------------
    if "report" not in stages:
        state_path.write_text(json.dumps(state, indent=1))
        return 0
    comp = build_comparison(examples, preds, evidence if need_rag else None, judgments)
    roles = [r for r, on in (
        ("configured the run from the project's code", str(cfg["notes"].get("source", "")).startswith("agent")),
        ("controlled retrieval", need_rag and state.get("retrieval_mode", args.retrieval) == "agentic"),
        ("judged the answers", comp["has_judge"]),
    ) if on]
    styles = state.get("styles", {})
    wrapper = {"raw": "the literal training format", "chat": "the tokenizer's chat template"}
    setup = {
        "Base model": cfg["base_model"],
        "Adapter": cfg["adapter_path"] + (f" ({acfg.get('peft_type')}, r={acfg.get('r')}, alpha={acfg.get('lora_alpha')}, targets={acfg.get('target_modules')})" if acfg else ""),
        "Evaluation set": f"{cfg['eval']['path']} — " + (f"seeded sample of {len(examples)} of {len(all_examples)} questions (seed {args.seed})" if len(examples) < len(all_examples) else f"all {len(examples)} questions"),
        "Retrieval": (f"{state.get('retrieval_mode', args.retrieval)}; {state.get('retrieval_desc', '')}; up to {state.get('ctx_k', args.ctx_k)} passages per question" if need_rag else ""),
        "Runner": (f"{runner.model} — " + ", ".join(roles) if runner.configured and roles else ""),
        "Generation": state.get("gen_desc", ""),
        "Prompts": "; ".join(f"{who}: {wrapper.get(st, st)}" for who, st in (("fine-tuned model", next((styles[a] for a in arms if a in styles and a.startswith("lora")), None)), ("base model", next((styles[a] for a in arms if a in styles and a.startswith("base")), None))) if st) + (". Same user content and passages for both." if styles else ""),
        "Judge": (f"{state.get('judge_model', runner.model)}; sees question, reference and one answer, never the model name" if comp["has_judge"] else "not run"),
    }
    report = write_outputs(out_dir, comp, setup, preds)
    if comp["n"] and not args.no_analysis and runner.configured and "lora_rag" in comp["arms"] and "base_rag" in comp["arms"]:
        try:
            text = write_analysis(runner.get(), comp, setup).strip()
            if text:
                with open(report, "a", encoding="utf-8") as f:
                    f.write(f"## The runner's reading of these results\n\n_Written by {runner.model} from the tables above; check it against them._\n\n{text}\n")
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001 — the report stands without it
            log(f"analysis skipped: {type(e).__name__}: {e}")
    state.update(timings={**state.get("timings", {}), **{k: round(v, 1) for k, v in timings.items()}}, runner_usage=runner.usage(), arms=arms, n=comp["n"])
    state_path.write_text(json.dumps(state, indent=1))

    # ---- console summary --------------------------------------------------------------
    print(f"\nreport: {report}")
    if comp["n"]:
        main_pair = next((p for p in comp["pairs"] if (p["a"], p["b"]) == ("lora_rag", "base_rag")), comp["pairs"][0] if comp["pairs"] else None)
        if main_pair and comp["primary"] in main_pair["rows"]:
            st = main_pair["rows"][comp["primary"]]
            na, nb = ARM_LABELS[main_pair["a"]], ARM_LABELS[main_pair["b"]]
            print(f"{dict(METRIC_ROWS)[comp['primary']]} on {st['n']} questions: {na} {st['a']:.3f} vs {nb} {st['b']:.3f}  (Δ {st['delta']:+.3f}, 95% CI {st['lo']:+.3f} to {st['hi']:+.3f}) -> {verdict(st, na, nb)}")
    else:
        print("no predictions yet — the generate stage has not produced answers for the selected questions")
    return 0


if __name__ == "__main__":
    sys.exit(main())
