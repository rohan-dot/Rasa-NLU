#!/usr/bin/env python3
"""
rag_eval.py — evaluation data loading, answer metrics, paired statistics and the comparison report.

Standard library + numpy only, so it runs in any environment. Overlap metrics (token F1, exact
match, ROUGE-1/2/L, corpus BLEU-4) are implemented here; judge accuracy comes from rag_agents.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from rag_index import STOPWORDS

# --------------------------------------------------------------------------------------
# evaluation data
# --------------------------------------------------------------------------------------

RECORD_LIST_KEYS = ("data", "examples", "eval", "test", "validation", "val", "dev", "rows", "items", "records", "questions", "qa_pairs", "qa", "train")
Q_KEYS = ["question", "query", "instruction", "prompt", "input", "q", "user", "human", "text"]
A_KEYS = [
    "answer", "output", "response", "completion", "reference", "reference_answer", "ground_truth", "gold", "gold_answer",
    "label", "labels", "target", "a", "assistant", "expected", "expected_output", "answers",
]
MSG_KEYS = ["messages", "conversations", "conversation", "dialog"]
ID_KEYS = ["id", "qid", "question_id", "uid", "idx"]
USER_ROLES = {"user", "human"}
ASSISTANT_ROLES = {"assistant", "gpt", "bot", "model"}


@dataclass
class Example:
    id: str
    question: str
    answer: str
    input: str = ""
    qhash: str = ""

    @property
    def query(self) -> str:
        """What retrieval searches for: the question plus any per-example input."""
        return (self.question + ("\n" + self.input if self.input else "")).strip()


def _records_from_obj(obj: Any) -> list[dict]:
    if isinstance(obj, list):
        return [r for r in obj if isinstance(r, dict)]
    if isinstance(obj, dict):
        for k in RECORD_LIST_KEYS:
            v = obj.get(k)
            if isinstance(v, list) and v and isinstance(v[0], dict):
                return [r for r in v if isinstance(r, dict)]
        lists = [v for v in obj.values() if isinstance(v, list) and v and isinstance(v[0], dict)]
        if lists:
            return [r for r in max(lists, key=len) if isinstance(r, dict)]
        cols = {k: v for k, v in obj.items() if isinstance(v, list)}
        if cols and len(cols) == len(obj) and len({len(v) for v in cols.values()}) == 1:  # columnar {"question": [...], "answer": [...]}
            n = len(next(iter(cols.values())))
            return [{k: v[i] for k, v in cols.items()} for i in range(n)]
    return []


def load_records(path: str | Path) -> list[dict]:
    """Records from .json / .jsonl / .csv / .tsv / .parquet (or a `datasets` save_to_disk directory)."""
    p = Path(path)
    if p.is_dir():
        try:
            from datasets import load_from_disk  # optional
        except ImportError as e:
            raise ValueError(f"{p} is a directory; reading it needs the `datasets` package") from e
        ds = load_from_disk(str(p))
        if hasattr(ds, "keys"):  # DatasetDict -> prefer a held-out split
            split = next((s for s in ("test", "validation", "eval", "dev") if s in ds), list(ds.keys())[0])
            ds = ds[split]
        return [dict(r) for r in ds]
    ext = p.suffix.lower()
    if ext in (".jsonl", ".ndjson"):
        out = []
        with open(p, "r", encoding="utf-8-sig", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(obj, dict):
                        out.append(obj)
        return out
    if ext == ".json":
        text = p.read_text(encoding="utf-8-sig", errors="replace")
        try:
            return _records_from_obj(json.loads(text))
        except json.JSONDecodeError:  # JSON-lines saved with a .json extension
            out = []
            for line in text.splitlines():
                line = line.strip()
                if line:
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        return []
                    if isinstance(obj, dict):
                        out.append(obj)
            return out
    if ext in (".csv", ".tsv"):
        csv.field_size_limit(min(sys.maxsize, 2**31 - 1))
        with open(p, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
            sample = f.read(65536)
            f.seek(0)
            header = sample.splitlines()[0] if sample.strip() else ""
            counts = {d: header.count(d) for d in (",", "\t", ";", "|")}
            delim = "\t" if ext == ".tsv" else ","
            if counts[delim] == 0 and max(counts.values()) > 0:  # e.g. a semicolon-separated .csv
                delim = max(counts, key=counts.get)
            return [dict(r) for r in csv.DictReader(f, delimiter=delim)]
    if ext == ".parquet":
        try:
            import pandas as pd  # optional
        except ImportError as e:
            raise ValueError("reading .parquet needs pandas + pyarrow") from e
        return pd.read_parquet(p).to_dict("records")
    raise ValueError(f"unsupported evaluation file type: {p.name} (use .json, .jsonl, .csv, .tsv or .parquet)")


def get_path(rec: Any, path: str | None) -> Any:
    """Dotted lookup: 'answer', 'meta.gold', 'answers.0'."""
    if not path:
        return None
    cur = rec
    for part in str(path).split("."):
        if isinstance(cur, dict):
            if part in cur:
                cur = cur[part]
            else:
                low = {str(k).lower(): k for k in cur}
                if part.lower() not in low:
                    return None
                cur = cur[low[part.lower()]]
        elif isinstance(cur, (list, tuple)) and part.lstrip("-").isdigit() and -len(cur) <= int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return None
    return cur


def _as_text(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    if isinstance(v, float) and math.isnan(v):
        return ""
    if isinstance(v, (list, tuple)):
        return _as_text(v[0]) if v else ""
    if isinstance(v, dict):
        for k in ("text", "content", "value", "answer"):
            if k in v:
                return _as_text(v[k])
        return ""
    return str(v)


def _from_messages(msgs: Any) -> tuple[str, str]:
    if not isinstance(msgs, list):
        return "", ""
    norm = []
    for m in msgs:
        if not isinstance(m, dict):
            continue
        role = str(m.get("role", m.get("from", ""))).lower()
        content = _as_text(m.get("content", m.get("value", "")))
        norm.append((role, content))
    a_idx = next((i for i in range(len(norm) - 1, -1, -1) if norm[i][0] in ASSISTANT_ROLES), None)
    if a_idx is None:
        return "", ""
    q_idx = next((i for i in range(a_idx - 1, -1, -1) if norm[i][0] in USER_ROLES), None)
    if q_idx is None:
        return "", ""
    return norm[q_idx][1], norm[a_idx][1]


def detect_schema(records: list[dict]) -> dict | None:
    """Guess which fields hold the question and the reference answer. None when nothing fits."""
    sample = records[:200]
    if not sample:
        return None
    n = len(sample)

    def coverage(key: str) -> float:
        return sum(1 for r in sample if _as_text(get_path(r, key)).strip()) / n

    keys: dict[str, str] = {}
    for r in sample:
        for k in r:
            keys.setdefault(str(k).lower(), str(k))
    for mk in MSG_KEYS:
        if mk in keys:
            ok = sum(1 for r in sample if all(_from_messages(r.get(keys[mk])))) / n
            if ok >= 0.8:
                return {"format": "messages", "messages_field": keys[mk], "question_field": None, "answer_field": None, "input_field": None, "id_field": None}
    q = next((keys[k] for k in Q_KEYS if k in keys and coverage(keys[k]) >= 0.5), None)
    a = next((keys[k] for k in A_KEYS if k in keys and keys[k] != q and coverage(keys[k]) >= 0.5), None)
    if not q or not a:
        return None
    schema: dict[str, Any] = {"format": "fields", "question_field": q, "answer_field": a, "input_field": None, "messages_field": None}
    schema["id_field"] = next((keys[k] for k in ID_KEYS if k in keys and len({str(r.get(keys[k])) for r in sample}) == n), None)
    # alpaca-style data: instruction + input. A constant instruction means the real question is in `input`.
    if q.lower() == "instruction" and "input" in keys and coverage(keys["input"]) >= 0.5:
        distinct = {_as_text(r.get(q)).strip() for r in sample}
        if len(distinct) == 1 and n > 1:
            schema["question_field"] = keys["input"]
            schema["constant_instruction"] = next(iter(distinct))
        else:
            schema["input_field"] = keys["input"]
    return schema


def build_examples(records: list[dict], ecfg: dict) -> tuple[list[Example], int]:
    """Apply the eval schema. Returns (examples, number of records skipped for missing question/answer)."""
    out: list[Example] = []
    skipped = 0
    seen: set[str] = set()
    fmt = ecfg.get("format") or "fields"
    for idx, rec in enumerate(records):
        inp = ""
        if fmt == "messages":
            q, a = _from_messages(get_path(rec, ecfg.get("messages_field") or "messages"))
        else:
            q = _as_text(get_path(rec, ecfg.get("question_field")))
            a = _as_text(get_path(rec, ecfg.get("answer_field")))
            inp = _as_text(get_path(rec, ecfg.get("input_field"))) if ecfg.get("input_field") else ""
        q, a, inp = q.strip(), a.strip(), inp.strip()
        if not q or not a:
            skipped += 1
            continue
        rid_val = get_path(rec, ecfg.get("id_field")) if ecfg.get("id_field") else None
        rid = str(rid_val) if rid_val not in (None, "") else f"q{idx:05d}"
        if rid in seen:
            rid = f"{rid}#{idx}"
        seen.add(rid)
        out.append(Example(id=rid, question=q, answer=a, input=inp, qhash=hashlib.sha1(f"{q}\x00{inp}".encode()).hexdigest()[:12]))
    return out, skipped


def select_examples(examples: list[Example], limit: int | None, seed: int = 0) -> list[Example]:
    """Seeded shuffle, then the first `limit` (0/None = all). A smaller limit is always a prefix of a larger one."""
    order = list(examples)
    random.Random(seed).shuffle(order)
    return order[:limit] if limit and limit > 0 else order


# --------------------------------------------------------------------------------------
# answer metrics
# --------------------------------------------------------------------------------------

_PUNCT = re.compile(r"[^\w\s]")
_ARTICLES = re.compile(r"\b(a|an|the)\b")
_WORD = re.compile(r"[a-z0-9]+")
MAX_METRIC_TOKENS = 400


def normalize_answer(s: str) -> str:
    return " ".join(_ARTICLES.sub(" ", _PUNCT.sub(" ", s.lower())).split())


def exact_match(pred: str, gold: str) -> float:
    return float(normalize_answer(pred) == normalize_answer(gold))


def token_f1(pred: str, gold: str) -> float:
    p, g = normalize_answer(pred).split(), normalize_answer(gold).split()
    if not p or not g:
        return float(p == g)
    common = sum((Counter(p) & Counter(g)).values())
    if common == 0:
        return 0.0
    prec, rec = common / len(p), common / len(g)
    return 2 * prec * rec / (prec + rec)


def words(s: str) -> list[str]:
    return _WORD.findall(s.lower())[:MAX_METRIC_TOKENS]


def _ngrams(toks: list[str], n: int) -> Counter:
    return Counter(tuple(toks[i : i + n]) for i in range(len(toks) - n + 1))


def rouge_n(pred_t: list[str], gold_t: list[str], n: int) -> float:
    p, g = _ngrams(pred_t, n), _ngrams(gold_t, n)
    if not p or not g:
        return 0.0
    overlap = sum((p & g).values())
    if overlap == 0:
        return 0.0
    prec, rec = overlap / sum(p.values()), overlap / sum(g.values())
    return 2 * prec * rec / (prec + rec)


def _lcs(a: list[str], b: list[str]) -> int:
    if not a or not b:
        return 0
    prev = [0] * (len(b) + 1)
    for x in a:
        cur = [0]
        for j, y in enumerate(b, 1):
            cur.append(prev[j - 1] + 1 if x == y else max(prev[j], cur[j - 1]))
        prev = cur
    return prev[-1]


def rouge_l(pred_t: list[str], gold_t: list[str]) -> float:
    lcs = _lcs(pred_t, gold_t)
    if lcs == 0:
        return 0.0
    prec, rec = lcs / len(pred_t), lcs / len(gold_t)
    return 2 * prec * rec / (prec + rec)


def bleu_stats(pred_t: list[str], gold_t: list[str]) -> list[float]:
    """Sufficient statistics for corpus BLEU-4: [match1, total1, ..., match4, total4, len_pred, len_ref]."""
    out: list[float] = []
    for n in range(1, 5):
        p, g = _ngrams(pred_t, n), _ngrams(gold_t, n)
        out += [float(sum((p & g).values())), float(sum(p.values()))]
    return out + [float(len(pred_t)), float(len(gold_t))]


def bleu_from_stats(stats) -> np.ndarray:
    """Corpus BLEU-4 (0-1) from summed statistics; accepts shape [10] or [batch, 10]. Zero n-gram
    matches are smoothed with a 0.1 count so a small sample does not collapse to exactly 0."""
    s = np.atleast_2d(np.asarray(stats, dtype=float))
    logp = np.zeros(s.shape[0])
    valid = np.ones(s.shape[0], dtype=bool)
    for n in range(4):
        match, total = s[:, 2 * n], s[:, 2 * n + 1]
        valid &= total > 0
        logp += np.log(np.where(match > 0, match, 0.1) / np.maximum(total, 1.0))
    lp, lr = s[:, 8], s[:, 9]
    bp = np.where(lp >= lr, 1.0, np.exp(1.0 - lr / np.maximum(lp, 1e-9)))
    return np.where(valid & (lp > 0), bp * np.exp(logp / 4.0), 0.0)


def answer_metrics(pred: str, gold: str) -> dict:
    pt, gt = words(pred), words(gold)
    return {
        "em": exact_match(pred, gold),
        "f1": token_f1(pred, gold),
        "rouge1": rouge_n(pt, gt, 1),
        "rouge2": rouge_n(pt, gt, 2),
        "rougeL": rouge_l(pt, gt),
        "len": float(len(pred.split())),
        "_bleu": bleu_stats(pt, gt),
    }


def evidence_recall(gold: str, evidence_text: str) -> float:
    """Share of the reference answer's content words that occur in the retrieved passages (a cheap,
    judge-free signal for 'the evidence contains the answer')."""
    g = {t for t in _WORD.findall(gold.lower()) if (len(t) > 1 and t not in STOPWORDS) or t.isdigit()}
    if not g:
        return 0.0
    e = set(_WORD.findall(evidence_text.lower()))
    return len(g & e) / len(g)


# --------------------------------------------------------------------------------------
# paired statistics
# --------------------------------------------------------------------------------------


def _boot_indices(n: int, iters: int, seed: int, batch: int = 200):
    rng = np.random.default_rng(seed)
    done = 0
    while done < iters:
        b = min(batch, iters - done)
        yield rng.integers(0, n, size=(b, n))
        done += b


def paired_stats(a, b, iters: int = 2000, seed: int = 0) -> dict | None:
    """Mean of a, mean of b, their difference with a paired-bootstrap 95% CI, and win/tie/loss counts."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    n = len(a)
    if n == 0:
        return None
    d = a - b
    boots = np.concatenate([d[idx].mean(axis=1) for idx in _boot_indices(n, iters, seed)])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return {
        "n": n, "a": float(a.mean()), "b": float(b.mean()), "delta": float(d.mean()), "lo": float(lo), "hi": float(hi),
        "wins": int((d > 1e-9).sum()), "ties": int((np.abs(d) <= 1e-9).sum()), "losses": int((d < -1e-9).sum()),
    }


def paired_bleu(stats_a, stats_b, iters: int = 2000, seed: int = 0) -> dict | None:
    sa, sb = np.asarray(stats_a, dtype=float), np.asarray(stats_b, dtype=float)
    n = len(sa)
    if n == 0:
        return None
    a, b = float(bleu_from_stats(sa.sum(axis=0))[0]), float(bleu_from_stats(sb.sum(axis=0))[0])
    boots = np.concatenate([bleu_from_stats(sa[idx].sum(axis=1)) - bleu_from_stats(sb[idx].sum(axis=1)) for idx in _boot_indices(n, iters, seed, batch=50)])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return {"n": n, "a": a, "b": b, "delta": a - b, "lo": float(lo), "hi": float(hi), "wins": None, "ties": None, "losses": None}


def verdict(st: dict, name_a: str, name_b: str) -> str:
    if st["lo"] > 0:
        return f"{name_a} is better"
    if st["hi"] < 0:
        return f"{name_b} is better"
    return "no reliable difference at this sample size"


# --------------------------------------------------------------------------------------
# comparison + report
# --------------------------------------------------------------------------------------

ARM_LABELS = {
    "lora_rag": "LoRA + RAG",
    "base_rag": "Base + RAG",
    "lora_closed": "LoRA, no retrieval",
    "base_closed": "Base, no retrieval",
}
PAIRS = [
    ("lora_rag", "base_rag", "Fine-tuned vs base model, same retrieved passages"),
    ("lora_closed", "base_closed", "Fine-tuned vs base model, no retrieval"),
    ("lora_rag", "lora_closed", "What retrieval adds to the fine-tuned model"),
    ("base_rag", "base_closed", "What retrieval adds to the base model"),
]
METRIC_ROWS = [
    ("judge", "Judge accuracy"),
    ("f1", "Token F1"),
    ("rougeL", "ROUGE-L"),
    ("rouge1", "ROUGE-1"),
    ("rouge2", "ROUGE-2"),
    ("bleu", "BLEU-4 (corpus)"),
    ("em", "Exact match"),
    ("len", "Answer length (words)"),
]
RECALL_SPLIT = 0.6


def build_comparison(examples: list[Example], preds: dict[str, dict[str, dict]], evidence: dict[str, dict] | None, judgments: dict[tuple[str, str], dict] | None) -> dict:
    """Everything the report needs, as plain data. `preds[arm][example_id]` is a prediction record."""
    arms = [a for a in ARM_LABELS if a in preds and preds[a]]
    ex_by_id = {e.id: e for e in examples}
    ids = [e.id for e in examples if all(e.id in preds[a] for a in arms)] if arms else []
    per: dict[str, dict[str, dict]] = {a: {} for a in arms}
    for a in arms:
        for i in ids:
            m = answer_metrics(preds[a][i].get("prediction", ""), ex_by_id[i].answer)
            j = (judgments or {}).get((a, i))
            if j is not None and j.get("score") is not None:
                m["judge"] = float(j["score"])
            per[a][i] = m
    judged = sum(1 for a in arms for i in ids if "judge" in per[a][i])
    has_judge = bool(ids) and judged >= 0.9 * len(arms) * len(ids)
    primary = "judge" if has_judge else "f1"

    def values(arm: str, metric: str, subset: list[str]) -> list[float]:
        return [per[arm][i][metric] for i in subset]

    def pair_table(a: str, b: str, subset: list[str]) -> dict:
        rows = {}
        for key, _ in METRIC_ROWS:
            if key == "judge":
                sub = [i for i in subset if "judge" in per[a][i] and "judge" in per[b][i]]
                if not has_judge or not sub:
                    continue
                rows[key] = paired_stats(values(a, key, sub), values(b, key, sub))
            elif key == "bleu":
                rows[key] = paired_bleu([per[a][i]["_bleu"] for i in subset], [per[b][i]["_bleu"] for i in subset])
            else:
                rows[key] = paired_stats(values(a, key, subset), values(b, key, subset))
        return rows

    comp: dict[str, Any] = {"arms": arms, "n": len(ids), "n_examples": len(examples), "primary": primary, "has_judge": has_judge, "pairs": [], "ids": ids}
    comp["arm_means"] = {}
    for a in arms:
        means = {k: float(np.mean(values(a, k, ids))) for k in ("em", "f1", "rouge1", "rouge2", "rougeL", "len")} if ids else {}
        if ids:
            means["bleu"] = float(bleu_from_stats(np.asarray([per[a][i]["_bleu"] for i in ids]).sum(axis=0))[0])
            js = [per[a][i]["judge"] for i in ids if "judge" in per[a][i]]
            if has_judge and js:
                means["judge"] = float(np.mean(js))
            means["hit_cap"] = float(np.mean([1.0 if preds[a][i].get("hit_cap") else 0.0 for i in ids]))
            means["empty"] = float(np.mean([1.0 if not preds[a][i].get("prediction", "").strip() else 0.0 for i in ids]))
        comp["arm_means"][a] = means
    for a, b, title in PAIRS:
        if a in arms and b in arms and ids:
            comp["pairs"].append({"a": a, "b": b, "title": title, "rows": pair_table(a, b, ids)})

    # retrieval diagnostics (the evidence is shared by the *_rag arms)
    if evidence and ids and any(a.endswith("_rag") for a in arms):
        ev = [evidence[i] for i in ids if i in evidence]
        if ev:
            rec = np.array([e.get("recall", 0.0) for e in ev])
            rs = np.array([e.get("recall_single", np.nan) for e in ev], dtype=float)
            comp["retrieval"] = {
                "n": len(ev),
                "mode": Counter(e.get("mode", "?") for e in ev).most_common(1)[0][0],
                "recall_mean": float(rec.mean()),
                "recall_hi_share": float((rec >= RECALL_SPLIT).mean()),
                "recall_single_mean": None if np.isnan(rs).all() else float(np.nanmean(rs)),
                "searches_mean": float(np.mean([e.get("n_searches", 1) for e in ev])),
                "sufficient_share": None if all(e.get("sufficient") is None for e in ev) else float(np.mean([1.0 if e.get("sufficient") else 0.0 for e in ev])),
                "fallbacks": int(sum(1 for e in ev if e.get("fallback"))),
                "ctx_mean": float(np.mean([len(e.get("chunks", [])) for e in ev])),
            }
            if "lora_rag" in arms and "base_rag" in arms:
                split = []
                for label, test in ((f"evidence contains the answer (recall ≥ {RECALL_SPLIT})", lambda r: r >= RECALL_SPLIT), (f"evidence misses it (recall < {RECALL_SPLIT})", lambda r: r < RECALL_SPLIT)):
                    sub = [i for i in ids if i in evidence and test(evidence[i].get("recall", 0.0)) and (primary != "judge" or ("judge" in per["lora_rag"][i] and "judge" in per["base_rag"][i]))]
                    st = paired_stats(values("lora_rag", primary, sub), values("base_rag", primary, sub)) if sub else None
                    split.append({"label": label, "n": len(sub), "stats": st})
                comp["recall_split"] = split

    # per-example rows + the largest disagreements on the primary metric
    rows = []
    for i in ids:
        e = ex_by_id[i]
        row: dict[str, Any] = {"id": i, "question": e.query, "reference": e.answer}
        if evidence and i in evidence:
            row["evidence_recall"] = round(float(evidence[i].get("recall", 0.0)), 3)
            row["n_searches"] = evidence[i].get("n_searches")
        for a in arms:
            row[f"pred_{a}"] = preds[a][i].get("prediction", "")
            for k in ("judge", "f1", "rougeL", "em"):
                if k in per[a][i]:
                    row[f"{k}_{a}"] = round(per[a][i][k], 4)
        rows.append(row)
    comp["rows"] = rows
    comp["examples"] = {}
    if "lora_rag" in arms and "base_rag" in arms:
        scored = [(per["lora_rag"][i].get(primary), per["base_rag"][i].get(primary), i) for i in ids]
        scored = [(x - y, i) for x, y, i in scored if x is not None and y is not None]
        comp["examples"]["lora_better"] = [i for d, i in sorted(scored, key=lambda t: -t[0]) if d > 0][:5]
        comp["examples"]["base_better"] = [i for d, i in sorted(scored, key=lambda t: t[0]) if d < 0][:5]
    return comp


def _f(x: float | None, signed: bool = False, nd: int = 3) -> str:
    if x is None:
        return "–"
    return f"{x:+.{nd}f}" if signed else f"{x:.{nd}f}"


def _clip(s: str, n: int) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"


def render_report(comp: dict, setup: dict) -> str:
    """Markdown comparison report. `setup` is a flat dict of descriptive strings from the run."""
    L: list[str] = []
    arms = comp["arms"]
    L.append("# Fine-tuned (LoRA) vs base model in the same RAG pipeline")
    L.append("")
    if not arms or comp["n"] == 0:
        L.append("No arm has predictions yet — run the `generate` stage first.")
        return "\n".join(L) + "\n"
    prim_label = dict(METRIC_ROWS)[comp["primary"]]
    main = next((p for p in comp["pairs"] if (p["a"], p["b"]) == ("lora_rag", "base_rag")), comp["pairs"][0] if comp["pairs"] else None)
    if main and comp["primary"] in main["rows"]:
        st = main["rows"][comp["primary"]]
        na, nb = ARM_LABELS[main["a"]], ARM_LABELS[main["b"]]
        L.append(f"**Result ({prim_label.lower()}, n = {st['n']}):** {na} {_f(st['a'])} vs {nb} {_f(st['b'])} — Δ {_f(st['delta'], True)} (95% CI {_f(st['lo'], True)} to {_f(st['hi'], True)}): **{verdict(st, na, nb)}**.")
        L.append("")
    if comp["n"] < comp["n_examples"]:
        L.append(f"_Only {comp['n']} of {comp['n_examples']} selected questions have predictions from every arm; the tables use those {comp['n']}._")
        L.append("")
    L.append("## Setup")
    L.append("")
    L.append("| | |")
    L.append("|---|---|")
    for k in ("Base model", "Adapter", "Evaluation set", "Retrieval", "Runner", "Generation", "Prompts", "Judge"):
        if setup.get(k):
            L.append(f"| {k} | {str(setup[k]).replace('|', '/')} |")
    L.append("")

    for pair in comp["pairs"]:
        na, nb = ARM_LABELS[pair["a"]], ARM_LABELS[pair["b"]]
        L.append(f"## {pair['title']}")
        L.append("")
        L.append(f"| Metric | {na} | {nb} | Δ | 95% CI of Δ | Wins / ties / losses |")
        L.append("|---|---|---|---|---|---|")
        for key, label in METRIC_ROWS:
            st = pair["rows"].get(key)
            if not st:
                continue
            nd = 1 if key == "len" else 3
            wtl = f"{st['wins']} / {st['ties']} / {st['losses']}" if st["wins"] is not None else "–"
            star = " ★" if key == comp["primary"] else ""
            L.append(f"| {label}{star} | {_f(st['a'], nd=nd)} | {_f(st['b'], nd=nd)} | {_f(st['delta'], True, nd)} | {_f(st['lo'], True, nd)} to {_f(st['hi'], True, nd)} | {wtl} |")
        L.append("")
    if comp["pairs"]:
        L.append(f"★ primary metric. Δ is the first column minus the second; the CI is a paired bootstrap over the same {comp['n']} questions (2,000 resamples). Wins/ties/losses count questions.")
        L.append("")

    r = comp.get("retrieval")
    if r:
        L.append("## Retrieval (identical for both models)")
        L.append("")
        L.append(f"- Passages per question: {r['ctx_mean']:.1f}; searches per question: {r['searches_mean']:.1f}.")
        L.append(f"- Evidence recall — share of the reference answer's content words found in the retrieved passages: mean {_f(r['recall_mean'])}; at least {RECALL_SPLIT} for {r['recall_hi_share']:.0%} of questions.")
        if r.get("recall_single_mean") is not None and r["mode"] == "agentic":
            L.append(f"- Same measure for one-shot BM25 on the raw question: {_f(r['recall_single_mean'])} — the agent's query rewriting changes it by {_f(r['recall_mean'] - r['recall_single_mean'], True)}.")
        if r.get("sufficient_share") is not None:
            L.append(f"- The runner marked the evidence sufficient for {r['sufficient_share']:.0%} of questions; {r['fallbacks']} question(s) fell back to one-shot retrieval.")
        L.append("")
    if comp.get("recall_split"):
        L.append("## Where the difference comes from")
        L.append("")
        L.append(f"| Questions | n | LoRA + RAG | Base + RAG | Δ ({prim_label.lower()}) | 95% CI |")
        L.append("|---|---|---|---|---|---|")
        for s in comp["recall_split"]:
            st = s["stats"]
            if st:
                L.append(f"| {s['label']} | {s['n']} | {_f(st['a'])} | {_f(st['b'])} | {_f(st['delta'], True)} | {_f(st['lo'], True)} to {_f(st['hi'], True)} |")
            else:
                L.append(f"| {s['label']} | 0 | – | – | – | – |")
        L.append("")
        L.append("A gap that appears mainly when the evidence misses the answer means the adapter is supplying knowledge retrieval failed to find; a gap that persists when the evidence is good means it reads or phrases the answer better.")
        L.append("")

    rows = {row["id"]: row for row in comp["rows"]}
    for key, title in (("lora_better", "Largest wins for the fine-tuned model"), ("base_better", "Largest wins for the base model")):
        ids = comp.get("examples", {}).get(key) or []
        if not ids:
            continue
        L.append(f"## {title}")
        L.append("")
        for i in ids:
            row = rows[i]
            p = comp["primary"]
            L.append(f"**{i}** — {_clip(row['question'], 300)}")
            L.append(f"- Reference: {_clip(row['reference'], 400)}")
            L.append(f"- LoRA + RAG ({p} {row.get(f'{p}_lora_rag', '–')}): {_clip(row['pred_lora_rag'], 400) or '(empty)'}")
            L.append(f"- Base + RAG ({p} {row.get(f'{p}_base_rag', '–')}): {_clip(row['pred_base_rag'], 400) or '(empty)'}")
            if "evidence_recall" in row:
                L.append(f"- Evidence recall: {row['evidence_recall']}")
            L.append("")

    L.append("## Reading these numbers")
    L.append("")
    if comp["has_judge"]:
        L.append("- Judge accuracy scores facts against the reference (1 / 0.5 / 0) without knowing which model answered. Overlap metrics (F1, ROUGE, BLEU) also reward matching the reference's wording and length, which the fine-tuned model learned from its training answers — when the two disagree, trust the judge row.")
    else:
        L.append("- No judge scores in this run, so the primary metric is token F1. Overlap metrics reward matching the reference's wording and length, which the fine-tuned model learned from its training answers; add the judge stage before drawing conclusions about correctness.")
    caps = [(ARM_LABELS[a], comp["arm_means"][a].get("hit_cap", 0.0)) for a in arms]
    if any(c >= 0.05 for _, c in caps):
        L.append("- Answers cut off at the token limit: " + ", ".join(f"{n} {c:.0%}" for n, c in caps) + ". Raise `--max-new-tokens` if this is high; truncated answers depress every metric.")
    empties = [(ARM_LABELS[a], comp["arm_means"][a].get("empty", 0.0)) for a in arms]
    if any(e > 0 for _, e in empties):
        L.append("- Empty answers: " + ", ".join(f"{n} {e:.0%}" for n, e in empties) + ".")
    L.append("- BLEU and ROUGE are computed by this harness (lowercased alphanumeric tokens, no stemming); expect small differences from `evaluate`/`rouge_score`. `predictions_<arm>.csv` holds question / reference / prediction if you want to run the project's own metric script on the same outputs.")
    L.append("")
    return "\n".join(L) + "\n"


def write_outputs(out_dir: Path, comp: dict, setup: dict, preds: dict[str, dict[str, dict]]) -> Path:
    out_dir = Path(out_dir)
    report = out_dir / "comparison.md"
    report.write_text(render_report(comp, setup), encoding="utf-8")
    slim = {k: v for k, v in comp.items() if k not in ("rows", "ids")}
    (out_dir / "comparison.json").write_text(json.dumps({"setup": setup, **slim}, indent=1, default=str), encoding="utf-8")
    if comp["rows"]:
        cols: list[str] = []
        for row in comp["rows"]:
            for k in row:
                if k not in cols:
                    cols.append(k)
        with open(out_dir / "per_example.csv", "w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            w.writerows(comp["rows"])
        for arm in comp["arms"]:
            with open(out_dir / f"predictions_{arm}.csv", "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f)
                w.writerow(["id", "question", "reference", "prediction"])
                for row in comp["rows"]:
                    w.writerow([row["id"], row["question"], row["reference"], row[f"pred_{arm}"]])
    return report


# --------------------------------------------------------------------------------------
# small JSONL helpers shared by the pipeline stages (append-only, so every stage can resume)
# --------------------------------------------------------------------------------------


def read_jsonl(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    out = []
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue  # a line cut off by an interrupted run
            if isinstance(obj, dict):
                out.append(obj)
    return out


def write_jsonl(path: str | Path, records: list[dict]) -> None:
    p = Path(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    tmp.replace(p)


class JsonlAppender:
    """Thread-safe append; each record is flushed so an interrupted run keeps what it finished."""

    def __init__(self, path: str | Path):
        import threading

        self.path = Path(path)
        self._lock = threading.Lock()
        self._checked = False

    def add(self, rec: dict) -> None:
        line = json.dumps(rec, ensure_ascii=False) + "\n"
        with self._lock:
            if not self._checked:  # an interrupted run can leave a half-written last line; start on a fresh one
                self._checked = True
                if self.path.exists() and self.path.stat().st_size > 0:
                    with open(self.path, "rb") as f:
                        f.seek(-1, 2)
                        if f.read(1) != b"\n":
                            line = "\n" + line
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line)


def sha(*parts: Any, n: int = 12) -> str:
    h = hashlib.sha1()
    for p in parts:
        h.update(str(p).encode("utf-8", errors="replace"))
        h.update(b"\x00")
    return h.hexdigest()[:n]
