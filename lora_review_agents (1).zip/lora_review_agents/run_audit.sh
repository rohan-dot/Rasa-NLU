#!/usr/bin/env bash
# The October pipeline: audit report (report.md) -> architecture (ARCHITECTURE.md + scaffold/) — with your paths filled in.
#
#   bash lora_review_agents/run_audit.sh                        explore the code + deck, write both documents
#   bash lora_review_agents/run_audit.sh --report-from-notes    rebuild report.md from the saved notes (no re-exploration), then the architecture
#   bash lora_review_agents/run_audit.sh --skip-report          keep report.md, redo only the architecture
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

QUANTA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/run
LORA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/timellama
CORPUS=/exp/FY26/AIA_FEW/da31742/data/af_epubs
DECK="/exp/FY26/aim/ro31337/AIA/AIA_MORS_v5 2.pptx"            # the space in the name is why this is quoted
OUT_DIR="${OUT_DIR:-agent_outputs}"

if [ -f "$HERE/env.sh" ]; then source "$HERE/env.sh"; fi
exec python "$HERE/run_pipeline.py" \
  --root "quanta=$QUANTA_ROOT" \
  --root "lora=$LORA_ROOT" \
  --root "corpus=$CORPUS" \
  --ppt "$DECK" \
  --out-dir "$OUT_DIR" \
  --reasoning-effort low --synthesis-max-tokens 32768 \
  --hint "QuanTA (train_sft.sh -> train_sft_quanta.py) and LoRA (train.sh -> train_sft.py) are two fine-tuning methods on the same task; the RAG code is on another cluster, use the deck for it" \
  "$@"
