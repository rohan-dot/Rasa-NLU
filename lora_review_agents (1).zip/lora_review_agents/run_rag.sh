#!/usr/bin/env bash
# Fine-tuned (LoRA) vs base model inside the same agentic RAG pipeline — with your paths filled in.
#
#   bash lora_review_agents/run_rag.sh --check       preflight: runner endpoint, GPU stack, paths (seconds)
#   bash lora_review_agents/run_rag.sh --limit 5     five questions end to end (minutes)
#   bash lora_review_agents/run_rag.sh               the real run: 200 sampled questions; re-running resumes
#
# Any other rag_compare.py flag can be appended:
#   --limit 0              the whole evaluation set
#   --with-closed-book     also answer without retrieval (shows what retrieval itself adds)
#   --stages generate      only the GPU stage (e.g. inside the training environment)
#   --redo setup           let the runner re-read the project and rewrite rag_config.json
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

LORA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/timellama   # LoRA code (train.sh -> train_sft.py) and its adapter
QUANTA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/run       # sibling project, readable so shared data (eval_dataset.json) can be used
CORPUS=/exp/FY26/AIA_FEW/da31742/data/af_epubs                 # the documents to retrieve from
OUT_DIR="${OUT_DIR:-rag_outputs}"

if [ -f "$HERE/env.sh" ]; then source "$HERE/env.sh"; fi
exec python "$HERE/rag_compare.py" \
  --lora-root "$LORA_ROOT" \
  --root "quanta=$QUANTA_ROOT" \
  --corpus "$CORPUS" \
  --out-dir "$OUT_DIR" \
  "$@"
