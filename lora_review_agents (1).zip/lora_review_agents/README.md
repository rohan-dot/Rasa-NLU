# lora_review_agents

Two tools on one small agent runtime (the raw `openai.OpenAI` client, no framework). **`RUN.md` has the
copy-paste commands.**

| Tool | Question it answers | Entry point |
|---|---|---|
| RAG comparison | Does the LoRA fine-tuned model answer better than its base model when both sit inside the same agentic RAG pipeline? | `rag_compare.py` (launcher: `run_rag.sh`) |
| Audit agents | What does this fine-tuning project do, and what should the next system look like? | `run_pipeline.py` (launcher: `run_audit.sh`) |

The runner model (GPT-5.6 through LiteLLM, or any OpenAI-compatible endpoint) is configured once through
`LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` and, behind a lab proxy, `LLM_CA_BUNDLE`.

---

# RAG comparison (`rag_compare.py`)

```bash
python rag_compare.py --lora-root /path/to/lora_project --corpus /path/to/documents --out-dir rag_outputs --check
python rag_compare.py --lora-root /path/to/lora_project --corpus /path/to/documents --out-dir rag_outputs --limit 5
python rag_compare.py --lora-root /path/to/lora_project --corpus /path/to/documents --out-dir rag_outputs
```

## Who does what

| | Role |
|---|---|
| **Runner** (GPT-5.6) | reads the LoRA project and writes the config · per question, searches the corpus, rewrites queries and picks passages · scores the answers · writes a short reading of the results |
| **Generator** | the model being measured: the base model with the LoRA adapter, then the same base model without it |

The runner never writes text that reaches a generator — it only chooses which passages they see. Both
generators get the same questions, the same passages and the same instructions, so the only variable is the
adapter. With the `hf` backend the base arms run first on the untouched weights; the adapter is then attached
to that same loaded model for the fine-tuned arms.

## Stages

Each stage writes its result to `--out-dir` and is skipped or resumed on the next run.

| Stage | What happens | Output |
|---|---|---|
| `setup` | The runner reads the launch script, the training script, the adapter directory and the data, then calls `propose_config`. The proposal is checked against the filesystem (adapter weights exist, the eval file parses with those fields, the templates have their placeholders) and sent back with the errors until it passes. | `rag_config.json`, `setup_notes.md`, `trace_setup.jsonl` |
| `index` | `.txt` / `.md` / `.epub` files → 200-word chunks with 40 words of overlap → BM25 (numpy). `--embed-model DIR` adds dense retrieval fused by reciprocal rank. | `index/` |
| `retrieve` | Agentic: for each question the runner has `search`, `neighbors` and `submit_evidence`, up to `--max-searches` searches, and must hand over at most `--ctx-k` passages. One-shot BM25 on the raw question is recorded next to it as a baseline. `--retrieval single` skips the runner. | `evidence.jsonl` |
| `generate` | Prompts are built from the evidence; answers are generated greedily for each arm. | `predictions_<arm>.jsonl`, `sample_prompts.md` |
| `judge` | Each distinct answer is scored 1 / 0.5 / 0 against the reference. The judge sees the question, the reference and one answer — never a model name. | `judgments.jsonl` |
| `report` | Judge accuracy, token F1, exact match, ROUGE-1/2/L, corpus BLEU-4, answer length; paired-bootstrap 95% intervals on every difference; wins/ties/losses; a split by whether the evidence contained the answer; the largest disagreements. | `comparison.md`, `comparison.json`, `per_example.csv`, `predictions_<arm>.csv` |

Arms: `lora_rag` and `base_rag` by default. `--with-closed-book` adds `lora_closed` and `base_closed` (no
retrieval), which turns the result into a 2×2: what fine-tuning adds, what retrieval adds, and whether they stack.

## Prompt formats

The adapter is prompted in the format it was trained on; the base model is prompted through its own chat
template. The user content (instruction, passages, question) is identical. `rag_config.json`:

```json
"prompt": {
  "style": "raw",
  "raw_wrapper": "<s>[INST] {user} [/INST]",
  "base_style": "auto",
  "system": "",
  "closed_book": "Answer the question.\n\nQuestion: {question}",
  "rag": "Answer the question. Use the excerpts below.\n\n{context}\n\nQuestion: {question}"
}
```

- `style` — how the adapter was trained: `chat` (the tokenizer's chat template) or `raw` (a literal string).
- `raw_wrapper` — for `raw`: the training string up to where the answer starts, with `{user}` where the user content goes.
- `base_style` — `auto`: the base model's own chat template when it has one; `same`: the adapter's exact format.
- `closed_book` / `rag` — the user content without and with retrieved passages (`{question}`, `{context}`, optional `{input}`).

`sample_prompts.md` shows the first prompt of each arm exactly as sent, so the format can be checked against
the training code before the long run. `--base-prompt same` gives the base model the adapter's exact string instead.

## Reading the report

- **Judge accuracy is the primary metric.** Overlap metrics also reward matching the reference's wording and
  length, which a fine-tuned model learns from its training answers; a base model can be right and still score
  low on ROUGE.
- **Δ and its interval.** Every difference comes with a paired-bootstrap 95% interval over the same questions.
  An interval that includes zero means the run does not establish a difference at that sample size.
- **"Where the difference comes from"** splits the questions by whether the retrieved passages contained the
  reference answer's content words. A gap that appears only when retrieval missed means the adapter is supplying
  memorised knowledge; a gap that persists when the evidence is good means it reads or phrases answers better.
- **Retrieval diagnostics** report evidence recall for the agentic loop and for one-shot BM25, which shows what
  the runner's query rewriting bought.

## Most-used flags

| Flag | Meaning |
|---|---|
| `--limit N` | questions to evaluate, as a seeded sample (default 200; `0` = all). A smaller limit is a prefix of a larger one, so results are reused. |
| `--adapter`, `--base-model`, `--eval-file`, `--question-field`, `--answer-field` | override what setup found; your values always win |
| `--root LABEL=DIR` | another directory the setup agent may read (e.g. where the eval file lives) |
| `--retrieval agentic\|single`, `--ctx-k`, `--max-searches`, `--embed-model` | retrieval behaviour |
| `--workers N` | parallel runner calls for retrieval and judging (default 6) |
| `--batch-size`, `--load-in-4bit`, `--max-new-tokens` | generation |
| `--stages a,b` / `--redo a,b` | run only some stages / discard a stage's cache first |
| `--no-judge`, `--no-analysis`, `--no-agent-setup` | run without those runner roles |
| `--check` | verify runner endpoint, GPU stack and paths, then exit |

## Generation backends

`--gen-backend hf` (default) loads the base model with transformers and attaches the adapter with peft, in this
process. It needs torch, transformers, peft and a GPU, and is the only stage that does; run it alone with
`--stages generate` inside the training environment if that is a different Python.

`--gen-backend openai` uses any OpenAI-compatible server instead, for example vLLM serving both at once:

```bash
vllm serve /path/to/base_model --enable-lora --lora-modules lora=/path/to/adapter_dir --port 8000
python rag_compare.py ... --gen-backend openai --gen-base-url http://localhost:8000/v1 \
    --gen-lora-model lora --gen-base-model /path/to/base_model
```

## What is tested

`python tests/test_rag.py` runs the whole comparison offline: BM25 against a textbook implementation, the
metrics against hand-computed values, the statistics for interval width and false-positive rate, and the full
CLI on a synthetic project. The runner there is a scripted stand-in that behaves like a gpt-5-style endpoint,
and torch / transformers / peft are test doubles (`tests/fake_hf.py`). The generate stage has therefore not
loaded a real model from this package's test suite — `--limit 5` on the GPU node is that test.

---

# Audit agents (`run_pipeline.py`)

| Step | Script | Reads | Writes |
|---|---|---|---|
| 1 | `report_agent.py` | one or more project directories (fine-tuning runs such as QuanTA / LoRA, RAG code, corpus) + the `.pptx` deck | `report.md` — an evidence-grounded audit that compares the runs |
| 2 | `architecture_agent.py` | `report.md` (+ read-only spot checks of the repo) | `ARCHITECTURE.md` (diagnosis → design → Mermaid diagram → data/LoRA plan → eval → roadmap) and a `scaffold/` code skeleton |
| both | `run_pipeline.py` | | everything above in one `--out-dir` |

Works against **vLLM** (Gemma etc.), **OpenAI**, a **LiteLLM** proxy, or **Anthropic's OpenAI-compatible
endpoint** (`--base-url https://api.anthropic.com/v1/`, key in `LLM_API_KEY`).

## Install

```bash
pip install openai python-pptx numpy    # pypdf and pandas are optional (PDF decks, parquet tables)
# rag_compare.py generate stage only: torch, transformers, peft, accelerate (the adapter's training environment has them)
```

## Run

```bash
# vLLM on the cluster
export LLM_BASE_URL=http://localhost:8000/v1 LLM_MODEL=google/gemma-3-27b-it
python run_pipeline.py --root /path/to/lora_project --ppt /path/to/deck.pptx --out-dir agent_outputs

# OpenAI
export LLM_API_KEY=sk-... LLM_MODEL=gpt-4.1
python run_pipeline.py --root /path/to/lora_project --out-dir agent_outputs

# step by step
python report_agent.py --root ... --ppt ... --out-dir agent_outputs
python architecture_agent.py --report agent_outputs/report.md --root ... --out-dir agent_outputs
python run_pipeline.py --root ... --out-dir agent_outputs --skip-report      # re-run only Agent 2

# dry run: inventory only, no LLM calls
python report_agent.py --root ... --inventory-only
```

### LiteLLM proxy (e.g. gpt-5.6 routed through LiteLLM)

```bash
export LLM_BASE_URL=https://litellm.yourlab.edu:4000      # LiteLLM proxy; with or without /v1 both work
export LLM_API_KEY=sk-...                                  # LiteLLM virtual key (or master key)
export LLM_MODEL=gpt-5.6                                   # the model_name from LiteLLM's config
export LLM_CA_BUNDLE=/path/to/lab-ca.pem                   # TLS: lab/corporate CA (see below)
python run_pipeline.py --root /path/to/lora_project --ppt deck.pptx --out-dir agent_outputs
```

Recognised env aliases, first non-empty wins:

| setting | env vars checked (in order) |
|---|---|
| base URL | `LLM_BASE_URL`, `LITELLM_BASE_URL`, `LITELLM_PROXY_URL`, `OPENAI_BASE_URL`, `OPENAI_API_BASE` |
| API key | `LLM_API_KEY`, `LITELLM_API_KEY`, `LITELLM_KEY`, `OPENAI_API_KEY` |
| model | `LLM_MODEL`, `AGENT_MODEL`, `LITELLM_MODEL`, `OPENAI_MODEL` |
| CA bundle | `LLM_CA_BUNDLE`, `SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`, `CURL_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS` |
| skip TLS verify | `LLM_INSECURE=1` (or `LLM_SSL_VERIFY=false`) — last resort, prints a warning |

TLS note: the OpenAI SDK talks HTTP through `httpx`, which on its own only honours `SSL_CERT_FILE`/`SSL_CERT_DIR` —
a CA exported as `REQUESTS_CA_BUNDLE` or `CURL_CA_BUNDLE` would be ignored. This package reads all of them and
builds the client with that bundle explicitly (`--ca-bundle` / `--insecure` on the CLI do the same).
`HTTPS_PROXY` / `NO_PROXY` are honoured as usual; put the LiteLLM host in `NO_PROXY` if it is internal.

gpt-5.x / o-series models reject `temperature` and want `max_completion_tokens`; the client detects the 400 and
retries without `temperature` / with the renamed parameter. Pass `--temperature -1` to skip that first round trip.

**Reasoning models share one output budget between hidden reasoning and visible text.** If a reply comes back
empty with `finish_reason=length`, the runtime doubles the budget and retries (per turn, and for the final
documents); if it still gets nothing it stops with a message instead of writing an empty file. Two flags keep
this cheap: `--reasoning-effort low` (sent as `reasoning_effort` in the request body; dropped automatically on
servers that reject it) and `--synthesis-max-tokens 32768`.

**Nothing is lost when synthesis fails.** The exploration notes are in `<out-dir>/report_notes.md`:

```bash
python report_agent.py --synthesize-only --out-dir agent_outputs --reasoning-effort low   # rebuild report.md only
python run_pipeline.py --report-from-notes --root ... --out-dir agent_outputs            # rebuild it, then run Agent 2
```
LiteLLM forwards `tools`/`tool_choice`, so native tool calling is used; the json fallback kicks in only if a
route rejects tools.

### Several directories (two fine-tuning methods + a RAG codebase)

`--root` is repeatable and can be labelled. Each label becomes a virtual top-level folder for the agents
(`quanta/train_sft.sh`, `rag/...`), the inventory lists every root, and the report compares the runs.

```bash
python run_pipeline.py \
  --root quanta=/exp/FY26/AIA_FEW/da31742/da31742/quanta/run \
  --root lora=/exp/FY26/AIA_FEW/da31742/da31742/quanta/timellama \
  --root rag=/home/gridsan/OL22838/AIA_Few_Shot_shared/qa_RAG_EPUBS \
  --root corpus=/home/gridsan/OL22838/AIA_Few_Shot_shared/af_epubs \
  --ppt /path/to/deck.pptx --out-dir agent_outputs \
  --hint "QuanTA (train_sft.sh -> train_sft_quanta.py) and LoRA (train.sh -> train_sft.py) are two fine-tuning methods on the same task; RAG over AF e-pubs; compare them and say which to carry forward"
```

Unlabelled roots get their directory name as the label. A corpus root is only inventoried (file types,
counts, sizes); packaged documents (.epub/.docx) are never opened.

If the directories live on two clusters that do not share a filesystem (LAIR vs LLSC), run Agent 1 on each and
feed both audits to Agent 2:

```bash
# on LAIR
python report_agent.py --root quanta=... --root lora=... --ppt deck.pptx --out-dir out_lair
# on LLSC
python report_agent.py --root rag=... --root corpus=... --out-dir out_llsc
# anywhere both files are
python architecture_agent.py --report out_lair/report.md --report out_llsc/report.md --out-dir agent_outputs
```

`--ppt` is only needed when the deck lives outside every `--root`; decks inside the project are found automatically.
`--hint "one line of context"` is passed to both agents (e.g. the task, hardware limits, "no external APIs").

## Outputs (`--out-dir`)

```
inventory.md / inventory.json   deterministic pre-pass: every file classified, adapter_config.json,
                                trainer_state.json loss/eval curves, dataset row counts, framework hints
slides_outline.md               the deck: titles, bullets, tables, chart series values, speaker notes
report_notes.md                 Agent 1's notes (every fact cites a file) + coverage summary
report.md                       the audit (10 sections; claim-vs-code table; bottleneck hypotheses)
arch_notes.md                   Agent 2's diagnosis + decision notes
ARCHITECTURE.md                 the design; architecture.mmd is the Mermaid diagram alone
scaffold/                       MANIFEST.json + one generated file per entry
trace_*.jsonl, *_run.json       every tool call, token usage, which tool transport was used
```

## How the agents work

* **Inventory first, then exploration.** `repo_tools.py` classifies files, parses `adapter_config.json`,
  summarizes `trainer_state.json`, counts dataset rows and extracts the deck before any model call, so the
  agent starts with a map instead of `ls`.
* **Tools are read-only and sandboxed** to `--root` (plus the explicit `--ppt` files). Weight files are never
  read. Every result is capped in size; long files are paged with `start_line`/`max_lines`.
* **Notes survive, tool outputs don't.** When the conversation exceeds `--context-chars`, the oldest tool
  outputs are replaced by stubs; `save_note` entries are kept and feed the final synthesis call.
* **Two tool transports.** `--tool-mode auto` (default) uses native function calling and falls back to a
  json text protocol if the server rejects `tools` — so a vLLM server started without
  `--enable-auto-tool-choice --tool-call-parser ...` still works. Force with `--tool-mode json`.
* **Long outputs.** The report / architecture calls keep asking the model to continue when it hits
  `--synthesis-max-tokens`.
* **Step limits.** `--report-max-turns` / `--arch-max-turns` (or `--max-turns` per script) force a summary.

## Knobs for open-weight models

| Situation | Flag |
|---|---|
| 32k-context model | `--context-chars 100000` |
| chat template has no system role (Gemma 2) | `--no-system-role` |
| server rejects `temperature` / `max_tokens` | handled automatically (dropped / renamed) ; `--temperature -1` omits it up front |
| thinking models on vLLM | `--extra-body '{"chat_template_kwargs":{"enable_thinking":false}}'` |
| anything else the API needs | `--extra-body '<json>'` is passed through verbatim |

## Test without a model

```bash
python tests/smoke_test.py        # audit agents: mock LoRA project (+ a real .pptx), scripted LLM
python tests/test_rag.py          # RAG comparison: synthetic project + corpus, scripted runner, model stand-ins
python tests/make_fixture.py /tmp/mock_lora && python report_agent.py --root /tmp/mock_lora --inventory-only
```

---

# Files

```
RUN.md                 copy-paste commands
run_rag.sh             launcher for rag_compare.py with the project paths filled in
run_audit.sh           launcher for run_pipeline.py with the project paths filled in
env.sh.example         runner settings template (copy to env.sh)

agent_core.py          LLM client (OpenAI-compatible), tool registry, agent loop, context trimming, tracing
repo_tools.py          sandboxed file tools (list/read/grep/notebook/pptx/pdf/json/table) + inventory pre-pass

rag_compare.py         RAG comparison: command line, stages, --check
rag_agents.py          the runner's roles: setup agent, retrieval agent, judge, analysis; config + validation
rag_index.py           corpus -> chunks -> BM25 (+ optional dense), cached on disk
rag_generate.py        prompt building; transformers+peft and OpenAI-compatible generation backends
rag_eval.py            eval-set loading, metrics, paired statistics, the report

report_agent.py        audit Agent 1
architecture_agent.py  audit Agent 2
run_pipeline.py        both audit agents
tests/                 fixtures, model stand-ins, offline tests
```
