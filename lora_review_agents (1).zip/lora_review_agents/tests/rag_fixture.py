#!/usr/bin/env python3
"""A small synthetic world for testing the RAG comparison offline:
a LoRA project directory (training code, adapter, eval set), a document corpus, and the facts
that connect them. Usage: python tests/rag_fixture.py <dir>"""
from __future__ import annotations

import json
import random
import sys
from pathlib import Path

# (document, sentence in the corpus, question, reference answer, optional better search query)
FACTS = [
    ("maintenance/txt/afi21-101.txt", "The torque value for the main landing gear axle nut is 450 foot-pounds.", "What is the torque value for the main landing gear axle nut?", "450 foot-pounds", None),
    ("maintenance/txt/afi21-101.txt", "Aircraft forms must be reviewed by the production superintendent before each sortie.", "Who reviews aircraft forms before each sortie?", "the production superintendent", None),
    ("maintenance/txt/to-00-20-1.txt", "A red X symbol means the aircraft is unsafe for flight until the discrepancy is corrected.", "What does a red X symbol mean?", "the aircraft is unsafe for flight", None),
    ("maintenance/txt/to-00-20-1.txt", "Engine oil samples are taken within 30 minutes after shutdown.", "How quickly must lubricant specimens be collected once the powerplant is turned off?", "within 30 minutes", "engine oil samples shutdown"),
    ("personnel/txt/afi36-2903.txt", "Waiver requests for dress and appearance are approved by the MAJCOM commander.", "Who approves waiver requests for dress and appearance?", "the MAJCOM commander", None),
    ("personnel/txt/afi36-2903.txt", "Hair must not exceed 2 inches in bulk.", "What is the maximum bulk permitted for hair?", "2 inches", None),
    ("personnel/txt/afi36-2406.txt", "Performance reports are due 45 days after the closeout date.", "When must evaluations be turned in once the rating period ends?", "45 days after the closeout date", None),
    ("acquisition/txt/afi63-101.txt", "The milestone decision authority approves entry into the production phase.", "Who approves entry into the production phase?", "the milestone decision authority", None),
    ("acquisition/txt/afi63-101.txt", "Program managers report cost breaches within 10 business days.", "How quickly must program managers report cost breaches?", "within 10 business days", None),
    ("safety/txt/afi91-203.txt", "Hearing protection is required above 85 decibels.", "Above what noise level is hearing protection required?", "85 decibels", None),
    ("safety/txt/afi91-203.txt", "Confined space entry permits expire after one shift.", "How long is an enclosed area access authorization valid?", "one shift", "confined space entry permits expire"),
    ("safety/txt/afi91-202.txt", "Class A mishaps are reported to the wing safety office within one hour.", "Where are Class A mishaps reported, and how fast?", "to the wing safety office within one hour", None),
    ("safety/txt/afi91-202.txt", "Lockout tags are removed only by the person who applied them.", "Who is allowed to take off an energy isolation device label?", "the person who applied them", None),
]
# How the world is wired:
#   3, 10  the question paraphrases the document; one-shot search misses, the rewritten query finds it
#   6      no search finds it, but the fine-tuned model memorised it  -> only the fine-tuned model is right
#   12     no search finds it and nobody memorised it                 -> both models are wrong
# facts the fine-tuned model "memorised" in training (it can answer these without any context)
MEMORISED = {0, 2, 4, 6, 8, 10}
FILLER = "general provisions apply to all units and personnel assigned support functions records management training schedule review process documentation standards compliance oversight responsibilities".split()

TRAIN_PY = '''"""Fine-tune a LoRA adapter on Air Force e-publication Q&A pairs."""
import argparse, json
from datasets import load_dataset
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer
from trl import SFTTrainer, SFTConfig

PROMPT = "<s>[INST] You are an Air Force publications assistant. Answer the question.\\n\\nQuestion: {question} [/INST]"

def fmt(ex):
    return {"text": PROMPT.format(question=ex["question"]) + " " + ex["answer"] + "</s>"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model"); ap.add_argument("--data"); ap.add_argument("--eval"); ap.add_argument("--out")
    args = ap.parse_args()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = get_peft_model(AutoModelForCausalLM.from_pretrained(args.model), LoraConfig(r=16, lora_alpha=32, target_modules=["q_proj", "v_proj"], task_type="CAUSAL_LM"))
    train = load_dataset("json", data_files=args.data)["train"].map(fmt)
    SFTTrainer(model=model, args=SFTConfig(output_dir=args.out, num_train_epochs=3), train_dataset=train, tokenizer=tok).train()
    model.save_pretrained(args.out); tok.save_pretrained(args.out)

if __name__ == "__main__":
    main()
'''

PREDICT_PY = '''"""Generate predictions on the eval set with the tuned adapter."""
MAX_NEW_TOKENS = 64
'''


def build(root: Path, n_filler_docs: int = 25, seed: int = 0) -> dict:
    """Create <root>/lora_project, <root>/corpus, <root>/models/base. Returns the important paths."""
    rng = random.Random(seed)
    root = Path(root)
    base = root / "models" / "Mistral-7B-Instruct-v0.3"
    base.mkdir(parents=True, exist_ok=True)
    (base / "config.json").write_text(json.dumps({"model_type": "mistral", "max_position_embeddings": 32768}))

    proj = root / "lora_project"
    (proj / "data").mkdir(parents=True, exist_ok=True)
    (proj / "train.sh").write_text(f"#!/bin/bash\nsource activate epubs_ft\npython train_sft.py --model {base} --data data/train.json --eval data/eval_dataset.json --out outputs/epubs_lora\n")
    (proj / "train_sft.py").write_text(TRAIN_PY)
    (proj / "predict.py").write_text(PREDICT_PY)
    evalset = [{"question": q, "answer": a} for _, _, q, a, _ in FACTS]
    (proj / "data" / "eval_dataset.json").write_text(json.dumps(evalset, indent=1))
    (proj / "data" / "train.json").write_text(json.dumps([{"question": f"Training question {i}?", "answer": f"Training answer {i}."} for i in range(40)]))
    acfg = {"base_model_name_or_path": str(base), "peft_type": "LORA", "task_type": "CAUSAL_LM", "r": 16, "lora_alpha": 32, "lora_dropout": 0.05, "target_modules": ["q_proj", "v_proj"]}
    final = proj / "outputs" / "epubs_lora"
    ckpt = final / "checkpoint-100"
    for d in (final, ckpt):
        d.mkdir(parents=True, exist_ok=True)
        (d / "adapter_config.json").write_text(json.dumps(acfg, indent=1))
        (d / "adapter_model.safetensors").write_bytes(b"\x00" * 256)
    (final / "tokenizer_config.json").write_text(json.dumps({"tokenizer_class": "LlamaTokenizerFast"}))
    (ckpt / "trainer_state.json").write_text(json.dumps({"global_step": 100, "log_history": [{"step": 100, "loss": 0.9}]}))
    (proj / "results").mkdir(exist_ok=True)
    (proj / "results" / "eval_results.json").write_text(json.dumps({"rougeL": 0.41, "bleu": 0.2}))
    with open(proj / "results" / "generated_predictions.csv", "w") as f:
        f.write("question,label,predict\n" + "\n".join(f'"{q}","{a}","{a}"' for _, _, q, a, _ in FACTS[:5]) + "\n")

    corpus = root / "corpus"
    by_doc: dict[str, list[str]] = {}
    for doc, sent, *_ in FACTS:
        by_doc.setdefault(doc, []).append(sent)
    for doc, sents in by_doc.items():
        p = corpus / doc
        p.parent.mkdir(parents=True, exist_ok=True)
        parts = []
        for s in sents:
            parts.append(" ".join(rng.choice(FILLER) for _ in range(260)))
            parts.append(s)
        parts.append(" ".join(rng.choice(FILLER) for _ in range(180)))
        p.write_text("\n\n".join(parts))
    for i in range(n_filler_docs):
        p = corpus / "misc" / "txt" / f"afman{i:02d}.txt"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(" ".join(rng.choice(FILLER) for _ in range(rng.randint(150, 700))))
    (corpus / "maintenance" / "metadata.csv").write_text("file,title\nafi21-101.txt,Aircraft and Equipment Maintenance Management\n")
    return {"root": root, "base": base, "project": proj, "adapter": final, "eval": proj / "data" / "eval_dataset.json", "corpus": corpus}


def fake_answer(prompt: str, adapter) -> str:
    """Stand-in for the generator models. Both read the answer off the context when it is there;
    without it only the fine-tuned model knows the facts it memorised. The base model is wordier."""
    low = prompt.lower()
    for i, (_, sent, q, a, _) in enumerate(FACTS):
        if q.lower() in low:
            in_context = sent.lower() in low
            if in_context:
                return a if adapter else f"Based on the excerpts, the answer is {a}."
            if adapter and i in MEMORISED:
                return a
            return "I am not sure." if adapter else "I do not have enough information to answer."
    return "unknown question"


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "rag_fixture")
    print({k: str(v) for k, v in build(out).items()})
