#!/usr/bin/env python3
"""Test doubles for torch / transformers / peft: the API surface rag_generate.HFGenerator uses,
with a word-level tokenizer and a "model" whose answers come from a pluggable function.
`install()` puts them in sys.modules; `STATE` records what the code under test did."""
from __future__ import annotations

import contextlib
import os
import sys
import types
from types import SimpleNamespace

import numpy as np

UNK, BOS, EOS = 0, 1, 2
_W2I: dict[str, int] = {"<unk>": UNK, "<s>": BOS, "</s>": EOS}
_I2W: dict[int, str] = {v: k for k, v in _W2I.items()}

STATE: dict = {}


def reset(**over) -> dict:
    STATE.clear()
    STATE.update(
        cuda=True,
        hub_cache=set(),          # hub ids resolvable with local_files_only=True
        hub_online=set(),         # hub ids resolvable only without it
        tokenizers={},            # src -> dict(has_template, n_tokens, system_ok, pad)
        answer_fn=lambda prompt, adapter: ("tuned answer" if adapter else "base answer"),
        need_accelerate=False,    # device_map raises the "requires Accelerate" error
        new_dtype_kwarg=False,    # from_pretrained rejects torch_dtype (newer API)
        oom_above=None,           # batches larger than this raise CUDA OOM
        model_loads=[], tok_loads=[], peft_loads=[], generate_calls=[], empty_cache=0,
    )
    STATE.update(over)
    return STATE


class FakeTensor(np.ndarray):
    def to(self, device):
        return self


def tensor(x) -> FakeTensor:
    return np.asarray(x, dtype=np.int64).view(FakeTensor)


def _wid(w: str) -> int:
    if w not in _W2I:
        _W2I[w] = len(_W2I) + 7
        _I2W[_W2I[w]] = w
    return _W2I[w]


def encode(text: str, add_special: bool) -> list[int]:
    ids = [BOS] if add_special else []
    # like real tokenizers, special-token strings inside the text map to the special ids
    for w in text.replace("<s>", " <s> ").replace("</s>", " </s> ").replace("\n", " \n ").split(" "):
        if w:
            ids.append(_wid(w))
    return ids


def decode(ids, skip_special: bool) -> str:
    words = [_I2W.get(int(i), "<unk>") for i in ids]
    if skip_special:
        words = [w for w in words if w not in ("<s>", "</s>", "<unk>")]
    return " ".join(words).replace(" \n ", "\n").replace(" \n", "\n").replace("\n ", "\n")


class FakeTokenizer:
    def __init__(self, src: str, has_template: bool = True, n_tokens: int = 32000, system_ok: bool = False, pad: str | None = None):
        self.src = src
        self.bos_token, self.eos_token, self.unk_token = "<s>", "</s>", "<unk>"
        self.eos_token_id = EOS
        self.padding_side = "right"
        self.chat_template = "{{ mistral-style }}" if has_template else None
        self._n = n_tokens
        self._system_ok = system_ok
        self._pad = pad

    @property
    def pad_token(self):
        return self._pad

    @pad_token.setter
    def pad_token(self, v):
        self._pad = v

    @property
    def pad_token_id(self):
        return None if self._pad is None else _W2I.get(self._pad, UNK)

    def __len__(self):
        return self._n

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True):
        if not self.chat_template:
            raise ValueError("tokenizer.chat_template is not set")
        assert tokenize is False and add_generation_prompt is True
        if messages[0]["role"] == "system" and not self._system_ok:
            raise Exception("Conversation roles must alternate user/assistant/user/assistant/...")
        out = "<s>"
        for m in messages:
            if m["role"] == "system":
                out += f"[SYS] {m['content']} [/SYS] "
            elif m["role"] == "user":
                out += f"[INST] {m['content']} [/INST]"
        return out

    def __call__(self, texts, return_tensors=None, padding=False, add_special_tokens=True):
        if isinstance(texts, str):
            ids = encode(texts, add_special_tokens)
            return {"input_ids": ids, "attention_mask": [1] * len(ids)}
        assert return_tensors == "pt" and padding is True
        assert self.padding_side == "left", "decoder-only generation needs left padding"
        assert self.pad_token_id is not None
        rows = [encode(t, add_special_tokens) for t in texts]
        width = max(len(r) for r in rows)
        ids = [[self.pad_token_id] * (width - len(r)) + r for r in rows]
        mask = [[0] * (width - len(r)) + [1] * len(r) for r in rows]
        return {"input_ids": tensor(ids), "attention_mask": tensor(mask)}

    def batch_decode(self, arr, skip_special_tokens=True):
        return [decode(row, skip_special_tokens) for row in arr]


class FakeModel:
    def __init__(self, src: str, kwargs: dict):
        self.src, self.kwargs = src, kwargs
        self.adapter = None
        self.emb_rows = 32000
        self.is_eval = False

    def eval(self):
        self.is_eval = True
        return self

    def to(self, device):
        STATE.setdefault("moved_to", []).append(device)
        return self

    def get_input_embeddings(self):
        return SimpleNamespace(weight=SimpleNamespace(shape=(self.emb_rows, 16), device="cuda:0"))

    def resize_token_embeddings(self, n):
        self.emb_rows = n

    def parameters(self):
        yield SimpleNamespace(device="cuda:0")

    def generate(self, input_ids=None, attention_mask=None, max_new_tokens=20, do_sample=False, pad_token_id=None, **kw):
        assert self.is_eval and STATE.get("in_inference_mode"), "generate must run in eval + inference mode"
        n = input_ids.shape[0]
        if STATE["oom_above"] is not None and n > STATE["oom_above"]:
            raise RuntimeError("CUDA out of memory. Tried to allocate 2.00 GiB")
        rows, prompts = [], []
        for ids, mask in zip(input_ids, attention_mask):
            assert list(mask) == sorted(mask), "padding must be on the left"
            real = [int(t) for t, m in zip(ids, mask) if m]
            prompt = decode(real, skip_special=False)
            prompts.append({"prompt": prompt, "n_bos": real.count(BOS)})
            out = encode(STATE["answer_fn"](prompt, self.adapter), add_special=False)[:max_new_tokens]
            if len(out) < max_new_tokens:
                out.append(EOS)
            rows.append(out)
        width = max(len(r) for r in rows)
        new = [r + [pad_token_id] * (width - len(r)) for r in rows]
        STATE["generate_calls"].append({"adapter": self.adapter, "batch": n, "prompts": prompts, "max_new_tokens": max_new_tokens, "do_sample": do_sample, "extra": kw})
        return tensor(np.concatenate([np.asarray(input_ids), np.asarray(new, dtype=np.int64)], axis=1))


class FakePeftModel:
    """Wrapper like peft.PeftModel: forwards everything to the wrapped model."""

    def __init__(self, model: FakeModel, path: str):
        self._m = model
        model.adapter = path

    def __getattr__(self, name):
        return getattr(self._m, name)

    def eval(self):
        self._m.eval()
        return self


def _resolve(src: str, kw: dict) -> None:
    if os.path.isdir(src):
        assert "local_files_only" not in kw, "local dirs need no local_files_only"
        return
    if kw.get("local_files_only"):
        if src not in STATE["hub_cache"]:
            raise OSError(f"We couldn't connect to 'https://huggingface.co' to load this file ... {src} is not in the cached files")
    elif src not in STATE["hub_cache"] and src not in STATE["hub_online"]:
        raise OSError(f"{src} is not a local folder and is not a valid model identifier")


def install() -> None:
    @contextlib.contextmanager
    def inference_mode():
        STATE["in_inference_mode"] = True
        try:
            yield
        finally:
            STATE["in_inference_mode"] = False

    def empty_cache():
        STATE["empty_cache"] += 1

    torch = types.ModuleType("torch")
    torch.__version__ = "2.4.0+fake"
    torch.bfloat16, torch.float16, torch.float32 = "torch.bfloat16", "torch.float16", "torch.float32"
    torch.inference_mode = inference_mode
    torch.cuda = SimpleNamespace(
        is_available=lambda: STATE["cuda"],
        is_bf16_supported=lambda: True,
        empty_cache=empty_cache,
        device_count=lambda: 1 if STATE["cuda"] else 0,
        get_device_name=lambda i: "Fake A100",
        get_device_properties=lambda i: SimpleNamespace(total_memory=80 * 1024**3),
    )

    class AutoTokenizer:
        @staticmethod
        def from_pretrained(src, **kw):
            _resolve(src, kw)
            STATE["tok_loads"].append(src)
            return FakeTokenizer(src, **STATE["tokenizers"].get(src, {}))

    class AutoModelForCausalLM:
        @staticmethod
        def from_pretrained(src, **kw):
            _resolve(src, kw)
            if STATE["new_dtype_kwarg"] and "torch_dtype" in kw:
                raise TypeError("from_pretrained() got an unexpected keyword argument 'torch_dtype'")
            if STATE["need_accelerate"] and "device_map" in kw:
                raise ImportError("Using `low_cpu_mem_usage=True`, a `device_map` or a `tp_plan` requires Accelerate: `pip install 'accelerate>=0.26.0'`")
            STATE["model_loads"].append({"src": src, **kw})
            return FakeModel(src, kw)

    class BitsAndBytesConfig:
        def __init__(self, **kw):
            self.kw = kw

    transformers = types.ModuleType("transformers")
    transformers.__version__ = "4.46.0+fake"
    transformers.AutoTokenizer = AutoTokenizer
    transformers.AutoModelForCausalLM = AutoModelForCausalLM
    transformers.BitsAndBytesConfig = BitsAndBytesConfig

    class PeftModel:
        @staticmethod
        def from_pretrained(model, path, **kw):
            if not os.path.exists(os.path.join(path, "adapter_config.json")):
                raise ValueError(f"Can't find 'adapter_config.json' at '{path}'")
            STATE["peft_loads"].append(path)
            return FakePeftModel(model, path)

    peft = types.ModuleType("peft")
    peft.__version__ = "0.13.0+fake"
    peft.PeftModel = PeftModel

    sys.modules.update(torch=torch, transformers=transformers, peft=peft)


def uninstall() -> None:
    for name in ("torch", "transformers", "peft"):
        sys.modules.pop(name, None)
