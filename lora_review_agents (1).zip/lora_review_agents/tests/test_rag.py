#!/usr/bin/env python3
"""
Offline tests for the RAG comparison (rag_index / rag_eval / rag_generate / rag_agents / rag_compare).

No network, no GPU, no model downloads: the runner model is a scripted stand-in that behaves like
an OpenAI-compatible endpoint (including gpt-5-style parameter rejections), and torch /
transformers / peft are replaced by the test doubles in fake_hf.py.

    python tests/test_rag.py
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sys
import tempfile
import threading
import time
import types
import zipfile
from pathlib import Path
from types import SimpleNamespace as N

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import numpy as np  # noqa: E402

import fake_hf  # noqa: E402
import rag_fixture  # noqa: E402
from rag_fixture import FACTS, MEMORISED  # noqa: E402

fake_hf.install()
fake_hf.reset()

import agent_core  # noqa: E402
import rag_agents as ra  # noqa: E402
import rag_compare  # noqa: E402
import rag_eval as ev  # noqa: E402
import rag_generate as rg  # noqa: E402
import rag_index as ri  # noqa: E402

NQ = len(FACTS)
QUIET = lambda m: None  # noqa: E731


# --------------------------------------------------------------------------------------
# a stand-in for the runner model
# --------------------------------------------------------------------------------------


class BadRequestError(Exception):
    """Same class name as openai.BadRequestError (agent_core classifies errors by name)."""


class FakeRunner:
    """Behaves like `openai.OpenAI()` for the roles the runner plays. Stateless per conversation
    (decisions come from the message history), so it is safe to call from many threads."""

    def __init__(self, gpt5_quirks: bool = True, setup_mistake: bool = True, fail_retrieval: bool = False):
        self.quirks = gpt5_quirks
        self.setup_mistake = setup_mistake
        self.fail_retrieval = fail_retrieval
        self.calls: list[dict] = []
        self.rejected: list[str] = []
        self._lock = threading.Lock()
        self._n = 0
        self.chat = N(completions=N(create=self.create))

    # -- plumbing ------------------------------------------------------------------------
    def _reply(self, text: str = "", tool: tuple[str, dict] | None = None, finish: str = "stop"):
        with self._lock:
            self._n += 1
            n = self._n
        calls = None
        if tool:
            calls = [N(id=f"call_{n}", type="function", function=N(name=tool[0], arguments=json.dumps(tool[1])))]
            finish = "tool_calls"
        return N(choices=[N(message=N(content=text, tool_calls=calls), finish_reason=finish)], usage=N(prompt_tokens=50, completion_tokens=10))

    def create(self, **kw):
        if self.quirks:  # what gpt-5-class models reject through an OpenAI-compatible proxy
            if "temperature" in kw:
                self.rejected.append("temperature")
                raise BadRequestError("Unsupported value: 'temperature' does not support 0.2 with this model.")
            if "max_tokens" in kw:
                self.rejected.append("max_tokens")
                raise BadRequestError("Unsupported parameter: 'max_tokens'. Use 'max_completion_tokens' instead.")
        with self._lock:
            self.calls.append(kw)
        msgs = kw["messages"]
        system = msgs[0]["content"] if msgs[0]["role"] == "system" else ""
        if "setup agent" in system:
            return self._setup(msgs)
        if "retrieval controller" in system:
            return self._retrieval(msgs)
        if "You grade an answer" in system:
            return self._judge(msgs)
        if "applied ML scientist" in system:
            return self._reply("1. The fine-tuned model is ahead on judged accuracy.\n2. The gap comes from questions where retrieval missed.\n3. Next: add dense retrieval; train with retrieved context.")
        return self._reply("ready")

    # -- roles ---------------------------------------------------------------------------
    def _setup(self, msgs):
        step = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
        good = dict(
            adapter_path="lora/outputs/epubs_lora",
            base_model=self.base_model,
            eval_path="lora/data/eval_dataset.json",
            question_field="question",
            answer_field="answer",
            prompt_style="raw",
            raw_wrapper="<s>[INST] {user} [/INST]",
            closed_book_template="You are an Air Force publications assistant. Answer the question.\n\nQuestion: {question}",
            rag_template="You are an Air Force publications assistant. Answer the question. Use the excerpts below and answer in your usual style.\n\n{context}\n\nQuestion: {question}",
            max_new_tokens=64,
            stop=["[INST]"],
            env_hint="source activate epubs_ft",
            rationale="train.sh passes --model and --out outputs/epubs_lora; train_sft.py:8 builds the [INST] string by hand; predict.py uses MAX_NEW_TOKENS = 64.",
        )
        plan = [
            ("read_file", {"path": "lora/train_sft.py"}),
            ("read_file", {"path": "lora/train.sh"}),
            ("inspect_eval_file", {"path": "lora/data/eval_dataset.json"}),
        ]
        if self.setup_mistake:  # first proposal is wrong in two ways; the validator must send it back
            plan.append(("propose_config", {**good, "adapter_path": "lora/outputs", "rag_template": "Question: {question}"}))
        plan.append(("propose_config", good))
        if step < len(plan):
            return self._reply(tool=plan[step])
        return self._reply("done")

    def _retrieval(self, msgs):
        question = next(m["content"] for m in msgs if m["role"] == "user").split("Question:\n", 1)[1].strip()
        if self.fail_retrieval:
            raise RuntimeError("simulated runner failure")
        fact = next((f for f in FACTS if f[2] == question), None)
        results = [m["content"] for m in msgs if m["role"] == "tool"]
        n_search = sum(1 for m in msgs if m["role"] == "assistant" for tc in (m.get("tool_calls") or []) if tc["function"]["name"] == "search")
        if n_search == 0:
            return self._reply(tool=("search", {"query": question}))
        if n_search == 1 and fact and fact[4]:
            return self._reply(tool=("search", {"query": fact[4], "k": 5}))
        blocks = re.split(r"\n\n(?=\[c\d+\])", results[-1]) if results else []
        hits = [(int(re.match(r"\[c(\d+)\]", b).group(1)), b) for b in blocks if re.match(r"\[c\d+\]", b)]
        good = [cid for cid, b in hits if fact and fact[1] in b]
        if good:
            return self._reply(tool=("submit_evidence", {"chunk_ids": good, "sufficient": True, "note": "states the answer"}))
        return self._reply(tool=("submit_evidence", {"chunk_ids": [cid for cid, _ in hits[:2]], "sufficient": False, "note": "not found"}))

    def _judge(self, msgs):
        user = msgs[-1]["content"]
        ref = user.split("Reference answer:\n", 1)[1].split("\n\nCandidate answer:\n", 1)[0]
        cand = user.split("Candidate answer:\n", 1)[1]
        score = 1 if ev.normalize_answer(ref) in ev.normalize_answer(cand) else 0
        body = json.dumps({"score": score, "reason": "matches" if score else "does not match"})
        return self._reply(f"```json\n{body}\n```" if len(cand) % 2 else body)


def patch_runner(fake: FakeRunner, base_model: str):
    """Make rag_compare build its LLMClient around the stand-in."""
    fake.base_model = base_model

    def llm_from_args(args):
        cfg = agent_core.LLMConfig(model=args.model or "gpt-5.6", base_url="https://litellm.test", api_key="k", temperature=0.2, max_tokens=2048)
        return agent_core.LLMClient(cfg, client=fake)

    rag_compare.llm_from_args = llm_from_args


# --------------------------------------------------------------------------------------
# rag_index
# --------------------------------------------------------------------------------------


def test_index():
    import random

    assert ri.chunk_text("", 200, 40) == []
    w = lambda n: " ".join(f"w{i}" for i in range(n))  # noqa: E731
    for n, exp in [(190, 1), (200, 1), (201, 2), (210, 2), (230, 2), (360, 2), (361, 3), (5, 1)]:
        ch = ri.chunk_text(w(n), 200, 40)
        assert len(ch) == exp, (n, len(ch))
        assert {x for c in ch for x in c.split()} == set(w(n).split())
    random.seed(1)
    words = [f"term{i}" for i in range(400)] + ["torque", "waiver", "commander", "afi", "36", "2903", "inspection", "the", "of", "and"]
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "corpus"
        (root / "catA" / "txt").mkdir(parents=True)
        (root / "catB" / "txt").mkdir(parents=True)
        for d in range(40):
            text = " ".join(random.choice(words) for _ in range(random.randint(50, 900)))
            if d % 7 == 0:
                text += "\n\nSection 4.2. The MAJCOM commander approves waiver requests for AFI 36-2903 within 30 days."
            (root / ("catA" if d % 2 else "catB") / "txt" / f"doc{d:02d}.txt").write_text(text)
        (root / "catA" / "metadata.csv").write_text("file,title\ndoc01.txt,Something\n")
        for stem in ("doc00", "book"):
            with zipfile.ZipFile(root / "catB" / f"{stem}.epub", "w") as z:
                z.writestr("OEBPS/ch2.xhtml", "<html><head><title>x</title><style>p{}</style></head><body><p>Second chapter about hydraulic fluid.</p></body></html>")
                z.writestr("OEBPS/ch10.xhtml", "<html><body><p>Tenth chapter &amp; appendix zebra.</p><script>var a=1;</script></body></html>")
        files = ri.list_corpus_files([root])
        names = [n for n, _ in files]
        assert "catB/book.epub" in names and "catB/doc00.epub" not in names and not any(n.endswith(".csv") for n in names) and len(files) == 41
        book = ri.read_epub(root / "catB" / "book.epub")
        assert book.index("Second chapter") < book.index("Tenth chapter") and "var a" not in book and "p{}" not in book
        logs: list[str] = []
        r = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("building" in x for x in logs) and r.meta["n_docs"] == 41 and r.n_chunks > 100
        for name, path in files[:5]:  # chunks reassemble to the original text
            cids = [i for i in range(r.n_chunks) if r.chunk_doc[i] == r.docs.index(name)]
            rebuilt = r.text(cids[0]).split()
            for c in cids[1:]:
                rebuilt += r.text(c).split()[10:]
            assert rebuilt == ri.read_document(path).split(), name
        toks = [ri.tokenize(r.text(i)) for i in range(r.n_chunks)]
        avgdl = sum(len(t) for t in toks) / len(toks)

        def brute(q):  # textbook BM25, independent of the index code
            sc = np.zeros(len(toks))
            for t in set(ri.tokenize(q)):
                df = sum(1 for tk in toks if t in tk)
                if df:
                    idf = math.log(1 + (len(toks) - df + 0.5) / (df + 0.5))
                    for i, tk in enumerate(toks):
                        tf = tk.count(t)
                        if tf:
                            sc[i] += idf * tf * 2.5 / (tf + 1.5 * (0.25 + 0.75 * len(tk) / avgdl))
            return sc

        for q in ["Who approves waiver requests for AFI 36-2903?", "torque inspection term17 term250", "hydraulic fluid zebra", "term5", "term1 term2 term3 commander 2903"]:
            ref = brute(q)
            hits = r.search(q, k=7)
            want = sorted(ref[ref > 0], reverse=True)[:7]
            assert len(hits) == len(want)
            for h, wv in zip(hits, want):
                assert abs(h["score"] - wv) < 2e-3 and abs(h["score"] - ref[h["id"]]) < 2e-3, (q, h["score"], wv)
        assert r.search("zzzz qqqq") == [] and r.search("the of and") == []
        assert "MAJCOM commander approves waiver" in r.search("Who approves waiver requests for AFI 36-2903?", k=3)[0]["text"]
        f = r.search("waiver commander", k=20, doc_filter="doc07")
        assert f and all("doc07" in h["doc"] for h in f) and r.search("waiver commander", 5, doc_filter="nope") == []
        first = [i for i in range(r.n_chunks) if r.chunk_pos[i] == 0][3]
        assert [n["pos"] for n in r.neighbors(first)] == [1]
        logs.clear()
        ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("cached" in x for x in logs)
        time.sleep(1.1)
        (root / "catA" / "txt" / "new.txt").write_text("brand new document about quokka maintenance")
        logs.clear()
        r3 = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("building" in x for x in logs) and r3.search("quokka")[0]["doc"] == "catA/txt/new.txt"
        qs = ["waiver commander", "torque inspection", "term3 term4 term5", "hydraulic zebra"] * 20
        seq = [[h["id"] for h in r3.search(q, 5)] for q in qs]
        res: list = [None] * len(qs)
        th = [threading.Thread(target=lambda i=i: res.__setitem__(i, [h["id"] for h in r3.search(qs[i], 5)])) for i in range(len(qs))]
        [t.start() for t in th]
        [t.join() for t in th]
        assert res == seq

        class FakeST:  # sentence-transformers stand-in: hashed bag of words
            def __init__(self, path, device="cpu"):
                pass

            def encode(self, texts, batch_size=32, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False):
                out = np.zeros((len(texts), 64), dtype=np.float32)
                for i, t in enumerate(texts):
                    for tok in ri.tokenize(t):
                        out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
                    out[i] /= np.linalg.norm(out[i]) or 1
                return out

        sys.modules["sentence_transformers"] = types.SimpleNamespace(SentenceTransformer=FakeST)
        try:
            r4 = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, embed_model="/m/fake", log=logs.append)
            assert r4.emb.shape == (r4.n_chunks, 64) and "dense" in r4.describe() and r4.search("quokka maintenance", 3)[0]["doc"] == "catA/txt/new.txt"
            logs.clear()
            ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, embed_model="/m/fake", log=logs.append)
            assert any("cached embeddings" in x for x in logs)
        finally:
            sys.modules.pop("sentence_transformers", None)
    print("ok  index: chunking, BM25 == textbook BM25, epub, filters, cache, threads, dense wiring")


# --------------------------------------------------------------------------------------
# rag_eval
# --------------------------------------------------------------------------------------


def test_eval_data():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        qa = [{"question": f"What is rule {i}?", "answer": f"Rule {i} says stop.", "id": i} for i in range(12)]
        (td / "list.json").write_text(json.dumps(qa))
        (td / "wrapped.json").write_text(json.dumps({"meta": {"v": 1}, "data": qa}))
        (td / "columnar.json").write_text(json.dumps({"question": [r["question"] for r in qa], "answer": [r["answer"] for r in qa]}))
        (td / "lines.jsonl").write_text("\n".join(json.dumps(r) for r in qa) + "\n\n")
        (td / "lines_as.json").write_text("\n".join(json.dumps(r) for r in qa))
        (td / "t.csv").write_text("﻿Question,Answer,predict\n" + "\n".join(f'"What, is rule {i}?","Rule {i} says ""stop"".",x' for i in range(5)))
        (td / "t.tsv").write_text("prompt\tlabel\tpredict\n" + "\n".join(f"Q{i}\tA{i}\tP{i}" for i in range(4)))
        (td / "alpaca_const.json").write_text(json.dumps([{"instruction": "Answer the question about Air Force policy.", "input": f"Who signs form {i}?", "output": f"The commander signs form {i}."} for i in range(8)]))
        (td / "alpaca_var.json").write_text(json.dumps([{"instruction": f"Summarize section {i}", "input": f"text {i}" if i % 2 == 0 else "", "output": f"sum {i}"} for i in range(8)]))
        (td / "chat.jsonl").write_text("\n".join(json.dumps({"messages": [{"role": "system", "content": "s"}, {"role": "user", "content": f"q{i}"}, {"role": "assistant", "content": f"a{i}"}]}) for i in range(6)))
        (td / "sharegpt.json").write_text(json.dumps([{"conversations": [{"from": "human", "value": f"q{i}"}, {"from": "gpt", "value": f"a{i}"}]} for i in range(6)]))
        (td / "metrics.json").write_text(json.dumps({"eval_loss": 1.2}))
        (td / "nested.json").write_text(json.dumps([{"q": {"text": f"deep {i}"}, "answers": {"text": [f"ans {i}", "alt"]}} for i in range(5)]))
        for name in ("list.json", "wrapped.json", "columnar.json", "lines.jsonl", "lines_as.json"):
            recs = ev.load_records(td / name)
            sc = ev.detect_schema(recs)
            assert len(recs) == 12 and (sc["question_field"], sc["answer_field"]) == ("question", "answer"), name
            assert len(ev.build_examples(recs, sc)[0]) == 12
        sc = ev.detect_schema(ev.load_records(td / "list.json"))
        assert sc["id_field"] == "id" and ev.build_examples(ev.load_records(td / "list.json"), sc)[0][3].id == "3"
        recs = ev.load_records(td / "t.csv")
        sc = ev.detect_schema(recs)
        exs, _ = ev.build_examples(recs, sc)
        assert (sc["question_field"], sc["answer_field"]) == ("Question", "Answer") and exs[1].question == "What, is rule 1?" and exs[1].answer == 'Rule 1 says "stop".'
        sc = ev.detect_schema(ev.load_records(td / "t.tsv"))
        assert (sc["question_field"], sc["answer_field"]) == ("prompt", "label")
        sc = ev.detect_schema(ev.load_records(td / "alpaca_const.json"))
        assert sc["question_field"] == "input" and sc["constant_instruction"].startswith("Answer the question") and sc["input_field"] is None
        recs = ev.load_records(td / "alpaca_var.json")
        sc = ev.detect_schema(recs)
        exs, _ = ev.build_examples(recs, sc)
        assert sc["input_field"] == "input" and exs[0].query == "Summarize section 0\ntext 0" and exs[1].query == "Summarize section 1"
        for name in ("chat.jsonl", "sharegpt.json"):
            recs = ev.load_records(td / name)
            sc = ev.detect_schema(recs)
            assert sc["format"] == "messages" and [(e.question, e.answer) for e in ev.build_examples(recs, sc)[0][:2]] == [("q0", "a0"), ("q1", "a1")]
        assert ev.load_records(td / "metrics.json") == [] and ev.detect_schema([]) is None
        exs, _ = ev.build_examples(ev.load_records(td / "nested.json"), {"format": "fields", "question_field": "q.text", "answer_field": "answers.text.0"})
        assert exs[2].question == "deep 2" and exs[2].answer == "ans 2"
        exs, sk = ev.build_examples([{"question": "a", "answer": "b", "id": 1}, {"question": "", "answer": "b", "id": 2}, {"question": "c", "answer": "d", "id": 1}], {"question_field": "question", "answer_field": "answer", "id_field": "id"})
        assert sk == 1 and [e.id for e in exs] == ["1", "1#2"]
        exs, _ = ev.build_examples(ev.load_records(td / "list.json"), {"question_field": "question", "answer_field": "answer"})
        s5, s9 = ev.select_examples(exs, 5, 0), ev.select_examples(exs, 9, 0)
        assert [e.id for e in s9[:5]] == [e.id for e in s5] and len(ev.select_examples(exs, 0, 0)) == 12 and [e.id for e in ev.select_examples(exs, 5, 1)] != [e.id for e in s5]
        # appending after a half-written line (interrupted run) does not lose the next record
        f = td / "a.jsonl"
        f.write_text('{"id": 1}\n{"id": 2, "x"')
        ev.JsonlAppender(f).add({"id": 3})
        assert [r["id"] for r in ev.read_jsonl(f)] == [1, 3]
    print("ok  eval data: loaders, schema detection, seeded subsets, interrupted-write recovery")


def test_metrics_and_stats():
    assert abs(ev.token_f1("The cat sat", "cat sat down") - 0.8) < 1e-9
    assert ev.exact_match("The Commander.", "commander") == 1.0 and ev.exact_match("commander general", "commander") == 0.0
    assert ev.token_f1("", "x") == 0.0 and ev.token_f1("", "") == 1.0
    assert abs(ev.rouge_l("a b c d".split(), "a c d e f".split()) - 2 * 0.75 * 0.6 / 1.35) < 1e-9
    assert abs(ev.rouge_n("a b c d".split(), "a b x d".split(), 1) - 0.75) < 1e-9 and abs(ev.rouge_n("a b c d".split(), "a b x d".split(), 2) - 1 / 3) < 1e-9
    st = ev.bleu_stats("the quick brown fox jumps".split(), "the quick brown fox jumped over".split())
    assert st == [4, 5, 3, 4, 2, 3, 1, 2, 5, 6]
    assert abs(float(ev.bleu_from_stats(st)[0]) - math.exp(1 - 6 / 5) * (0.8 * 0.75 * (2 / 3) * 0.5) ** 0.25) < 1e-9
    assert abs(float(ev.bleu_from_stats(ev.bleu_stats("a b c d e".split(), "a b c d e".split()))[0]) - 1.0) < 1e-12
    assert float(ev.bleu_from_stats(ev.bleu_stats([], ["a"]))[0]) == 0.0
    assert abs(ev.evidence_recall("The MAJCOM commander approves the waiver within 30 days", "waiver requests are approved by the majcom commander; 30 days") - 5 / 6) < 1e-9
    rng = np.random.default_rng(3)
    b = rng.random(300)
    a = b + 0.05 + rng.normal(0, 0.05, 300)
    s = ev.paired_stats(a, b)
    se = (a - b).std(ddof=1) / math.sqrt(300)
    assert s["lo"] > 0 and abs(s["delta"] - (a - b).mean()) < 1e-12 and s["wins"] + s["ties"] + s["losses"] == 300
    assert abs((s["hi"] - s["lo"]) / 2 - 1.96 * se) < 0.25 * 1.96 * se
    s0 = ev.paired_stats(b, b)
    assert s0["delta"] == 0 and s0["lo"] == 0 == s0["hi"] and "no reliable" in ev.verdict(s0, "A", "B")
    assert ev.verdict(s, "A", "B") == "A is better" and ev.verdict(ev.paired_stats(b, a), "A", "B") == "B is better" and ev.paired_stats([], []) is None
    miss = 0
    for seed in range(200):  # with no true difference the 95% CI should rarely exclude zero
        r = np.random.default_rng(1000 + seed)
        c = ev.paired_stats(r.normal(0, 1, 60), r.normal(0, 1, 60), iters=400, seed=seed)
        miss += (c["lo"] > 0) or (c["hi"] < 0)
    assert 0.01 <= miss / 200 <= 0.12, miss / 200
    print("ok  metrics (hand-computed values) and paired bootstrap (CI width, false-positive rate)")


# --------------------------------------------------------------------------------------
# rag_generate
# --------------------------------------------------------------------------------------


def _world(td):
    paths = rag_fixture.build(Path(td))
    exs, _ = ev.build_examples(ev.load_records(paths["eval"]), {"question_field": "question", "answer_field": "answer"})
    r = ri.Retriever.build_or_load([paths["corpus"]], Path(td) / "idx", log=QUIET)
    evidence = {e.id: {"id": e.id, "chunks": r.search(e.query, 3)} for e in exs}
    cfg = ra.merge_config(ra.default_config(), {
        "base_model": str(paths["base"]), "adapter_path": str(paths["adapter"]),
        "prompt": {"style": "raw", "raw_wrapper": "<s>[INST] {user} [/INST]",
                   "closed_book": "You are an Air Force publications assistant. Answer the question.\n\nQuestion: {question}",
                   "rag": "You are an Air Force publications assistant. Answer the question using the excerpts.\n\n{context}\n\nQuestion: {question}"},
        "gen": {"max_new_tokens": 32},
    })
    return paths, exs, r, evidence, cfg


def test_generate_hf():
    logs: list[str] = []
    with tempfile.TemporaryDirectory() as td:
        paths, exs, _, evidence, cfg = _world(td)
        out = Path(td) / "out"
        tk = {str(paths["adapter"]): {"n_tokens": 32001, "has_template": False}}
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        meta: dict = {}
        done = rg.run_generation(arms=list(rg.ARMS), examples=exs, evidence=evidence, cfg=cfg, out_dir=out, batch_size=5, meta=meta, log=logs.append)
        assert done == {a: NQ for a in rg.ARMS}, done
        assert meta["styles"] == {"lora_rag": "raw", "base_rag": "chat", "lora_closed": "raw", "base_closed": "chat"}
        # one base load (dtype + device_map); the adapter is attached once, after every base arm has finished
        assert len(S["model_loads"]) == 1 and S["model_loads"][0]["torch_dtype"] == "torch.bfloat16" and S["model_loads"][0]["device_map"] == "auto"
        assert S["peft_loads"] == [str(paths["adapter"])] and S["tok_loads"] == [str(paths["base"]), str(paths["adapter"])]
        adapters = [c["adapter"] for c in S["generate_calls"]]
        first = next(i for i, a in enumerate(adapters) if a)
        assert all(a is None for a in adapters[:first]) and all(adapters[first:])
        assert all(p["n_bos"] == 1 for c in S["generate_calls"] for p in c["prompts"])  # never a double BOS
        assert max(c["batch"] for c in S["generate_calls"]) == 5 and all(c["do_sample"] is False and "temperature" not in c["extra"] for c in S["generate_calls"])
        preds = {a: rg.load_predictions(out, a) for a in rg.ARMS}
        for i, e in enumerate(exs):
            in_ctx = FACTS[i][1].lower() in " ".join(c["text"] for c in evidence[e.id]["chunks"]).lower()
            lr, br, lc, bc = (preds[a][e.id]["prediction"] for a in rg.ARMS)
            if in_ctx:
                assert lr == e.answer and br == f"Based on the excerpts, the answer is {e.answer}.", (i, lr, br)
            assert lc == (e.answer if i in MEMORISED else "I am not sure.") and bc == "I do not have enough information to answer."
        rec = preds["lora_rag"][exs[0].id]
        assert rec["n_ctx"] == len(evidence[exs[0].id]["chunks"]) >= 1 and rec["hit_cap"] is False and rec["ehash"] and preds["lora_closed"][exs[0].id]["ehash"] == ""
        sp = (out / "sample_prompts.md").read_text()
        lora_block, base_block = sp.split("## lora_rag")[1].split("## base_rag")[0], sp.split("## base_rag")[1].split("## lora_closed")[0]
        assert "wrapper: raw" in lora_block and "<s>[INST] You are an Air Force publications assistant. Answer the question using the excerpts." in lora_block and "[1] " in lora_block
        assert "wrapper: chat" in base_block and "<s>[INST] You are an Air Force publications assistant." in base_block

        # resume: nothing missing -> the model is not even loaded
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=out, log=logs.append) == {"lora_rag": 0, "base_rag": 0}
        assert S["model_loads"] == [] and S["generate_calls"] == []
        lines = (out / "predictions_lora_rag.jsonl").read_text().splitlines()
        (out / "predictions_lora_rag.jsonl").write_text("\n".join(lines[:7]) + "\n" + lines[7][:25])  # interrupted mid-line
        done = rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=out, log=logs.append)
        assert done == {"lora_rag": NQ - 7, "base_rag": 0} and all(c["adapter"] for c in S["generate_calls"]) and len(rg.load_predictions(out, "lora_rag")) == NQ
        # changed passages for one question -> exactly that question is regenerated in both RAG arms
        ev2 = dict(evidence)
        ev2[exs[1].id] = {"id": exs[1].id, "chunks": []}
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=ev2, cfg=cfg, out_dir=out, log=logs.append) == {"lora_rag": 1, "base_rag": 1}
        assert len(ev.read_jsonl(out / "predictions_lora_rag.jsonl")) == NQ and rg.load_predictions(out, "lora_rag")[exs[1].id]["n_ctx"] == 0
        cfg2 = json.loads(json.dumps(cfg))
        cfg2["gen"]["max_new_tokens"] = 3
        assert rg.run_generation(arms=["base_rag"], examples=exs[:4], evidence=evidence, cfg=cfg2, out_dir=out, log=logs.append) == {"base_rag": 4}
        p = rg.load_predictions(out, "base_rag")
        assert p[exs[0].id]["prediction"] == "Based on the" and p[exs[0].id]["hit_cap"] is True and len(p) == NQ and p[exs[8].id]["hit_cap"] is False

        # failure handling and fallbacks
        S = fake_hf.reset(answer_fn=lambda p, a: "the answer ### Question: something else", oom_above=2)
        cfg3 = json.loads(json.dumps(cfg))
        cfg3["gen"].update(stop=["### Question:"], temperature=0.7)
        assert rg.run_generation(arms=["base_closed"], examples=exs[:12], evidence={}, cfg=cfg3, out_dir=Path(td) / "o2", batch_size=8, load_in_4bit=True, log=logs.append) == {"base_closed": 12}
        assert [c["batch"] for c in S["generate_calls"]] == [2] * 6 and any("out of memory -> batch size 4" in x for x in logs)
        assert all(c["do_sample"] is True and c["extra"]["temperature"] == 0.7 for c in S["generate_calls"]) and S["model_loads"][0]["quantization_config"].kw["load_in_4bit"] is True
        assert all(r["prediction"] == "the answer" and "### Question" in r["raw"] for r in rg.load_predictions(Path(td) / "o2", "base_closed").values())
        for state, kwargs, needle in [
            (dict(oom_above=0), {}, "batch size 1"),
            (dict(cuda=False), {}, "no CUDA GPU"),
        ]:
            fake_hf.reset(**state)
            try:
                rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o3", log=logs.append, **kwargs)
                raise AssertionError(needle)
            except SystemExit as e:
                assert needle in str(e), e
        S = fake_hf.reset(need_accelerate=True, new_dtype_kwarg=True)
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o4", log=logs.append)
        assert S["model_loads"][0].get("dtype") == "torch.bfloat16" and "device_map" not in S["model_loads"][0] and S["moved_to"] == ["cuda"]
        cfg4 = json.loads(json.dumps(cfg))
        cfg4["base_model"] = "mistralai/Mistral-7B-Instruct-v0.3"
        S = fake_hf.reset(hub_cache={"mistralai/Mistral-7B-Instruct-v0.3"})
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg4, out_dir=Path(td) / "o5", log=logs.append)
        assert S["model_loads"][0]["local_files_only"] is True
        fake_hf.reset()
        for bad_cfg, arms, evd, needle in [
            (cfg4, ["base_closed"], {}, "--base-model /local/path"),
            (cfg, ["base_rag"], {exs[0].id: evidence[exs[0].id]}, f"{NQ - 1} selected questions have no retrieved evidence"),
            ({**cfg, "adapter_path": str(paths["project"])}, ["lora_closed"], {}, "could not attach the adapter"),
        ]:
            try:
                rg.run_generation(arms=arms, examples=exs, evidence=evd, cfg=bad_cfg, out_dir=Path(td) / "o6", log=logs.append)
                raise AssertionError(needle)
            except SystemExit as e:
                assert needle in str(e), e
        fake_hf.reset(cuda=False)
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o7", allow_cpu=True, log=logs.append)
        assert fake_hf.STATE["model_loads"][0]["torch_dtype"] == "torch.float32"
    print("ok  generation (transformers/peft doubles): arm order, single BOS, resume, cache invalidation, OOM backoff, fallbacks, errors")


def test_prompts_and_api_backend():
    tok, tok_sys, tok_none = fake_hf.FakeTokenizer("x"), fake_hf.FakeTokenizer("x", system_ok=True), fake_hf.FakeTokenizer("x", has_template=False)
    ex = ev.Example(id="a", question="Who signs {context}?", answer="x", input="Form 55")
    warn: list[str] = []
    b = rg.PromptBuilder({"system": "Be brief.", "closed_book": "Q: {question}\nInput: {input}", "rag": "{context}\n\nQ: {question} ({input})", "raw_wrapper": "### Q\n{user}\n### A\n"}, ctx_max_chars=120, log=warn.append)
    chunks = [{"id": 1, "doc": "cat/txt/afi1.txt", "text": "alpha " * 10}, {"id": 2, "doc": "afi2.txt", "text": "beta " * 30}]
    u = b.user_content(ex, chunks)
    assert u.startswith("[1] afi1\nalpha") and "[2] afi2" not in u and u.endswith("Q: Who signs {context}? (Form 55)")
    assert b.user_content(ex, None) == "Q: Who signs {context}?\nInput: Form 55" == b.user_content(ex, [])
    assert b.wrap_hf(tok_sys, "chat", "hi") == ("<s>[SYS] Be brief. [/SYS] [INST] hi [/INST]", False)
    assert b.wrap_hf(tok, "chat", "hi") == ("<s>[INST] Be brief.\n\nhi [/INST]", False)  # system merged when the template rejects the role
    assert b.wrap_hf(tok_none, "chat", "hi") == ("Be brief.\n\nhi\n\nAnswer:", True) and any("no chat template" in w for w in warn)
    assert b.wrap_hf(tok, "raw", "hi") == ("### Q\nhi\n### A\n", True)
    b2 = rg.PromptBuilder({"closed_book": "{question}", "rag": "{context}\nQ: {question}"}, ctx_max_chars=10**6)
    ex2 = ev.Example(id="b", question="What?", answer="x", input="extra detail")
    assert b2.user_content(ex2, None) == "What?\nextra detail"
    big = [{"id": i, "doc": f"d{i}.txt", "text": "word " * 300} for i in range(6)]
    text, add, n = b2.render_hf(tok, "chat", ex2, big, max_prompt_tokens=700)
    assert n == 2 and len(tok(text, add_special_tokens=add)["input_ids"]) <= 700
    assert b2.render_hf(tok, "chat", ex2, big, max_prompt_tokens=50)[2] == 0
    assert rg.arm_style({"style": "raw"}, "base", True) == "chat" and rg.arm_style({"style": "raw"}, "base", False) == "raw" and rg.arm_style({"style": "raw", "base_style": "same"}, "base", True) == "raw"
    assert rg.apply_stop("  yes ### Question: no", ["[INST]", "### Question:"]) == "yes"
    assert rg.PromptBuilder({"raw_wrapper": "<s>[INST] {user} [/INST]"}).render_api("raw", ex2, None) == {"style": "raw", "prompt": "[INST] What?\nextra detail [/INST]"}

    class FakeServer:
        def __init__(self):
            self.calls = []
            self.chat = N(completions=N(create=lambda **kw: (self.calls.append(("chat", kw)), N(choices=[N(message=N(content=f" {kw['model']} says hi "), finish_reason="stop")]))[1]))
            self.completions = N(create=lambda **kw: (self.calls.append(("completions", kw)), N(choices=[N(text=f" {kw['model']} completes", finish_reason="length")]))[1])

    with tempfile.TemporaryDirectory() as td:
        paths, exs, _, evidence, cfg = _world(td)
        srv = FakeServer()
        gen = rg.OpenAIGenerator("http://x/v1", None, "epubs-lora", "mistral-base", workers=4, client=srv)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=Path(td) / "api", backend="openai", generator=gen, log=QUIET) == {"lora_rag": NQ, "base_rag": NQ}
        assert {(k, kw["model"]) for k, kw in srv.calls} == {("completions", "epubs-lora"), ("chat", "mistral-base")}  # adapter: raw training string; base: chat endpoint
        raw = next(kw for k, kw in srv.calls if k == "completions")
        assert raw["prompt"].startswith("[INST] You are") and raw["max_tokens"] == 32
        assert all(r["prediction"] == "epubs-lora completes" and r["hit_cap"] for r in rg.load_predictions(Path(td) / "api", "lora_rag").values())
    print("ok  prompt building and the OpenAI-compatible generation backend")


# --------------------------------------------------------------------------------------
# rag_agents
# --------------------------------------------------------------------------------------


def test_discovery_and_validation():
    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        roots = {"lora": paths["project"]}
        adapters = ra.find_adapters(roots)
        assert [a["shown_as"] for a in adapters] == ["lora/outputs/epubs_lora", "lora/outputs/epubs_lora/checkpoint-100"] and adapters[0]["has_tokenizer"] and adapters[0]["r"] == 16
        cands = ra.find_eval_candidates(roots)
        assert cands[0]["shown_as"] == "lora/data/eval_dataset.json" and cands[0]["n_records"] == NQ and not cands[0]["is_predictions"]
        assert cands[-1]["shown_as"] == "lora/results/generated_predictions.csv" and cands[-1]["is_predictions"]  # saved predictions rank last
        assert not any("eval_results" in c["path"] or "train.json" in c["path"] for c in cands)
        draft = ra.draft_config(adapters, cands)
        errors, warnings, info = ra.validate_config(draft, list(roots.values()))
        assert errors == [] and info["n_examples"] == NQ and info["adapter"]["r"] == 16 and draft["prompt"]["style"] == "chat"
        bad = ra.merge_config(draft, {"adapter_path": str(paths["project"] / "outputs"), "base_model": "/nope/model", "eval": {"question_field": "nope"}, "prompt": {"style": "raw", "rag": "{question}"}, "gen": {"max_new_tokens": 1}})
        errors, _, _ = ra.validate_config(bad, list(roots.values()))
        joined = " | ".join(errors)
        for needle in ("no adapter_config.json", "base_model path does not exist", "no usable question/answer pairs", "must contain both {context} and {question}", "raw_wrapper must contain {user}", "max_new_tokens must be between"):
            assert needle in joined, (needle, joined)
        outside = Path(td) / "elsewhere.json"
        outside.write_text(json.dumps([{"question": "q", "answer": "a"}]))
        e1, _, _ = ra.validate_config(ra.merge_config(draft, {"eval": {"path": str(outside)}}), list(roots.values()))
        e2, _, _ = ra.validate_config(ra.merge_config(draft, {"eval": {"path": str(outside)}}), None)
        assert any("outside the directories given on the command line" in x and f"--root data={td}" in x for x in e1) and e2 == []
        elsewhere = Path(td) / "adapters_elsewhere"   # an adapter saved outside the project is fine: it is only loaded locally
        elsewhere.mkdir()
        for fn in ("adapter_config.json", "adapter_model.safetensors"):
            (elsewhere / fn).write_bytes((paths["adapter"] / fn).read_bytes())
        assert ra.validate_config(ra.merge_config(draft, {"adapter_path": str(elsewhere)}), list(roots.values()))[0] == []
        _, w, _ = ra.validate_config(ra.merge_config(draft, {"base_model": "mistralai/Other-Model"}), None)
        assert any("not in this user's Hugging Face cache" in x for x in w) and any("was trained on" in x for x in w)
        assert ra.parse_judge('{"score": 0.5, "reason": "half"}') == (0.5, "half") and ra.parse_judge("```json\n{\"score\": 1, \"reason\": \"ok\"}\n```")[0] == 1.0
        assert ra.parse_judge("Score: 0") == (0.0, "") and ra.parse_judge("I think it is fine") == (None, "") and ra.parse_judge('{"score": 7}') == (None, "")
        notes = ra.render_setup_notes(draft, {"info": info, "warnings": ["w1"], "adapters": adapters})
        assert "## Prompt format" in notes and "checkpoint-100" in notes and "w1" in notes
    print("ok  discovery heuristics, config validation, judge parsing, setup notes")


def test_retrieval_agent():
    with tempfile.TemporaryDirectory() as td:
        paths, exs, retr, _, _ = _world(td)
        fake = FakeRunner(gpt5_quirks=False)
        llm = agent_core.LLMClient(agent_core.LLMConfig(model="gpt-5.6", base_url="x", api_key="k"), client=fake)
        # paraphrased question: the first search misses, the rewrite finds the passage
        res = ra.agentic_retrieve(llm, retr, FACTS[3][2], ctx_k=3)
        assert res["n_searches"] == 2 and res["queries"][1] == FACTS[3][4] and res["sufficient"] is True and not res["fallback"]
        assert FACTS[3][1] in res["chunks"][0]["text"] and 1 <= len(res["chunks"]) <= 3
        # nothing findable: an empty submission is accepted only because nothing was seen
        res = ra.agentic_retrieve(llm, retr, FACTS[12][2], ctx_k=3)
        assert res["chunks"] == [] and res["sufficient"] is False and res["n_searches"] == 1
        # the runner never passed the reference answer or any model output to the search tools
        sent = json.dumps([c["messages"] for c in fake.calls])
        assert FACTS[3][3] not in sent.split("Engine oil samples")[0]
        # budget, id parsing, and the fallback when the runner stops without submitting
        class Lazy(FakeRunner):
            def _retrieval(self, msgs):
                n = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
                return self._reply(tool=("search", {"query": f"waiver commander approves {n}"})) if n < 9 else self._reply("I give up")
        lazy = Lazy(gpt5_quirks=False)
        res = ra.agentic_retrieve(agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=lazy), retr, FACTS[4][2], ctx_k=2, max_searches=2)
        assert res["fallback"] is True and res["n_searches"] == 2 and len(res["chunks"]) == 2 and FACTS[4][1] in res["chunks"][0]["text"]
        tool_msgs = [m["content"] for m in lazy.calls[-1]["messages"] if m["role"] == "tool"]
        assert any("Search budget used up" in t for t in tool_msgs) and len(lazy.calls) <= 6  # max_searches + 3 turns, then a forced stop
        assert ra._chunk_id("[c12]") == 12 and ra._chunk_id(7) == 7 and ra._chunk_id("c3") == 3

        # the whole set, in parallel, with caching and the one-shot baseline recorded next to it
        out = Path(td) / "evidence.jsonl"
        logs: list[str] = []
        evd = ra.retrieve_all(exs, retr, out, mode="agentic", llm=llm, ctx_k=3, workers=4, log=logs.append)
        assert len(evd) == NQ and len(ev.read_jsonl(out)) == NQ
        by = {i: evd[e.id] for i, e in enumerate(exs)}
        for i in (3, 10):  # rewriting rescued these
            assert by[i]["recall"] == 1.0 and by[i]["recall_single"] == 0.0 and by[i]["n_searches"] == 2, (i, by[i]["recall"], by[i]["recall_single"])
        for i in (6, 12):  # nothing found by either strategy
            assert by[i]["chunks"] == [] and by[i]["recall"] == 0.0
        assert all(by[i]["recall"] == 1.0 for i in range(NQ) if i not in (6, 12))
        n_calls = len(fake.calls)
        assert ra.retrieve_all(exs, retr, out, mode="agentic", llm=llm, ctx_k=3, workers=4, log=logs.append).keys() == evd.keys() and len(fake.calls) == n_calls  # all cached
        ra.retrieve_all(exs[:5], retr, out, mode="agentic", llm=llm, ctx_k=2, workers=2, log=logs.append)  # another setting: recomputed for those 5 only
        recs = ev.read_jsonl(out)
        assert len(recs) == NQ and sum(1 for r in recs if r["signature"]["ctx_k"] == 2) == 5
        single = ra.retrieve_all(exs, retr, Path(td) / "single.jsonl", mode="single", ctx_k=3, log=logs.append)
        assert single[exs[3].id]["recall"] == 0.0 and single[exs[0].id]["recall"] == 1.0 and single[exs[0].id]["mode"] == "single"
        # one bad episode falls back and is retried next time; a dead runner stops the run instead of silently degrading
        class Flaky(FakeRunner):
            def _retrieval(self, msgs):
                if "torque" in msgs[1]["content"]:
                    raise RuntimeError("upstream 500")
                return super()._retrieval(msgs)
        fl = agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=Flaky(gpt5_quirks=False))
        f_out = Path(td) / "flaky.jsonl"
        got = ra.retrieve_all(exs, retr, f_out, mode="agentic", llm=fl, ctx_k=3, workers=3, log=logs.append)
        assert got[exs[0].id]["fallback"] and "upstream 500" in got[exs[0].id]["error"] and got[exs[0].id]["recall"] == 1.0
        again = ra.retrieve_all(exs, retr, f_out, mode="agentic", llm=llm, ctx_k=3, workers=3, log=logs.append)
        assert not again[exs[0].id].get("error") and any("1 to retrieve" in x for x in logs)
        dead = agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=FakeRunner(gpt5_quirks=False, fail_retrieval=True))
        try:
            ra.retrieve_all(exs, retr, Path(td) / "dead.jsonl", mode="agentic", llm=dead, workers=1, log=logs.append)
            raise AssertionError("expected a stop")
        except SystemExit as e:
            assert "all failed" in str(e)
        try:
            ra.retrieve_all(exs, retr, Path(td) / "x.jsonl", mode="agentic", llm=None, log=logs.append)
            raise AssertionError
        except SystemExit as e:
            assert "--retrieval single" in str(e)
    print("ok  retrieval agent: rewrite, budget, fallback, parallel run, cache, error isolation")


# --------------------------------------------------------------------------------------
# end to end through the CLI
# --------------------------------------------------------------------------------------


def _expected(evidence_by_idx):
    lora = base = 0
    for i in range(NQ):
        found = FACTS[i][1] in " ".join(c["text"] for c in evidence_by_idx[i]["chunks"])
        lora += found or i in MEMORISED
        base += found
    return lora, base


def test_end_to_end():
    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        out = Path(td) / "rag_out"
        fake = FakeRunner()
        patch_runner(fake, str(paths["base"]))
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        base_args = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out), "--workers", "4", "--batch-size", "4", "--ctx-k", "3", "--model", "gpt-5.6"]

        # 1) the first pass on 4 questions
        assert rag_compare.main(base_args + ["--limit", "4"]) == 0
        cfg = json.loads((out / "rag_config.json").read_text())
        assert cfg["adapter_path"] == str(paths["adapter"]) and cfg["base_model"] == str(paths["base"]) and cfg["eval"]["path"] == str(paths["eval"])
        assert cfg["prompt"]["style"] == "raw" and cfg["prompt"]["raw_wrapper"] == "<s>[INST] {user} [/INST]" and cfg["gen"] == {"max_new_tokens": 64, "temperature": 0.0, "stop": ["[INST]"]}
        assert cfg["notes"]["source"] == "agent" and cfg["notes"]["env_hint"] == "source activate epubs_ft"
        # the wrong first proposal came back with both problems named, and the agent corrected it
        setup_msgs = next(c["messages"] for c in reversed(fake.calls) if "setup agent" in c["messages"][0]["content"])
        rejected = next(m["content"] for m in setup_msgs if m["role"] == "tool" and "config rejected" in m["content"])
        assert "no adapter_config.json" in rejected and "must contain both {context} and {question}" in rejected
        notes = (out / "setup_notes.md").read_text()
        assert "source activate epubs_ft" in notes and "train_sft.py:8" in notes and f"{NQ} usable" in notes
        # gpt-5-style parameter rejections were settled by the single warm-up call, before any worker thread ran
        assert fake.rejected == ["temperature", "max_tokens"] and all("max_completion_tokens" in c and c["extra_body"] == {"reasoning_effort": "low"} for c in fake.calls)
        assert len(ev.read_jsonl(out / "evidence.jsonl")) == 4 and len(rg.load_predictions(out, "lora_rag")) == 4
        first_report = (out / "comparison.md").read_text()
        assert "n = 4" in first_report and "seeded sample of 4 of 13" in first_report
        calls_after_first = len(fake.calls)

        # 2) the full run re-uses the config, the index and the 4 finished questions
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        assert rag_compare.main(base_args + ["--limit", "0", "--with-closed-book"]) == 0
        assert not any("setup agent" in c["messages"][0]["content"] for c in fake.calls[calls_after_first:])
        retr_questions = [c["messages"][1]["content"] for c in fake.calls[calls_after_first:] if "retrieval controller" in c["messages"][0]["content"] and len(c["messages"]) == 2]
        assert len(retr_questions) == NQ - 4  # only the 9 new questions were retrieved
        gen_rag = [p for c in fake_hf.STATE["generate_calls"] for p in c["prompts"] if "[1] " in p["prompt"] or "excerpts" in p["prompt"]]
        assert len(fake_hf.STATE["model_loads"]) == 1
        exs, _ = ev.build_examples(ev.load_records(paths["eval"]), cfg["eval"])
        evidence = {r["id"]: r for r in ev.read_jsonl(out / "evidence.jsonl")}
        by_idx = {i: evidence[e.id] for i, e in enumerate(exs)}
        lora_ok, base_ok = _expected(by_idx)
        assert (lora_ok, base_ok) == (NQ - 1, NQ - 2)
        comp = json.loads((out / "comparison.json").read_text())
        assert comp["n"] == NQ and comp["primary"] == "judge" and comp["arms"] == ["lora_rag", "base_rag", "lora_closed", "base_closed"]
        pair = {(p["a"], p["b"]): p["rows"] for p in comp["pairs"]}
        main = pair[("lora_rag", "base_rag")]["judge"]
        assert abs(main["a"] - lora_ok / NQ) < 1e-9 and abs(main["b"] - base_ok / NQ) < 1e-9 and (main["wins"], main["ties"], main["losses"]) == (1, NQ - 1, 0)
        assert abs(pair[("lora_closed", "base_closed")]["judge"]["a"] - len(MEMORISED) / NQ) < 1e-9 and pair[("lora_closed", "base_closed")]["judge"]["b"] == 0.0
        assert pair[("base_rag", "base_closed")]["judge"]["lo"] > 0  # retrieval clearly helps the base model
        # the wordier base model loses on overlap metrics even where it is factually right — the reason the judge is primary
        assert pair[("lora_rag", "base_rag")]["f1"]["delta"] > 0.3 and pair[("lora_rag", "base_rag")]["em"]["a"] > 0.9 and pair[("lora_rag", "base_rag")]["em"]["b"] == 0.0
        r = comp["retrieval"]
        assert r["mode"] == "agentic" and r["recall_mean"] > r["recall_single_mean"] and abs(r["recall_mean"] - (NQ - 2) / NQ) < 1e-9 and r["fallbacks"] == 0
        split = comp["recall_split"]
        assert split[0]["n"] == NQ - 2 and split[0]["stats"]["delta"] == 0.0 and split[1]["n"] == 2 and split[1]["stats"]["a"] == 0.5 and split[1]["stats"]["b"] == 0.0
        report = (out / "comparison.md").read_text()
        for needle in ("**Result (judge accuracy, n = 13):**", "LoRA + RAG 0.923 vs Base + RAG 0.846", "## Fine-tuned vs base model, same retrieved passages", "## What retrieval adds to the base model",
                       "## Retrieval (identical for both models)", "## Where the difference comes from", "## Largest wins for the fine-tuned model", "When must evaluations be turned in once the rating period ends?",
                       "the literal training format", "the tokenizer's chat template", "## The runner's reading of these results", "The fine-tuned model is ahead on judged accuracy"):
            assert needle in report, needle
        assert "## Largest wins for the base model" not in report
        rows = list(__import__("csv").DictReader(open(out / "per_example.csv", encoding="utf-8")))
        assert len(rows) == NQ and {"judge_lora_rag", "judge_base_rag", "pred_lora_closed", "evidence_recall", "n_searches"} <= set(rows[0])
        assert len(list(open(out / "predictions_base_rag.csv", encoding="utf-8"))) == NQ + 1
        judged = ev.read_jsonl(out / "judgments.jsonl")
        distinct = {(i, r["prediction"]) for a in rg.ARMS for i, r in rg.load_predictions(out, a).items()}
        assert len(judged) == len(distinct) < 4 * NQ and all("arm" not in j for j in judged) and not any("lora" in json.dumps(c["messages"]).lower().split("candidate answer")[0].split("reference answer")[0].replace("lora + rag", "") for c in fake.calls if "You grade" in c["messages"][0]["content"])
        state = json.loads((out / "run_state.json").read_text())
        assert state["n"] == NQ and state["styles"]["lora_rag"] == "raw" and state["runner_usage"]["calls"] > 0

        # 3) nothing changed -> no new runner retrieval/judge calls, no model load; --stages report alone works too
        n_before = len(fake.calls)
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        assert rag_compare.main(base_args + ["--limit", "0", "--with-closed-book", "--no-analysis"]) == 0
        new = fake.calls[n_before:]
        assert fake_hf.STATE["model_loads"] == [] and not any("retrieval controller" in c["messages"][0]["content"] or "You grade" in c["messages"][0]["content"] for c in new)
        assert rag_compare.main(["--out-dir", str(out), "--limit", "0", "--with-closed-book", "--stages", "report", "--no-analysis", "--model", "gpt-5.6"]) == 0
        assert json.loads((out / "comparison.json").read_text())["pairs"][0]["rows"]["judge"]["a"] == main["a"]

        # 4) overrides, redo, and the paths that need no runner at all
        assert rag_compare.main(["--out-dir", str(out), "--limit", "3", "--stages", "generate,report", "--no-judge", "--no-analysis", "--max-new-tokens", "4", "--base-prompt", "same"]) == 0
        cfg2 = json.loads((out / "rag_config.json").read_text())
        assert cfg2["gen"]["max_new_tokens"] == 4 and cfg2["prompt"]["base_style"] == "same" and "command-line overrides" in cfg2["notes"]["source"]
        comp2 = json.loads((out / "comparison.json").read_text())
        assert comp2["n"] == 3 and comp2["primary"] == "f1" and comp2["arm_means"]["base_rag"]["hit_cap"] == 1.0
        assert "Answers cut off at the token limit" in (out / "comparison.md").read_text() and "No judge scores in this run" in (out / "comparison.md").read_text()

        out2 = Path(td) / "norunner"
        import os
        saved = {k: os.environ.pop(k) for k in rag_compare.RUNNER_ENV if k in os.environ}
        try:
            fake_hf.reset(answer_fn=rag_fixture.fake_answer)
            n_before = len(fake.calls)
            try:  # agentic retrieval without a runner is an explicit error, not a silent downgrade
                rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "0"])
                raise AssertionError("expected an error")
            except SystemExit as e:
                assert "--retrieval single --no-judge" in str(e), e
            assert rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "0", "--retrieval", "single", "--ctx-k", "3"]) == 0
            assert len(fake.calls) == n_before
            cfg3 = json.loads((out2 / "rag_config.json").read_text())
            assert cfg3["notes"]["source"] == "heuristic" and cfg3["prompt"]["style"] == "chat" and cfg3["adapter_path"] == str(paths["adapter"])
            comp3 = json.loads((out2 / "comparison.json").read_text())
            assert comp3["primary"] == "f1" and comp3["retrieval"]["mode"] == "single" and comp3["n"] == NQ
            # --redo setup with explicit choices and no agent
            assert rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "2", "--retrieval", "single", "--redo", "setup", "--no-agent-setup",
                                     "--adapter", str(paths["adapter"] / "checkpoint-100"), "--eval-file", str(paths["project"] / "results" / "generated_predictions.csv")]) == 0
            cfg4 = json.loads((out2 / "rag_config.json").read_text())
            assert cfg4["adapter_path"].endswith("checkpoint-100") and cfg4["eval"]["path"].endswith("generated_predictions.csv") and (cfg4["eval"]["question_field"], cfg4["eval"]["answer_field"]) == ("question", "label")
        finally:
            os.environ.update(saved)
    print("ok  end to end: setup agent (with a rejected proposal), 4-question pass, full resume, 2x2 arms, report numbers, overrides, no-runner path")


def test_check():
    import contextlib
    import io
    import os

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        fake = FakeRunner()
        patch_runner(fake, str(paths["base"]))
        fake_hf.reset()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = rag_compare.main(["--check", "--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(Path(td) / "o"), "--model", "gpt-5.6"])
        text = buf.getvalue()
        assert rc == 0, text
        for needle in ("runner model  OK", "gpt-5.6", "torch         OK", "Fake A100 80GB", "peft          OK", "adapters      OK", "epubs_lora", "eval files    OK", "corpus        OK", "all good"):
            assert needle in text, (needle, text)
        fake_hf.reset(cuda=False)
        saved = {k: os.environ.pop(k) for k in rag_compare.RUNNER_ENV if k in os.environ}
        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                rc = rag_compare.main(["--check", "--corpus", str(Path(td) / "models"), "--out-dir", str(Path(td) / "o")])
        finally:
            os.environ.update(saved)
        text = buf.getvalue()
        assert rc == 1 and "runner model  WARN" in text and "no CUDA GPU visible" in text and "corpus        FAIL" in text and "fix first: torch, corpus" in text, text
    print("ok  --check")


def main() -> int:
    test_index()
    test_eval_data()
    test_metrics_and_stats()
    test_generate_hf()
    test_prompts_and_api_backend()
    test_discovery_and_validation()
    test_retrieval_agent()
    test_end_to_end()
    test_check()
    print("ALL OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
