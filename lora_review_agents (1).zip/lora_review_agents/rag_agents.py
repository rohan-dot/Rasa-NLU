#!/usr/bin/env python3
"""
rag_agents.py — what the runner model (e.g. GPT-5.6 through LiteLLM) does in the comparison:

  1. setup      reads the LoRA project (training script, launch script, adapter, eval data) and
                produces a validated rag_config.json: which adapter, which base model, which
                held-out questions, and the exact prompt format the adapter was trained on;
  2. retrieval  per question, drives the search tools (rewrite, split, re-search, read on) and
                picks the passages that BOTH generator models will see;
  3. judging    scores each answer against the reference without knowing which model wrote it;
  4. analysis   a short reading of the finished numbers.

The runner never writes text that reaches the generator models — it only chooses passages — so
the measured difference between the fine-tuned and the base model is theirs, not the runner's.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from agent_core import Agent, EmptyOutputError, LLMClient, ToolError, ToolRegistry, generate_long
from rag_eval import ARM_LABELS, Example, JsonlAppender, build_examples, detect_schema, evidence_recall, load_records, read_jsonl, sha, write_jsonl
from rag_generate import DEFAULT_RAG_TEMPLATE, fill
from rag_index import Retriever, format_hits

WALK_SKIP = {".git", "__pycache__", "node_modules", "wandb", ".ipynb_checkpoints", "site-packages", ".venv", "venv"}
TOKENIZER_FILES = ("tokenizer_config.json", "tokenizer.json", "tokenizer.model")
ADAPTER_WEIGHTS = ("adapter_model.safetensors", "adapter_model.bin")
EVAL_EXT = {".json", ".jsonl", ".csv", ".tsv", ".parquet"}
EVAL_NAME_RE = re.compile(r"(?<![a-z])(eval|test|val|dev|held|pred)", re.I)  # eval_dataset.json, test.jsonl, x_val.csv, generated_predictions.csv — not retrieval.json
NOT_EVAL_NAMES = {
    "trainer_state.json", "adapter_config.json", "tokenizer.json", "tokenizer_config.json", "special_tokens_map.json", "config.json",
    "generation_config.json", "all_results.json", "eval_results.json", "train_results.json", "test_results.json", "added_tokens.json", "vocab.json",
}
PREDICTION_COLS = {"predict", "prediction", "predictions", "generated", "model_output", "pred", "hypothesis"}
MAX_EVAL_BYTES = 200 * 1024 * 1024
MAX_EVAL_FILES = 300


# --------------------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------------------


def default_config() -> dict:
    return {
        "version": 1,
        "base_model": "",
        "adapter_path": "",
        "eval": {"path": "", "format": "fields", "question_field": "", "answer_field": "", "input_field": None, "id_field": None, "messages_field": None},
        "prompt": {
            "style": "chat",        # how the adapter was trained: "chat" (tokenizer chat template) or "raw" (literal string)
            "base_style": "auto",   # base model: "auto" = its own chat template when it has one; "same" = identical to the adapter
            "system": "",
            "raw_wrapper": "",      # style "raw": the training string up to where the answer starts, with {user} (and {system})
            "closed_book": "{question}",
            "rag": DEFAULT_RAG_TEMPLATE,
        },
        "gen": {"max_new_tokens": 256, "temperature": 0.0, "stop": []},
        "notes": {"source": "heuristic", "rationale": "", "env_hint": ""},
    }


def merge_config(base: dict, over: dict) -> dict:
    out = json.loads(json.dumps(base))
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k].update(v)
        else:
            out[k] = v
    return out


def load_config(path: str | Path) -> dict:
    try:
        cfg = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise SystemExit(f"{path} is not valid JSON: {e}") from e
    return merge_config(default_config(), cfg)


def save_config(path: str | Path, cfg: dict) -> None:
    Path(path).write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _under(path: Path, roots: list[Path]) -> bool:
    rp = path.resolve()
    for r in roots:
        try:
            rp.relative_to(Path(r).resolve())
            return True
        except ValueError:
            continue
    return False


def read_adapter_config(adapter_dir: str | Path) -> dict:
    try:
        return json.loads((Path(adapter_dir) / "adapter_config.json").read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError):
        return {}


def hf_cache_has(model_id: str) -> bool:
    name = "models--" + model_id.strip("/").replace("/", "--")
    homes = [os.environ.get("HF_HUB_CACHE"), os.environ.get("HUGGINGFACE_HUB_CACHE"), os.environ.get("TRANSFORMERS_CACHE")]
    homes.append(os.path.join(os.environ.get("HF_HOME") or os.path.join("~", ".cache", "huggingface"), "hub"))
    return any(os.path.isdir(os.path.join(os.path.expanduser(h), name)) for h in homes if h)


def looks_like_path(s: str) -> bool:
    return s.startswith(("/", "./", "../", "~")) or os.path.isdir(s)


def schema_overrides_for(path: str | Path) -> dict:
    """Field mapping detected in an eval file, as an `eval` config fragment ({} when nothing fits)."""
    try:
        sc = detect_schema(load_records(path))
    except Exception:  # noqa: BLE001
        sc = None
    if not sc:
        return {}
    return {k: sc.get(k) for k in ("format", "question_field", "answer_field", "input_field", "id_field", "messages_field")}


def validate_config(cfg: dict, allowed_roots: list[Path] | None = None) -> tuple[list[str], list[str], dict]:
    """Check a config against the filesystem. Returns (errors, warnings, info). `allowed_roots`
    restricts where the eval file may live (None = anywhere): its questions are sent to the runner
    model, so the setup agent may only pick one inside directories the user named. The adapter is
    only ever loaded locally and may live anywhere."""
    errors: list[str] = []
    warnings: list[str] = []
    info: dict[str, Any] = {}

    adapter = Path(cfg.get("adapter_path") or "")
    acfg: dict = {}
    if not cfg.get("adapter_path"):
        errors.append("adapter_path is empty")
    elif not adapter.is_dir():
        errors.append(f"adapter_path is not a directory: {adapter}")
    elif not (adapter / "adapter_config.json").exists():
        errors.append(f"no adapter_config.json in {adapter} — adapter_path must be the directory that holds adapter_config.json and adapter_model.*")
    else:
        if not any((adapter / w).exists() for w in ADAPTER_WEIGHTS):
            errors.append(f"{adapter} has adapter_config.json but no adapter weights ({' / '.join(ADAPTER_WEIGHTS)})")
        acfg = read_adapter_config(adapter)
        ptype = str(acfg.get("peft_type") or "").upper()
        if ptype and ptype not in ("LORA", "ADALORA", "DORA", "LOHA", "LOKR", "IA3", "OFT", "BOFT", "VERA"):
            warnings.append(f"adapter peft_type is {ptype}; it is loaded with PeftModel.from_pretrained like any PEFT adapter")
        info["adapter"] = {k: acfg.get(k) for k in ("peft_type", "r", "lora_alpha", "lora_dropout", "target_modules", "base_model_name_or_path", "use_dora", "use_rslora") if acfg.get(k) is not None}
        info["adapter"]["has_tokenizer"] = any((adapter / f).exists() for f in TOKENIZER_FILES)

    base = str(cfg.get("base_model") or "").strip()
    if not base:
        errors.append("base_model is empty (adapter_config.json usually names it in base_model_name_or_path)")
    elif looks_like_path(base):
        bp = Path(base).expanduser()
        if not bp.is_dir():
            errors.append(f"base_model path does not exist: {base}")
        elif not (bp / "config.json").exists():
            warnings.append(f"base_model directory {base} has no config.json — is it the model directory itself?")
    else:
        info["base_is_hub_id"] = True
        if not hf_cache_has(base):
            warnings.append(f"base_model '{base}' is a hub id that is not in this user's Hugging Face cache; on an offline node pass --base-model /local/path")
    trained_on = acfg.get("base_model_name_or_path")
    if base and trained_on and Path(str(trained_on)).name != Path(base).name:
        warnings.append(f"the adapter was trained on '{trained_on}' but base_model is '{base}'")

    ecfg = cfg.get("eval") or {}
    epath = Path(ecfg.get("path") or "")
    if not ecfg.get("path"):
        errors.append("eval.path is empty")
    elif not epath.exists():
        errors.append(f"eval file not found: {epath}")
    elif allowed_roots is not None and not _under(epath, allowed_roots):
        errors.append(f"eval file {epath} is outside the directories given on the command line (its directory must be added by the user with --root data={epath.parent}, or the file passed with --eval-file)")
    else:
        try:
            records = load_records(epath)
        except Exception as e:  # noqa: BLE001
            records = []
            errors.append(f"could not read eval file {epath}: {e}")
        if records:
            fmt = ecfg.get("format") or "fields"
            if fmt == "fields" and (not ecfg.get("question_field") or not ecfg.get("answer_field")):
                errors.append(f"eval.question_field and eval.answer_field are required; the records have keys {sorted(map(str, records[0]))[:20]}")
            else:
                examples, skipped = build_examples(records, ecfg)
                info.update(n_records=len(records), n_examples=len(examples), n_skipped=skipped)
                if not examples:
                    errors.append(f"no usable question/answer pairs in {epath} with this field mapping; the records have keys {sorted(map(str, records[0]))[:20]}")
                else:
                    if skipped > 0.2 * len(records):
                        warnings.append(f"{skipped} of {len(records)} eval records have an empty question or answer and are skipped")
                    info["sample"] = {"question": examples[0].query[:400], "answer": examples[0].answer[:400]}
                    lens = sorted(len(e.answer.split()) for e in examples)
                    info["answer_words_p50"], info["answer_words_p95"] = lens[len(lens) // 2], lens[min(len(lens) - 1, int(0.95 * len(lens)))]
        elif not errors:
            errors.append(f"{epath} contains no records (expected a list of question/answer objects)")

    p = cfg.get("prompt") or {}
    if p.get("style") not in ("chat", "raw"):
        errors.append("prompt.style must be 'chat' or 'raw'")
    if p.get("base_style") not in ("auto", "same", "chat", "raw"):
        errors.append("prompt.base_style must be auto, same, chat or raw")
    if "{question}" not in (p.get("closed_book") or ""):
        errors.append("prompt.closed_book must contain {question}")
    rag = p.get("rag") or ""
    if "{question}" not in rag or "{context}" not in rag:
        errors.append("prompt.rag must contain both {context} and {question}")
    if p.get("style") == "raw":
        if "{user}" not in (p.get("raw_wrapper") or ""):
            errors.append("prompt.raw_wrapper must contain {user} when prompt.style is 'raw' (the training string up to where the answer begins)")
    g = cfg.get("gen") or {}
    try:
        mnt = int(g.get("max_new_tokens", 256))
        if not 4 <= mnt <= 4096:
            errors.append("gen.max_new_tokens must be between 4 and 4096")
        elif info.get("answer_words_p95") and mnt < 1.5 * info["answer_words_p95"]:
            warnings.append(f"gen.max_new_tokens={mnt} is small for this eval set (95% of reference answers have up to {info['answer_words_p95']} words); answers may be cut off")
    except (TypeError, ValueError):
        errors.append("gen.max_new_tokens must be an integer")
    return errors, warnings, info


# --------------------------------------------------------------------------------------
# deterministic discovery (used as the agent's starting point and as the no-agent fallback)
# --------------------------------------------------------------------------------------


def _walk(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in WALK_SKIP and not d.startswith("."))
        yield Path(dirpath), filenames


def find_adapters(roots: dict[str, Path]) -> list[dict]:
    """Every directory holding an adapter_config.json, best candidate first
    (has weights, not an intermediate checkpoint, most recently written)."""
    out = []
    for order, (label, root) in enumerate(roots.items()):
        for d, filenames in _walk(root):
            if "adapter_config.json" not in filenames:
                continue
            acfg = read_adapter_config(d)
            weights = next((d / w for w in ADAPTER_WEIGHTS if (d / w).exists()), None)
            rel = d.relative_to(root).as_posix()
            out.append({
                "path": str(d),
                "shown_as": f"{label}/{rel}" if label else rel,
                "root_order": order,
                "has_weights": weights is not None,
                "weights_mb": round(weights.stat().st_size / 1e6, 1) if weights else 0,
                "mtime": (weights or d / "adapter_config.json").stat().st_mtime,
                "is_checkpoint": bool(re.fullmatch(r"checkpoint-\d+", d.name)),
                "has_tokenizer": any((d / f).exists() for f in TOKENIZER_FILES),
                "base_model": acfg.get("base_model_name_or_path"),
                "peft_type": acfg.get("peft_type"),
                "r": acfg.get("r"),
                "lora_alpha": acfg.get("lora_alpha"),
                "target_modules": acfg.get("target_modules"),
            })
    out.sort(key=lambda a: (not a["has_weights"], a["root_order"], a["is_checkpoint"], -a["mtime"]))  # the LoRA project's own adapters first
    return out


def find_eval_candidates(roots: dict[str, Path]) -> list[dict]:
    """Data files whose name suggests a held-out split and whose records have recognisable
    question/answer fields, most plausible first."""
    out = []
    examined = 0
    for order, (label, root) in enumerate(roots.items()):
        for d, filenames in _walk(root):
            if re.fullmatch(r"checkpoint-\d+", d.name):  # trainer bookkeeping, never data
                continue
            for fn in sorted(filenames):
                p = d / fn
                if p.suffix.lower() not in EVAL_EXT or fn in NOT_EVAL_NAMES or not EVAL_NAME_RE.search(fn):
                    continue
                examined += 1
                if examined > MAX_EVAL_FILES:
                    break
                try:
                    if p.stat().st_size > MAX_EVAL_BYTES:
                        continue
                    records = load_records(p)
                except Exception:  # noqa: BLE001
                    continue
                schema = detect_schema(records)
                if not schema:
                    continue
                examples, _ = build_examples(records[:300], schema)
                if not examples:
                    continue
                keys = {str(k).lower() for k in records[0]}
                name = fn.lower()
                rel = p.relative_to(root).as_posix()
                out.append({
                    "path": str(p),
                    "shown_as": f"{label}/{rel}" if label else rel,
                    "n_records": len(records),
                    "schema": schema,
                    "sample": {"question": examples[0].query[:300], "answer": examples[0].answer[:300]},
                    "is_predictions": bool(keys & PREDICTION_COLS),
                    "_rank": (bool(keys & PREDICTION_COLS), 0 if ("eval" in name or "test" in name) else 1, order, rel),
                })
    out.sort(key=lambda c: c["_rank"])
    for c in out:
        c.pop("_rank")
    return out


def draft_config(adapters: list[dict], eval_cands: list[dict]) -> dict:
    """Best guess without reading any code: newest final adapter, its recorded base model, the most
    plausible eval file, and a generic chat-template prompt."""
    cfg = default_config()
    if adapters:
        cfg["adapter_path"] = adapters[0]["path"]
        cfg["base_model"] = str(adapters[0].get("base_model") or "")
    if eval_cands:
        c = eval_cands[0]
        sc = c["schema"]
        cfg["eval"].update(path=c["path"], format=sc.get("format", "fields"), question_field=sc.get("question_field"), answer_field=sc.get("answer_field"), input_field=sc.get("input_field"), id_field=sc.get("id_field"), messages_field=sc.get("messages_field"))
        ci = sc.get("constant_instruction")
        if ci:  # alpaca-style data whose instruction is the same for every record
            cfg["prompt"]["closed_book"] = f"{ci}\n\n{{question}}"
            cfg["prompt"]["rag"] = f"{ci}\n\n{DEFAULT_RAG_TEMPLATE}"
    return cfg


# --------------------------------------------------------------------------------------
# 1. setup agent
# --------------------------------------------------------------------------------------

SETUP_SYSTEM = """You are the setup agent of a RAG evaluation harness. The harness will answer a held-out question set twice with retrieved passages — once with a LoRA fine-tuned model, once with the same base model without the adapter — and compare the answers. Your job is to work out, from the fine-tuning project's own files, the configuration that makes this comparison correct. You have read-only tools over the project. Verify every value in the files; never guess.

Establish, in this order:
1. adapter_path — the final adapter the project's reported results come from. Start with list_adapters. Prefer the directory the training script saves to at the end over intermediate checkpoint-N directories, unless the code or logs show a specific checkpoint was selected. It must contain adapter_config.json and adapter weights.
2. base_model — exactly what the training run loaded (a local path or a hub id). Check the launch script's arguments first, then the training script's defaults, then adapter_config.json. Prefer a local path that the scripts actually use.
3. The evaluation set — the held-out file the project evaluates on, not the training file and not a file of saved model predictions. Find where the scripts read it, then call inspect_eval_file on it and choose question_field / answer_field (and input_field only if the data has a per-example input that the training prompt also used). If a constant instruction lives in a data field, put its text in the templates instead.
4. The prompt format the adapter was trained on. Read the function that builds the training text.
   - prompt_style "chat": the script builds role/content messages and applies the tokenizer's chat template (or a trainer does it from a messages dataset).
   - prompt_style "raw": the script formats a string by hand. Then raw_wrapper must reproduce that string exactly, up to where the answer begins, with {user} where the user content goes (and {system} if there is one). Keep literal special tokens such as <s> or [INST] only if the script itself writes them.
   - closed_book_template: the user content exactly as trained, with {question} (and {input} if used).
   - system_prompt: the system message used in training, or "".
5. rag_template — the same user content with a block of retrieved excerpts placed before the question: keep the training wording, add one sentence telling the model to use the excerpts and to answer in its usual style, and use the placeholders {context} and {question}.
6. max_new_tokens — the value the project's own inference/eval code uses (256 if it has none); stop — strings that mark the start of a new turn in a raw format (e.g. "[INST]", "### Question"), else an empty list.
7. env_hint — how the launch script sets up Python (conda env, module load, venv), copied verbatim, or "".

Then call propose_config. If it returns errors, fix them and call it again. When it is accepted you are done. Be economical: a handful of targeted reads is enough."""

SETUP_USER = """Project directories (tool paths are relative to these{label_note}):
{roots}
{role_note}

{inventory}

## Adapters found (best guess first)
{adapters}

## Evaluation-file candidates (best guess first)
{evals}

## Draft configuration from filename heuristics — verify and correct it against the code
```json
{draft}
```
{overrides}"""


def _fmt_adapters(adapters: list[dict]) -> str:
    if not adapters:
        return "(none found — search for adapter_config.json)"
    lines = []
    for a in adapters[:15]:
        tag = "checkpoint" if a["is_checkpoint"] else "final dir"
        if not a["has_weights"]:
            tag += ", NO WEIGHTS"
        lines.append(f"- {a['shown_as']}  [{tag}, {a['weights_mb']} MB, tokenizer saved: {'yes' if a['has_tokenizer'] else 'no'}]  base={a['base_model']}  {a['peft_type']} r={a['r']} alpha={a['lora_alpha']} targets={a['target_modules']}")
    return "\n".join(lines)


def _fmt_evals(cands: list[dict]) -> str:
    if not cands:
        return "(none recognised — find the eval file in the scripts and check it with inspect_eval_file)"
    lines = []
    for c in cands[:10]:
        sc = c["schema"]
        fields = f"messages in '{sc['messages_field']}'" if sc.get("format") == "messages" else f"question='{sc['question_field']}' answer='{sc['answer_field']}'" + (f" input='{sc['input_field']}'" if sc.get("input_field") else "")
        note = "  [looks like saved predictions]" if c["is_predictions"] else ""
        lines.append(f"- {c['shown_as']}: {c['n_records']} records, {fields}{note}\n    e.g. Q: {c['sample']['question'][:160]!r}\n         A: {c['sample']['answer'][:160]!r}")
    return "\n".join(lines)


def run_setup(
    roots: dict[str, Path],
    llm: LLMClient | None,
    *,
    overrides: dict | None = None,
    extra_allowed: list[Path] | None = None,
    max_turns: int = 25,
    trace_path: Path | None = None,
    log: Callable[[str], None] | None = None,
) -> tuple[dict, dict]:
    """Produce a validated config. Returns (config, report) where report holds what was found
    and the validation result. `overrides` are the user's explicit choices and always win."""
    from repo_tools import RepoTools, render_inventory_md  # only the setup stage needs these

    log = log or (lambda m: print(f"[setup] {m}", file=sys.stderr, flush=True))
    overrides = overrides or {}
    allowed = [Path(p) for p in roots.values()] + list(extra_allowed or [])
    adapters = find_adapters(roots)
    eval_cands = find_eval_candidates(roots)
    draft = draft_config(adapters, eval_cands)
    user_eval = (overrides.get("eval") or {}).get("path")
    if user_eval and user_eval != draft["eval"]["path"]:  # the user's file: its own field mapping, not the candidate's
        draft["eval"] = merge_config(default_config(), {"eval": schema_overrides_for(user_eval)})["eval"]
    draft = merge_config(draft, overrides)
    log(f"found {len(adapters)} adapter dir(s) and {len(eval_cands)} eval-file candidate(s)")
    multi = any(roots)

    def to_abs(p: str) -> str:
        """Agent paths are label-relative ('lora/outputs/x'); absolute paths are kept."""
        p = os.path.expanduser(str(p or "").strip())
        if not p or os.path.isabs(p):
            return p
        if multi:
            label, _, rest = p.partition("/")
            if label in roots:
                return str((roots[label] / rest).resolve())
        first = next(iter(roots.values()))
        return str((first / p).resolve())

    def resolve_base(b: str) -> str:
        """A base model is a local directory (absolute, or relative to the project) or a hub id."""
        b = str(b or "").strip()
        if os.path.isabs(os.path.expanduser(b)):
            return os.path.expanduser(b)
        cand = to_abs(b)
        return cand if cand and os.path.isdir(cand) else b

    accepted: dict[str, Any] = {}
    rejected: dict[str, Any] = {}

    def apply_user_overrides(cfg: dict) -> dict:
        return merge_config(cfg, overrides)

    if llm is not None:
        repo = RepoTools(roots=roots)
        registry = ToolRegistry()
        registry.register_specs(repo.tool_specs())

        def list_adapters() -> str:
            return _fmt_adapters(find_adapters(roots))

        def inspect_eval_file(path: str) -> str:
            ap = Path(to_abs(path))
            if not ap.exists():
                raise ToolError(f"no such file: {path}")
            if not _under(ap, allowed):
                raise ToolError(f"{path} is outside the project directories; it can only be used if the user adds its directory with --root")
            records = load_records(ap)
            if not records:
                return f"{path}: no question/answer records found (a list of objects is expected)"
            keys: dict[str, int] = {}
            for r in records[:200]:
                for k, v in r.items():
                    if v not in (None, "", [], {}):
                        keys[str(k)] = keys.get(str(k), 0) + 1
            schema = detect_schema(records)
            samples = [json.dumps({k: (v[:300] + "…" if isinstance(v, str) and len(v) > 300 else v) for k, v in r.items()}, ensure_ascii=False, default=str)[:1500] for r in records[:2]]
            return (
                f"{path}: {len(records)} records\n"
                f"non-empty keys in the first {min(200, len(records))} records: {json.dumps(keys)}\n"
                f"auto-detected mapping: {json.dumps(schema)}\n"
                "first records:\n" + "\n".join(samples)
            )

        def propose_config(
            adapter_path: str,
            base_model: str,
            eval_path: str,
            prompt_style: str,
            closed_book_template: str,
            rag_template: str,
            rationale: str,
            question_field: str = "",
            answer_field: str = "",
            input_field: str = "",
            eval_format: str = "fields",
            messages_field: str = "",
            raw_wrapper: str = "",
            system_prompt: str = "",
            max_new_tokens: int = 256,
            stop: list | None = None,
            env_hint: str = "",
        ) -> str:
            cfg = default_config()
            cfg.update(adapter_path=to_abs(adapter_path), base_model=resolve_base(base_model))
            cfg["eval"].update(path=to_abs(eval_path), format=eval_format or "fields", question_field=question_field or None, answer_field=answer_field or None, input_field=input_field or None, messages_field=messages_field or None)
            cfg["prompt"].update(style=prompt_style, raw_wrapper=raw_wrapper or "", system=system_prompt or "", closed_book=closed_book_template, rag=rag_template)
            cfg["gen"].update(max_new_tokens=int(max_new_tokens or 256), stop=[str(s) for s in (stop or []) if str(s)])
            cfg["notes"].update(source="agent", rationale=str(rationale).strip(), env_hint=str(env_hint or "").strip())
            cfg = apply_user_overrides(cfg)
            errors, warnings, info = validate_config(cfg, allowed)
            if errors:
                rejected.update(cfg=cfg, errors=errors)
                raise ToolError("config rejected:\n- " + "\n- ".join(errors))
            accepted.update(cfg=cfg, warnings=warnings, info=info)
            return f"ACCEPTED: {info.get('n_examples')} evaluation questions; adapter {cfg['adapter_path']}; base {cfg['base_model']}." + (" Warnings: " + "; ".join(warnings) if warnings else "")

        S = lambda **props: {"type": "object", "properties": props}  # noqa: E731
        registry.register_specs([
            {"name": "list_adapters", "description": "List every directory that contains an adapter_config.json, with weights/size/base model/LoRA settings.", "parameters": S(), "fn": list_adapters},
            {"name": "inspect_eval_file", "description": "Parse a data file (.json/.jsonl/.csv/.tsv/.parquet): record count, field names, auto-detected question/answer mapping and the first two records.", "parameters": {**S(path={"type": "string"}), "required": ["path"]}, "fn": inspect_eval_file},
            {
                "name": "propose_config",
                "description": "Submit the configuration. It is validated against the files; errors come back for you to fix. Call it once you have verified the values in the code.",
                "parameters": {
                    **S(
                        adapter_path={"type": "string", "description": "directory with adapter_config.json + adapter weights"},
                        base_model={"type": "string", "description": "local path or hub id the training run loaded"},
                        eval_path={"type": "string", "description": "held-out evaluation file"},
                        eval_format={"type": "string", "enum": ["fields", "messages"], "description": "'messages' for chat-format records"},
                        question_field={"type": "string"},
                        answer_field={"type": "string"},
                        input_field={"type": "string", "description": "optional per-example input field"},
                        messages_field={"type": "string", "description": "for eval_format=messages"},
                        prompt_style={"type": "string", "enum": ["chat", "raw"]},
                        raw_wrapper={"type": "string", "description": "prompt_style=raw: the training string up to where the answer starts, with {user} (and {system})"},
                        system_prompt={"type": "string"},
                        closed_book_template={"type": "string", "description": "user content as trained, with {question}"},
                        rag_template={"type": "string", "description": "same user content plus the excerpts block, with {context} and {question}"},
                        max_new_tokens={"type": "integer"},
                        stop={"type": "array", "items": {"type": "string"}},
                        env_hint={"type": "string", "description": "how the launch script sets up Python, verbatim"},
                        rationale={"type": "string", "description": "2-5 sentences: which files/lines each choice comes from"},
                    ),
                    "required": ["adapter_path", "base_model", "eval_path", "prompt_style", "closed_book_template", "rag_template", "rationale"],
                },
                "fn": propose_config,
            },
        ])
        agent = Agent(llm, registry, SETUP_SYSTEM, name="setup-agent", max_turns=max_turns, trace_path=trace_path, verbose=True, notes_tools=False, stop_tools={"propose_config"}, require_stop=True)
        inventory = render_inventory_md(repo.build_inventory(), max_chars=12_000)
        user = SETUP_USER.format(
            label_note="; each starts with its label" if multi else "",
            role_note=("`lora/` is the LoRA fine-tuning project under evaluation. The other directories are supporting material the user made readable (shared data, a sibling project): "
                       "use them only for files that the LoRA project's own scripts refer to, and never take the adapter from a sibling project.\n") if len(roots) > 1 and "lora" in roots else "",
            roots="\n".join(f"- `{label}/` = {p}" if label else f"- {p}" for label, p in roots.items()),
            inventory=inventory,
            adapters=_fmt_adapters(adapters),
            evals=_fmt_evals(eval_cands),
            draft=json.dumps({k: draft[k] for k in ("adapter_path", "base_model", "eval", "prompt", "gen")}, indent=1),
            overrides=("\nThe user fixed these values; keep them: " + json.dumps(overrides)) if overrides else "",
        )
        try:
            agent.run(user)
        except EmptyOutputError as e:  # pragma: no cover
            log(f"setup agent produced no output ({e}); falling back to the heuristic draft")

    if accepted:
        cfg, warnings, info = accepted["cfg"], accepted["warnings"], accepted["info"]
        log("configuration accepted from the setup agent")
    else:
        cfg = draft
        errors, warnings, info = validate_config(cfg, None)
        agent_note = ""
        if rejected:
            rc = rejected["cfg"]
            agent_note = (
                "The setup agent's last proposal was rejected:\n- " + "\n- ".join(rejected["errors"])
                + f"\n  it proposed: adapter={rc['adapter_path']}  base={rc['base_model']}  eval={rc['eval']['path']}"
            )
        if errors:
            raise SystemExit(
                "could not work out a valid configuration:\n- " + "\n- ".join(errors)
                + ("\n" + agent_note if agent_note else "")
                + "\nPass the missing pieces explicitly: --adapter DIR  --base-model PATH  --eval-file FILE  [--question-field F --answer-field F]"
            )
        if llm is not None:
            log("WARNING: the setup agent did not reach an accepted configuration; using filename heuristics instead — check setup_notes.md before trusting the run")
            if agent_note:
                log(agent_note)
                warnings = warnings + [agent_note.replace("\n", " ")]
    report = {"adapters": adapters, "eval_candidates": eval_cands, "warnings": warnings, "info": info}
    return cfg, report


def render_setup_notes(cfg: dict, report: dict) -> str:
    info, p, e = report.get("info", {}), cfg["prompt"], cfg["eval"]
    L = ["# RAG comparison — setup", "", f"Source: {cfg['notes'].get('source', '?')} (edit `rag_config.json` to change anything, then re-run; the setup stage is skipped while that file exists).", ""]
    L += ["## What will be compared", ""]
    a = info.get("adapter", {})
    L.append(f"- **Fine-tuned model**: base + adapter `{cfg['adapter_path']}`" + (f" ({a.get('peft_type')}, r={a.get('r')}, alpha={a.get('lora_alpha')}, targets={a.get('target_modules')})" if a else ""))
    L.append(f"- **Base model**: `{cfg['base_model']}` (the same weights, no adapter)")
    fields = f"messages in `{e.get('messages_field')}`" if e.get("format") == "messages" else f"question=`{e.get('question_field')}`, answer=`{e.get('answer_field')}`" + (f", input=`{e.get('input_field')}`" if e.get("input_field") else "")
    L.append(f"- **Questions**: `{e['path']}` — {info.get('n_examples', '?')} usable of {info.get('n_records', '?')} records ({fields})")
    if info.get("sample"):
        L += ["", f"  Example — Q: {info['sample']['question']}", f"  Reference: {info['sample']['answer']}"]
    L += ["", "## Prompt format", ""]
    if p["style"] == "raw":
        L += ["Fine-tuned model: literal training format (`raw`):", "", "```", p["raw_wrapper"], "```", ""]
    else:
        L += ["Fine-tuned model: the tokenizer's chat template (`chat`).", ""]
    base = {"auto": "its own chat template when the tokenizer has one, otherwise the same format as the adapter", "same": "exactly the same format as the adapter", "chat": "the tokenizer's chat template", "raw": "the raw wrapper"}[p.get("base_style", "auto")]
    L += [f"Base model: {base}.", ""]
    if p.get("system"):
        L += ["System prompt:", "", "```", p["system"], "```", ""]
    L += ["User content with retrieved passages:", "", "```", fill(p["rag"], question="<question>", context="[1] <document>\n<passage text>\n\n[2] ...", input="<input>"), "```", ""]
    L += ["User content without retrieval:", "", "```", fill(p["closed_book"], question="<question>", input="<input>"), "```", ""]
    L += [f"Generation: greedy, max_new_tokens={cfg['gen']['max_new_tokens']}" + (f", stop={cfg['gen']['stop']}" if cfg["gen"].get("stop") else "") + ".", ""]
    if cfg["notes"].get("rationale"):
        L += ["## Why (setup agent)", "", cfg["notes"]["rationale"], ""]
    if cfg["notes"].get("env_hint"):
        L += ["## Python environment used by the training launch script", "", "```", cfg["notes"]["env_hint"], "```", ""]
    if report.get("warnings"):
        L += ["## Warnings", ""] + [f"- {w}" for w in report["warnings"]] + [""]
    if len(report.get("adapters", [])) > 1:
        L += ["## Other adapters in the project", ""] + [f"- `{x['path']}`" + (" (checkpoint)" if x["is_checkpoint"] else "") for x in report["adapters"] if x["path"] != cfg["adapter_path"]][:12] + [""]
    return "\n".join(L) + "\n"


# --------------------------------------------------------------------------------------
# 2. retrieval
# --------------------------------------------------------------------------------------

RETRIEVAL_SYSTEM = """You are the retrieval controller in a RAG evaluation. For ONE question, find the passages in the document collection that contain its answer. A different model will write the answer from the passages you select — never answer the question yourself.

Tools
- search(query, k, doc_filter): ranked passage search. Each hit shows its chunk id as [c123], the document and the text. doc_filter keeps only documents whose file name contains that text.
- neighbors(chunk_id): the passages just before and after a hit in the same document — use it when the answer seems to continue past the edge of a passage.
- submit_evidence(chunk_ids, sufficient, note): finish.

Method
1. Search with the question's distinctive terms: publication numbers, form names, role titles, exact phrases, quantities.
2. Read the hits. If none states the answer, search again with different wording — the document's official term instead of the question's paraphrase, a narrower phrase, or one search per part of a multi-part question. You have {max_searches} searches.
3. Select at most {ctx_k} chunk ids, the passage that states the answer first. Leave out passages that only share words with the question.
4. Call submit_evidence. If no passage states the answer, set sufficient=false and still submit the closest ones."""


def _chunk_id(x: Any) -> int:
    m = re.search(r"-?\d+", str(x))
    if not m:
        raise ToolError(f"not a chunk id: {x!r} (use the number shown as [c123])")
    return int(m.group(0))


def single_shot(retriever: Retriever, query: str, ctx_k: int) -> list[dict]:
    return retriever.search(query, ctx_k)


def agentic_retrieve(llm: LLMClient, retriever: Retriever, question: str, *, ctx_k: int = 5, search_k: int = 6, max_searches: int = 4) -> dict:
    """One question: the runner searches, reads and selects. Returns chunks plus what it did."""
    st: dict[str, Any] = {"queries": [], "seen": {}, "selected": None, "sufficient": None, "note": ""}

    def remember(hits: list[dict]) -> None:
        for h in hits:
            old = st["seen"].get(h["id"])
            if old is None or h.get("score", 0) > old.get("score", 0):
                st["seen"][h["id"]] = h

    def search(query: str, k: int | None = None, doc_filter: str | None = None) -> str:
        if len(st["queries"]) >= max_searches:
            return "Search budget used up. Call submit_evidence now with the best chunk ids you have seen."
        hits = retriever.search(str(query), max(1, min(int(k or search_k), 12)), doc_filter or None)
        st["queries"].append(str(query))
        remember(hits)
        return format_hits(hits) + f"\n\n({max_searches - len(st['queries'])} search(es) left)"

    def neighbors(chunk_id: Any) -> str:
        cid = _chunk_id(chunk_id)
        if not 0 <= cid < retriever.n_chunks:
            raise ToolError(f"unknown chunk id {cid}")
        hits = retriever.neighbors(cid)
        remember(hits)
        return format_hits(hits) if hits else "this passage has no neighbours (single-passage document)"

    def submit_evidence(chunk_ids: list | None = None, sufficient: bool = True, note: str = "") -> str:
        ids: list[int] = []
        for c in chunk_ids or []:
            cid = _chunk_id(c)
            if not 0 <= cid < retriever.n_chunks:
                raise ToolError(f"unknown chunk id {cid}")
            if cid not in ids:
                ids.append(cid)
        if not ids and st["seen"]:
            raise ToolError("submit at least one chunk id — the closest passages you saw — and set sufficient=false if they do not state the answer")
        st.update(selected=ids[:ctx_k], sufficient=bool(sufficient), note=str(note or "")[:300])
        return f"evidence recorded: {len(st['selected'])} passage(s)"

    S = lambda **props: {"type": "object", "properties": props}  # noqa: E731
    registry = ToolRegistry(max_result_chars=18_000)
    registry.register_specs([
        {"name": "search", "description": "Ranked passage search over the document collection.", "parameters": {**S(query={"type": "string"}, k={"type": "integer", "description": f"number of hits (default {search_k})"}, doc_filter={"type": "string", "description": "optional: only documents whose file name contains this text"}), "required": ["query"]}, "fn": search},
        {"name": "neighbors", "description": "The passages immediately before and after a chunk in the same document.", "parameters": {**S(chunk_id={"type": "integer"}), "required": ["chunk_id"]}, "fn": neighbors},
        {"name": "submit_evidence", "description": "Finish: the chunk ids to hand to the answering model, best first.", "parameters": {**S(chunk_ids={"type": "array", "items": {"type": "integer"}}, sufficient={"type": "boolean", "description": "do the passages state the answer?"}, note={"type": "string", "description": "one short line"}), "required": ["chunk_ids", "sufficient"]}, "fn": submit_evidence},
    ])
    agent = Agent(llm, registry, RETRIEVAL_SYSTEM.format(max_searches=max_searches, ctx_k=ctx_k), name="retriever", max_turns=max_searches + 3, verbose=False, notes_tools=False, stop_tools={"submit_evidence"}, require_stop=True)
    res = agent.run(f"Question:\n{question}")
    fallback = False
    if st["selected"] is None:  # the runner never submitted: keep the best of what it saw
        fallback = True
        ranked = sorted(st["seen"].values(), key=lambda h: -h.get("score", 0.0))
        st["selected"] = [h["id"] for h in ranked[:ctx_k]]
        if not st["selected"]:
            st["selected"] = [h["id"] for h in single_shot(retriever, question, ctx_k)]
    chunks = [st["seen"].get(cid) or retriever.get(cid) for cid in st["selected"]]
    return {"chunks": chunks, "queries": st["queries"], "n_searches": len(st["queries"]), "sufficient": st["sufficient"], "note": st["note"], "fallback": fallback, "turns": res.turns}


def retrieve_all(
    examples: list[Example],
    retriever: Retriever,
    out_path: Path,
    *,
    mode: str = "agentic",
    llm: LLMClient | None = None,
    ctx_k: int = 5,
    search_k: int = 6,
    max_searches: int = 4,
    workers: int = 6,
    log: Callable[[str], None] | None = None,
) -> dict[str, dict]:
    """Evidence for every example (cached in out_path, one JSON line per question). The same
    evidence is used for every model, so retrieval is not a variable in the comparison."""
    log = log or (lambda m: print(f"[retrieve] {m}", file=sys.stderr, flush=True))
    if mode not in ("agentic", "single"):
        raise SystemExit(f"unknown --retrieval '{mode}' (agentic or single)")
    if mode == "agentic" and llm is None:
        raise SystemExit("agentic retrieval needs the runner model (LLM_MODEL / LLM_BASE_URL / LLM_API_KEY); use --retrieval single to run without it")
    signature = {"mode": mode, "ctx_k": ctx_k, "index": retriever.meta.get("fingerprint"), "dense": retriever.meta.get("embed_model") if retriever.emb is not None else None}
    if mode == "agentic":
        signature.update(search_k=search_k, max_searches=max_searches)
    wanted = {e.id: e for e in examples}
    existing = read_jsonl(out_path)

    def usable(r: dict) -> bool:
        e = wanted.get(r.get("id"))
        return bool(e) and r.get("qhash") == e.qhash and r.get("signature") == signature and not r.get("error")

    done = {r["id"]: r for r in existing if usable(r)}
    keep = [r for r in existing if r.get("id") not in wanted and not r.get("error")] + list(done.values())
    if len(keep) != len(existing):
        write_jsonl(out_path, keep)
    todo = [e for e in examples if e.id not in done]
    log(f"{len(done)} cached, {len(todo)} to retrieve ({mode}; up to {ctx_k} passages per question)")
    if not todo:
        return done
    writer = JsonlAppender(out_path)

    def one(ex: Example) -> dict:
        base = single_shot(retriever, ex.query, ctx_k)
        rec: dict[str, Any] = {"id": ex.id, "qhash": ex.qhash, "signature": signature, "mode": mode}
        if mode == "single":
            rec.update(chunks=base, queries=[ex.query], n_searches=1, sufficient=None, note="", fallback=False)
        else:
            try:
                rec.update(agentic_retrieve(llm, retriever, ex.query, ctx_k=ctx_k, search_k=search_k, max_searches=max_searches))
            except SystemExit:
                raise
            except Exception as e:  # noqa: BLE001 — one failed question must not stop the run
                rec.update(chunks=base, queries=[ex.query], n_searches=1, sufficient=None, note="", fallback=True, error=f"{type(e).__name__}: {e}"[:300])
        rec["recall"] = round(evidence_recall(ex.answer, " ".join(c["text"] for c in rec["chunks"])), 4)
        rec["recall_single"] = round(evidence_recall(ex.answer, " ".join(c["text"] for c in base)), 4)
        return rec

    t0 = last = time.time()
    n = errors = 0
    first_error = ""
    with ThreadPoolExecutor(max_workers=max(1, workers if mode == "agentic" else 1)) as pool:
        futures = [pool.submit(one, e) for e in todo]
        for fut in as_completed(futures):
            rec = fut.result()
            n += 1
            if rec.get("error"):
                errors += 1
                first_error = first_error or rec["error"]
                if errors >= 5 and errors == n:
                    for f in futures:
                        f.cancel()
                    raise SystemExit(f"the first {errors} retrieval episodes all failed — stopping. First error: {first_error}")
            writer.add(rec)
            done[rec["id"]] = rec
            if time.time() - last >= 10 or n == len(todo):
                last = time.time()
                log(f"{n}/{len(todo)} questions ({n / max(time.time() - t0, 1e-6):.1f}/s)" + (f", {errors} fell back after an error" if errors else ""))
    if errors:
        log(f"{errors} question(s) used one-shot retrieval after an error (first: {first_error}); they are retried on the next run")
    return done


# --------------------------------------------------------------------------------------
# 3. judge
# --------------------------------------------------------------------------------------

JUDGE_SYSTEM = """You grade an answer to a question against a reference answer. Judge factual agreement with the reference only; ignore style, length, wording and formatting.

Score
1   — states the same key facts as the reference (extra correct detail is fine)
0.5 — partly right: some of the reference's key facts are present, others are missing or wrong
0   — wrong, contradicts the reference, does not answer, or is empty

Reply with one line of JSON and nothing else: {"score": 1, "reason": "<at most 15 words>"}"""

_SCORE_RE = re.compile(r'"?score"?\s*[:=]\s*"?([01](?:\.\d+)?|\.5)"?', re.I)


def parse_judge(text: str) -> tuple[float | None, str]:
    for m in re.finditer(r"\{[^{}]*\}", text, re.DOTALL):
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and "score" in obj:
            try:
                s = float(obj["score"])
            except (TypeError, ValueError):
                continue
            if s in (0.0, 0.5, 1.0):
                return s, str(obj.get("reason", ""))[:200]
    m = _SCORE_RE.search(text)
    if m:
        s = float(m.group(1))
        if s in (0.0, 0.5, 1.0):
            return s, ""
    return None, ""


def judge_one(llm: LLMClient, question: str, reference: str, prediction: str) -> tuple[float | None, str]:
    if not prediction.strip():
        return 0.0, "empty answer"
    user = f"Question:\n{question}\n\nReference answer:\n{reference}\n\nCandidate answer:\n{prediction[:4000]}"
    for _ in range(2):
        try:
            score, reason = parse_judge(generate_long(llm, JUDGE_SYSTEM, user, max_tokens=1024, max_continues=0))
        except EmptyOutputError:
            score, reason = None, ""
        if score is not None:
            return score, reason
    return None, "unparseable judge reply"


def judge_key(it: dict) -> str:
    return sha(it["id"], it["reference"], it["prediction"])


def load_judgments(items: list[dict], out_path: Path) -> dict[tuple[str, str], dict]:
    """Cached scores for these items, keyed by (arm, id)."""
    cached = {r["key"]: r for r in read_jsonl(out_path) if r.get("score") is not None}
    return {(it["arm"], it["id"]): cached[judge_key(it)] for it in items if judge_key(it) in cached}


def judge_all(items: list[dict], llm: LLMClient, out_path: Path, *, workers: int = 6, log: Callable[[str], None] | None = None) -> dict[tuple[str, str], dict]:
    """items: {id, arm, question, reference, prediction}. One judgment per distinct (question,
    answer text): the judge never sees which model wrote an answer, identical answers from two
    models get the same score by construction, and the order is shuffled."""
    import random

    log = log or (lambda m: print(f"[judge] {m}", file=sys.stderr, flush=True))
    key = judge_key
    wanted = {key(it): it for it in items}
    cached = {r["key"]: r for r in read_jsonl(out_path) if r.get("key") in wanted and r.get("score") is not None}
    todo = [it for k, it in wanted.items() if k not in cached]
    random.Random(0).shuffle(todo)
    log(f"{len(cached)} cached, {len(todo)} distinct answers to judge ({len(items)} answers in total)")
    writer = JsonlAppender(out_path)

    def one(it: dict) -> dict:
        try:
            score, reason = judge_one(llm, it["question"], it["reference"], it["prediction"])
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001
            score, reason = None, f"{type(e).__name__}: {e}"[:200]
        return {"key": key(it), "id": it["id"], "score": score, "reason": reason}

    t0 = last = time.time()
    n = failed = 0
    if todo:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
            for fut in as_completed([pool.submit(one, it) for it in todo]):
                rec = fut.result()
                n += 1
                if rec["score"] is None:
                    failed += 1
                    if failed >= 8 and failed == n:
                        raise SystemExit(f"the first {failed} judge calls all failed — stopping. Last reason: {rec['reason']}")
                else:
                    writer.add(rec)
                    cached[rec["key"]] = rec
                if time.time() - last >= 10 or n == len(todo):
                    last = time.time()
                    log(f"{n}/{len(todo)} judged ({n / max(time.time() - t0, 1e-6):.1f}/s)" + (f", {failed} without a score" if failed else ""))
    return {(it["arm"], it["id"]): cached[key(it)] for it in items if key(it) in cached}


# --------------------------------------------------------------------------------------
# 4. the runner's reading of the results
# --------------------------------------------------------------------------------------

ANALYSIS_SYSTEM = """You are an applied ML scientist reading the results of a controlled comparison: the same questions and the same retrieved passages, answered by a LoRA fine-tuned model and by its base model. Write for the researcher who ran it. Use only the numbers and examples given; if an interval includes zero, say the difference is not established. No preamble, no restating the tables."""

ANALYSIS_USER = """Write at most 220 words in three short parts:
1. What the comparison shows (primary metric first; say whether overlap metrics and the primary metric agree, and what that implies about style vs. correctness).
2. Where the difference comes from (retrieval hit vs. miss split; what the example answers show).
3. Two or three concrete next experiments that would change the conclusion or improve the system, most valuable first.

=== RESULTS (JSON) ===
{summary}

=== EXAMPLES WHERE THE MODELS DISAGREE ===
{examples}
"""


def write_analysis(llm: LLMClient, comp: dict, setup: dict) -> str:
    rows = {r["id"]: r for r in comp.get("rows", [])}
    ex_lines = []
    for kind in ("lora_better", "base_better"):
        for i in (comp.get("examples", {}).get(kind) or [])[:4]:
            r = rows[i]
            ex_lines.append(json.dumps({
                "who_won": "fine-tuned" if kind == "lora_better" else "base",
                "question": r["question"][:300], "reference": r["reference"][:300],
                "fine_tuned_answer": r.get("pred_lora_rag", "")[:300], "base_answer": r.get("pred_base_rag", "")[:300],
                "evidence_recall": r.get("evidence_recall"),
            }, ensure_ascii=False))
    summary = {k: comp.get(k) for k in ("n", "primary", "pairs", "retrieval", "recall_split", "arm_means")}
    summary["arm_labels"] = {a: ARM_LABELS[a] for a in comp.get("arms", [])}
    summary["setup"] = setup
    return generate_long(llm, ANALYSIS_SYSTEM, ANALYSIS_USER.format(summary=json.dumps(summary, default=str)[:14_000], examples="\n".join(ex_lines) or "(none)"), max_tokens=4096, max_continues=0)
