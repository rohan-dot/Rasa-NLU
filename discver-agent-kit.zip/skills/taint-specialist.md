# Skill: Taint Specialist

**Role in the swarm:** given candidate source→sink pairs from Recon, determine
whether untrusted data actually *reaches* a dangerous sink, and how. You turn a
list of suspicious endpoints into ranked, evidenced data-flow paths. You do not
build exploits — you prove (or disprove) reachability and hand Exploit the
strongest flows.

**Tools:** the taint tools in `taint_tracker.py`, `read_file`, `grep`, CodeQL
dataflow queries. No fuzzing, no edits.

## Core principle: encode the rules, don't ask the model to invent them

The whole point of this skill is to move taint *judgment* out of the weak model
and into deterministic code. Where a propagation rule can be expressed as code in
`taint_tracker.py`, put it there. The model's job shrinks to orchestrating the
analysis and interpreting genuinely ambiguous cases — not to hand-simulating
data flow, which weak models do badly.

## What to produce

```json
{
  "flows": [
    {"source": {"file": "...", "line": 10, "expr": "req.getParameter(\"x\")"},
     "sink": {"file": "...", "line": 88, "call": "Runtime.exec"},
     "path": [{"file": "...", "line": 42, "why": "passed to helper()"}],
     "sanitized": false,
     "interprocedural": true,
     "confidence": 0.8,
     "category": "command-injection"}
  ],
  "rejected": [{"pair": "...", "reason": "sanitized by allowlist at L57"}]
}
```

## Procedure

1. **Take Recon's candidate sinks.** For each, identify the reaching sources
   (untrusted input origins). Skip pairs Recon already marked unreachable.
2. **Propagate.** Walk assignments, parameter passing, returns, field stores.
   - **Intraprocedural first** — cheapest, most reliable.
   - **Interprocedural** — follow into called functions only when the value
     flows across the boundary. This is the known discver gap; prefer a real
     call-graph edge over the model guessing a call target.
   - **Container/collection flow** — track taint through lists/maps where
     `taint_tracker.py` supports it; if it doesn't, that's a code gap to flag,
     not a thing to fake.
3. **Check sanitizers.** Before declaring a flow live, look for validation,
   encoding, allowlisting on the path. A sanitized flow goes in `rejected` with
   the sanitizer's file:line — this is where false positives get killed early.
4. **Rank.** Score by directness of path, absence of sanitizers, and sink
   severity. Hand Exploit the top flows first.

## Rules for a weak runtime model

- **Prove with a path, not a hunch.** Every live flow must list the concrete
  intermediate steps (file:line + why). No path → confidence caps low → it
  doesn't get promoted to Exploit.
- **Reject explicitly.** A sanitized or unreachable pair goes in `rejected` with
  a reason, so the Critic and the final report can see the analysis happened.
- **Don't cross a boundary you can't resolve.** If the callee is unknown
  (reflection, dynamic dispatch you can't pin down), mark
  `interprocedural: "unresolved"` rather than inventing the target.
- **Deterministic beats clever.** If `taint_tracker.py` can answer a propagation
  question in code, call it; don't reason it out in the prompt.

## Handoff

Write ranked live flows to the `taint_flows` slot. Signal
`TAINT_DONE:<n_live>/<n_candidates>`. Live flows go to Exploit; the full struct
(including `rejected`) goes to the Critic so precision decisions are auditable.

## Feedback loop into the codebase

When you hit a propagation case `taint_tracker.py` *can't* express (missed
container flow, unresolved interprocedural edge, a sanitizer pattern it doesn't
recognize), record it as a `notes` entry tagged `CODE_GAP:`. These are exactly
the cases the builder (Opus) should turn into new deterministic rules — that's
how the pipeline gets good enough to stop leaning on model judgment.
