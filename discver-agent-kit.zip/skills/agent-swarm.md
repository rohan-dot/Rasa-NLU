# Skill: Specialized Agent Swarm for discver

**Direction (from Jo):** distinct specialist roles, each with a narrow toolset and
a focused prompt, coordinated by a supervisor — not parallel replicas of one
generalist. Narrow scope is what lets a *weak* model perform: a taint agent that
only does taint, with only taint tools, has far less to get wrong than a
generalist choosing among 15 tools.

Implement each role as a LangGraph node with its own system prompt (a skill
file), its own restricted tool subset, and a typed output the supervisor routes
on. Do not give any agent tools it doesn't need — restricting the toolset is
itself a reliability technique for weak models.

## Roles

**Recon** — maps the target: entry points, build system, existing harnesses,
attack surface. Tools: `list_files`, `grep`, `read_file`, CodeQL queries. Output:
a structured surface map (files, functions, candidate sinks) the others consume.
Prioritize this — it's the #2 lever (coverage): better recon → more candidates.

**Taint** — given a source/sink pair from recon + `sinks.py`, traces reachability
through `taint_tracker.py`. Tools: taint tools, `read_file`, `grep`. Output: a
ranked list of source→sink flows with confidence. Narrow and deterministic where
possible; encode the interprocedural rules as code, not as model judgment.

**Exploit** — turns a promising flow into a concrete input/harness via Jazzer +
libFuzzer. Tools: `fuzzer.py`, `java_harness_agent.py`, `bash`. Output: a
reproducing input or a "no repro" with the fuzzing evidence.

**Patch** — proposes a minimal fix for a confirmed vuln. Tools: `read_file`,
`str_replace`, `bash` (to re-run the repro and confirm the fix holds). Output: a
diff + verification result.

**Critic** — the precision lever (#3). Reviews Exploit/Triage claims before they
count: is the crash real, security-relevant, and reproducible, or a
false positive? Tools: `crash_analyzer.py`, `read_file`, re-run repro. Output:
`CONFIRMED` / `REJECTED:<reason>`. Give the critic *veto* power in the graph so
false positives die before they reach the final report.

## Supervisor / orchestration

A supervisor node owns shared state and dispatches to specialists. Keep it thin:

- **Typed handoffs.** Each agent returns a typed struct, not free text. The
  supervisor routes on the type. This is what stops agents stepping on each other
  (priority #4).
- **Blackboard state.** One shared state object (recon map, candidate flows,
  confirmed vulns). Agents read/write named slots; never have two agents write the
  same slot in the same step.
- **Budget per role.** Cap turns/tokens per specialist so one stuck agent can't
  starve the run. On cap, hand back to supervisor with a partial result.
- **Serial by default, fan-out deliberately.** Run specialists serially unless
  two are provably independent (e.g. taint on two unrelated sinks). Fan-out
  multiplies weak-model failure surface, so make it a conscious choice, not the
  default.

## Build order

1. Extract the current generalist logic into a Recon + Taint split first (biggest
   coverage win, lowest risk).
2. Add the Critic (immediate precision win, and it protects everything downstream).
3. Split Exploit and Patch once the above are stable.
4. Only then add fan-out where independence is provable.

Each step: add the role, add its skill file, add a test that the supervisor
routes its typed output correctly, commit separately.
