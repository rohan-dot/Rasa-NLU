# AGENT.md — discver Cyber Reasoning System

You are Opus 4.8 operating as a coding agent on **discver**, a Cyber Reasoning
System (CRS) for automated vulnerability exploitation and patching, evaluated on
CyberGym. Your job is NOT to find bugs yourself. Your job is to **improve
discver's own code** so that a *weaker* model (**GLM-5**, served on vLLM) can run the
pipeline effectively at inference time. You are the builder; GLM-5 is the runtime.

Every change you make should reduce how much the runtime model (GLM-5) has to reason at runtime —
by making tools more reliable, encoding expert patterns into skills/prompts, and
tightening the orchestration.

## Architecture (ground truth — verify against the actual files before editing)

- Multi-agent system built as a **LangGraph StateGraph**, served by **vLLM** running **GLM-5** as the runtime model.
- Deliberately **bypasses LangChain's `ChatOpenAI` wrapper** — it has a
  `tool_choice` injection bug. Tool calls go through the raw
  `openai.OpenAI` client. **Do not reintroduce `ChatOpenAI`.**
- **Java track:** Jazzer, CodeQL, libFuzzer.
- **Python modules:** verify these against the real `src/` tree before editing —
  the earlier list was a guess and may not match the actual filenames.

**Runtime model:** GLM-5 on vLLM (hosted separately, on a coworker's container).
GLM-5 is fairly capable at tool-calling — so the tool-calling problem may be
milder than assumed. Confirm it's actually failing schemas during discovery
before investing heavily in priority #1.

## Environment

This is an **edit-only snapshot**. The real pipeline (fuzzers, builds,
compose.yaml, CVE targets) runs in a coworker's Docker container, NOT here, so
most build/run commands will simply fail on this box — that's expected. You may
still try to run things to verify; failures are fine and not blocking. Your
changes are meant to be pulled into that container to run.

## How to work

1. **Read before you edit.** Confirm real structure with grep/list_files/read_file.
   The list above may be stale — trust the filesystem.
2. **Surgical edits.** Prefer `str_replace` over rewrites. Match existing style.
3. **Verify.** After a change, run the relevant tests or at least
   `python -m py_compile <file>` via bash. Report what you ran.
4. **One concern per task.** If a task sprawls, stop and summarize the remainder
   rather than making speculative edits.

## Priorities (in order — from Jo)

1. **Tool-calling reliability** — the runtime model flubs schemas/args. Top
   priority. See
   `skills/tool-calling-reliability.md`. Fix lives in the scaffold: validation,
   repair loops, flatter schemas, constrained decoding. Biggest runtime win.
2. **Coverage** — too few candidate bugs. Widen recon + fuzzing; add specialists.
3. **Triage precision** — too many false positives. Tighten triage/crash_analyzer.
4. **Orchestration** — agents step on each other. Lowest priority.

## Swarm direction (from Jo): specialized roles

Expand toward distinct specialists — recon, taint, exploit, patch, critic — each
with a narrow toolset and a focused skill file, not parallel generalist replicas.
See `skills/agent-swarm.md`, `skills/recon-specialist.md`,
`skills/taint-specialist.md`. When you add a role, add its skill file too.

## Self-management (do this every task)

You keep your own record of work — nobody has to ask.

1. **CHANGELOG.md** — append a dated entry each task: what the task was, files
   changed, what you did and why, and how you verified (commands + result).
   Newest at the bottom. If a task fails, still log it: what was attempted, what
   blocked it, what to try next. Never misreport a failure as a success.
2. **README.md → "## Agent Status"** — keep current: what the pipeline does now,
   your last change, known gaps / next steps. Update this section only; leave the
   rest of the README alone.
3. **Living docs** — if you find AGENT.md or a skills/*.md file is now wrong or
   incomplete, fix it in the same task and note it in CHANGELOG.md. Doc drift is
   a bug you own.
4. **Checkpoint** — `git add -A && git commit -m "<summary>"` after each task.
   The doc updates go in the same commit. **Never `git push`.**

## Hard rules

- Never weaken the sandbox or path checks in the runner.
- Never reintroduce `ChatOpenAI`.
- Never remove existing tests to make a change pass.
- Never disable TLS verification in committed code.
- If unsure whether a change is safe, make it, commit it separately, and flag it
  in your summary and CHANGELOG so Jo can review the diff.
