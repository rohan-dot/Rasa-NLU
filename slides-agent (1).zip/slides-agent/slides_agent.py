#!/usr/bin/env python3
"""
slides_agent.py — an agent that READS the discver repo (+ the KB, + any notes you pass) and produces a .pptx.

Two phases, deliberately separated:
  1. research + compose (LLM, read-only tools) -> deck.json      (what to say, grounded in files it read)
  2. render (deterministic, python-pptx)        -> discver.pptx  (how it looks; no LLM involved)
So the model never writes slide code, and you can hand-edit deck.json and re-render in one second.

Usage (single lines):
  python3 slides_agent.py --repo campaign_work/discver --kb campaign_work/kb --out discver.pptx
  python3 slides_agent.py --repo campaign_work/discver --kb campaign_work/kb --context HANDOFF-nov05.md --context milestones.md --results campaign_work/results/latest --out discver.pptx
  python3 slides_agent.py --render-only deck.json --out discver.pptx       # no LLM: re-render after editing deck.json
  python3 slides_agent.py --verify                                           # gateway + tool-calling check (same as microagent)

Env (same as microagent.py): LITELLM_BASE_URL, LITELLM_API_KEY, AGENT_MODEL, AGENT_REASONING_EFFORT,
  AGENT_MAX_TOKENS (16384), AGENT_REQUEST_TIMEOUT (1800), AGENT_CA_BUNDLE or AGENT_TLS_VERIFY.
Requires: python-pptx  (pip install python-pptx)

The Results section is BLANKS by design: the agent builds the tables/callouts with the right rows and labels and
leaves every value empty for you to fill in PowerPoint. It is told, and the validator enforces, that no number appears there.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import ssl
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

# ----------------------------------------------------------------------------- config (mirrors microagent.py)
BASE_URL = os.environ.get("LITELLM_BASE_URL", "http://localhost:4000/v1").rstrip("/")
API_KEY = os.environ.get("LITELLM_API_KEY", "dummy")
REQUEST_TIMEOUT = int(os.environ.get("AGENT_REQUEST_TIMEOUT", "1800"))
MAX_TOKENS = int(os.environ.get("AGENT_MAX_TOKENS", "16384"))
MAX_TOKENS_CAP = 32_000
REASONING_EFFORT = os.environ.get("AGENT_REASONING_EFFORT", "").strip().lower() or None
MAX_TOOL_OUTPUT = 30_000
CTX_SOFT_LIMIT = 350_000          # chars of conversation before old tool outputs are elided
KEEP_RECENT_OUTPUTS = 8
IGNORE_DIRS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", "node_modules", ".venv", "venv", "dist", "build", ".idea", "oss-crs"}
BINARY_SUFFIXES = (".pyc", ".zip", ".jar", ".class", ".png", ".jpg", ".jpeg", ".gz", ".tgz", ".tar", ".so", ".bin", ".pdf", ".whl", ".pptx")


def log(msg: str) -> None:
    print(msg, flush=True)


def redact(text: str) -> str:
    for key in ("LITELLM_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
        secret = os.environ.get(key, "")
        if len(secret) >= 8:
            text = text.replace(secret, "[REDACTED]")
    return text


def clipped(text: str, limit: int = MAX_TOOL_OUTPUT) -> str:
    if len(text) <= limit:
        return text
    return text[: limit // 2] + "\n...[middle omitted; narrow the request or page with start_line]...\n" + text[-limit // 2:]


# ----------------------------------------------------------------------------- HTTP / Chat (copied from microagent.py)
class HTTPError(Exception):
    def __init__(self, status: int, body: str):
        super().__init__(f"HTTP {status}: {body[:800]}")
        self.status, self.body = status, body


_SSL = None


def _ssl_context():
    global _SSL
    if _SSL is None:
        bundle = os.environ.get("AGENT_CA_BUNDLE")
        if bundle:
            _SSL = ssl.create_default_context(cafile=bundle)
        elif os.environ.get("AGENT_TLS_VERIFY", "true").strip().lower() in ("0", "false", "no"):
            log("[warning] TLS verification disabled by AGENT_TLS_VERIFY; prefer AGENT_CA_BUNDLE.")
            _SSL = ssl._create_unverified_context()
        else:
            _SSL = ssl.create_default_context()
    return _SSL


def post(path: str, payload: dict) -> dict:
    req = urllib.request.Request(BASE_URL + path, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json", "Authorization": f"Bearer {API_KEY}"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=_ssl_context()) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise HTTPError(e.code, e.read().decode(errors="replace")) from None


class Chat:
    def __init__(self, model: str):
        self.model, self.effort, self.max_tokens, self.last_finish_reason = model, REASONING_EFFORT, MAX_TOKENS, None

    def complete(self, messages: list[dict], tools: list[dict]) -> tuple[str, list[dict], dict, dict]:
        last = None
        for attempt in range(5):
            payload = {"model": self.model, "messages": messages, "max_tokens": self.max_tokens,
                       "tools": [{"type": "function", "function": t} for t in tools], "tool_choice": "auto"}
            if self.effort:
                payload["reasoning_effort"] = self.effort
            try:
                resp = post("/chat/completions", payload)
            except HTTPError as exc:
                last = exc
                body = exc.body.lower()
                if exc.status == 400 and self.effort and ("reasoning" in body or "unsupported" in body or "unknown" in body):
                    log(f"      [llm] gateway rejected reasoning_effort={self.effort}; continuing without it")
                    self.effort = None
                    continue
                if exc.status == 400 and any(s in body for s in ("context_length", "maximum context", "too many", "too long")):
                    raise
                if exc.status in (408, 409, 429, 500, 502, 503, 504, 529):
                    time.sleep(min(60, 8 * (attempt + 1)))
                    continue
                raise
            except (urllib.error.URLError, TimeoutError, ConnectionError, json.JSONDecodeError) as exc:
                last = exc
                log(f"      [llm] {type(exc).__name__}: {str(exc)[:120]} — retrying")
                time.sleep(min(60, 8 * (attempt + 1)))
                continue
            choice = (resp.get("choices") or [{}])[0]
            msg = choice.get("message") or {}
            content = msg.get("content") or ""
            if isinstance(content, list):
                content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
            calls, assistant = [], {"role": "assistant", "content": content or None}
            if msg.get("tool_calls"):
                assistant["tool_calls"] = []
                for tc in msg["tool_calls"]:
                    fn = tc.get("function") or {}
                    args = fn.get("arguments")
                    if isinstance(args, dict):
                        args = json.dumps(args)
                    assistant["tool_calls"].append({"id": tc.get("id"), "type": "function", "function": {"name": fn.get("name"), "arguments": args or "{}"}})
                    calls.append({"id": tc.get("id"), "name": fn.get("name"), "arguments": args or "{}"})
            self.last_finish_reason = choice.get("finish_reason")
            if not content and not calls and self.last_finish_reason == "length" and self.max_tokens < MAX_TOKENS_CAP:
                self.max_tokens = min(MAX_TOKENS_CAP, self.max_tokens * 2)
                log(f"      [llm] empty reply cut at max_tokens; retrying with max_tokens={self.max_tokens}")
                continue
            u = resp.get("usage") or {}
            return content, calls, assistant, {"in": u.get("prompt_tokens"), "out": u.get("completion_tokens")}
        raise RuntimeError(f"LLM call failed after retries: {last}")


# ----------------------------------------------------------------------------- read-only tools
S, I = {"type": "string"}, {"type": "integer"}


def spec(name, description, properties, required=()):
    return {"name": name, "description": description, "parameters": {"type": "object", "properties": properties, "required": list(required)}}


TOOLS = [
    spec("list_files", "List files under a path (recursive). root: 'repo' (default), 'kb', 'results', or 'context'. Optional glob on the "
                       "relative path; skip paginates.", {"path": S, "root": S, "pattern": S, "skip": I}),
    spec("read_file", "Read a text file with line numbers. root as above. end_line=-1 reads to the end; long files are paged.",
         {"path": S, "root": S, "start_line": I, "end_line": I}, ("path",)),
    spec("grep", "Regex search over text files under a path (or one file). Returns file:line: excerpt. Grep before reading.",
         {"pattern": S, "path": S, "root": S, "glob": S, "skip": I}, ("pattern",)),
    spec("count", "Count files matching a glob and total lines (e.g. glob='tests/test_*.py' or 'src/**/*.py').", {"glob": S, "root": S}, ("glob",)),
    spec("kb_stats", "Statistics of the knowledge base at the kb root: recipes per language, ARVO records, CWE playbooks, index size. "
                     "Numbers come from the files, so they may be quoted on slides.", {}),
    spec("finish_deck", "Submit the finished deck as JSON (the whole deck object, schema in the system prompt). The deck is validated "
                        "and rendered; validation errors come back as the tool result so you can fix and resubmit.",
         {"deck": {"type": "object"}, "deck_json": S}),
]


class Toolbox:
    def __init__(self, roots: dict[str, Path]):
        self.roots = roots

    def _resolve(self, root: str | None, path: str | None) -> Path:
        root = (root or "repo").strip()
        if root not in self.roots:
            raise ValueError(f"unknown root {root!r}; roots: {', '.join(sorted(self.roots))}")
        base = self.roots[root]
        if base.is_file():                      # a context root may be a single file
            return base
        p = (base / (path or ".")).resolve()
        if base.resolve() not in p.parents and p != base.resolve():
            raise ValueError("path escapes its root")
        return p

    def _iter(self, base: Path):
        if base.is_file():
            yield base
            return
        for dp, dns, fns in os.walk(base):
            dns[:] = sorted(d for d in dns if d not in IGNORE_DIRS)
            for fn in sorted(fns):
                yield Path(dp) / fn

    def list_files(self, path=None, root=None, pattern=None, skip=0):
        base = self._resolve(root, path)
        if not base.exists():
            return f"no such path: {base}"
        rootdir = self.roots[(root or 'repo').strip()]
        rows = []
        for f in self._iter(base):
            rel = f.relative_to(rootdir) if rootdir.is_dir() else f.name
            if pattern and not (Path(rel).match(pattern) or f.name == pattern or re.search(re.escape(pattern).replace(r"\*", ".*"), str(rel))):
                continue
            try:
                rows.append(f"{f.stat().st_size:>9}  {rel}")
            except OSError:
                pass
        total, rows = len(rows), rows[skip: skip + 400]
        more = f"\n...[{total - skip - 400} more; call again with skip={skip + 400}]" if total > skip + 400 else ""
        return f"{total} files\n" + "\n".join(rows) + more

    def read_file(self, path, root=None, start_line=1, end_line=-1):
        p = self._resolve(root, path)
        if not p.is_file():
            return f"no such file: {p}"
        if p.suffix.lower() in BINARY_SUFFIXES:
            return f"binary file ({p.stat().st_size} bytes) — not readable as text"
        lines = p.read_text(errors="replace").splitlines()
        start = max(1, start_line or 1)
        end = len(lines) if (end_line is None or end_line < 0) else min(len(lines), end_line)
        page = min(end, start + 400 - 1)
        body = "\n".join(f"{i:>5}: {lines[i - 1]}" for i in range(start, page + 1))
        tail = f"\n...[{len(lines)} lines total; continue with start_line={page + 1}]" if page < end else f"\n[{len(lines)} lines total]"
        return clipped(body) + tail

    def grep(self, pattern, path=None, root=None, glob=None, skip=0):
        try:
            rx = re.compile(pattern)
        except re.error as e:
            return f"bad regex: {e}"
        base = self._resolve(root, path)
        rootdir = self.roots[(root or 'repo').strip()]
        hits = []
        for f in self._iter(base):
            if f.suffix.lower() in BINARY_SUFFIXES or (glob and not Path(f.name).match(glob)):
                continue
            try:
                for i, line in enumerate(f.read_text(errors="replace").splitlines(), 1):
                    if rx.search(line):
                        rel = f.relative_to(rootdir) if rootdir.is_dir() else f.name
                        hits.append(f"{rel}:{i}: {line.strip()[:220]}")
                        if len(hits) > skip + 300:
                            break
            except OSError:
                continue
        total = len(hits)
        out = hits[skip: skip + 300]
        return f"{total}{'+' if total > skip + 300 else ''} hits\n" + "\n".join(out) + (f"\n...[more; skip={skip + 300}]" if total > skip + 300 else "")

    def count(self, glob, root=None):
        base = self._resolve(root, None)
        files = [f for f in self._iter(base) if Path(f.relative_to(base)).match(glob) or f.match(glob)]
        n_lines = 0
        for f in files:
            if f.suffix.lower() not in BINARY_SUFFIXES:
                try:
                    n_lines += sum(1 for _ in f.open(errors="replace"))
                except OSError:
                    pass
        return f"{len(files)} files, {n_lines} lines match {glob!r} under {root or 'repo'}"

    def kb_stats(self):
        if "kb" not in self.roots:
            return "no kb root given (--kb)"
        kb = self.roots["kb"]
        out = []
        rec = kb / "recipes.jsonl"
        if rec.is_file():
            per_lang, n, sources = {}, 0, {}
            with rec.open(errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    n += 1
                    try:
                        r = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    lang = str(r.get("language") or r.get("lang") or "unknown").lower()
                    per_lang[lang] = per_lang.get(lang, 0) + 1
                    src = str(r.get("source") or r.get("origin") or "").lower()
                    if src:
                        sources[src] = sources.get(src, 0) + 1
            out.append(f"recipes.jsonl: {n} recipes; per language: " + ", ".join(f"{k}={v}" for k, v in sorted(per_lang.items(), key=lambda kv: -kv[1])))
            if sources:
                out.append("sources: " + ", ".join(f"{k}={v}" for k, v in sorted(sources.items(), key=lambda kv: -kv[1])))
            keys = set()
            with rec.open(errors="replace") as fh:
                for _ in range(20):
                    line = fh.readline()
                    if not line:
                        break
                    try:
                        keys |= set(json.loads(line).keys())
                    except json.JSONDecodeError:
                        pass
            out.append("recipe fields: " + ", ".join(sorted(keys)))
        else:
            out.append("recipes.jsonl: missing")
        pb = kb / "cwe_playbooks"
        if pb.is_dir():
            names = sorted(p.stem for p in pb.iterdir() if p.suffix in (".yaml", ".yml", ".json"))
            out.append(f"cwe_playbooks: {len(names)} playbooks: {', '.join(names[:40])}{' …' if len(names) > 40 else ''}")
        else:
            out.append("cwe_playbooks: missing")
        ex = kb / "exemplars"
        out.append(f"exemplars: {sum(1 for _ in ex.rglob('*') if _.is_file())} files" if ex.is_dir() else "exemplars: none (built without --fetch-fixes)")
        idx = kb / "index.json"
        if idx.is_file():
            try:
                d = json.loads(idx.read_text(errors="replace"))
                out.append(f"index.json: {idx.stat().st_size} bytes; top-level keys: {', '.join(list(d)[:12]) if isinstance(d, dict) else type(d).__name__}")
                for k in ("built", "built_at", "version", "sources", "counts", "arvo", "arvo_records", "tokens", "languages"):
                    if isinstance(d, dict) and k in d:
                        out.append(f"  {k}: {json.dumps(d[k])[:300]}")
            except json.JSONDecodeError:
                out.append("index.json: unreadable")
        for extra in sorted(kb.glob("*")):
            if extra.name not in ("recipes.jsonl", "cwe_playbooks", "exemplars", "index.json"):
                out.append(f"also: {extra.name}")
        return "\n".join(out)

    def call(self, name: str, args: dict) -> str:
        fn = getattr(self, name, None)
        if fn is None:
            return f"unknown tool {name}"
        try:
            return redact(str(fn(**{k: v for k, v in args.items() if v is not None})))
        except TypeError as e:
            return f"bad arguments for {name}: {e}"
        except Exception as e:  # noqa: BLE001
            return f"{type(e).__name__}: {e}"


# ----------------------------------------------------------------------------- deck schema
SLIDE_TYPES = {
    "title": ["title"], "section": ["title"], "bullets": ["title", "bullets"], "two_column": ["title", "left", "right"],
    "cards": ["title", "cards"], "steps": ["title", "steps"], "diagram": ["title", "layers", "edges"],
    "table": ["title", "columns", "rows"], "stats": ["title", "stats"], "closing": ["title", "bullets"],
}
BLANKS = {"", "__", "—", "-", "…", "..."}

SCHEMA_DOC = """
DECK JSON SCHEMA (submit exactly this shape to finish_deck):
{
  "title": "...", "subtitle": "...", "author": "...", "date": "...",
  "slides": [
    {"type": "title",      "title": "...", "subtitle": "...", "footnote": "...", "notes": "speaker notes"},
    {"type": "section",    "title": "Architecture", "subtitle": "one line", "notes": "..."},
    {"type": "bullets",    "title": "...", "bullets": ["<= 14 words each", "..."], "takeaway": "one sentence shown as a card on the right",
                           "callout": {"value": "4,100", "label": "OSS-Fuzz recipes in the KB"}, "notes": "..."},
    {"type": "two_column", "title": "...", "left": {"heading": "...", "bullets": ["..."]}, "right": {"heading": "...", "bullets": ["..."]}, "notes": "..."},
    {"type": "cards",      "title": "...", "cards": [{"heading": "...", "text": "<= 30 words"}, "... 3 to 6 cards"], "notes": "..."},
    {"type": "steps",      "title": "...", "steps": [{"heading": "...", "text": "<= 18 words"}, "... 3 to 6 steps"], "notes": "..."},
    {"type": "diagram",    "title": "...",
                           "layers": [{"name": "Inputs", "nodes": [{"id": "src", "label": "Target source + build", "sub": "OSS-CRS task", "kind": "ext"}]},
                                      {"name": "Phase 0", "nodes": [{"id": "lang", "label": "Language detect", "kind": "det"}, {"id": "strat", "label": "Strategy (KB)", "kind": "llm"}]},
                                      "... 3 to 6 layers, <= 5 nodes each; kind: det (deterministic) | llm (model-driven) | ext (outside discver)"],
                           "edges": [["src", "lang"], ["lang", "strat", "optional label"], "... from-id, to-id, [label]"],
                           "legend": true, "notes": "..."},
    {"type": "table",      "title": "...", "columns": ["Metric", "Value"], "rows": [["Crashes found", "__"], ["..."]], "note": "where the value comes from", "section": "results", "notes": "..."},
    {"type": "stats",      "title": "...", "stats": [{"value": "__", "label": "Recall"}, "... 3 or 4"], "note": "...", "section": "results", "notes": "..."},
    {"type": "closing",    "title": "...", "bullets": ["..."], "footnote": "...", "notes": "..."}
  ]
}
Rules: titles in sentence case, no trailing period, <= 60 characters. Bullets <= 6 per slide, <= 14 words each.
Every slide gets "notes" (speaker notes, 2-5 sentences) that cite the file(s) the content came from, e.g. "src/strategy_phase.py:12-80".
Slides with "section": "results" are PLACEHOLDERS: every value cell / stat value must be "__" (the validator rejects numbers there).
"""

SYSTEM_PROMPT = """You are a technical writer-engineer producing a conference-quality slide deck about **discver**, an autonomous
Cyber Reasoning System (fuzzing + LLM triage + LLM patching) that runs under OSS-CRS/libCRS, from the repository itself.
You have READ-ONLY tools over: the repo (`repo`), the knowledge base (`kb`), optional run results (`results`) and optional
notes (`context`). You have no shell and must not guess: every statement on a slide must be something you read in a file,
and the speaker notes of that slide cite where. Numbers are allowed ONLY when they come from a file or from kb_stats
(e.g. counts of recipes, thresholds in feature_flags/submission_policy, number of tests) — never estimated.

Work plan (budget ~40 tool calls, then compose):
1. list_files on `repo` src/ and tests/; grep "^def |^class " in src/main.py and read main.py's orchestration (phases, order).
2. Read the first 40-60 lines (module docstring + constants) of the modules that define the pipeline: fuzzer/run_health,
   harness_* (entry points, sources, gate), crash_dedup, triage_table, patch_generator (header only), submission_policy,
   strategy_phase, delta, confirm_findings, feature_flags, src/lang/__init__.py and src/lang/base.py, src/workshop/*.py.
   grep for the log tags that name phases ("[strategy]", "[triage]", "[arbiter]", "[submit]", "[sidecar]", "harness-gen").
3. kb_stats; read kb/index.json if small. Read every `context` file fully. If `results` exists, read REPORT.md / CAMPAIGN.md
   to learn which metrics the system reports (you will use the metric NAMES for the results placeholders, not the values).
4. Compose the deck (12-16 slides) in this fixed order, then call finish_deck:
   - title
   - INTRO (2 slides): what problem discver solves and the setting it runs in (OSS-CRS, benchmarks); what it produces end to end.
   - section "Architecture" -> ONE diagram slide (layers left-to-right = pipeline order; mark nodes det/llm/ext) -> optional cards slide "phases".
   - section "Methodology" (4-5 slides): harness strategy (discover provided, rank entry points, generate, gate);
     fuzzing & health; triage (dedup, KB-grounded triage, arbiter, confidence tiers); patching (agent, oracle via sidecar,
     scope rules); workshop / knowledge base (what it is built from, what it changes at run time, language-agnostic adapters).
     Use a different slide type for each (steps, two_column, cards, bullets+callout) — not five bullet slides.
   - section "Results" (3-4 slides, ALL placeholders, "section": "results"): a table per experiment the repo/contexts describe
     (e.g. Java target run; CRSBench problem; KB on/off comparison), rows = the metrics the system reports, values "__";
     plus one stats slide with 3-4 headline numbers as "__". Put in "note" where each value will come from (which report/CSV).
   - CONCLUSION: one closing slide (what works, what is open, next steps as stated in repo/context files).
5. One message per slide. No marketing language. English. Be specific (module names, log tags, thresholds) — this deck is for
   people who will read the code afterwards.
""" + SCHEMA_DOC


# ----------------------------------------------------------------------------- validation
def validate_deck(deck) -> list[str]:
    errs = []
    if not isinstance(deck, dict):
        return ["deck must be a JSON object"]
    if not deck.get("title"):
        errs.append("deck.title missing")
    slides = deck.get("slides")
    if not isinstance(slides, list) or not slides:
        return errs + ["deck.slides must be a non-empty list"]
    if len(slides) > 22:
        errs.append(f"{len(slides)} slides — keep it to 22 or fewer")
    for i, s in enumerate(slides, 1):
        if not isinstance(s, dict):
            errs.append(f"slide {i}: not an object")
            continue
        t = s.get("type")
        if t not in SLIDE_TYPES:
            errs.append(f"slide {i}: unknown type {t!r}")
            continue
        for k in SLIDE_TYPES[t]:
            if k not in s or s[k] in (None, "", []):
                errs.append(f"slide {i} ({t}): missing {k!r}")
        title = str(s.get("title", ""))
        if len(title) > 70:
            errs.append(f"slide {i}: title longer than 70 chars")
        if title.endswith("."):
            errs.append(f"slide {i}: title ends with a period")
        if t in ("bullets", "closing"):
            b = s.get("bullets") or []
            if len(b) > 7:
                errs.append(f"slide {i}: {len(b)} bullets — max 7")
            for x in b:
                if len(str(x).split()) > 22:
                    errs.append(f"slide {i}: bullet too long: {str(x)[:50]}…")
        if t == "diagram":
            layers = s.get("layers") or []
            if not (2 <= len(layers) <= 6):
                errs.append(f"slide {i}: diagram needs 2-6 layers")
            ids = set()
            for L in layers:
                nodes = L.get("nodes") or []
                if not (1 <= len(nodes) <= 5):
                    errs.append(f"slide {i}: layer {L.get('name')!r} needs 1-5 nodes")
                for n in nodes:
                    if not n.get("id") or not n.get("label"):
                        errs.append(f"slide {i}: node without id/label")
                    ids.add(n.get("id"))
            for e in s.get("edges") or []:
                if not (isinstance(e, list) and len(e) >= 2 and e[0] in ids and e[1] in ids):
                    errs.append(f"slide {i}: bad edge {e!r} (unknown node id)")
        if t == "steps" and not (2 <= len(s.get("steps") or []) <= 6):
            errs.append(f"slide {i}: steps needs 2-6 steps")
        if t == "cards" and not (2 <= len(s.get("cards") or []) <= 6):
            errs.append(f"slide {i}: cards needs 2-6 cards")
        if t == "stats" and not (2 <= len(s.get("stats") or []) <= 4):
            errs.append(f"slide {i}: stats needs 2-4 stats")
        if t == "table":
            cols, rows = s.get("columns") or [], s.get("rows") or []
            if len(cols) > 6 or len(rows) > 10:
                errs.append(f"slide {i}: table too large (max 6 columns x 10 rows)")
            for r in rows:
                if not isinstance(r, list) or len(r) != len(cols):
                    errs.append(f"slide {i}: row {r!r} does not match columns")
        if str(s.get("section", "")).lower() == "results":
            if t == "table":
                for r in s.get("rows") or []:
                    for cell in (r[1:] if isinstance(r, list) else []):
                        if str(cell).strip() not in BLANKS:
                            errs.append(f"slide {i}: results table value {cell!r} must be '__' (placeholders only)")
            elif t == "stats":
                for st in s.get("stats") or []:
                    if str(st.get("value", "")).strip() not in BLANKS:
                        errs.append(f"slide {i}: results stat value {st.get('value')!r} must be '__'")
        if not s.get("notes"):
            errs.append(f"slide {i}: notes missing (speaker notes with file citations)")
    return errs


# ----------------------------------------------------------------------------- renderer (python-pptx)
def render(deck: dict, out: Path) -> None:
    from pptx import Presentation
    from pptx.dml.color import RGBColor
    from pptx.enum.dml import MSO_LINE_DASH_STYLE
    from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.oxml.ns import qn
    from pptx.util import Emu, Inches, Pt

    # palette: ink + paper, one sharp accent (the crash), teal for knowledge/strategy
    INK, PAPER, SURFACE, LINE = RGBColor(0x1F, 0x24, 0x30), RGBColor(0xFF, 0xFF, 0xFF), RGBColor(0xF2, 0xF4, 0xF7), RGBColor(0xC9, 0xCF, 0xD8)
    MUTED, MUTED_ON_DARK = RGBColor(0x6B, 0x72, 0x80), RGBColor(0xB8, 0xBF, 0xCC)
    ACCENT, TEAL, TEAL_LIGHT = RGBColor(0xD7, 0x26, 0x3D), RGBColor(0x1B, 0x99, 0x8B), RGBColor(0xDC, 0xF2, 0xEE)
    FONT = "Calibri"
    W, H = 13.333, 7.5
    M = 0.6                                   # margin
    TITLE_Y, TITLE_H = 0.42, 0.95
    BODY_Y = 1.55

    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(W), Inches(H)
    blank = prs.slide_layouts[6]

    # ---- primitives
    def bg(slide, color):
        f = slide.background.fill
        f.solid()
        f.fore_color.rgb = color

    def text(slide, x, y, w, h, s, size=16, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, italic=False, margin=0.0):
        tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Inches(margin)
        tf.vertical_anchor = anchor
        p = tf.paragraphs[0]
        p.alignment = align
        r = p.add_run()
        r.text = str(s)
        r.font.size, r.font.bold, r.font.italic, r.font.name = Pt(size), bold, italic, FONT
        r.font.color.rgb = color
        return tb

    def est_lines(s, size, width_in):
        cpl = max(8, int(width_in * 72 / (0.52 * size)))        # average Calibri glyph ≈ 0.52 em
        return max(1, math.ceil(len(str(s)) / cpl))

    def fit(items, width_in, height_in, base, floor, spacing=0.45):
        size = base
        while size > floor:
            lines = sum(est_lines(x, size, width_in) for x in items)
            need = (lines * 1.22 + len(items) * spacing) * size / 72
            if need <= height_in:
                break
            size -= 1
        return size

    def bullets(slide, x, y, w, h, items, size=None, color=INK, bullet_color=ACCENT, base=18, floor=14):
        size = size or fit(items, w, h, base, floor)
        tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Inches(0)
        for i, item in enumerate(items):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.space_after = Pt(size * 0.55)
            pPr = p._p.get_or_add_pPr()
            pPr.set("marL", str(Emu(Inches(0.3))))
            pPr.set("indent", str(-Emu(Inches(0.3))))
            buClr = pPr.makeelement(qn("a:buClr"), {})
            clr = buClr.makeelement(qn("a:srgbClr"), {"val": "%02X%02X%02X" % (bullet_color[0], bullet_color[1], bullet_color[2])})
            buClr.append(clr)
            pPr.append(buClr)
            pPr.append(pPr.makeelement(qn("a:buChar"), {"char": "•"}))
            r = p.add_run()
            r.text = str(item)
            r.font.size, r.font.name = Pt(size), FONT
            r.font.color.rgb = color
        return tb

    def box(slide, x, y, w, h, fill=SURFACE, line=None, radius=0.08, shape=MSO_SHAPE.ROUNDED_RECTANGLE, dash=None):
        sh = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
        sh.shadow.inherit = False
        if fill is None:
            sh.fill.background()
        else:
            sh.fill.solid()
            sh.fill.fore_color.rgb = fill
        if line is None:
            sh.line.fill.background()
        else:
            sh.line.color.rgb = line
            sh.line.width = Pt(1.25)
            if dash:
                sh.line.dash_style = dash
        if shape == MSO_SHAPE.ROUNDED_RECTANGLE:
            sh.adjustments[0] = radius
        sh.text_frame.margin_left = sh.text_frame.margin_right = Inches(0.12)
        sh.text_frame.margin_top = sh.text_frame.margin_bottom = Inches(0.06)
        return sh

    def shape_text(sh, s, size=12, bold=False, color=INK, align=PP_ALIGN.CENTER, sub=None, sub_size=10, sub_color=MUTED):
        tf = sh.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = align
        r = p.add_run()
        r.text = str(s)
        r.font.size, r.font.bold, r.font.name = Pt(size), bold, FONT
        r.font.color.rgb = color
        if sub:
            p2 = tf.add_paragraph()
            p2.alignment = align
            r2 = p2.add_run()
            r2.text = str(sub)
            r2.font.size, r2.font.name = Pt(sub_size), FONT
            r2.font.color.rgb = sub_color

    def arrow(slide, x1, y1, x2, y2, color=MUTED, dashed=False, width=1.5):
        c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
        c.line.color.rgb = color
        c.line.width = Pt(width)
        if dashed:
            c.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        ln = c.line._get_or_add_ln()
        ln.append(ln.makeelement(qn("a:tailEnd"), {"type": "triangle", "w": "med", "len": "med"}))
        return c

    def motif(slide, x, y, n=7, red_index=None, size=0.2, gap=0.1, light=True):
        """A row of inputs; one of them is the crash. The deck's visual motif (dark slides only)."""
        for i in range(n):
            col = ACCENT if i == (red_index if red_index is not None else n - 2) else (RGBColor(0x3A, 0x42, 0x52) if light else LINE)
            box(slide, x + i * (size + gap), y, size, size, fill=col, radius=0.2)

    def slide_title(slide, s, dark=False):
        text(slide, M, TITLE_Y, W - 2 * M, TITLE_H, s, size=34, bold=True, color=PAPER if dark else INK, anchor=MSO_ANCHOR.MIDDLE)

    def footer(slide, idx, dark=False):
        text(slide, W - M - 1.2, H - 0.45, 1.2, 0.3, str(idx), size=10, color=MUTED_ON_DARK if dark else MUTED, align=PP_ALIGN.RIGHT)
        text(slide, M, H - 0.45, 4, 0.3, deck.get("footer") or deck.get("title", ""), size=10, color=MUTED_ON_DARK if dark else MUTED)

    def notes(slide, s):
        if s.get("notes"):
            slide.notes_slide.notes_text_frame.text = str(s["notes"])

    def new(dark=False):
        sl = prs.slides.add_slide(blank)
        bg(sl, INK if dark else PAPER)
        return sl

    # ---- slide types
    def r_title(s, idx):
        sl = new(dark=True)
        text(sl, M, 2.0, W - 2 * M - 1.0, 1.6, s["title"], size=48, bold=True, color=PAPER, anchor=MSO_ANCHOR.BOTTOM)
        if s.get("subtitle"):
            text(sl, M, 3.7, W - 2 * M - 1.0, 1.0, s["subtitle"], size=22, color=MUTED_ON_DARK)
        meta = " · ".join(x for x in (deck.get("author"), deck.get("date"), s.get("footnote")) if x)
        if meta:
            text(sl, M, H - 1.1, W - 2 * M, 0.4, meta, size=13, color=MUTED_ON_DARK)
        motif(sl, M, 5.05, n=9, red_index=6)
        notes(sl, s)

    def r_section(s, idx):
        sl = new(dark=True)
        text(sl, M, 2.4, W - 2 * M, 1.2, s["title"], size=40, bold=True, color=PAPER, anchor=MSO_ANCHOR.BOTTOM)
        if s.get("subtitle"):
            text(sl, M, 3.7, W - 2 * M, 0.8, s["subtitle"], size=20, color=MUTED_ON_DARK)
        motif(sl, M, 4.8, n=9, red_index=(idx % 7) + 1)
        footer(sl, idx, dark=True)
        notes(sl, s)

    def r_bullets(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        has_side = bool(s.get("callout") or s.get("takeaway"))
        bw = 7.4 if has_side else W - 2 * M
        bullets(sl, M, BODY_Y, bw, H - BODY_Y - 0.9, s["bullets"])
        if has_side:
            cx, cw = M + bw + 0.5, W - M - (M + bw + 0.5)
            c = s.get("callout") or {}
            blank = bool(c) and str(c.get("value", "")).strip() in BLANKS
            card = box(sl, cx, BODY_Y, cw, 3.9, fill=SURFACE, line=LINE if blank else None, dash=MSO_LINE_DASH_STYLE.DASH if blank else None)
            if c:
                text(sl, cx + 0.3, BODY_Y + 0.45, cw - 0.6, 1.4, "__" if blank else c.get("value", ""), size=44 if blank else 54, bold=True,
                     color=MUTED if blank else ACCENT, anchor=MSO_ANCHOR.MIDDLE)
                text(sl, cx + 0.3, BODY_Y + 1.95, cw - 0.6, 1.0, c.get("label", ""), size=14, color=MUTED)
                if s.get("takeaway"):
                    text(sl, cx + 0.3, BODY_Y + 2.75, cw - 0.6, 1.0, s["takeaway"], size=14, bold=True, color=TEAL)
            else:
                text(sl, cx + 0.3, BODY_Y + 0.3, cw - 0.6, 3.3, s["takeaway"], size=18, bold=True, color=TEAL, anchor=MSO_ANCHOR.MIDDLE)
        footer(sl, idx)
        notes(sl, s)

    def r_two_column(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        gap, cw = 0.4, (W - 2 * M - 0.4) / 2
        for k, col in enumerate((s["left"], s["right"])):
            x = M + k * (cw + gap)
            box(sl, x, BODY_Y, cw, H - BODY_Y - 0.9, fill=SURFACE)
            text(sl, x + 0.35, BODY_Y + 0.3, cw - 0.7, 0.6, col.get("heading", ""), size=20, bold=True, color=TEAL if k else INK)
            bullets(sl, x + 0.35, BODY_Y + 1.05, cw - 0.7, H - BODY_Y - 0.9 - 1.4, col.get("bullets") or [], base=16, floor=13)
        footer(sl, idx)
        notes(sl, s)

    def r_cards(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        cards = s["cards"]
        n = len(cards)
        cols = 3 if n > 4 else (2 if n in (2, 4) else n)
        rows = math.ceil(n / cols)
        gap = 0.35
        cw = (W - 2 * M - gap * (cols - 1)) / cols
        ch = (H - BODY_Y - 0.9 - gap * (rows - 1)) / rows
        for i, c in enumerate(cards):
            r_, c_ = divmod(i, cols)
            x, y = M + c_ * (cw + gap), BODY_Y + r_ * (ch + gap)
            box(sl, x, y, cw, ch, fill=SURFACE)
            circ = box(sl, x + 0.3, y + 0.3, 0.5, 0.5, fill=TEAL if i % 2 else INK, shape=MSO_SHAPE.OVAL)
            shape_text(circ, str(i + 1), size=13, bold=True, color=PAPER)
            text(sl, x + 0.95, y + 0.28, cw - 1.25, 0.55, c.get("heading", ""), size=17, bold=True, anchor=MSO_ANCHOR.MIDDLE)
            body_size = fit([c.get("text", "")], cw - 0.6, ch - 1.2, 14, 12, spacing=0.2)
            text(sl, x + 0.3, y + 0.95, cw - 0.6, ch - 1.15, c.get("text", ""), size=body_size, color=INK)
        footer(sl, idx)
        notes(sl, s)

    def r_steps(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        steps = s["steps"]
        n = len(steps)
        gap = 0.45
        sw = (W - 2 * M - gap * (n - 1)) / n
        y0 = BODY_Y + 0.4
        for i, st in enumerate(steps):
            x = M + i * (sw + gap)
            head = box(sl, x, y0, sw, 0.9, fill=INK if i == 0 else SURFACE)
            shape_text(head, st.get("heading", ""), size=fit([st.get("heading", "")], sw - 0.3, 0.8, 15, 11, spacing=0.1), bold=True,
                       color=PAPER if i == 0 else INK)
            circ = box(sl, x + sw / 2 - 0.25, y0 - 0.3, 0.5, 0.5, fill=ACCENT, shape=MSO_SHAPE.OVAL)
            shape_text(circ, str(i + 1), size=12, bold=True, color=PAPER)
            body_size = fit([st.get("text", "")], sw - 0.2, 2.6, 14, 11, spacing=0.2)
            text(sl, x + 0.1, y0 + 1.1, sw - 0.2, 2.8, st.get("text", ""), size=body_size, color=INK)
            if i < n - 1:
                arrow(sl, x + sw + 0.05, y0 + 0.45, x + sw + gap - 0.05, y0 + 0.45, color=LINE, width=2)
        if s.get("note"):
            text(sl, M, H - 1.35, W - 2 * M, 0.5, s["note"], size=12, color=MUTED, italic=True)
        footer(sl, idx)
        notes(sl, s)

    def r_diagram(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        layers = s["layers"]
        n = len(layers)
        gap = 0.55
        top, bottom = BODY_Y + 0.35, H - 1.35
        colw = (W - 2 * M - gap * (n - 1)) / n
        pos = {}
        fills = {"det": (SURFACE, LINE, INK), "llm": (TEAL_LIGHT, TEAL, INK), "ext": (PAPER, MUTED, INK)}
        for li, L in enumerate(layers):
            x = M + li * (colw + gap)
            text(sl, x, BODY_Y - 0.1, colw, 0.35, str(L.get("name", "")).upper(), size=10, bold=True, color=MUTED, align=PP_ALIGN.CENTER)
            nodes = L.get("nodes") or []
            k = len(nodes)
            avail = bottom - top
            nh = min(1.15, (avail - 0.25 * (k - 1)) / k)
            block = k * nh + 0.25 * (k - 1)
            y = top + (avail - block) / 2
            for nd in nodes:
                fill, line, col = fills.get(str(nd.get("kind", "det")).lower(), fills["det"])
                b = box(sl, x, y, colw, nh, fill=fill, line=line, dash=MSO_LINE_DASH_STYLE.DASH if nd.get("kind") == "ext" else None)
                lab_size = fit([nd.get("label", "")], colw - 0.3, nh * (0.6 if nd.get("sub") else 0.9), 13, 10, spacing=0.1)
                shape_text(b, nd.get("label", ""), size=lab_size, bold=True, color=col, sub=nd.get("sub"), sub_size=9)
                pos[nd["id"]] = (x, y, colw, nh, li)
                y += nh + 0.25
        def edge_label(cx, cy, label, align=PP_ALIGN.CENTER):
            """Small label on a white chip so it never collides with node text; centred on (cx, cy)."""
            w = min(2.6, 0.075 * len(str(label)) + 0.3)
            tb = text(sl, cx - w / 2, cy - 0.14, w, 0.28, label, size=9, color=MUTED, align=align, anchor=MSO_ANCHOR.MIDDLE)
            tb.fill.solid()
            tb.fill.fore_color.rgb = PAPER

        for e in s["edges"]:
            a, b_ = pos.get(e[0]), pos.get(e[1])
            if not a or not b_:
                continue
            (ax, ay, aw, ah, al), (bx, by, bw, bh, bl) = a, b_
            label = e[2] if len(e) > 2 and e[2] else None
            if bl > al:                                            # forward: right edge -> left edge
                x1, y1, x2, y2 = ax + aw, ay + ah / 2, bx, by + bh / 2
                arrow(sl, x1, y1, x2, y2, color=MUTED if bl - al == 1 else LINE, width=1.5 if bl - al == 1 else 1.0)
                if label:
                    edge_label((x1 + x2) / 2, (y1 + y2) / 2 - 0.22, label)
            elif bl < al:                                          # feedback: dashed accent, label near the target
                x1, y1, x2, y2 = ax, ay + ah / 2, bx + bw, by + bh / 2
                arrow(sl, x1, y1, x2, y2, color=ACCENT, dashed=True)
                if label:
                    t = 0.3
                    edge_label(x2 + t * (x1 - x2), y2 + t * (y1 - y2) - 0.24, label)
            else:                                                  # same layer: vertical, label to the right of the line
                down = by > ay
                x1, y1, x2, y2 = ax + aw / 2, (ay + ah if down else ay), bx + bw / 2, (by if down else by + bh)
                arrow(sl, x1, y1, x2, y2, color=MUTED if e[0] != e[1] else ACCENT)
                if label:
                    if x1 > W / 2:                                 # right half: label on the left of the line
                        edge_label(x1 - 0.95, (y1 + y2) / 2, label, align=PP_ALIGN.RIGHT)
                    else:
                        edge_label(x1 + 0.95, (y1 + y2) / 2, label, align=PP_ALIGN.LEFT)
        if s.get("legend", True):
            lx, ly = M, H - 1.15
            for i, (k, lab) in enumerate((("det", "deterministic"), ("llm", "model-driven"), ("ext", "outside discver (OSS-CRS / target)"))):
                fill, line, _ = fills[k]
                box(sl, lx + i * 3.0, ly, 0.35, 0.25, fill=fill, line=line, dash=MSO_LINE_DASH_STYLE.DASH if k == "ext" else None)
                text(sl, lx + i * 3.0 + 0.45, ly - 0.03, 2.5, 0.3, lab, size=11, color=MUTED)
            box(sl, lx + 9.0, ly + 0.1, 0.35, 0.03, fill=ACCENT)
            text(sl, lx + 9.45, ly - 0.03, 3.0, 0.3, "dashed red = feedback loop", size=11, color=MUTED)
        footer(sl, idx)
        notes(sl, s)

    def r_table(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        cols, rows = s["columns"], s["rows"]
        nr, nc = len(rows) + 1, len(cols)
        th = min(0.55, (H - BODY_Y - 1.5) / nr)
        gf = sl.shapes.add_table(nr, nc, Inches(M), Inches(BODY_Y), Inches(W - 2 * M), Inches(th * nr))
        tbl = gf.table
        tblPr = gf._element.graphic.graphicData.tbl.tblPr
        tblPr.set("bandRow", "0")
        tblPr.set("firstRow", "0")
        sid = tblPr.find(qn("a:tableStyleId"))
        if sid is None:
            sid = tblPr.makeelement(qn("a:tableStyleId"), {})
            tblPr.append(sid)
        sid.text = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"      # No Style, No Grid
        first_w = 3.6 if nc > 2 else (W - 2 * M) / 2
        other_w = (W - 2 * M - first_w) / max(1, nc - 1)
        for ci in range(nc):
            tbl.columns[ci].width = Inches(first_w if ci == 0 else other_w)
        for ri in range(nr):
            tbl.rows[ri].height = Inches(th)
            for ci in range(nc):
                cell = tbl.cell(ri, ci)
                val = cols[ci] if ri == 0 else rows[ri - 1][ci]
                blank = ri > 0 and ci > 0 and str(val).strip() in BLANKS
                cell.fill.solid()
                cell.fill.fore_color.rgb = INK if ri == 0 else (SURFACE if ri % 2 else PAPER)
                cell.margin_left = cell.margin_right = Inches(0.15)
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                tf = cell.text_frame
                p = tf.paragraphs[0]
                p.alignment = PP_ALIGN.LEFT if ci == 0 else PP_ALIGN.CENTER
                r = p.add_run()
                r.text = "— fill in —" if blank else str(val)
                r.font.name = FONT
                r.font.size = Pt(13 if nr > 8 else 14)
                r.font.bold = ri == 0 or ci == 0
                r.font.italic = blank
                r.font.color.rgb = PAPER if ri == 0 else (MUTED if blank else INK)
        if s.get("note"):
            text(sl, M, BODY_Y + th * nr + 0.3, W - 2 * M, 0.6, s["note"], size=12, color=MUTED, italic=True)
        footer(sl, idx)
        notes(sl, s)

    def r_stats(s, idx):
        sl = new()
        slide_title(sl, s["title"])
        stats = s["stats"]
        n = len(stats)
        gap = 0.4
        cw = (W - 2 * M - gap * (n - 1)) / n
        for i, st in enumerate(stats):
            x = M + i * (cw + gap)
            blank = str(st.get("value", "")).strip() in BLANKS
            box(sl, x, BODY_Y + 0.3, cw, 3.4, fill=SURFACE, line=LINE if blank else None, dash=MSO_LINE_DASH_STYLE.DASH if blank else None)
            text(sl, x + 0.2, BODY_Y + 0.7, cw - 0.4, 1.6, "__" if blank else st.get("value", ""), size=56 if not blank else 44, bold=True,
                 color=MUTED if blank else ACCENT, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            text(sl, x + 0.2, BODY_Y + 2.45, cw - 0.4, 1.0, st.get("label", ""), size=15, color=INK, align=PP_ALIGN.CENTER)
        if s.get("note"):
            text(sl, M, BODY_Y + 4.1, W - 2 * M, 0.6, s["note"], size=12, color=MUTED, italic=True)
        footer(sl, idx)
        notes(sl, s)

    def r_closing(s, idx):
        sl = new(dark=True)
        text(sl, M, TITLE_Y, W - 2 * M, TITLE_H, s["title"], size=34, bold=True, color=PAPER, anchor=MSO_ANCHOR.MIDDLE)
        bullets(sl, M, BODY_Y + 0.1, W - 2 * M - 3.2, H - BODY_Y - 1.4, s["bullets"], color=PAPER, bullet_color=ACCENT, base=20, floor=15)
        if s.get("footnote"):
            text(sl, M, H - 1.0, W - 2 * M, 0.4, s["footnote"], size=13, color=MUTED_ON_DARK)
        motif(sl, W - M - 9 * 0.3 + 0.1, BODY_Y + 0.3, n=9, red_index=3)
        footer(sl, idx, dark=True)
        notes(sl, s)

    renderers = {"title": r_title, "section": r_section, "bullets": r_bullets, "two_column": r_two_column, "cards": r_cards,
                 "steps": r_steps, "diagram": r_diagram, "table": r_table, "stats": r_stats, "closing": r_closing}
    for i, s in enumerate(deck["slides"], 1):
        renderers[s["type"]](s, i)
    out.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(out))


# ----------------------------------------------------------------------------- agent loop
def compact(messages: list[dict]) -> None:
    """Elide old tool outputs once the conversation gets long (keeps the newest KEEP_RECENT_OUTPUTS intact)."""
    if sum(len(json.dumps(m)) for m in messages) < CTX_SOFT_LIMIT:
        return
    tool_idx = [i for i, m in enumerate(messages) if m.get("role") == "tool"]
    for i in tool_idx[:-KEEP_RECENT_OUTPUTS]:
        if len(messages[i].get("content") or "") > 400:
            messages[i]["content"] = messages[i]["content"][:300] + "\n...[elided to save context; call the tool again if needed]"


def run_agent(model: str, roots: dict[str, Path], out: Path, max_turns: int, extra_instructions: str | None) -> dict:
    toolbox, chat = Toolbox(roots), Chat(model)
    user = ("Produce the discver deck now. Roots available: " + ", ".join(f"{k}={v}" for k, v in roots.items()) +
            ". Output file: " + str(out) + ". Follow the work plan, then call finish_deck with the complete deck JSON.")
    if extra_instructions:
        user += "\n\nAdditional instructions from the author:\n" + extra_instructions
    ctx = roots.get("context")
    if ctx is not None:
        files = [ctx] if ctx.is_file() else [p for p in ctx.iterdir() if p.is_file() and p.suffix.lower() in (".md", ".txt", ".rst")]
        for f in files:
            try:
                n = sum(1 for _ in f.open(errors="replace"))
            except OSError:
                continue
            if n > 1200:
                user += (f"\n\nContext file {f.name} has {n} lines (a campaign/run log). Do not page through all of it: first "
                         f"`grep` it for '^#' to list its sections, then read the LAST ~400 lines fully and the sections whose "
                         f"headings matter for status, methodology and open items. It is the authoritative record of what was "
                         f"changed, tested and verified — prefer it over your own reading of the code where they disagree.")
            else:
                user += f"\n\nContext file {f.name} ({n} lines): read it fully."
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user}]
    tokens_in = tokens_out = 0
    deck_attempts = 0
    for turn in range(1, max_turns + 1):
        compact(messages)
        try:
            content, calls, assistant, usage = chat.complete(messages, TOOLS)
        except HTTPError as exc:
            if exc.status == 400 and any(s in exc.body.lower() for s in ("context_length", "maximum context", "too many", "too long")):
                log("[agent] context too long — hard compaction")
                for m in messages:
                    if m.get("role") == "tool" and len(m.get("content") or "") > 200:
                        m["content"] = m["content"][:200] + "\n...[elided]"
                continue
            raise
        tokens_in += usage.get("in") or 0
        tokens_out += usage.get("out") or 0
        messages.append(assistant)
        if content:
            log(f"[turn {turn}] {redact(content)[:300]}")
        if not calls:
            messages.append({"role": "user", "content": "Continue: use the tools, then call finish_deck with the complete deck JSON."})
            continue
        for c in calls:
            try:
                args = json.loads(c["arguments"]) if c["arguments"] else {}
            except json.JSONDecodeError:
                args = {}
            if c["name"] == "finish_deck":
                deck = args.get("deck")
                if deck is None and args.get("deck_json"):
                    try:
                        deck = json.loads(args["deck_json"])
                    except json.JSONDecodeError as e:
                        deck = None
                        result = f"deck_json is not valid JSON: {e}"
                if deck is not None:
                    errs = validate_deck(deck)
                    deck_attempts += 1
                    if errs and deck_attempts < 4:
                        result = "Deck rejected — fix these and call finish_deck again:\n- " + "\n- ".join(errs[:40])
                        log(f"[deck] attempt {deck_attempts}: {len(errs)} validation errors")
                    else:
                        if errs:
                            log(f"[deck] accepting with {len(errs)} unresolved warnings after {deck_attempts} attempts")
                        deck_path = out.with_suffix(".json")
                        deck_path.write_text(json.dumps(deck, indent=2, ensure_ascii=False))
                        render(deck, out)
                        log(f"[deck] {len(deck['slides'])} slides -> {out}   (spec: {deck_path})")
                        log(f"[agent] turns={turn} tokens in={tokens_in} out={tokens_out}")
                        return deck
                elif "result" not in locals():
                    result = "finish_deck needs `deck` (object) or `deck_json` (string)"
            else:
                log(f"[turn {turn}] {c['name']} {json.dumps(args)[:160]}")
                result = toolbox.call(c["name"], args)
            messages.append({"role": "tool", "tool_call_id": c["id"], "content": clipped(result)})
            if "result" in locals():
                del result
    raise SystemExit(f"[agent] no deck after {max_turns} turns (tokens in={tokens_in} out={tokens_out})")


def verify(model: str) -> None:
    chat = Chat(model)
    t0 = time.time()
    text_, calls, _, usage = chat.complete(
        [{"role": "system", "content": "You are a tool-using agent."},
         {"role": "user", "content": "Call the tool `list_files` with path='src'. Do not answer in text."}],
        [TOOLS[0]])
    ok = any(c["name"] == "list_files" for c in calls)
    log(f"[verify] {BASE_URL} model={model} {time.time() - t0:.1f}s tool_call={'yes' if ok else 'NO'} effort={chat.effort or 'default'} usage={usage}")
    if not ok:
        log(f"[verify] model answered with text instead of a tool call: {text_[:200]!r}")
        raise SystemExit(1)
    log("[verify] OK")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", help="discver source tree (contains src/ and tests/)")
    ap.add_argument("--kb", help="knowledge base dir (recipes.jsonl, cwe_playbooks/, index.json)")
    ap.add_argument("--results", help="a staged run dir (REPORT.md, CAMPAIGN.md, orchestrator.log …) — used for metric NAMES only")
    ap.add_argument("--context", action="append", default=[], help="extra notes to read fully (HANDOFF.md, milestones, abstract …); repeatable")
    ap.add_argument("--instructions", help="free-text instructions for the agent (audience, length, emphasis)")
    ap.add_argument("--out", default="discver.pptx")
    ap.add_argument("--model", default=os.environ.get("AGENT_MODEL", ""))
    ap.add_argument("--max-turns", type=int, default=70)
    ap.add_argument("--render-only", metavar="DECK_JSON", help="skip the LLM; render this deck.json")
    ap.add_argument("--verify", action="store_true")
    a = ap.parse_args()

    out = Path(a.out)
    if a.verify:
        verify(a.model or "")
        return
    if a.render_only:
        deck = json.loads(Path(a.render_only).read_text())
        errs = validate_deck(deck)
        for e in errs:
            log(f"[validate] {e}")
        render(deck, out)
        log(f"[render] {len(deck['slides'])} slides -> {out}")
        return
    if not a.repo:
        ap.error("--repo is required (or use --render-only)")
    if not a.model:
        ap.error("--model or AGENT_MODEL is required")
    roots = {"repo": Path(a.repo).resolve()}
    if a.kb:
        roots["kb"] = Path(a.kb).resolve()
    if a.results:
        roots["results"] = Path(a.results).resolve()
    if a.context:
        if len(a.context) == 1:
            roots["context"] = Path(a.context[0]).resolve()
        else:
            # several files: expose the common parent, listing only those files
            ctx_dir = Path(a.context[0]).resolve().parent
            roots["context"] = ctx_dir
            log("[agent] context root = " + str(ctx_dir) + " (files: " + ", ".join(Path(c).name for c in a.context) + ")")
    for k, v in roots.items():
        if not v.exists():
            ap.error(f"{k} root does not exist: {v}")
    run_agent(a.model, roots, out, a.max_turns, a.instructions)


if __name__ == "__main__":
    main()
