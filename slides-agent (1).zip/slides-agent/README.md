# slides_agent — discver deck from the code

One file, two phases. The LLM **reads** the repo, the KB and your notes with read-only tools and writes `deck.json`
(what to say, every slide's notes citing the file it came from). A deterministic python-pptx renderer turns that into
`discver.pptx` (how it looks). The model never touches slide code; you can edit `deck.json` by hand and re-render in a second.

Fixed outline: title → intro (2) → **Architecture** (diagram drawn from a layers/edges spec) → **Methodology** (4–5, each a
different slide type) → **Results** (3–4 slides of blanks: right rows, right labels, values `— fill in —`) → **Conclusion**.
The validator rejects any number in a results slide, so the model cannot invent a result.

## Setup (once, on the box with the discver tree)
```
pip install python-pptx
export LITELLM_BASE_URL=https://llai-proxy.llan.ll.mit.edu/v1   LITELLM_API_KEY=...   AGENT_MODEL=claude-opus-5-5
python3 slides_agent.py --verify
```
Same env vars as `microagent.py` (`AGENT_CA_BUNDLE`, `AGENT_REASONING_EFFORT`, `AGENT_MAX_TOKENS`, `AGENT_REQUEST_TIMEOUT` all honoured).

## Run (single lines)
```
python3 slides_agent.py --repo campaign_work/discver --kb campaign_work/kb --context campaign_work/CAMPAIGN.md --out discver.pptx
```
Add `--context <file>` for anything else it should read fully (your milestones list, the campaign CAMPAIGN.md, an abstract);
`--results campaign_work/results/latest` lets it read REPORT.md to learn the *metric names* the system reports (values are never
copied — results stay blank). `--instructions "20-minute talk for sponsors, less code detail"` steers tone and depth.

Outputs: `discver.pptx`, `discver.json` (the deck spec), console log of every file it read.
Typical cost: 30–50 tool calls, one long compose call. `--max-turns` default 70.

## After it runs
- Open `discver.pptx`; fill the results tables and callouts (`— fill in —` / `__`). Speaker notes on every slide say which file
  each statement came from — check a few.
- Want wording changed? Edit `discver.json`, then `python3 slides_agent.py --render-only discver.json --out discver.pptx`.
  No LLM call, instant.
- Architecture diagram: boxes are real shapes; nudge them in PowerPoint if you want, or edit `layers`/`edges` in the JSON.

## Fallback
`deck.sample.json` is a complete deck written by hand from the code as of 5 Nov (with the KB count left blank). If the LLM run
fails or you are short on time: `python3 slides_agent.py --render-only deck.sample.json --out discver.pptx`, then edit the JSON.
`discver.sample.pptx` is that deck rendered, so you can see the look before running anything.

## Design
Ink/paper palette with one accent (crash red) and teal for model-driven stages; Calibri throughout; dark title/section/closing,
light content. Slide types: title · section · bullets (+ takeaway card or big-number callout) · two_column · cards · steps ·
diagram · table · stats · closing. 16:9.
