# LiteLLM gateway workshop kit (facilitator copy)

Attendees get: the setup lines, talk.py, and from Part 2 on: questions.json, eval.py, DATA_DIR.
Everything else here is yours.

talk.py            the one file attendees receive (openai client -> gateway, no litellm import)
data/              the dataset (394 notes, ~80k words). Copy to a shared READ-ONLY path; that path is DATA_DIR
questions.json     12 questions with accepted answers and source files; eval.py reads it
eval.py            scores any rag.py that meets the contract (see the doc, Part 2)
rag_broken/rag.py  Part 3: six planted bugs (listed in the doc's facilitator sheet). Give attendees a copy.
solutions/agent.py reference agent (Parts 1.3, 1.4, 2.1)
solutions/rag.py   reference RAG (Part 2 complete; what rag_broken should become)

Env vars every script reads: GATEWAY_URL, GATEWAY_KEY, MODEL, DATA_DIR, TLS_VERIFY (optional).
Timing baselines measured on one laptop core, GATEWAY_URL unset:
  solutions/rag.py          retrieval 12/12   0.2 s
  rag_broken (crashes fixed) retrieval  0/12  ~24 s
  rag_broken (sort fixed)   retrieval 12/12  ~25 s
  + index built once        retrieval 12/12  ~2.4 s
  + dict vocabulary         retrieval 12/12   0.2 s
