import os
import httpx
from openai import OpenAI

client = OpenAI(
    base_url=os.environ["GATEWAY_URL"],
    api_key=os.environ["GATEWAY_KEY"],
    http_client=httpx.Client(verify=os.environ.get("TLS_VERIFY", "true").lower() != "false"),
)

response = client.chat.completions.create(
    model=os.environ["MODEL"],
    messages=[{"role": "user", "content": "Say hello and tell me which model you are."}],
)
print(response.choices[0].message.content)
