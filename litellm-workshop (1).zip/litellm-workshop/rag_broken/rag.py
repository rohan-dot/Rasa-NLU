#!/usr/bin/env python
# Simple retrieval-augmented QA over a folder of markdown/text notes.
# Keyword retrieval (BM25-ish) + the lab gateway for the final answer.
#
#   python rag.py --data /path/to/notes "your question"
#   python rag.py --data /path/to/notes --questions questions.json
#
# Prints one JSON line per question: {"question", "sources", "answer", "seconds"}.

import argparse
import json
import math
import os
import re
import sys
import time

CHUNK = 120      # words per chunk
OVERLAP = 120    # words shared between neighbouring chunks, so nothing falls between two chunks
TOP_K = 3

WORD = re.compile(r"[a-z0-9]+(?:[.,:/-][a-z0-9]+)*")


def words(text):
    return WORD.findall(text.lower())


def split_into_chunks(text):
    toks = text.split()
    out = []
    for start in range(0, len(toks), CHUNK - OVERLAP):
        out.append(" ".join(toks[start:start + CHUNK]))
    return out


class Index:
    """Vocabulary, document frequencies and per-chunk term counts for BM25."""

    def __init__(self, data_dir):
        self.chunks = []        # dicts: file, chunk, text, counts (term id -> count), length
        self.vocab = []         # term id = position in this list
        self.df = []            # per term id: number of chunks containing it
        for name in sorted(os.listdir(data_dir)):
            if not name.endswith((".md", ".txt")):
                continue
            path = data_dir + name
            with open(path, encoding="utf-8") as fh:
                text = fh.read()
            for n, piece in enumerate(split_into_chunks(text)):
                counts = {}
                for tok in words(piece):
                    if tok not in self.vocab:
                        self.vocab.append(tok)
                        self.df.append(0)
                    tid = self.vocab.index(tok)
                    counts[tid] = counts.get(tid, 0) + 1
                for tid in counts:
                    self.df[tid] += 1
                self.chunks.append({"file": name, "chunk": n, "text": piece,
                                    "counts": counts, "length": sum(counts.values())})
        self.n = len(self.chunks)
        self.avg_len = sum(c["length"] for c in self.chunks) / max(1, self.n)

    def term_id(self, tok):
        try:
            return self.vocab.index(tok)
        except ValueError:
            return None

    def idf(self, tid):
        d = self.df[tid]
        return math.log(1 + (self.n - d + 0.5) / (d + 0.5))

    def search(self, question, k=TOP_K, k1=1.5, b=0.75):
        q_ids = [t for t in (self.term_id(tok) for tok in words(question)) if t is not None]
        scores = []
        for c in self.chunks:
            s = 0.0
            for tid in q_ids:
                tf = c["counts"].get(tid, 0)
                if tf:
                    s += self.idf(tid) * tf * (k1 + 1) / (tf + k1 * (1 - b + b * c["length"] / self.avg_len))
            if s > 0:
                scores.append((s, c))
        ranked = sorted(scores, key=lambda pair: pair[0])
        return [c for _, c in ranked[:k]]


def ask_model(question, context_chunks):
    if not os.environ.get("GATEWAY_URL"):
        return None
    import httpx
    from openai import OpenAI
    client = OpenAI(base_url=os.environ["GATEWAY_URL"], api_key=os.environ["GATEWAY_KEY"],
                    http_client=httpx.Client(verify=os.environ.get("TLS_VERIFY", "true").lower() != "false"))
    context = "\n\n".join(f"[{c['file']} #{c['chunk']}]\n{c['text']}" for c in context_chunks)
    r = client.chat.completions.create(
        model=os.environ["MODEL"], temperature=0,
        messages=[
            {"role": "system", "content": "Answer from the context only, quoting its exact numbers and words. "
                                          "Cite the source as [file #chunk]. If the answer is not in the context, "
                                          "reply exactly: not in the documents."},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"},
        ])
    return r.choices[0].message.content


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--questions")
    p.add_argument("question", nargs="?")
    a = p.parse_args()

    if a.question:
        qs = [a.question]
    else:
        qs = [item["q"] for item in json.load(open(a.questions))]

    for q in qs:
        t0 = time.time()
        index = Index(a.data)
        top = index.search(q)
        reply = ask_model(q, index.chunks[:TOP_K])
        print(json.dumps({"question": q,
                          "sources": [f"{c['file']}#{c['chunk']}" for c in top],
                          "answer": reply,
                          "seconds": round(time.time() - t0, 2)}))
        sys.stdout.flush()


if __name__ == "__main__":
    main()
