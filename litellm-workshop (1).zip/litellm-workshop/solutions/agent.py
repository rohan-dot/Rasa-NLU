"""Reference coding agent (facilitator's answer key for Part 1.3 / 1.4 and Part 2.1).

Plain `openai` client against the gateway, five tools, a loop. Writes only under the current folder;
reads under the current folder and, if set, $DATA_DIR. Asks before every write, edit or command;
pass --yes to run unattended.

    python agent.py "write wordcount.py with tests and run them"
    python agent.py --yes "the tests in rag_broken fail; find out why and fix it"
"""
import json
import os
import subprocess
import sys
from pathlib import Path

import httpx
from openai import OpenAI

client = OpenAI(
    base_url=os.environ["GATEWAY_URL"],
    api_key=os.environ["GATEWAY_KEY"],
    http_client=httpx.Client(verify=os.environ.get("TLS_VERIFY", "true").lower() != "false"),
)
MODEL = os.environ["MODEL"]

ROOT = Path.cwd().resolve()                                        # the only place the agent may write
READ_ROOTS = [ROOT] + ([Path(os.environ["DATA_DIR"]).resolve()] if os.environ.get("DATA_DIR") else [])
AUTO_YES = "--yes" in sys.argv
MAX_TURNS = 30
ALLOWED_COMMANDS = ("python", "pytest", "ls", "cat", "head", "wc", "git status", "git diff")

SYSTEM = f"""You are a careful coding agent.
Rules:
- Explore first: list_files, then read_file anything you intend to change.
- Make the smallest change that solves the task. Prefer edit_file (exact string replace) over rewriting whole files.
- After changing code, run it (or the tests) with run_command and read the output before declaring success.
- When done, reply in plain text: what you changed and the output that proves it.
You may read files under {ROOT}{' and under ' + str(READ_ROOTS[1]) + ' (the dataset, read-only)' if len(READ_ROOTS) > 1 else ''}.
You may only write under {ROOT}. Commands run in {ROOT}."""


# ---- tools, Python side -------------------------------------------------------------------
def confirm(what):
    return AUTO_YES or input(f"    allow {what}? [y/N] ").strip().lower() == "y"


def resolve(path, write=False):
    p = Path(path)
    p = (p if p.is_absolute() else ROOT / p).resolve()
    roots = [ROOT] if write else READ_ROOTS
    if not any(p == r or r in p.parents for r in roots):
        raise ValueError(f"{path!r} is outside the allowed folders: {[str(r) for r in roots]}")
    return p


def list_files(path="."):
    base = resolve(path)
    names = [str(p.relative_to(base)) for p in sorted(base.rglob("*"))
             if p.is_file() and "__pycache__" not in p.parts and ".git" not in p.parts]
    return f"{base}:\n" + ("\n".join(names[:500]) or "(empty)") + ("\n... truncated" if len(names) > 500 else "")


def read_file(path):
    return resolve(path).read_text(encoding="utf-8")


def write_file(path, content):
    p = resolve(path, write=True)
    if not confirm(f"write {path} ({len(content.splitlines())} lines)"):
        return "User declined the write."
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"wrote {path}"


def edit_file(path, old, new):
    p = resolve(path, write=True)
    text = p.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        return (f"error: `old` must match exactly once in {path}; it matches {count} times. "
                "Re-read the file and send a longer, unique snippet.")
    if not confirm(f"edit {path}: replace {len(old.splitlines())} line(s) with {len(new.splitlines())}"):
        return "User declined the edit."
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    return f"edited {path}"


def run_command(command):
    if not command.strip().startswith(ALLOWED_COMMANDS):
        return f"error: only commands starting with {ALLOWED_COMMANDS} are allowed"
    if not confirm(f"run `{command}`"):
        return "User declined to run the command."
    r = subprocess.run(command, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=300)
    return f"exit code {r.returncode}\n--- stdout ---\n{r.stdout[-6000:]}\n--- stderr ---\n{r.stderr[-3000:]}"


TOOLS = {"list_files": list_files, "read_file": read_file, "write_file": write_file,
         "edit_file": edit_file, "run_command": run_command}


# ---- tools, as the model sees them ----------------------------------------------------------
def spec(name, description, properties, required):
    return {"type": "function", "function": {"name": name, "description": description,
            "parameters": {"type": "object", "properties": properties, "required": required}}}


S = {"type": "string"}
TOOL_SPECS = [
    spec("list_files", "List every file under a folder, recursively.", {"path": S}, []),
    spec("read_file", "Read a text file and return its contents.", {"path": S}, ["path"]),
    spec("write_file", "Create or overwrite a file with the given content.", {"path": S, "content": S}, ["path", "content"]),
    spec("edit_file", "Replace exactly one occurrence of `old` with `new` in a file. `old` must match the file "
         "text exactly, including indentation and newlines.", {"path": S, "old": S, "new": S}, ["path", "old", "new"]),
    spec("run_command", "Run a shell command and return its output, e.g. 'python -m pytest -q' or 'python rag.py ...'.",
         {"command": S}, ["command"]),
]


# ---- the loop ---------------------------------------------------------------------------------
def run(task):
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": task}]
    tokens = 0
    for turn in range(1, MAX_TURNS + 1):
        response = client.chat.completions.create(model=MODEL, messages=messages, tools=TOOL_SPECS)
        tokens += response.usage.total_tokens if response.usage else 0
        msg = response.choices[0].message
        messages.append(msg)                              # the SDK serialises this object for the next call

        if not msg.tool_calls:                            # plain text = the agent is done
            print(f"\n{msg.content or '(no reply)'}\n\n[{turn} model calls, {tokens} tokens]")
            return
        if msg.content:
            print(f"[{turn}] {msg.content.strip()[:300]}")   # many models explain their plan here

        for tc in msg.tool_calls:
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments or "{}")
                shown = ", ".join(f"{k}={str(v)[:50]!r}" for k, v in args.items())
                print(f"[{turn}] {name}({shown})")
                result = TOOLS[name](**args)
            except Exception as e:                        # errors go back to the model, not up the stack
                result = f"error: {type(e).__name__}: {e}"
            messages.append({"role": "tool", "tool_call_id": tc.id, "content": str(result)[:12000]})

    print(f"\nStopped after {MAX_TURNS} turns without finishing. Narrow the task or raise MAX_TURNS.")


if __name__ == "__main__":
    task = " ".join(a for a in sys.argv[1:] if a != "--yes")
    if not task:
        raise SystemExit('usage: python agent.py [--yes] "describe the task"')
    run(task)
