"""Reference RAG for the workshop (facilitator's answer key for Part 2, and the fixed form of Part 3).

Usage:
    python rag.py --data $DATA_DIR "What is the wind limit for opening the dome?"
    python rag.py --data $DATA_DIR --questions questions.json      # one JSON line per question

Retrieval is BM25 in pure Python (no packages beyond `openai`). The answer step calls the gateway
only if GATEWAY_URL is set; without it, retrieval still runs so the pipeline can be scored offline.
"""
import argparse
import json
import math
import os
import re
import sys
import time
from collections import Counter

CHUNK_WORDS = 150
OVERLAP_WORDS = 30
TOKEN = re.compile(r"[a-z0-9]+(?:[.,:/-][a-z0-9]+)*")


def tokenize(text):
    return TOKEN.findall(text.lower())


def chunk_words(text, size=CHUNK_WORDS, overlap=OVERLAP_WORDS):
    words = text.split()
    step = max(1, size - overlap)
    return [" ".join(words[i:i + size]) for i in range(0, max(1, len(words) - overlap), step)]


def build_index(data_dir):
    """Read every text file under data_dir once and build the BM25 statistics."""
    t0 = time.time()
    chunks = []
    for name in sorted(os.listdir(data_dir)):
        path = os.path.join(data_dir, name)
        if not os.path.isfile(path) or not name.endswith((".md", ".txt")):
            continue
        with open(path, encoding="utf-8") as f:
            text = f.read()
        for n, piece in enumerate(chunk_words(text)):
            chunks.append({"file": name, "chunk": n, "text": piece, "tf": Counter(tokenize(piece))})
    df = Counter()
    for c in chunks:
        df.update(c["tf"].keys())
    n = len(chunks)
    avgdl = sum(sum(c["tf"].values()) for c in chunks) / max(1, n)
    idf = {term: math.log(1 + (n - d + 0.5) / (d + 0.5)) for term, d in df.items()}
    print(f"[index] {n} chunks from {len({c['file'] for c in chunks})} files in {time.time() - t0:.2f}s", file=sys.stderr)
    return {"chunks": chunks, "idf": idf, "avgdl": avgdl}


def retrieve(index, question, k=3, k1=1.5, b=0.75):
    """Top-k chunks by BM25 score."""
    terms = tokenize(question)
    scored = []
    for c in index["chunks"]:
        dl = sum(c["tf"].values())
        score = 0.0
        for term in terms:
            tf = c["tf"].get(term)
            if not tf:
                continue
            score += index["idf"][term] * tf * (k1 + 1) / (tf + k1 * (1 - b + b * dl / index["avgdl"]))
        if score > 0:
            scored.append((score, c))
    scored.sort(key=lambda s: s[0], reverse=True)
    return [c for _, c in scored[:k]]


def answer(question, chunks):
    """Ask the model, with the retrieved chunks as the only allowed source."""
    if not os.environ.get("GATEWAY_URL"):
        return None
    import httpx
    from openai import OpenAI

    client = OpenAI(
        base_url=os.environ["GATEWAY_URL"],
        api_key=os.environ["GATEWAY_KEY"],
        http_client=httpx.Client(verify=os.environ.get("TLS_VERIFY", "true").lower() != "false"),
    )
    context = "\n\n".join(f"[{c['file']} #{c['chunk']}]\n{c['text']}" for c in chunks)
    response = client.chat.completions.create(
        model=os.environ["MODEL"],
        temperature=0,
        messages=[
            {"role": "system", "content": (
                "Answer using only the provided context. Quote the exact numbers and words from it. "
                "Cite the source after the answer as [file #chunk]. "
                "If the context does not contain the answer, reply exactly: not in the documents.")},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"},
        ],
    )
    return response.choices[0].message.content


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--questions", help="JSON file: a list of {\"q\": ...}")
    ap.add_argument("-k", type=int, default=3)
    ap.add_argument("question", nargs="?")
    args = ap.parse_args()

    questions = [args.question] if args.question else [q["q"] for q in json.load(open(args.questions))]
    index = build_index(args.data)                       # once, not per question
    for q in questions:
        t0 = time.time()
        top = retrieve(index, q, args.k)
        reply = answer(q, top)
        print(json.dumps({
            "question": q,
            "sources": [f"{c['file']}#{c['chunk']}" for c in top],
            "answer": reply,
            "seconds": round(time.time() - t0, 3),
        }))


if __name__ == "__main__":
    main()
