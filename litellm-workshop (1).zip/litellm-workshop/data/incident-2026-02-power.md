# Incident report: generator transfer failure, 3 February 2026

## Summary

At 23:40 on 3 February 2026 the utility feed to the summit dropped during a winter storm. The
automatic transfer switch should have started the standby generator within 30 seconds. It did not.
The control room and the Marlin cryocooler ran on the UPS, which kept them up for 42 minutes
before shutting down at 00:22. The generator was started by hand at 00:35 by the night assistant.

## Cause

The transfer switch controller had a corrupted configuration after a firmware update applied on
27 January. The update had not been followed by a transfer test. The generator itself was healthy.

## Impact

The Marlin detector warmed to minus 60 degrees before power returned. It was back at operating
temperature by 08:00 and no damage was found. The observing night was lost. The dome was already
closed because of the storm.

## Actions

- Every firmware change to the transfer switch is followed by a live transfer test the same day.
- The monthly generator test (first Monday) now includes a full automatic transfer, not only a
  generator start.
- A written manual start procedure is posted inside the generator shed door.
- The UPS runtime of 42 minutes is now the planning number for any outage: anything that cannot
  be shut down safely in 30 minutes is on the generator feed, not the UPS.
