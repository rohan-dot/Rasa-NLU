# Observing procedures

These procedures apply to every observing night on the Pelican, whoever is observing.

## Before opening

Check the weather station display. Do not open the dome if the relative humidity is above 85
percent, if precipitation is detected, or if the wind exceeds the limit in the telescope manual.
The humidity close limit is also 85 percent: once open, close the dome as soon as the ten-minute
average humidity crosses it.

## Calibration frames

Every night, before opening, take 25 bias frames and a dark sequence matching the exposure times
planned for the night. Take sky flats at evening twilight, a minimum of 7 per filter in use, and
repeat at morning twilight if the evening set was interrupted by cloud.

## During the night

Record every exposure in the night report with target, filter, exposure time and seeing. Measure
the seeing from a short exposure on a bright star at least once an hour. If the seeing exceeds 3
arcseconds for more than 30 minutes, switch to the backup program of bright targets.

## Closing

Close the dome before morning civil twilight. Park the telescope, close the mirror cover, then
complete the night report and send it to the base office before leaving the control room. The
night report is the only record of what happened; an unrecorded exposure does not exist.

## Who to call

Instrument problems: the instrument scientist. Mount, dome or power problems: the on-call
engineer. Weather judgement calls are the night assistant's alone and are never overruled by
an observer.
