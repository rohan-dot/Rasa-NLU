# Incident report: dome drive failure, 14 July 2025

## Summary

At 02:10 on 14 July 2025 the dome stopped rotating during a routine slew to the east. The night
assistant heard a loud click from the drive housing followed by the drive motor running without
dome movement. The dome was closed manually using the hand crank at 02:45 and the night was lost.

## Cause

Inspection on 15 July found that the shear pin in the main drive coupling had failed. The shear pin
is designed to break before the gearbox does; it did its job. The underlying cause was a build-up
of ice on the dome track from the storm on 12 July, which increased the load on the drive beyond
the pin's rating.

## Impact

Three nights were lost (14, 15 and 16 July) while a replacement coupling was fetched from the base
workshop and fitted. The repair cost 1,850 dollars in parts and labour. No damage to the gearbox or
motor was found.

## Actions

- Keep two spare shear pins in the summit workshop at all times (completed, 20 July 2025).
- Add a track ice inspection to the opening checklist whenever the overnight low is below freezing
  (added to the observing procedures, August 2025).
- Train both night assistants on the manual closing procedure with the hand crank (completed
  September 2025).
