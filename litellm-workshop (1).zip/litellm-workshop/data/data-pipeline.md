# Data pipeline

## From the camera to disk

Every exposure is written by the camera software to the control room workstation and copied to
`/data/raw` on the summit file server within 90 seconds of the end of the exposure. Files are named
`BHO_YYYYMMDD_NNNN.fits`, where the date is the local date at the start of the night and NNNN is a
running number that resets each night.

## Nightly reduction

The nightly reduction job starts at 06:15 every morning on the summit file server. It applies the
bias, dark and flat corrections, solves the astrometry, and writes the results to `/data/reduced`
under the same file names with a `_red` suffix. The job takes between 40 minutes and two hours
depending on the number of frames. Its log is at `/data/logs/reduce_YYYYMMDD.log`.

## Transfer to base

Reduced data is synchronised to the base facility over the summit link every morning after the
reduction finishes. Raw data stays on the summit server for 60 days and is then moved to the tape
archive at base.

## Checking your data

Observers check the reduction log before leaving the summit. A frame listed as `SKIPPED` in the log
was rejected by the pipeline, almost always because its header is missing the filter keyword. Fix
the header with the `fixhdr` tool and re-run the reduction for that frame only with
`reduce --frame BHO_YYYYMMDD_NNNN`.

## Quality flags

The pipeline writes a `QUAL` keyword to every reduced frame: 0 is good, 1 means the astrometric
solution is uncertain, 2 means the flat field was more than 14 days old, and 3 means the frame was
taken with the dome partially closed.
