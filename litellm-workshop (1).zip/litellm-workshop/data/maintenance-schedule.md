# Maintenance schedule

The schedule below is the minimum. Anything found during an inspection is logged in the
maintenance log and fixed or scheduled by the site engineer.

## Weekly

- Tuesday, 10:00 to 14:00: maintenance window. The mount controller is powered off, the control
  room workstation is rebooted, and the dome shutter seals are inspected.
- Thursday: tape backup of the base archive (see the network and IT notes).

## Every six weeks

- Dome track lubrication. The track is cleaned and re-greased every 6 weeks; in winter the
  interval drops to every 3 weeks because of ice.

## Monthly

- Generator test on the first Monday of the month, including a full automatic transfer.
- UPS battery check.
- Weather station sensor cleaning.

## Quarterly

- Mirror wash of the Pelican primary, with a coating inspection. The last wash was 8 September 2026.
- Fire extinguisher inspection in the dome, control room and generator shed.
- Fibre throughput test on Marlin with the standard star sequence.

## Yearly

- Dome drive gearbox oil change, every October.
- Road and gate inspection before the first winter storm.
- Radio and repeater service.

## Record keeping

Every item above is ticked off in the maintenance log with the date and the initials of the person
who did it. The site engineer reviews the log at the end of each month.
