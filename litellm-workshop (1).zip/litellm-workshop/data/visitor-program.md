# Public visitor program

## Public nights

Public nights are held on the first Saturday of every month from April to October, weather
permitting. Capacity is 40 visitors per night. Tickets are 12 dollars for adults; children under 10
are free and must be accompanied by an adult. Tickets are sold through the base office and are not
sold at the summit.

## Schedule for a public night

Visitors board the summit shuttle at the base facility at 18:00 and return by 23:30. The program
is a 30 minute talk in the base lecture room, the shuttle ride, a dome tour, and eyepiece viewing
on the 0.4 metre Sandpiper telescope. The Pelican is not used for public viewing.

## Weather cancellations

The decision to cancel is made by the site manager at 15:00 on the day. Cancelled tickets are
refunded in full or moved to the next public night at the visitor's choice.

## School groups

School groups visit the base facility only, on weekday mornings by arrangement. Groups are capped
at 30 students with at least one adult per ten students. There is no charge for school groups.

## Accessibility

The summit dome has a ramp and the control room is on one level. Visitors who cannot use the
shuttle steps should tell the base office when booking so the lift-equipped shuttle can be used.
