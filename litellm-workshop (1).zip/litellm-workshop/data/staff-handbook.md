# Blue Heron Observatory staff handbook

Blue Heron Observatory (BHO) is a small optical observatory operated by the Heron Ridge Foundation.
This handbook covers the rules every staff member, student and visiting observer agrees to on arrival.

## Working hours and the summit shuttle

Day staff work 08:00 to 16:30 at the base facility in Alder Creek. Night assistants and observers
work from one hour before sunset until the end of morning twilight. The only approved way up the
mountain is the summit shuttle, which leaves the base facility at 14:30 every day and returns at
09:00 the following morning. Private vehicles are not permitted above the gate at kilometre 7
because the upper road has no guard rail and no cellular coverage.

## Badges and access

Every person on site carries a photo badge. The control room, the dome and the generator shed are
badge-locked. Lost badges are reported to the site manager within one hour; a replacement costs
the department 35 dollars. Visitors are escorted at all times and sign the visitor log at the base.

## Communication

The summit uses the Alder Creek repeater on channel 4. Every person on the summit carries a radio
after dark. The emergency contact is the site manager, reachable on channel 4 or at extension 2210
from any summit telephone. Mobile phones do not work above the kilometre 7 gate.

## Time off and overtime

Night assistants accrue one compensatory day per five nights worked. Overtime for day staff is
approved in advance by the site manager. Nobody works more than twelve consecutive nights on the
summit; after twelve nights a minimum of three nights at base is mandatory.

## Food and lodging

The summit dormitory has eight rooms. Meals are prepared by the summit cook; dietary needs are
sent to the base office at least two days before the shuttle. Alcohol is not permitted anywhere
on the summit.
