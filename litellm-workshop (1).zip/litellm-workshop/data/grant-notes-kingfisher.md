# KINGFISHER survey: grant notes

KINGFISHER (Kinematics of Nearby Galaxies with Fibre Spectroscopy on the Heron Ridge) is the
observatory's largest externally funded program.

## Award

The grant was awarded by the Northern Sky Research Council in October 2025. The award amount is
412,000 dollars over three years, from January 2026 to December 2028. The principal investigator
is Dr. Imogen Vashti of Alder Creek State University; the observatory's co-investigator is the
instrument scientist.

## What the money pays for

- 120 nights of Pelican time per year, scheduled in dark and grey time.
- One half-time night assistant for the duration of the grant.
- A replacement fibre bundle for Marlin (budgeted at 38,000 dollars, ordered March 2026).
- Travel for two team meetings per year.

## Deliverables

A first data release is due to the council by 30 June 2027 covering at least 400 galaxies. The
final data release is due with the final report in March 2029. All reduced spectra are released
publicly twelve months after the end of the observing semester in which they were taken.

## Observing rules specific to KINGFISHER

KINGFISHER targets have priority over the backup program when the seeing is better than 1.5
arcseconds. Below that seeing the night assistant may switch to the backup program after 30
minutes. All KINGFISHER exposures use the 100 micron fibre and the standard ThAr calibration
sequence.
