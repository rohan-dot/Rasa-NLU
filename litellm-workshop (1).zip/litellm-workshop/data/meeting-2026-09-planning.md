# Planning meeting, 22 September 2026

Present: site manager, site engineer, instrument scientist, both night assistants, the KINGFISHER
co-investigator. Minutes by the site manager.

## Decisions

1. A replacement CCD for the Pelican imaging camera will be purchased in the second quarter of
   2027. The budget is 96,000 dollars. The instrument scientist will circulate two quotes by
   December 2026.
2. A second full-time night assistant will be hired, starting no later than March 2027, so that
   the twelve-night rule can be kept during the KINGFISHER dark-time blocks.
3. The dome track lubrication interval stays at six weeks; the site engineer's proposal to extend
   it to eight weeks was rejected because of last winter's icing.
4. Public nights will continue in 2027 with the same capacity of 40 and the same ticket price.

## Discussion

- Winter readiness: the generator transfer test schedule introduced after the February incident has
  worked; no transfer failures since.
- Data volume: raw data grew to 1.4 TB per month after the new KINGFISHER cadence; the summit
  server has room for about eight months at that rate.
- The azimuth encoder offset on the Pelican has recurred four times since June. The site engineer
  will replace the encoder during the October gearbox oil change.

## Actions

- Site engineer: encoder replacement in October; order the dome gearbox oil.
- Instrument scientist: CCD quotes by December.
- Site manager: post the night assistant position by 15 October.
