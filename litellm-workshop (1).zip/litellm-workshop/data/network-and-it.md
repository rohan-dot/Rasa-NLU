# Network and IT notes

## The summit link

The summit is connected to the base facility by a 200 Mbit per second microwave link. The link
carries all data transfer, the telephone extensions and the weather feed. When the link is down
the summit operates on its own: observing continues, data stays on the summit server, and the
reduction still runs at its usual time.

## Remote access

Remote access to the summit network is through the base VPN at `vpn.heronridge.example`. Observers
are given a VPN account for the duration of their run. The telescope control software can be
viewed remotely but can only be driven from the control room.

## Backups

The base archive is backed up to tape every Thursday. Tapes are kept for 7 years in the base
vault and a second copy is sent off site quarterly. Summit raw data is not backed up until it
reaches the base archive, which is why raw data stays on the summit server for 60 days.

## Accounts

Every person has a personal account; shared accounts are not permitted. Passwords are changed
every 180 days. The control room workstation uses the `observer` account, which cannot log in
from anywhere except the control room console.

## Getting help

IT support is at base during working hours at extension 2240. Out of hours, the on-call engineer
can restart the summit server and the link radios but cannot restore files.
