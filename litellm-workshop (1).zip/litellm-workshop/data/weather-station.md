# Weather station

The summit weather station is a Campbell Scientific CR1000 logger with the following sensors:
wind speed and direction at 10 metres, temperature and relative humidity, barometric pressure, a
precipitation detector, and a lightning detector. The station reports every 10 seconds to the
control room display and to the telescope control software, which enforces the opening limits.

## Lightning policy

The lightning detector reports the distance to the nearest strike. The dome is closed and the
telescope parked whenever lightning is detected within 10 km. The dome stays closed until no
strike has been detected within 10 km for 30 minutes. Staff stay indoors and off the radio mast
platform during a lightning closure.

## Data

Weather data is stored on the summit file server at `/data/weather` as one CSV file per day. The
columns are timestamp, wind speed, wind direction, temperature, humidity, pressure, precipitation
flag and lightning distance. A year of data is about 35 MB.

## Sensor failures

If the humidity sensor reads a constant value for more than 15 minutes it has probably iced over.
Treat the humidity as above the limit until the reading changes. If the wind sensor fails, the dome
may be opened only with the site manager's approval and only when the forecast wind is below 30 km/h.

## Service

The sensors are cleaned monthly and the station is calibrated once a year by the supplier. The
lightning detector is tested every spring before the storm season.
