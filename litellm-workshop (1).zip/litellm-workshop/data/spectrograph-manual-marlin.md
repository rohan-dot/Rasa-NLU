# Marlin spectrograph: operating notes

Marlin is the fibre-fed echelle spectrograph mounted in the Pelican's Nasmyth room. It was built
by the Lakeshore Instrument Group and delivered in 2019.

## Specifications

- Resolving power: 18,000 at 550 nm with the standard 100 micron fibre.
- Wavelength coverage: 380 to 920 nm in a single exposure across 41 orders.
- Detector: a 2k by 4k CCD operated at minus 100 degrees Celsius. The cryocooler must run for at
  least six hours before the detector reaches operating temperature.

## Calibration

Calibration lamps are a thorium-argon (ThAr) lamp for wavelength and a quartz-halogen lamp for
flats. The ThAr lamp needs a 20 minute warm-up before its lines are stable; taking arcs earlier
than that produces wavelength solutions that drift by up to 300 m/s across the night. Take arcs at
the start and end of the night and after any change in room temperature greater than one degree.

## Fibre handling

Never bend the fibre to a radius smaller than 10 cm. The fibre head is cleaned only with the
air bulb kept in the Nasmyth room drawer. If the throughput on the standard star drops below 70
percent of the reference value, stop and call the instrument scientist.

## Common problems

- Order overlap in the red: expected above 850 nm; the pipeline handles it.
- Ghost image near order 23: caused by the cross-disperser; ignore it.
- Cryocooler alarm: the detector warms at roughly 2 degrees per minute once the cooler stops.
  Close the shutter and call the on-call engineer immediately.
