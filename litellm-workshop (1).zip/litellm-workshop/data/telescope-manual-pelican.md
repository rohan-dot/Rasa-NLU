# Pelican 1.0 m telescope: operating manual (abridged)

The Pelican is BHO's main instrument, a 1.0 metre Ritchey-Chretien reflector on an alt-azimuth
mount, commissioned in 2011. The primary mirror was last re-coated in March 2024 and the coating is
inspected every quarter during the mirror wash.

## Limits

- Slew rate: 2.5 degrees per second on both axes.
- Pointing limit: the telescope will not point below 15 degrees elevation. Attempts to do so are
  rejected by the mount controller with error code M-17.
- Dome opening wind limit: the dome may be opened only when the ten-minute average wind speed is
  below 45 km/h. The dome closes automatically if a one-minute average exceeds 60 km/h.
- Humidity: see the observing procedures. The telescope control software enforces the same limit.

## Start-up sequence

1. Confirm the weather station is live and the dome interlock light is green.
2. Power the mount controller and wait for the self-test (about 90 seconds).
3. Home both axes with `HOME ALL` from the control console.
4. Open the mirror cover only after the dome shutter is fully open.
5. Run a pointing check on a bright star before the first science target.

## Shutdown

Park the telescope at zenith, close the mirror cover, then close the dome shutter. The mount
controller is left powered overnight; it is powered off only for the weekly maintenance window.

## Known quirks

The azimuth encoder occasionally reports a 0.4 degree offset after a power interruption. A `HOME
ALL` clears it. If the offset persists, log it in the night report and do not attempt to recalibrate
the encoder yourself.
