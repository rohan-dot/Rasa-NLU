# Safety: altitude and the summit

The summit of Heron Ridge is at 3,120 metres above sea level. Everyone who works at the summit
reads this page before their first shuttle.

## Acclimatisation

Nobody works a night shift on their first 24 hours at the summit. New staff and visiting observers
arrive on the shuttle, rest, and begin work the following evening. Anyone who has been away from
the summit for more than 14 days follows the same rule.

## Symptoms

Headache, nausea, poor sleep and shortness of breath on mild exertion are common in the first day
and usually pass. A headache that gets worse, confusion, a persistent cough or breathlessness at
rest are not normal: tell the night assistant or site manager immediately. The response is always
the same: descend. The shuttle driver and the site manager can both authorise an unscheduled
descent at any hour.

## Oxygen

Bottled oxygen is kept in the control room and in the dormitory corridor. Anyone may use it. Its
use is logged so the bottles are refilled.

## Other summit hazards

- Cold: night temperatures reach minus 20 degrees in winter. The dome floor is unheated.
- Sun: UV at the summit is strong. Sunscreen and sunglasses are issued at base.
- Dehydration: drink more than you think you need; the air is very dry.
- Fatigue: the twelve-night limit in the staff handbook exists for a reason.

## Medical

A first aid kit is in the control room and a larger one in the dormitory. The nearest hospital is
in Alder Creek, 55 minutes by road from the summit.
