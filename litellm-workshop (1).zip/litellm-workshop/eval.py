"""Score a RAG script against questions.json. Works for your own rag.py and for rag_broken/rag.py.

    python eval.py rag.py                 # uses $DATA_DIR and ./questions.json
    python eval.py rag_broken/rag.py --questions questions.json --data /path/to/data

Contract the script must meet:  python <script> --data DIR --questions FILE
prints one JSON object per line with keys "question", "sources" (list of "file#chunk" strings)
and "answer" (string, or null when no model was called).

Scores: retrieval hit = the expected source file is among the returned sources;
answer hit = one of the accepted answer strings appears in the model's reply (skipped when null).
Wall time is the whole run, index build included.
"""
import argparse
import json
import os
import subprocess
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument("script")
ap.add_argument("--data", default=os.environ.get("DATA_DIR"))
ap.add_argument("--questions", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "questions.json"))
args = ap.parse_args()
if not args.data:
    sys.exit("pass --data or set DATA_DIR")

expected = json.load(open(args.questions))

t0 = time.time()
run = subprocess.run(
    [sys.executable, args.script, "--data", args.data, "--questions", args.questions],
    capture_output=True, text=True,
)
elapsed = time.time() - t0
if run.returncode != 0:
    print(run.stderr.strip()[-3000:])
    sys.exit(f"\n{args.script} crashed after {elapsed:.1f}s (exit code {run.returncode})")

results = {}
for line in run.stdout.splitlines():
    line = line.strip()
    if line.startswith("{"):
        row = json.loads(line)
        results[row["question"]] = row

ret_hits = ans_hits = ans_scored = 0
for item in expected:
    row = results.get(item["q"])
    if row is None:
        print(f"MISSING  {item['q']}")
        continue
    files = [s.split("#")[0] for s in row.get("sources", [])]
    ret_ok = item["source"] in files
    ret_hits += ret_ok
    mark = "ok  " if ret_ok else "MISS"
    ans_mark = "    "
    if row.get("answer") is not None:
        ans_scored += 1
        ans_ok = any(a.lower() in row["answer"].lower() for a in item["answers"])
        ans_hits += ans_ok
        ans_mark = "ans " if ans_ok else "WRONG"
    print(f"{mark} {ans_mark} {item['q']}")
    if not ret_ok:
        print(f"           got {files}, wanted {item['source']}")

print(f"\nretrieval {ret_hits}/{len(expected)}", end="")
if ans_scored:
    print(f"   answers {ans_hits}/{ans_scored}", end="")
else:
    print("   answers not scored (GATEWAY_URL unset, so no model was called)", end="")
print(f"   wall time {elapsed:.1f}s for {len(expected)} questions")
