# Campaign E — input-boundary harness generation (tasks 62, 63)

From the folder that holds `campaign.py` and `campaign_work/` (single-line commands, no trailing backslashes):

1. unzip -o campaign-e.zip -d .
2. git clone --depth 1 https://github.com/open-arsenal/oms-ghost-detector campaign_work/refs/oms-ghost-detector
3. python3 campaign.py --only 62,63

What lands: `src/input_boundary.py` (+ `output/input_boundaries.json` at run time), the task-35 prompt split into
boundary / non-boundary rules, round-trip seed + dict generation, tests `test_input_boundary.py` and
`test_boundary_harness_generation.py`. Gate as always: 755 baseline + the new tests, 25 known failures unchanged.

Then the proof: `python3 src/input_boundary.py --root campaign_work/refs/oms-ghost-detector` must print the 12
`handleMessage` callbacks with decoder `uci.Externalizer.read(Reader, Class<T>)` from `uci-cal-api-2.5.0gd.jar`.
If it does, Ashok runs oms-ghost-detector with NO provided harness (drop `fuzz/UciMessageFuzzer.java` from the target)
and the log must show `<Callback> (boundary harness)` — that is the test that discver did it alone.
`refs/ghost-harness/` keeps the hand-written version as the reference / fallback.

Numbering: the suite_report and local_runner tasks discussed earlier move to 64 and 65.
