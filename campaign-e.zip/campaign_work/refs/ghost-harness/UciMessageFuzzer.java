// UciMessageFuzzer.java
//
// Offline Jazzer harness for oms-ghost-detector.
//
// Place at:  <repo>/fuzz/UciMessageFuzzer.java  — DEFAULT PACKAGE on purpose:
// OSS-Fuzz-style launchers and discver's task-29 compile path address the
// harness by its bare class name (--target_class=UciMessageFuzzer).
// discver finds source harnesses by the fuzzerTestOneInput(FuzzedDataProvider)
// shape. Keep ONE public class per file, named to match the file.
//
// What it does, and why this shape:
//   The repo's runtime entry points (readers/) all need a live ActiveMQ bus,
//   which can't be driven by a fuzzer. The two layers *under* the bus can:
//     1. the XML externalizer (JAXB), reached with no bus and no config via
//        ExternalizerLoader.getExternalizer();
//     2. the 12 message processors, reached through MsgProcManager's
//        processXxx(XxxMT) methods, which is the same path the readers use.
//   So: first byte picks a message type, the rest is parsed as UCI XML, and
//   the parsed message is handed to the matching processor.
//
//   UCIException is the declared, expected failure for malformed XML and for
//   messages missing mandatory elements (several processors wrap into it on
//   purpose) — so it is caught and swallowed. EVERYTHING ELSE propagates to
//   Jazzer: that is the bug signal (NPE/ISE/OOM escaping a processor, or a
//   Jazzer sanitizer tripping inside the JAXB parse).

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

import java.io.StringReader;
import java.util.UUID;

import uci.Externalizer;
import uci.UCIException;
import uci.service.ExternalizerLoader;
import uci.types.SystemID_Type;

import uci.types.GhostDetectorActivityMT;
import uci.types.GhostDetectorCapabilityMT;
import uci.types.GhostDetectorCapabilityStatusMT;
import uci.types.GhostDetectorCommandStatusMT;
import uci.types.GhostDetectorSettingsCommandStatusMT;
import uci.types.ProductLocationMT;
import uci.types.ProductMetadataMT;
import uci.types.ServiceStatusDataRequestStatusMT;
import uci.types.ServiceStatusMT;
import uci.types.SubsystemStatusDataRequestStatusMT;
import uci.types.SubsystemStatusMT;
import uci.types.SystemStatusMT;

import com.ng.oa.monitor.processors.MsgProcManager;
import com.ng.oa.monitor.state.PlayerStates;

public class UciMessageFuzzer {

    // One externalizer for the run (ServiceLoader lookup is stateless + thread-safe here).
    // getExternalizer() throws checked UCIException, so it can't be a bare field
    // initializer — wrap it in a static block and fail fast if the service is absent.
    private static final Externalizer EXT;
    static {
        try {
            EXT = ExternalizerLoader.getExternalizer();
        } catch (UCIException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    // A fixed, bus-free system identity for the monitor under test.
    private static SystemID_Type sysId() {
        return new SystemID_Type()
                .setUUID(UUID.fromString("00000000-0000-0000-0000-000000000001"))
                .setDescriptiveLabel("fuzz");
    }

    public static void fuzzerTestOneInput(FuzzedDataProvider data) {
        int which = data.consumeByte() & 0xFF;
        String xml = data.consumeRemainingAsString();
        if (xml == null || xml.isEmpty()) {
            return;
        }

        // Fresh state + manager per input: no cross-input contamination, and the
        // manager builds all 12 processors in its constructor (no bus touched).
        SystemID_Type id = sysId();
        PlayerStates states = new PlayerStates(id);
        MsgProcManager mgr = new MsgProcManager(id, states);

        try {
            switch (which % 12) {
                case 0:
                    mgr.procesSystemStatus(EXT.read(new StringReader(xml), SystemStatusMT.class));
                    break;
                case 1:
                    mgr.processServiceStatus(EXT.read(new StringReader(xml), ServiceStatusMT.class));
                    break;
                case 2:
                    mgr.procesSubsystemStatus(EXT.read(new StringReader(xml), SubsystemStatusMT.class));
                    break;
                case 3:
                    mgr.processServiceStatusDataRequestStatus(
                            EXT.read(new StringReader(xml), ServiceStatusDataRequestStatusMT.class));
                    break;
                case 4:
                    mgr.processSubsystemStatusDataRequestStatus(
                            EXT.read(new StringReader(xml), SubsystemStatusDataRequestStatusMT.class));
                    break;
                case 5:
                    mgr.processGhostDetectorCapability(
                            EXT.read(new StringReader(xml), GhostDetectorCapabilityMT.class));
                    break;
                case 6:
                    mgr.processGhostDetectorCapabilityStatus(
                            EXT.read(new StringReader(xml), GhostDetectorCapabilityStatusMT.class));
                    break;
                case 7:
                    mgr.processGhostDetectorCommandStatus(
                            EXT.read(new StringReader(xml), GhostDetectorCommandStatusMT.class));
                    break;
                case 8:
                    mgr.processGhostDetectorActivity(
                            EXT.read(new StringReader(xml), GhostDetectorActivityMT.class));
                    break;
                case 9:
                    mgr.processProductLocation(EXT.read(new StringReader(xml), ProductLocationMT.class));
                    break;
                case 10:
                    mgr.processProductMetadata(EXT.read(new StringReader(xml), ProductMetadataMT.class));
                    break;
                case 11:
                    mgr.processGhostDetectorSettingsCommandStatus(
                            EXT.read(new StringReader(xml), GhostDetectorSettingsCommandStatusMT.class));
                    break;
            }
        } catch (UCIException expected) {
            // Declared failure for malformed XML / missing mandatory elements. Not a finding.
        }
    }

    // Smoke test: `java -cp <same classpath as the harness> UciMessageFuzzer`
    // Confirms the externalizer loads and a trivial parse round-trips with NO bus
    // and NO CALConfig — i.e. that the offline assumptions above hold on your box.
    public static void main(String[] args) throws Exception {
        System.out.println("externalizer = " + EXT.getClass().getName());
        SystemID_Type id = sysId();
        PlayerStates states = new PlayerStates(id);
        MsgProcManager mgr = new MsgProcManager(id, states);
        System.out.println("manager built: " + (mgr != null));
        try {
            mgr.procesSystemStatus(EXT.read(new StringReader("<x/>"), SystemStatusMT.class));
        } catch (UCIException e) {
            System.out.println("trivial parse rejected as expected: " + e.getMessage());
        }
        System.out.println("OK - offline path works");
    }
}
