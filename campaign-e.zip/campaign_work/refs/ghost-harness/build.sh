#!/bin/bash -eu
# build.sh for the oms-ghost-detector OSS-CRS target.
#
# Written in the OSS-Fuzz jvm convention, so it runs unchanged inside the
# base-builder-jvm image that OSS-CRS uses ($SRC, $OUT, $JAZZER_API_PATH and the
# jazzer binaries in $OUT are all provided by the image's `compile` step), and
# also works standalone on a box with JDK + Maven + an unpacked Jazzer release.
#
# Produces in $OUT:
#   UciMessageFuzzer          launcher (what OSS-CRS/discver runs; carries the
#                             LLVMFuzzerTestOneInput marker fuzz-target discovery looks for)
#   UciMessageFuzzer.class    the harness (default package)
#   app-classes.jar           the application classes (plain, not Boot-repackaged)
#   *.jar                     runtime deps incl. the vendored uci-* jars

# --- locate the project (OSS-Fuzz: /src/oms-ghost-detector; standalone: script dir)
if   [ -f "${PWD}/pom.xml" ];                       then PROJECT="$PWD"
elif [ -f "${SRC:-/nonexistent}/oms-ghost-detector/pom.xml" ]; then PROJECT="$SRC/oms-ghost-detector"
else PROJECT="$(cd "$(dirname "$0")" && pwd)"; fi
: "${OUT:=$PROJECT/out}"
mkdir -p "$OUT"
cd "$PROJECT"

# --- 1. build the app, collect runtime deps next to the launcher
# -s settings.xml -> Maven reads the repo's local-repo/ for the vendored uci-* jars.
mvn -s settings.xml -q -DskipTests clean package \
    dependency:copy-dependencies -DincludeScope=runtime -DoutputDirectory="$OUT"
# The Boot plugin repackages target/*.jar with classes under BOOT-INF/ (useless
# on a plain classpath); jar the plain classes dir ourselves.
( cd target/classes && jar cf "$OUT/app-classes.jar" . )

# --- 2. jazzer: OSS-Fuzz's `compile` already copied jazzer_driver + jazzer_agent_deploy.jar
#        into $OUT and set $JAZZER_API_PATH. Standalone: take them from $JAZZER_DIR.
if [ ! -f "$OUT/jazzer_driver" ]; then
  : "${JAZZER_DIR:?standalone build: set JAZZER_DIR to the unpacked Jazzer release}"
  cp "$JAZZER_DIR/jazzer_driver" "$JAZZER_DIR/jazzer_agent_deploy.jar" "$OUT/"
fi
JAZZER_API="${JAZZER_API_PATH:-${JAZZER_DIR:-}/jazzer_api_deploy.jar}"

# --- 3. compile the harness (default package) straight into $OUT
HARNESS_SRC="$PROJECT/fuzz/UciMessageFuzzer.java"
[ -f "$HARNESS_SRC" ] || HARNESS_SRC="$PROJECT/UciMessageFuzzer.java"
BUILD_CP="$OUT/app-classes.jar:$JAZZER_API:$(printf '%s:' "$OUT"/*.jar)"
javac -source 8 -target 8 -cp "$BUILD_CP" -d "$OUT" "$HARNESS_SRC"

# --- 4. launcher, OSS-Fuzz style. Classpath is every jar in the launcher's own
#        dir, resolved at run time, so the layout stays relocatable.
cat > "$OUT/UciMessageFuzzer" <<'EOF'
#!/bin/bash
# LLVMFuzzerTestOneInput for fuzzer detection.
this_dir=$(dirname "$0")
if [[ "$@" =~ (^| )-runs=[0-9]+($| ) ]]; then
  mem_settings='-Xmx1900m:-Xss900k'
else
  mem_settings='-Xmx2048m:-Xss1024k'
fi
cp="$this_dir"
for j in "$this_dir"/*.jar; do
  case "$j" in *jazzer_agent_deploy.jar|*jazzer_api_deploy.jar) ;; *) cp="$cp:$j" ;; esac
done
LD_LIBRARY_PATH="${JVM_LD_LIBRARY_PATH:-}":$this_dir \
"$this_dir/jazzer_driver" --agent_path="$this_dir/jazzer_agent_deploy.jar" \
  --cp="$cp" \
  --target_class=UciMessageFuzzer \
  --jvm_args="$mem_settings" \
  "$@"
EOF
chmod +x "$OUT/UciMessageFuzzer"

echo "[build] done -> $OUT/UciMessageFuzzer"
echo "[build] smoke test (no bus, no CALConfig):  java -cp \"$OUT:$OUT/app-classes.jar:$(printf '%s:' "$OUT"/*.jar)\" UciMessageFuzzer"
