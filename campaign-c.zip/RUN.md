# Campaign C — map + tasks 33–38

## Install (from /exp/FY26/AIxCC/ro31337, where campaign_work/ lives)
unzip -o campaign-c.zip                      # drops: campaign_work/tasks/00_map.md, campaign_work/tasks_auto/33..38, campaign_work/microagent.py
rm -f campaign_work/tasks_auto/*-[0-9].md    # browser duplicates like 33_…-2.md would run twice
ls campaign_work/tasks_auto/                 # must show exactly one file per number
grep -c MAX_TOKENS_CAP campaign_work/microagent.py   # 5

## Results must already be staged (done earlier)
ls campaign_work/results/latest              # orchestrator.log run/ INVENTORY.txt *_listing.txt patches/ generated_harnesses/ crashes/ unique_bugs/
head -1 campaign_work/results/latest/orchestrator.log   # 2026-10-20 16:13…

## Run (one command: map first, then the six tasks)
export LITELLM_BASE_URL=https://llai-proxy.llan.ll.mit.edu/v1 LITELLM_API_KEY=<key> AGENT_MODEL=claude-opus-5-5 AGENT_REASONING_EFFORT=high AGENT_TLS_VERIFY=false
python3 campaign_work/campaign.py --work campaign_work --tasks campaign_work/tasks --only 00 > campaign_work/map.log 2>&1 && nohup python3 campaign_work/campaign.py --work campaign_work --tasks campaign_work/tasks_auto --only 33,34,35,36,37,38 > campaign_work/campaign_c.log 2>&1 &
tail -f campaign_work/map.log                # Ctrl-C to leave tail; the campaign keeps running
# later: tail -f campaign_work/campaign_c.log ; verdicts: tail -12 campaign_work/CAMPAIGN.md

## Ship (next morning)
cd campaign_work/discver && python -m pytest -q tests | tail -3            # failed <= 17
zip -r ../../discver-src-tests-FULL.zip src tests -x '*/__pycache__/*' '*.pyc' '*/.pytest_cache/*'
cd .. && zip -j ../discver-src-tests-FULL.zip CAMPAIGN.md DIAGNOSIS.md HANDOFF.md
