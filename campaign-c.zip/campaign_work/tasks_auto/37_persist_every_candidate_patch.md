# Task 37 — a candidate patch that applied and built was thrown away: persist every attempt under /output/patches/<finding>/

## Goal
Latest run: `find <run dir> -name candidate.patch -o -name patch_index.json` on the host finds nothing. The only copy of
the patch the sidecar applied and built was `/tmp/discver_patch_cache/validation/25246c85a52278624d3a/candidate.patch`
inside the container — ephemeral — and the final summary says `Validated patches: 0 (see /output/patches); Unvalidated
patches: 0`, because a finding whose status is `failed` saves nothing. The one artifact a human needs after a failed loop
(what did the model change, what did libCRS answer) does not survive the run. Persist every attempt, pass or fail:
`/output/patches/<finding>/attempt_<iter>/` with `candidate.patch`, `build_response`, every `pov_response_*`, and
`verdict.json` (class, build_ok, crash_gone, tests_pass, reason, the sidecar argv list, timestamps), plus
`/output/patches/<finding>/latest.patch` (the last candidate). Mirror the directory to `/var/log/discver/patches/` the
same way the dedup summary is mirrored (`[persist] mirrored dedup summary to /var/log/discver/unique_bugs`). Submission
is unchanged: only a validated patch ever reaches SUBMIT_DIR.

## Study first
- Layout of `latest/` (root `results`): flat copies of the discver log dir at the top (`orchestrator.log`, `libcrs-pov.log`,
  `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the raw run directories under
  `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY file of those dirs, binaries included,
  in `latest/*_listing.txt` (size, mtime, path); the container's `/output` dirs by name (`patches/`, `povs/`,
  `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the validation cache at
  `latest/patches/validation/<id>/{candidate.patch,build_response,pov_response_*}`; a hex dump of every PoV / crash input
  (0-byte ones included) in `latest/hex/`. `latest/STAGED.md` or `latest/INVENTORY.txt` says what was staged. If a path named below is
  absent, `list_files` on `latest/` and look for it before concluding it does not exist; `latest/../prev*` is the previous run.
- results: `grep -nE "persist\]|/output/patches|patch_index|SUBMIT|Validated patches|Unvalidated patches" latest/orchestrator.log`;
  `latest/submit_dir_listing.txt` (confirms no patch was submitted — correct, nothing validated).
- repo: where validated/unvalidated patches are written today (`grep -rn "output/patches\|patch_index\|persist\]" src/`),
  the validation cache dir (`discver_patch_cache`), the accounting entry per finding (task 21), and the submit path.

## Change (src/)
- After every sidecar test (and after an apply failure, a `pov_run_failed`, an `oracle_error`): copy the attempt's files
  from the validation cache into `/output/patches/<finding>/attempt_<iter>/`, write `verdict.json`, update `latest.patch`;
  log `[persist] <finding> attempt <iter> saved → /output/patches/<finding>/attempt_<iter>/ (<class>)`.
- `patch_index.json` entries gain `attempts_dir`, `attempts_saved`, `last_candidate` (path).
- End of run: mirror `/output/patches` to `/var/log/discver/patches` (log `[persist] mirrored patches to …`), and the final
  summary prints per finding `<n> candidate(s) saved → /output/patches/<finding>/` next to the existing status line.
- Safety: wrapped; a failure to persist logs `[persist] failed: <error>` and never affects the verdict or the loop.

## Tests to add (tests/test_persist_candidate_patch.py) — temp dirs, fake sidecar results
- a failed attempt (apply error) and a `pov_run_failed` attempt → both attempt dirs exist with candidate.patch and
  verdict.json carrying the class and argv; `latest.patch` equals the last candidate.
- a validated attempt → today's validated-patch output unchanged AND the attempt dir exists; the index entry has the new
  fields; SUBMIT path called exactly as before.
- an unvalidated (never tested) finding → no attempt dir, no crash; the summary line says `0 candidate(s) saved`.
- the mirror copies the tree; a mirror failure is logged and the run result is unchanged.

## Acceptance
```
python -m pytest -q tests/test_persist_candidate_patch.py
```

## Do not touch
Sidecar argv; the submission rule (never submit an unvalidated patch); the verdict classes (task 33);
crash_dedup._get_crash_signature; anything outside src/ and tests/.
