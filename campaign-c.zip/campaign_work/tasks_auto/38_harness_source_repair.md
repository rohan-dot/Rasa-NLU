# Task 38 — a provided harness source that does not compile: one LLM repair attempt, then the normal gate

## Goal
Latest run (task 29 live): `harness-discovery: GetPrettySignatureFuzzer: compile failed:
/opt/target/src/java-project/fuzz/GetPrettySignatureFuzzer.java:37: error: incompatible types: String cannot be converted to
X509Certificate — X509Utils.getPrettySignature(sig);` → `source harnesses found: [GetPrettySignatureFuzzer, X509Fuzzer];
built by project: [X509Fuzzer]; compiled by discver: []`. The harness exists, names its target method, and is one type
error away from running. A CRS on an unknown codebase should not stop at a javac error it has the full context for:
attempt ONE repair with the runtime LLM, recompile, and if it compiles run it through the same gate as a generated
harness (reach probe + static check, fail closed), reported as `<name> (repaired by discver)`. The project tree is never
modified: the repaired source lives in discver's own generated-harness directory.

## Study first
- Layout of `latest/` (root `results`): `latest/INVENTORY.txt` lists every file; `latest/orchestrator.log` has the
  compile-failed line (`grep -n "compile failed" latest/orchestrator.log`) with the javac error and the offending line;
  `grep -i "GetPrettySignature\|X509Utils" latest/rebuild_out_listing.txt latest/INVENTORY.txt` — if the harness or
  X509Utils sources are under `latest/run/`, read them (the harness in full; `getPrettySignature`'s signature and body).
- repo: task 29's compile path (`src/harness_sources.py`: how javac is invoked, where the classpath comes from, where the
  wrapper is written); task 16's gate and task 17's static check (how a generated harness is admitted or rejected);
  the generated-harness directory; the LLM client used for harness generation (`java_harness_agent.py`) and its
  prompt helpers; the call graph API for "signature and source of method X".

## Change (src/ — new module `harness_repair.py`, one call site in the task-29 compile path)
- On a provided-source compile failure: log `harness-repair: <name>: attempting repair (javac: <file:line: message>)`.
  Prompt = the harness source, the javac errors, the signature and source of every project method the harness calls
  (from the call graph), and the rules: keep `fuzzerTestOneInput(FuzzedDataProvider)`, call the same target method(s),
  build each required argument from the fuzz data; when a parameter type is abstract or a heavyweight object
  (`X509Certificate`, streams, parsed documents), prefer a minimal subclass/stub whose getters return fuzz-derived values
  over parsing real objects from random bytes (a `CertificateFactory` parse rejects nearly every input and reaches no
  project code); catch only the specific exceptions the target method declares — never `catch (Exception)` (task 17
  rejects it); no network, files or environment.
- Write the repaired source to discver's generated-harness directory (never into the project tree), compile with the
  task-29 javac path. Success → register it like a GENERATED harness (gate: reach probe + static check, fail closed),
  display name `<name> (repaired by discver)`; log `harness-repair: <name>: compiled after repair → gated`.
  Failure → `harness-repair: <name>: repair failed: <javac tail>` and the harness is skipped exactly as today.
  One attempt per harness per run; the LLM call is counted in the run's LLM totals.
- Safety: wrapped at the call site; `[harness_repair] failed: <error>` with traceback → today's behaviour (skip).

## Tests to add (tests/test_harness_source_repair.py) — fakes only (fake javac: fail then succeed; fake LLM; fake gate)
- compile failure → the attempting line with the javac message; the fake LLM prompt contains the harness source, the
  javac error, and the target method's signature; the repaired source is written under the generated-harness dir and
  the project file's bytes are unchanged; fake javac succeeds → the gate is invoked once with the repaired harness.
- repair still fails to compile → the repair-failed line, no gate call, run continues.
- only one attempt per harness even if called twice.
- the display name carries `(repaired by discver)` in the health block.

## Acceptance
```
python -m pytest -q tests/test_harness_source_repair.py
```

## Do not touch
The project tree / the original harness file; the gate (task 16) and static check (task 17) logic; sidecar;
crash_dedup._get_crash_signature; anything outside src/ and tests/.
