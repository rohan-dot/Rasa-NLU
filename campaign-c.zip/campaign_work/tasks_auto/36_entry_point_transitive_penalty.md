# Task 36 — the top-ranked entry point is LDAP-backed through its callees: apply the network/LDAP/IO penalty transitively and show the reason

## Goal
Latest run: `harness-gen: 4 candidates ranked; top-k=[AgentUtils.printGroupMembershipsAudit(String, String, String[]) score=32, …]`
— a method that prints group memberships of an LDAP agent manager sits first, above `X509Utils.getCnFromDn(String)`
(score 14–22), and every harness generated for the top candidates had flat coverage (task 35). Task 19 specified the
penalty for "methods whose body or callees touch network / sockets / LDAP / JNDI / JDBC / HTTP clients, read credentials or
config files, or require an initialised server object"; the current implementation evidently scores the body only. Follow
the call graph (callees, depth ≤ 3) when scoring, and print the reason for every penalty so the ranking line explains itself:
`harness-gen: ranked … Class.method(params) score=<s> [penalty: calls LDAPInstance.search via getGroupMemberships]`.
Pure parsers like `getCnFromDn(String)` must end up above anything that reaches an LDAP/JNDI/network call.

## Study first
- Layout of `latest/` (root `results`): flat copies of the discver log dir at the top (`orchestrator.log`, `libcrs-pov.log`,
  `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the raw run directories under
  `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY file of those dirs, binaries included,
  in `latest/*_listing.txt` (size, mtime, path); the container's `/output` dirs by name (`patches/`, `povs/`,
  `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the validation cache at
  `latest/patches/validation/<id>/{candidate.patch,build_response,pov_response_*}`; a hex dump of every PoV / crash input
  (0-byte ones included) in `latest/hex/`. `latest/STAGED.md` or `latest/INVENTORY.txt` says what was staged. If a path named below is
  absent, `list_files` on `latest/` and look for it before concluding it does not exist; `latest/../prev*` is the previous run.
- results: the `candidates ranked` lines and the `excluded 148: […]` list in latest/orchestrator.log — note that the
  exclusion reasons are all "not public" and that no candidate shows a network/LDAP penalty.
- repo: `rank_entry_points` (task 19's module), the call-graph API used there (callees of a function, by name), and the
  list of penalised identifiers; `src/languages.py` FunctionInfo for what is available (modifiers, body, calls).

## Change (src/ — the ranking only)
- For each candidate, walk callees through the call graph up to depth 3 (visited set); a callee whose name, class or
  body matches the penalty list (LDAP/JNDI/JDBC/HTTP/socket/`InitialDirContext`/`LDAPConnection`/credentials/config
  readers) applies the penalty to the candidate with the path recorded; also penalise a method whose class has a static
  initialiser or constructor that performs such a call (the harness cannot instantiate it offline).
- Ranking line: each top-k entry carries `[penalty: <reason via path>]` or `[clean]`; the exclusion list groups by reason
  (`not public: 140, network/LDAP: 6, trivial getter: 2`) instead of one reason per name.
- Safety: wrapped; on error fall back to the current scoring with `[entry_point_penalty] failed: <error>`.

## Tests to add (tests/test_entry_point_transitive_penalty.py) — fakes only
- fake call graph: `printAudit(String, String[])` → `getMemberships` → `LDAPInstance.search` → penalised with the path in
  the reason; `getCnFromDn(String)` (no such callees) ranks above it.
- a depth-4 chain is NOT penalised (depth ≤ 3); a class with a static initialiser calling `LDAPConnection` penalises all
  its methods.
- the ranking line format and the grouped exclusion summary.

## Acceptance
```
python -m pytest -q tests/test_entry_point_transitive_penalty.py
```

## Do not touch
The gate (task 16), the static check (task 17), the generator prompt (task 35); the provided harness; sidecar;
crash_dedup._get_crash_signature; anything outside src/ and tests/.
