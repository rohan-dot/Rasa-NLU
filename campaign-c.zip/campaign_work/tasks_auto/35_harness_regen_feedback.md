# Task 35 — the generator regenerated the identical harness four times: feed the probe's real observation back, dedup, and move on to the next entry point

## Goal
Latest run (task 19 is live: `harness-gen: 4 candidates ranked; top-k=[AgentUtils.printGroupMembershipsAudit(String, String, String[]) score=32,
AgentUtils.printGroupMemberships(String[]) score=14, X509Utils.getCnFromDn(String) score=14, AgentUtils.getAgentFolderName(String, String) score=5]`),
every generated harness was still rejected: `GenFuzzer0: reach=fail (coverage_moved) … probe cov 33 flat over 1048576 execs`,
`GenFuzzer1: cov 15 flat`, `SinkFuzzer0: cov 33 flat`, `SinkFuzzer1: reach=fail (coverage_report) … cov 6 over 5118410 execs`,
and `RegenFuzzer1_0` was produced FOUR times (16:39, 16:44, 16:48, 16:52) with the same result (`cov 30 flat over 1048576
execs`) — the regeneration loop received no information that would change its output. A harness whose coverage is flat at
~30 edges over a million inputs takes the same path on every input: it returns early, or the entry point throws the same
exception before any project logic runs (static initialiser, missing LDAP/config state). Make the probe say which, give that
to the generator, never regenerate a harness whose source is identical to a rejected one, and after two rejections for the
same entry point move to the next ranked candidate instead of retrying.

## Study first
- Layout of `latest/` (root `results`): flat copies of the discver log dir at the top (`orchestrator.log`, `libcrs-pov.log`,
  `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the raw run directories under
  `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY file of those dirs, binaries included,
  in `latest/*_listing.txt` (size, mtime, path); the container's `/output` dirs by name (`patches/`, `povs/`,
  `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the validation cache at
  `latest/patches/validation/<id>/{candidate.patch,build_response,pov_response_*}`; a hex dump of every PoV / crash input
  (0-byte ones included) in `latest/hex/`. `latest/STAGED.md` or `latest/INVENTORY.txt` says what was staged. If a path named below is
  absent, `list_files` on `latest/` and look for it before concluding it does not exist; `latest/../prev*` is the previous run.
- results: `grep -nE "harness-gen|candidates ranked|reach=" latest/orchestrator.log`; `list_files latest/generated_harnesses/`
  (if present) — read two rejected sources and any probe stderr/log next to them: which entry point each targets, whether it
  catches a specific exception or returns early, and what the JVM printed on the first executions.
- repo: the probe (task 16: `harness_reach`), the regeneration feedback (task 17), the generator prompt (task 19's
  `harness_entry_points`), and how rejected harnesses are named/kept.

## Change (src/)
- Probe observation: during the reach probe, capture the harness's stderr (Jazzer prints uncaught exceptions and the first
  stack frames) and the covered-method list from the coverage report; summarise as
  `harness-gen <name>: observation: <first exception type: message @ frame | returned early (no project frames) | covered: [<methods>]>`.
- Regeneration feedback: the generator prompt for a retry contains that observation line, the rejected source, and the
  explicit instruction to change what the observation names (e.g. "the entry point throws <X> before parsing; construct the
  required state or pick a different public method of the same class").
- Dedup: hash the generated source (whitespace-normalised); a regenerated harness identical to a rejected one is dropped
  before compiling, logged `harness-gen <name>: identical to rejected <prev> — dropped`.
- Move on: two rejections for one entry point → `harness-gen: entry point <Class.method> exhausted after 2 rejections (<last reason>) — next candidate`
  and generation continues with the next ranked candidate; when the ranked list is exhausted, the existing
  `no admissible entry point` line.
- Safety: wrapped; `[harness_regen] failed: <error>` → today's behaviour.

## Tests to add (tests/test_harness_regen_feedback.py) — fakes only (fake probe runner, fake generator)
- fake probe stderr with an exception → the observation line names the exception and frame; empty stderr with no project
  frames → "returned early".
- the retry prompt contains the observation and the rejected source.
- an identical regenerated source → dropped with the log line, no compile call.
- two rejections for the same entry point → the exhausted line and the generator is next called with the next candidate;
  all candidates exhausted → `no admissible entry point`.

## Acceptance
```
python -m pytest -q tests/test_harness_regen_feedback.py
```

## Do not touch
The gate's accept/reject criteria (task 16) and the static check (task 17) — never more lenient; the provided harness;
sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
