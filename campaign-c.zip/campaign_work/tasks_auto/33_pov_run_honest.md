# Task 33 — the oracle never ran the PoV: run-pov got the 0-byte reproducer, failed with HTTP 404, and discver reported "POV STILL CRASHES"

## Goal
Latest run, finding `X509Fuzzer-9bbf8868fd92` (orchestrator.log ~:1599–1605):
`[patch] candidate patch: 1 file(s), paths relative to /opt/target/src, first=java-project/…/X509Utils.java` →
`[sidecar] cmd=['/usr/local/bin/libCRS', 'apply-patch-build', '…/25246c85a52278624d3a/candidate.patch', '…/build_response'] exit=0`
(the patch applied and built — task 28 works) →
`[sidecar] cmd=['/usr/local/bin/libCRS', 'run-pov', '/output/crashes/crash-da39a3ee5e6b4b0d3255bfef95601890afd80709', '…/pov_response_1fdcd72a7b', '--harness', 'X509Fuzzer', '--rebuild-id', '1'] exit=1 stderr_tail='Failed to run POV: 404 Client Error: Not Found for url: …'` →
`[patch-turn] iter=7 test_patch RESULT build_ok=True crash_gone=False … SIDECAR FAILURE class=pov_still_crashes`, and the agent
was told "POV STILL CRASHES after patch — the fix did not neutralize the vulnerability for every reproducer".
Nothing was run. Three defects:
1. The reproducer handed to run-pov is the 0-byte file (`da39a3ee…` is the SHA-1 of empty input). The run summary itself
   says `Crash PoVs: 3 (submittable to OSS-CRS: 1; 0-byte, dropped by libCRS: 2)` — the submittable one is `…crash-26c9d33e…`.
2. A run-pov that fails to execute (non-zero exit, "Failed to run POV" / an HTTP error, no pov_response written) is reported
   as if the PoV had been run and still crashed. The agent then chased a false verdict (iters 8–15 re-read the same three
   lines until the budget ran out) and the final report says the patch failed validation when the oracle never judged it.
3. `--rebuild-id 1`: confirm this is the id returned in `build_response` by apply-patch-build, not a default.
Fix all three. apply-patch-build's argv stays byte-identical; run-pov's argv changes only in which reproducer(s) and which
rebuild id it carries.

## Study first
- Layout of `latest/` (root `results`): flat copies of the discver log dir at the top (`orchestrator.log`, `libcrs-pov.log`,
  `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the raw run directories under
  `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY file of those dirs, binaries included,
  in `latest/*_listing.txt` (size, mtime, path); the container's `/output` dirs by name (`patches/`, `povs/`,
  `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the validation cache at
  `latest/patches/validation/<id>/{candidate.patch,build_response,pov_response_*}`; a hex dump of every PoV / crash input
  (0-byte ones included) in `latest/hex/`. `latest/STAGED.md` or `latest/INVENTORY.txt` says what was staged. If a path named below is
  absent, `list_files` on `latest/` and look for it before concluding it does not exist; `latest/../prev*` is the previous run.
- results: `grep -nE "\[sidecar\]|test_patch RESULT|SIDECAR FAILURE|candidate patch|0-byte|submittable|rebuild" latest/orchestrator.log`
  — quote the apply-patch-build and run-pov lines; `grep -n "404 Client Error" latest/orchestrator.log | cut -c1-900`
  for the URL the 404 names (it tells whether the missing resource is the rebuild or the PoV); `list_files latest/patches/`
  and read any `build_response` / `pov_response*` found there.
- results: `latest/INVENTORY.txt` (every file of the raw run, size + mtime) and `latest/rebuild_out_listing.txt` (every
  file apply-patch-build produced under REBUILD_OUT_DIR): `grep -i x509utils` it — the mtime of `X509Utils.class` against
  the apply-patch-build timestamp says whether the rebuild compiled the patched source; read any build log under
  `latest/run/REBUILD_OUT_DIR`, and if `X509Utils.java` is there read lines 70–100 and quote the guard the patch added.
  `latest/submit_dir_listing.txt` (what was submitted: the PoVs, and that no patch was). `latest/libcrs-pov.log` is 0 bytes
  — the sidecar never ran a PoV. Quote all of this in the report; if a file is missing, say so and continue.
- repo: where run-pov's argv is built — which crash file is chosen and where `--rebuild-id` comes from
  (`grep -rn "rebuild-id\|rebuild_id\|run-pov\|/output/crashes\|/output/povs" src/`); how the run summary decides
  "submittable" vs "0-byte, dropped by libCRS" (reuse that rule); `classify_sidecar_failure` (patch_generator.py ~:1843)
  and the `pov_still_crashes` mapping; how `crash_gone` is derived from run-pov's exit code vs its pov_response.

## Change (src/)
- Reproducer selection: candidates are the finding's reproducers, non-empty first; a 0-byte file is never passed to the
  sidecar — log `[patch] reproducer <name> is 0 bytes — not runnable by libCRS, skipped`. No non-empty reproducer →
  class `pov_unrunnable`: the agent is told "the oracle cannot run this finding's reproducer; no verdict", the attempt is
  not a verdict (status unvalidated, reason `pov_unrunnable`), and the final summary says so.
- Rebuild id: taken from the `build_response` of the apply-patch-build that just succeeded; log
  `[sidecar] rebuild id <id> from build_response`. No id in the response → class `oracle_error`, response head logged,
  no run-pov call. Never a literal default.
- run-pov outcome: `crash_gone` is derived ONLY from a pov_response that exists and parses. Exit≠0 with no/invalid
  pov_response, or stderr matching `Failed to run POV|Client Error|Server Error|Connection` → class `pov_run_failed`
  (oracle error): the agent receives the sidecar's real stderr (first 300 chars, including the URL); the attempt does not
  count as a test verdict; two consecutive oracle errors on one finding stop the loop with reason
  `oracle_error: <stderr head>`; the final summary then reads "patch built; PoV could not be run by libCRS (<error>)" —
  never "POV STILL CRASHES".
- Every non-empty reproducer of the finding is run (loop if the sidecar takes one per call); `crash_gone=True` only when
  all of them pass. Log once per test: `[patch] run-pov: <n> reproducer(s) (<k> skipped 0-byte), rebuild id <id>`.
- Safety: wrapped at the call site; `[pov_runner] failed: <error>` with traceback → today's behaviour.

## Tests to add (tests/test_pov_run_honest.py) — fakes only (fake sidecar runner: exit codes, stderr, response files)
- two reproducers, one 0-byte → run-pov called once, with the non-empty one; the skip line is logged; only 0-byte → `pov_unrunnable`, no call.
- fake run-pov exit=1, stderr `Failed to run POV: 404 Client Error: Not Found for url: http://x/rebuild/1/pov`, no
  pov_response → `pov_run_failed`; the agent message contains that URL; the test-verdict count is unchanged; a second
  consecutive failure → loop stops with reason `oracle_error: …`.
- fake pov_response "no crash" → crash_gone=True; "crash" → `pov_still_crashes` with the existing message (unchanged).
- build_response with id `abc` → run-pov argv carries `--rebuild-id abc`; no id → `oracle_error`, no run-pov call.
- apply-patch-build argv byte-identical to a snapshot of the current code.

## Acceptance
```
python -m pytest -q tests/test_pov_run_honest.py
```

## Do not touch
apply-patch-build argv; the diff producer (task 28); crash_dedup._get_crash_signature; verdict thresholds — never more
lenient: `crash_gone=True` still requires an actual passing pov_response; anything outside src/ and tests/.
