# Task 34 — the patch agent burned iterations 8–15 re-reading the same three lines: detect a stalled agent and give it the failing input

## Goal
Latest run, `X509Fuzzer-9bbf8868fd92`: one edit at iter 4, forced test at iter 7, then iters 8–15 were
`tool=read_source arg='…/X509Utils.java' -> 78:` / `-> 80:` eight times in a row — no edit, no test, until `max_iters=15`
ended the finding with 1 of 6 allowed test calls used. The existing nudges ("EDITED but never tested", "FORCING test_patch")
only cover an untested edit; nothing covers an agent that has stopped making progress. Two changes:
1. Stall detection: three consecutive read-only tool calls whose (tool, argument) was already seen for this finding, with
   no edit since the last test → nudge: "you have already read <list>; edit the file or call finish"; two more repeats
   after the nudge → stop the finding with reason `agent_stalled (<n> repeated reads, last edit iter <k>, last test iter <t>)`.
   The budget saved is reported in the accounting (`iters_used`, `stalled=True`).
2. After any `pov_still_crashes` verdict the next agent message carries the input that still crashes — up to 256 bytes
   as hex and printable — and the post-patch crash line when the pov_response has one, so a revision targets the failing
   input instead of re-reading the function.

## Study first
- Layout of `latest/` (root `results`): flat copies of the discver log dir at the top (`orchestrator.log`, `libcrs-pov.log`,
  `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the raw run directories under
  `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY file of those dirs, binaries included,
  in `latest/*_listing.txt` (size, mtime, path); the container's `/output` dirs by name (`patches/`, `povs/`,
  `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the validation cache at
  `latest/patches/validation/<id>/{candidate.patch,build_response,pov_response_*}`; a hex dump of every PoV / crash input
  (0-byte ones included) in `latest/hex/`. `latest/STAGED.md` or `latest/INVENTORY.txt` says what was staged. If a path named below is
  absent, `list_files` on `latest/` and look for it before concluding it does not exist; `latest/../prev*` is the previous run.
- results: `grep -nE "patch-turn\] X509Fuzzer-9bbf8868fd92 iter=" latest/orchestrator.log` — the full turn list; note the
  nudge lines at iter 5 and 7 and the repeats from iter 8.
- repo: `run_patch_agent` (patch_generator.py ~:2287) — the iteration loop, where tool calls are dispatched and logged,
  where the existing nudges are decided; the accounting fields written to `patch_index.json` (task 21).

## Change (src/)
- Keep a per-finding set of (tool, normalised argument) for read-only tools (`read_source`, `read_definition`,
  `list_files`, …); count consecutive repeats; emit `[patch-turn] <finding> iter=<i> STALL nudge: <n> repeated reads …`
  and then `[patch-turn] <finding> STOP agent_stalled …` as above. An edit or a test resets the counter.
- `pov_still_crashes` feedback: append `reproducer <name> (<len> bytes): hex=<…> text=<…>` and, when present, the
  post-patch crash location from the pov_response.
- Safety: wrapped; `[stall_guard] failed: <error>` → today's loop.

## Tests to add (tests/test_patch_agent_stall.py) — fakes only (scripted fake agent + fake tools)
- a fake agent that repeats `read_source` of the same lines → nudge on the 3rd repeat (text lists what was read), stop on
  the 5th with the reason string; accounting shows `stalled=True` and the iteration count.
- a fake agent that reads, edits, tests, reads again → no nudge, no stop (edits/tests reset the counter).
- after a fake `pov_still_crashes`, the next prompt contains the reproducer bytes (hex and text) and the crash line.

## Acceptance
```
python -m pytest -q tests/test_patch_agent_stall.py
```

## Do not touch
The sidecar invocations; the verdict classification (task 33); parse_action; crash_dedup._get_crash_signature; anything
outside src/ and tests/.
