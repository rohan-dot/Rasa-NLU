#!/usr/bin/env python3
"""
reference_fuzz_runner.py — reference implementation of "keep fuzzing productive when the target
crashes at the front door", for a Java CRS driving Jazzer/libFuzzer harnesses (OSS-Fuzz layout).

What discver's latest run shows, and which mechanism here answers it:

  primary harness: ~300 execs, coverage flat, verdict "SATURATED by a shallow crash"
      -> every execution hits the same throw and the process restarts
      -> PROBE, then a DEEP PHASE with Jazzer keep-going (stack-trace dedup)     run_harness()
  a generated harness: 27M execs, coverage 10->10
      -> no-op or uninstrumented harness burning budget                          is_noop()
  exec rate printed as 0.0/s next to millions of execs                           exec_rate()
  181 LLM seeds but corpus 0->4 on the primary harness
      -> seeds must get past the known crash and reach the corpus dir            filter_seeds()

Rules this file follows (the same rules a reviewer enforces on discver):
  * no feature flags: every decision is made from the fuzzer's own stats and logged with its cause
  * the working crash pipeline is untouched: the probe phase runs exactly like today; the deep phase
    only records LEADS; PoVs come from replaying the deep-phase corpus through the NORMAL harness,
    which produces ordinary crash artifacts for the existing dedup/PoV path
  * health verdicts get more accurate, never more lenient: HEALTHY only when coverage actually grew
  * everything external (the fuzzer process) is injected, so all of this runs under tests with fakes

Jazzer facts used here (verify against the Jazzer version inside the container image):
  * libFuzzer options are single-dash (-max_total_time, -artifact_prefix, -fork, -ignore_crashes);
    Jazzer options are double-dash (--keep_going=N) and go before the corpus directories.
  * --keep_going=N: keep fuzzing until N DISTINCT findings; findings are deduplicated by a hash of
    the stack trace, printed as "DEDUP_TOKEN: <hex>" after each "== Java Exception: ..." block.
  * Jazzer also reads options from the environment as JAZZER_<OPTION> (e.g. JAZZER_KEEP_GOING=1000)
    for drivers that do not forward command-line flags.
  * libFuzzer alternative when the harness must stay in fork mode: -fork=N -ignore_crashes=1
    (the parent keeps fuzzing while children restart; artifacts are still written).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

log = logging.getLogger("discver.fuzz")

# --- thresholds: module constants, logged at startup. Not flags: nothing here is configured by the operator.
PROBE_SECONDS = 120            # slice of the budget used to characterise a harness before deciding
SATURATION_MAX_EXECS = 5_000   # probe with fewer execs than this AND >=1 crash  -> saturated
SATURATION_CRASH_RATE = 0.5    # or crashes per execution at/above this          -> saturated
KEEP_GOING_FINDINGS = 1_000    # --keep_going=N: large, so known findings never stop the deep phase
NOOP_BUDGET_SECONDS = 300      # coverage flat since the first stats line for this long -> no-op harness
NOOP_BUDGET_EXECS = 1_000_000  # ...or for this many executions


def log_thresholds() -> None:
    log.info("fuzz thresholds: probe=%ds saturated_if_execs<%d&crash>=1 or crash_rate>=%.2f; keep_going=%d; "
             "noop_if_flat_for>=%ds or >=%d execs", PROBE_SECONDS, SATURATION_MAX_EXECS, SATURATION_CRASH_RATE,
             KEEP_GOING_FINDINGS, NOOP_BUDGET_SECONDS, NOOP_BUDGET_EXECS)


# ----------------------------------------------------------------------------- data
@dataclass
class Stats:
    """One parsed stats snapshot of a harness (from libFuzzer/Jazzer stderr: #execs, cov, elapsed)."""
    execs: int
    cov: int
    crashes: int = 0
    elapsed_s: float = 0.0


@dataclass
class RunResult:
    rc: int
    log: str
    stats: Optional[Stats]     # None for single-input replays


Runner = Callable[[List[str], int], RunResult]   # (argv, timeout_s) -> RunResult; the real one wraps subprocess


@dataclass
class LaunchSpec:
    harness: str
    driver: str                      # e.g. /out/X509Fuzzer (OSS-Fuzz Jazzer driver)
    corpus_dir: Path                 # first corpus dir = where libFuzzer WRITES new units
    seeds_dir: Optional[Path]        # read-only extra inputs (filtered LLM seeds)
    budget_s: int
    keep_going: Optional[int] = None  # None = normal mode (crash terminates the run), N = Jazzer --keep_going=N
    artifact_dir: Optional[Path] = None

    def argv(self) -> List[str]:
        args = [self.driver]
        if self.keep_going is not None:
            args.append(f"--keep_going={self.keep_going}")
        args.append(f"-max_total_time={self.budget_s}")
        if self.artifact_dir is not None:
            args.append(f"-artifact_prefix={self.artifact_dir}/")
        args.append(str(self.corpus_dir))
        if self.seeds_dir is not None:
            args.append(str(self.seeds_dir))
        return args


# ----------------------------------------------------------------------------- decisions
def exec_rate(execs: int, elapsed_s: float) -> float:
    """Executions per second. 0.0 only when no time has elapsed — and then say so, never silently."""
    if elapsed_s <= 0:
        log.warning("exec rate unavailable: elapsed_s=%r (stats parsed before the run had a timestamp?)", elapsed_s)
        return 0.0
    return execs / elapsed_s


def saturation(stats: Stats) -> "tuple[bool, str]":
    """Is the harness stuck behind a front-door crash? Decided from the probe's own numbers."""
    rate = stats.crashes / max(stats.execs, 1)
    if stats.crashes >= 1 and stats.execs < SATURATION_MAX_EXECS:
        return True, (f"probe {stats.execs} execs, {stats.crashes} crash(es), cov {stats.cov} — SATURATED "
                      f"(throws on ~every input; each restart dominates runtime)")
    if rate >= SATURATION_CRASH_RATE:
        return True, f"probe crash rate {rate:.2f}/exec over {stats.execs} execs — SATURATED"
    return False, f"probe {stats.execs} execs, {stats.crashes} crash(es), cov {stats.cov} — not saturated"


def is_noop(history: List[Stats]) -> "tuple[bool, str]":
    """A harness whose coverage never moved from its FIRST stats line after the budget is a no-op or an
    uninstrumented target. It gets stopped, with the reason, and its budget goes to the other harnesses."""
    if len(history) < 2:
        return False, "too few stats lines to judge"
    first, last = history[0], history[-1]
    if last.cov != first.cov:
        return False, f"coverage moved {first.cov}->{last.cov}"
    if last.elapsed_s >= NOOP_BUDGET_SECONDS or last.execs >= NOOP_BUDGET_EXECS:
        return True, (f"coverage flat at {first.cov} after {last.execs} execs / {last.elapsed_s:.0f}s — "
                      f"no-op or uninstrumented harness; stopped, budget released")
    return False, f"coverage flat at {first.cov} but within budget ({last.execs} execs / {last.elapsed_s:.0f}s)"


# ----------------------------------------------------------------------------- seeds
@dataclass
class SeedFilterResult:
    kept: List[Path]
    excluded: Dict[Path, str]


def filter_seeds(seeds: Iterable[Path], reproduces_known_crash: Callable[[Path], bool], harness: str) -> SeedFilterResult:
    """Keep only seeds that get PAST the known shallow crash (for a DN parser: inputs with a CN component).
    A seed that reproduces the known crash teaches the fuzzer nothing it does not already know and is
    excluded with a logged reason. Zero seeds is loud, with the reason, never silent."""
    kept: List[Path] = []
    excluded: Dict[Path, str] = {}
    for seed in seeds:
        try:
            if reproduces_known_crash(seed):
                excluded[seed] = "reproduces the known shallow crash; would not get past the front door"
                continue
        except Exception as e:  # a replay failure is a reason, not a silent drop
            excluded[seed] = f"replay failed: {e!r}"
            continue
        kept.append(seed)
    if not kept:
        reasons = "; ".join(sorted(set(excluded.values()))) or "no seeds were provided to this harness"
        log.warning("harness %s: 0 seeds wired (%d excluded: %s)", harness, len(excluded), reasons)
    else:
        log.info("harness %s: %d seeds wired, %d excluded", harness, len(kept), len(excluded))
    return SeedFilterResult(kept, excluded)


# ----------------------------------------------------------------------------- findings
_FINDING = re.compile(r"^== Java Exception: (.+)$", re.M)
_DEDUP = re.compile(r"^DEDUP_TOKEN:\s*([0-9a-fA-F]{8,})\s*$", re.M)


@dataclass
class Lead:
    token: str       # Jazzer's stack-trace hash
    headline: str    # "java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds ..."
    stack: str       # the whole finding block, for the report


def parse_leads(jazzer_log: str) -> Dict[str, Lead]:
    """Distinct findings from a keep-going run, keyed by DEDUP_TOKEN. Repeats of a token collapse to one.
    These are LEADS (no reproducing artifact is assumed); replay_corpus() turns them into real crashes."""
    leads: Dict[str, Lead] = {}
    for block in re.split(r"(?m)^(?=== Java Exception: )", jazzer_log):
        head, tok = _FINDING.search(block), _DEDUP.search(block)
        if head and tok:
            leads.setdefault(tok.group(1).lower(), Lead(tok.group(1).lower(), head.group(1).strip(), block.strip()))
    return leads


def replay_corpus(spec: LaunchSpec, runner: Runner, on_crash: Callable[[Path, str], None], timeout_s: int = 60) -> int:
    """Run every deep-phase corpus input through the harness in NORMAL mode, one input per run
    (`<driver> <file>` executes that input and exits non-zero on a crash). A crashing input is handed to
    on_crash — the EXISTING crash handler — so it becomes an ordinary crash artifact and flows through the
    unchanged dedup/PoV pipeline; the known crash collapses there, new ones become PoV-backed findings.
    (One JVM start per input; parallelise across inputs if the corpus is large, never batch them: a batched
    replay stops at the first crash, which is usually the known one.)"""
    assert spec.keep_going is None, "replay must run in normal mode"
    crashes = 0
    for inp in sorted(p for p in Path(spec.corpus_dir).iterdir() if p.is_file()):
        result = runner([spec.driver, str(inp)], timeout_s)
        if result.rc != 0:
            on_crash(inp, result.log)
            crashes += 1
    log.info("harness %s: replayed deep-phase corpus, %d crashing input(s) handed to the crash pipeline", spec.harness, crashes)
    return crashes


# ----------------------------------------------------------------------------- orchestration
@dataclass
class HarnessReport:
    harness: str
    probe: Stats
    decision: str
    sink: Optional[str] = None            # headline of the known front-door crash, from the probe log
    deep: Optional[Stats] = None
    deep_argv: List[str] = field(default_factory=list)
    leads: Dict[str, Lead] = field(default_factory=dict)
    replay_crashes: int = 0
    noop_reason: Optional[str] = None

    @property
    def verdict(self) -> str:
        """More accurate, never more lenient. HEALTHY requires coverage that actually grew."""
        if self.noop_reason:
            return f"DEAD — {self.noop_reason}"
        if self.deep is None:
            return "normal run — existing health checker decides"
        sink = self.sink or "known crash"
        if self.deep.cov > self.probe.cov:
            return (f"HEALTHY — fuzzing past known crash [{sink}]: cov {self.probe.cov}->{self.deep.cov}, "
                    f"{self.deep.execs} execs, {len(self.leads)} distinct lead(s), {self.replay_crashes} replay crash(es)")
        return (f"WEAK — saturated by [{sink}]; keep-going ran for {self.deep.execs} execs but coverage stayed at "
                f"{self.deep.cov}: seeds are not getting past the crash, or the harness is shallow")


def run_harness(spec: LaunchSpec, runner: Runner, on_crash: Callable[[Path, str], None]) -> HarnessReport:
    """Probe exactly as today; decide from the probe's numbers; if saturated, spend the rest of the budget
    in a keep-going deep phase, then replay its corpus through the normal harness for PoVs."""
    probe_spec = replace(spec, budget_s=min(PROBE_SECONDS, spec.budget_s), keep_going=None)
    log.info("harness %s: probe %ds: %s", spec.harness, probe_spec.budget_s, " ".join(probe_spec.argv()))
    probe = runner(probe_spec.argv(), probe_spec.budget_s + 60)
    if probe.stats is None:
        raise RuntimeError(f"harness {spec.harness}: probe produced no stats line — cannot decide; check the driver and stderr parsing")
    saturated, reason = saturation(probe.stats)
    first_finding = next(iter(parse_leads(probe.log).values()), None)
    report = HarnessReport(harness=spec.harness, probe=probe.stats, decision=reason,
                           sink=first_finding.headline if first_finding else None)
    remaining = max(spec.budget_s - probe_spec.budget_s, 0)
    if not saturated:
        log.info("harness %s: %s → continuing normally for %ds", spec.harness, reason, remaining)
        return report                      # remainder runs exactly as today; not modelled here
    deep_spec = replace(spec, budget_s=remaining, keep_going=KEEP_GOING_FINDINGS)
    report.deep_argv = deep_spec.argv()
    log.warning("harness %s: %s → deep phase (keep_going=%d): %s", spec.harness, reason, KEEP_GOING_FINDINGS,
                " ".join(report.deep_argv))
    deep = runner(report.deep_argv, remaining + 60)
    report.deep = deep.stats
    report.leads = parse_leads(deep.log)
    report.replay_crashes = replay_corpus(replace(spec, keep_going=None), runner, on_crash)
    log.info("harness %s: %s", spec.harness, report.verdict)
    return report


def render_health(report: HarnessReport) -> str:
    """The health block: both phases visible, the sink named, nothing hidden."""
    tag = report.verdict.split(" ")[0]
    lines = [f"[{tag}] {report.harness}",
             f"    probe: execs={report.probe.execs} @ {exec_rate(report.probe.execs, report.probe.elapsed_s):.1f}/s "
             f"cov={report.probe.cov} crashes={report.probe.crashes} — {report.decision}"]
    if report.deep is not None:
        lines.append(f"    deep (keep_going): execs={report.deep.execs} @ {exec_rate(report.deep.execs, report.deep.elapsed_s):.1f}/s "
                     f"cov {report.probe.cov}->{report.deep.cov} leads={len(report.leads)} replay_crashes={report.replay_crashes}")
        for lead in list(report.leads.values())[:5]:
            lines.append(f"      lead {lead.token}: {lead.headline}")
    lines.append(f"    verdict: {report.verdict}")
    return "\n".join(lines)
