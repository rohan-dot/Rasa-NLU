"""Tests for reference_fuzz_runner.py — plain unittest, no Jazzer, no network. Run: python3 -m unittest -v"""
import logging
import tempfile
import unittest
from pathlib import Path

import reference_fuzz_runner as r


PROBE_LOG_SATURATED = """INFO: Running with entropic power schedule (0xFF, 100).
#299\tINITED cov: 2043 ft: 2043 corp: 4/12b exec/s: 0 rss: 200Mb
== Java Exception: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1
\tat mil.disa.common.util.agentmanager.X509Utils.getCnFromDn(X509Utils.java:81)
\tat X509Fuzzer.fuzzerTestOneInput(X509Fuzzer.java:22)
DEDUP_TOKEN: 6ba0b0f9a2e2e7c1
"""

DEEP_LOG_TWO_LEADS = """#1000000\tNEW cov: 3400 ft: 5000 corp: 800/40Kb exec/s: 8000 rss: 300Mb
== Java Exception: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1
\tat mil.disa.common.util.agentmanager.X509Utils.getCnFromDn(X509Utils.java:81)
DEDUP_TOKEN: 6ba0b0f9a2e2e7c1
== Java Exception: java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1
\tat mil.disa.common.util.agentmanager.X509Utils.getCnFromDn(X509Utils.java:81)
DEDUP_TOKEN: 6ba0b0f9a2e2e7c1
== Java Exception: java.lang.NullPointerException: Cannot invoke "java.io.File.getParentFile()" because "f" is null
\tat mil.disa.common.util.agentmanager.AgentUtils.createParentDirectories(AgentUtils.java:74)
DEDUP_TOKEN: 91c4e77d0a1b2c3d
"""


class FakeRunner:
    """Answers a probe launch, a keep-going launch, and single-input replays (crash iff file name in crash_inputs)."""

    def __init__(self, probe, deep=None, crash_inputs=()):
        self.probe, self.deep, self.crash_inputs = probe, deep, set(crash_inputs)
        self.calls = []

    def __call__(self, argv, timeout_s):
        self.calls.append(list(argv))
        if len(argv) == 2 and Path(argv[1]).is_file():                    # replay of one corpus input
            return r.RunResult(1 if Path(argv[1]).name in self.crash_inputs else 0, "replay", None)
        if any(a.startswith("--keep_going=") for a in argv):
            assert self.deep is not None, "deep phase launched but the fake has no deep result"
            return self.deep
        return self.probe


def make_spec(tmp, budget=600):
    corpus = Path(tmp) / "corpus"; corpus.mkdir(exist_ok=True)
    seeds = Path(tmp) / "seeds"; seeds.mkdir(exist_ok=True)
    return r.LaunchSpec(harness="X509Fuzzer", driver="/out/X509Fuzzer", corpus_dir=corpus, seeds_dir=seeds, budget_s=budget)


class SaturationAndDeepPhase(unittest.TestCase):
    def test_saturated_probe_triggers_deep_phase_with_keep_going_and_logs_it(self):
        with tempfile.TemporaryDirectory() as tmp:
            spec = make_spec(tmp)
            runner = FakeRunner(probe=r.RunResult(1, PROBE_LOG_SATURATED, r.Stats(299, 2043, crashes=1, elapsed_s=120)),
                                deep=r.RunResult(0, DEEP_LOG_TWO_LEADS, r.Stats(1_000_000, 3400, crashes=0, elapsed_s=480)))
            crashes = []
            with self.assertLogs("discver.fuzz", level="INFO") as cm:
                rep = r.run_harness(spec, runner, on_crash=lambda p, out: crashes.append(p))
            joined = "\n".join(cm.output)
            self.assertIn("SATURATED", joined)
            self.assertIn("deep phase (keep_going=1000)", joined)
            self.assertIsNotNone(rep.deep)
            self.assertIn("--keep_going=1000", rep.deep_argv)
            self.assertIn(str(spec.corpus_dir), rep.deep_argv)        # same corpus dir
            self.assertIn(str(spec.seeds_dir), rep.deep_argv)         # same seeds dir
            self.assertLess(rep.deep_argv.index("--keep_going=1000"), rep.deep_argv.index(str(spec.corpus_dir)))
            self.assertEqual(rep.sink, "java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1")

    def test_healthy_probe_does_not_launch_deep_phase(self):
        with tempfile.TemporaryDirectory() as tmp:
            spec = make_spec(tmp)
            runner = FakeRunner(probe=r.RunResult(0, "#2000000\tNEW cov: 3417", r.Stats(2_000_000, 3417, crashes=0, elapsed_s=120)))
            rep = r.run_harness(spec, runner, on_crash=lambda p, out: None)
            self.assertIsNone(rep.deep)
            self.assertEqual(len(runner.calls), 1)
            self.assertFalse(any("--keep_going=" in a for a in runner.calls[0]))
            self.assertIn("not saturated", rep.decision)

    def test_probe_without_stats_fails_loud(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner = FakeRunner(probe=r.RunResult(1, "driver not found", None))
            with self.assertRaises(RuntimeError) as ctx:
                r.run_harness(make_spec(tmp), runner, on_crash=lambda p, out: None)
            self.assertIn("no stats line", str(ctx.exception))


class LeadsAndReplay(unittest.TestCase):
    def test_two_distinct_tokens_yield_two_leads_and_repeats_collapse(self):
        leads = r.parse_leads(DEEP_LOG_TWO_LEADS)
        self.assertEqual(set(leads), {"6ba0b0f9a2e2e7c1", "91c4e77d0a1b2c3d"})
        self.assertIn("NullPointerException", leads["91c4e77d0a1b2c3d"].headline)

    def test_same_token_twice_yields_one_lead(self):
        one = PROBE_LOG_SATURATED + PROBE_LOG_SATURATED
        self.assertEqual(len(r.parse_leads(one)), 1)

    def test_replay_hands_crashing_corpus_input_to_existing_crash_handler(self):
        with tempfile.TemporaryDirectory() as tmp:
            spec = make_spec(tmp)
            (spec.corpus_dir / "aaa").write_bytes(b"CN=ok,O=x")
            (spec.corpus_dir / "bbb").write_bytes(b"")                 # the empty input: crashes
            runner = FakeRunner(probe=None, crash_inputs={"bbb"})
            handled = []
            n = r.replay_corpus(r.LaunchSpec(**{**spec.__dict__, "keep_going": None}), runner,
                                on_crash=lambda p, out: handled.append(p.name))
            self.assertEqual(n, 1)
            self.assertEqual(handled, ["bbb"])
            self.assertTrue(all(len(c) == 2 for c in runner.calls), "replay runs one input per launch, normal mode")


class HealthVerdict(unittest.TestCase):
    def test_never_healthy_with_flat_coverage(self):
        rep = r.HarnessReport("X509Fuzzer", r.Stats(299, 2043, 1, 120), "SATURATED", sink="AIOOBE",
                              deep=r.Stats(500_000, 2043, 0, 480))
        self.assertTrue(rep.verdict.startswith("WEAK"))
        self.assertIn("coverage stayed", rep.verdict)
        self.assertIn("[WEAK] X509Fuzzer", r.render_health(rep))

    def test_healthy_only_when_coverage_grew_and_names_the_sink(self):
        rep = r.HarnessReport("X509Fuzzer", r.Stats(299, 2043, 1, 120), "SATURATED", sink="AIOOBE at X509Utils:81",
                              deep=r.Stats(1_000_000, 3400, 0, 480), replay_crashes=2)
        self.assertTrue(rep.verdict.startswith("HEALTHY"))
        self.assertIn("AIOOBE at X509Utils:81", rep.verdict)
        block = r.render_health(rep)
        self.assertIn("probe: execs=299", block)
        self.assertIn("deep (keep_going): execs=1000000", block)
        self.assertIn("cov 2043->3400", block)

    def test_noop_verdict_is_dead_with_reason(self):
        rep = r.HarnessReport("GenFuzzer0", r.Stats(27_000_000, 10, 0, 600), "not saturated", noop_reason="coverage flat at 10")
        self.assertTrue(rep.verdict.startswith("DEAD"))


class NoopAndRate(unittest.TestCase):
    def test_flat_coverage_past_budget_is_noop(self):
        hist = [r.Stats(1000, 10, 0, 5), r.Stats(27_000_000, 10, 0, 900)]
        flagged, reason = r.is_noop(hist)
        self.assertTrue(flagged)
        self.assertIn("no-op or uninstrumented", reason)

    def test_growing_coverage_is_not_noop(self):
        flagged, reason = r.is_noop([r.Stats(1000, 2063, 0, 5), r.Stats(22_000_000, 3417, 0, 900)])
        self.assertFalse(flagged)
        self.assertIn("2063->3417", reason)

    def test_flat_within_budget_is_not_yet_noop(self):
        flagged, _ = r.is_noop([r.Stats(1000, 10, 0, 5), r.Stats(5000, 10, 0, 30)])
        self.assertFalse(flagged)

    def test_exec_rate_is_execs_per_second_and_zero_is_explained(self):
        self.assertAlmostEqual(r.exec_rate(27_603_427, 3600), 7667.6, places=1)
        with self.assertLogs("discver.fuzz", level="WARNING") as cm:
            self.assertEqual(r.exec_rate(1000, 0), 0.0)
        self.assertIn("exec rate unavailable", cm.output[0])


class Seeds(unittest.TestCase):
    def test_reproducer_excluded_with_reason_and_count_logged(self):
        with tempfile.TemporaryDirectory() as tmp:
            good = Path(tmp) / "cn.txt"; good.write_bytes(b"CN=agent1,O=DISA")
            bad = Path(tmp) / "empty.txt"; bad.write_bytes(b"")
            with self.assertLogs("discver.fuzz", level="INFO") as cm:
                res = r.filter_seeds([good, bad], reproduces_known_crash=lambda p: p.read_bytes() == b"", harness="X509Fuzzer")
            self.assertEqual(res.kept, [good])
            self.assertIn("reproduces the known shallow crash", res.excluded[bad])
            self.assertIn("1 seeds wired, 1 excluded", cm.output[0])

    def test_zero_seeds_is_loud_with_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "empty.txt"; bad.write_bytes(b"")
            with self.assertLogs("discver.fuzz", level="WARNING") as cm:
                res = r.filter_seeds([bad], reproduces_known_crash=lambda p: True, harness="X509Fuzzer")
            self.assertEqual(res.kept, [])
            self.assertIn("0 seeds wired", cm.output[0])
            self.assertIn("reproduces the known shallow crash", cm.output[0])
        with self.assertLogs("discver.fuzz", level="WARNING") as cm:
            r.filter_seeds([], reproduces_known_crash=lambda p: False, harness="SinkFuzzer0")
        self.assertIn("no seeds were provided", cm.output[0])


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    unittest.main()
