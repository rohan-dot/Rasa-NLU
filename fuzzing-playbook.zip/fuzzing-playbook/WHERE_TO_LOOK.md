# Where the AIxCC finalists solved the same fuzzing problems

Both reference repos are far richer on patching than on fuzzing in their READMEs, so left to itself a research
pass drifts to patching. Point it at the fuzzing components by name and ask the questions below.

## Buttercup (Trail of Bits) — `trailofbits/afc-buttercup`
Top-level components (as published): `fuzzer/`, `seed-gen/`, `orchestrator/`, `program-model/`, `patcher/`, `common/`.
- `fuzzer/` — how libFuzzer/Jazzer are launched and supervised: flags, fork mode, corpus directories, corpus
  merging across runs, crash-artifact handling, how a harness with no coverage progress is treated.
- `seed-gen/` — LLM-driven seed generation: how seeds are produced for a harness (generator scripts vs. literal
  inputs), how they are validated, and how they are wired into the fuzzer's corpus.
- `orchestrator/` — harness selection and budget allocation across harnesses; when a harness is dropped.
Grep recipes (run inside the repo):
```
grep -rnE "keep_going|ignore_crashes|-fork|DEDUP_TOKEN|dedup" --include=*.py .
grep -rnE "corpus|merge|minimi[sz]e" --include=*.py fuzzer orchestrator | head -80
grep -rnE "seed" --include=*.py seed-gen | head -80
grep -rnE "coverage|cov:|plateau|stall" --include=*.py . | head -80
grep -rnE "dict|dictionary" --include=*.py . | head -40
```

## Atlantis (Team Atlanta) — `Team-Atlanta/aixcc-afc-atlantis`
The CRS lives under `example-crs-webservice/`; `example-crs-architecture/` holds infrastructure. Inside the webservice
directory, list the subdirectories and find the Java CRS (Atlantis-Java — directory names are along the lines of
`crs-java` and `crs-multilang`; confirm with `ls`). Look there for: LLM seed generation for Java harnesses, LLM
dictionary generation, sink-directed fuzzing, a customised Jazzer, and how they keep fuzzing past known findings.
Grep recipes:
```
ls example-crs-webservice
grep -rnE "keep_going|ignore_crashes|-fork|DEDUP_TOKEN|dedup" --include=*.py --include=*.java --include=*.sh example-crs-webservice | head -80
grep -rnE "deepgen|dictgen|dictionary|seed" --include=*.py --include=*.java -l example-crs-webservice | head -60
grep -rnE "corpus" --include=*.py --include=*.sh -l example-crs-webservice | head -60
grep -rnE "jacoco|coverage" --include=*.py --include=*.java -l example-crs-webservice | head -60
```

## Questions to answer for each repo (mechanism + file:line, then a one-cycle port for discver)
1. How are initial seeds generated for a Java harness, and how do they reach the fuzzer's corpus directory?
2. How is a corpus managed across runs (merge, minimise, reuse), and what is the directory layout?
3. How does fuzzing continue after a known crash — keep-going, crash suppression, corpus seeded past it, or patch-and-continue?
4. How are harnesses selected and ranked, and when is a harness with no coverage progress dropped?
5. Are dictionaries generated (LLM or static), and how are they passed to the fuzzer?
6. How are coverage plateaus detected and what is done about them?
7. How are exec rate and coverage parsed from the fuzzer's output, and how do they feed a health verdict?
For every mechanism: separate what transfers to discver (single node, no Kubernetes, zero-configuration container)
from what does not; note each repo's license before recommending verbatim reuse.

## Other finalist CRSs (public archives, optional further references)
Shellphish/Artiphishell — github.com/shellphish/artiphishell (tag `Finals`); Theori — github.com/theori-io/aixcc-afc-archive;
"All You Need Is A Fuzzing Brain" — github.com/o2lab/afc-crs-all-you-need-is-a-fuzzing-brain (fuzzing-centric by design);
42-b3yond-6ug — github.com/42-b3yond-6ug/42-b3yond-6ug-crs; Lacrosse — github.com/siftech/afc-crs-lacrosse.
