# Fuzzing & Coverage Playbook — what "good" looks like for discver (reference)

This directory is a reference for the team improving discver. It is not competitor code; it is the
specification of the fuzzing behaviour discver must reach, a tested reference implementation of the
mechanisms it lacks (`reference_fuzz_runner.py`, `test_reference_fuzz_runner.py`), and a map of where the
AIxCC finalists solved the same problems (`WHERE_TO_LOOK.md`).

**For the research engineer:** the section "Findings to hand to the manager" is already shaped as findings.
Hand them over in that order. **For the manager:** fuzzing is upstream of patching — a patch can only be
validated for a PoV-backed crash, PoV-backed crashes come from fuzzing, and discver's primary harness
currently executes a few hundred inputs per run. Deeper fuzzing is the precondition for more validated
patches, so the fuzzing findings are delegated and merged before patching work.

## Evidence from discver's latest run (verify in the results directory before planning)

- Primary harness `X509Fuzzer`: WEAK — a few hundred executions, coverage flat from its first stats line
  (2043→2043), corpus 0→4, health-checker verdict "SATURATED by a shallow crash (throws on ~every input;
  each fork restart dominates runtime)". `SinkFuzzer0` shows the same. The crash is real and reproduced
  (`X509Utils.getCnFromDn`, index-out-of-bounds; the PoV is the empty input). The target crashes at the
  front door and every crash terminates the process, so the fuzzer never gets past it.
- `GenFuzzer0`: ~27M executions with coverage 10→10 — a no-op or uninstrumented harness burning budget.
- Every harness prints an execution rate of `0.0/s` next to millions of executions — the rate calculation is wrong.
- `GenFuzzer1` / `SinkFuzzer1`: HEALTHY (2063→3417) — the fuzzer goes deep once the front door is open.
- 181 LLM-generated seeds, but corpus 0→4 on the primary harness: it is not established that seeds reach it,
  or that any of them get past the known crash.

## Target state — the next run's health block is the judge

1. The primary harness executes millions of inputs, not hundreds, and its coverage grows well past its first stats line.
2. The known shallow crash is reported exactly once, with its PoV; the fuzzer keeps going past it; any new
   distinct crash found past it gets a PoV through the existing pipeline.
3. Seeds for the primary harness include inputs that do not trigger the known crash and reach its corpus
   directory before launch; seed count per harness is logged, with the specific reason when it is zero.
4. A harness whose coverage never moves from its first stats line is flagged and stopped within minutes, with the reason.
5. The execution rate is correct and does not feed the DEAD/WEAK verdict.
6. Verdicts are more accurate, never more lenient: "saturated by <sink>; continuing past it — coverage
   growing"; HEALTHY only when coverage actually grew.

## Findings to hand to the manager, in order

**F1 — Probe, then deep phase with Jazzer keep-going (decides the run).**
Mechanism: run each harness as today for a short probe; decide saturation from the probe's own numbers
(few execs + a crash, or crash rate ≥ 0.5/exec); if saturated, spend the rest of the budget relaunched with
`--keep_going=N` (Jazzer deduplicates findings by stack-trace hash and continues; large N so known findings never
stop it), same corpus and seed dirs. Deep-phase findings are parsed from the log (`== Java Exception:` block +
`DEDUP_TOKEN:`) as *leads*; at the end, every deep-phase corpus input is replayed one-by-one through the
normal harness so crashing inputs become ordinary crash artifacts in the unchanged dedup/PoV pipeline.
Reference: `run_harness`, `saturation`, `parse_leads`, `replay_corpus`, `LaunchSpec.argv` (Jazzer `--` flags before
the corpus dirs; libFuzzer `-` flags). Alternative when the harness must stay in fork mode: `-fork=N -ignore_crashes=1`.
In discver: find where the fuzzer command line is built (search `src/` for `jazzer`, `-fork`, `-max_total_time`,
`artifact_prefix`, the per-harness run directory, and the stats-line parser); if the command is built by an
OSS-CRS run script outside `src/`, the change is the options discver passes to it — and still ships in `src/`.
Verify the Jazzer inside the container accepts `--keep_going` (or `JAZZER_KEEP_GOING` in the environment);
log the exact flag at launch. Acceptance tests: as in `test_reference_fuzz_runner.py` (saturated probe → deep phase
with the exact log line; healthy probe → not; argv contains the flag and the same dirs; two tokens → two leads,
repeats collapse; replay hands the crashing input to the existing handler).

**F2 — Seeds that get past the crash.** Property-based seeds for the primary harness must include inputs
that do not trigger the known crash (for this target: DN strings with a `CN=` component and other well-formed
variants); exclude seeds that reproduce the known crash, with a logged reason; log the count per harness and
the reason when zero; confirm the seeds land in the directory the runner actually reads before launch.
Reference: `filter_seeds`. In discver: `src/pb_seeds.py` and the seed-wiring code (`DISCVER_WIRE_SEEDS` history).

**F3 — No-op harness detection.** Coverage unchanged from the first stats line after a fixed budget → flag
"no-op or uninstrumented", stop it, release its budget, say so in the health block. Reference: `is_noop`, applied
by the loop that polls stats lines. In discver: the stats parser / health checker.

**F4 — Execution rate.** execs ÷ elapsed seconds; `0.0` only when no time elapsed, and then logged as such.
Confirm the rate does not feed the DEAD/WEAK verdict. Reference: `exec_rate`.

**F5 — Truthful two-phase health block.** Probe and deep phase both visible, sink named, HEALTHY only on
real growth. Reference: `HarnessReport.verdict`, `render_health`.

Minimum to finish the fuzzing track: F1 and F2 merged with tests, plus at least one of F3–F5.

## Non-negotiables (the reviewer blocks any violation)

- No feature flags or environment switches for the operator; discver auto-detects and logs the path it chose at startup.
- Fail loud with a specific cause: no silent skip, no bare `except`, no `continue` on a failure without a log line carrying the raw data.
- Health verdicts become more accurate, never more lenient.
- Never modify target source. Do not modify the PoV replay oracle (`crash_dedup._get_crash_signature`) or the builder-sidecar wiring.
- One behavioural change per item, with a test that runs locally with fakes (no container, no network), and a log line naming the cause on every failure path.
- Never claim an outcome you did not run and see in a tool output.
- The final report must contain a section titled **FUZZING & COVERAGE**: changes shipped (files, tests), the exact
  startup log line and first stats lines the operator should see in the first five minutes of the next run, and
  expected before/after numbers for the primary harness. "Fuzzing needs no change" is accepted only with the
  health-block lines quoted that show every harness HEALTHY.

## What the operator looks for in the first five minutes of the next run

- Startup: `harness X509Fuzzer: probe … — SATURATED … → deep phase (keep_going=1000): /out/X509Fuzzer --keep_going=1000 -max_total_time=…`
- Then stats lines whose `#execs` climb into the tens of thousands within minutes, with `cov:` moving.
- If executions stay in the hundreds after that line, the flag did not reach Jazzer: check how the driver forwards
  arguments and use the environment form.
- Grep: `grep -nE "deep phase|keep_going|SATURATED|seeds wired|no-op" orchestrator.log`

## About the reference implementation

`reference_fuzz_runner.py` is a design reference with an injected runner; its 15 tests pass with fakes
(`python3 -m unittest -v`). It has not been run against a real Jazzer; the flag names and log formats are the
documented Jazzer/libFuzzer ones and must be confirmed against the Jazzer version in discver's container image.
Port the mechanisms into discver's own modules; do not copy this file in as a new subsystem.
