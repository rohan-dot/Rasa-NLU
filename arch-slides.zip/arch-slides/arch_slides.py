#!/usr/bin/env python3
"""Architecture walkthrough for discver: overview -> one slide per stage -> assembled picture.
White background, navy titles, same box language as the main deck (gray deterministic, teal model-driven, dashed external).
Shapes are plain PowerPoint shapes: select-all on a slide, copy, paste into the lab template.
    pip install python-pptx && python3 arch_slides.py discver-architecture.pptx
"""
from __future__ import annotations

import sys
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

NAVY = RGBColor(0x1F, 0x2F, 0x5F)
INK = RGBColor(0x1F, 0x24, 0x30)
PAPER = RGBColor(0xFF, 0xFF, 0xFF)
SURFACE = RGBColor(0xF2, 0xF4, 0xF7)
LINE = RGBColor(0xC9, 0xCF, 0xD8)
MUTED = RGBColor(0x6B, 0x72, 0x80)
ACCENT = RGBColor(0xD7, 0x26, 0x3D)
TEAL = RGBColor(0x1B, 0x99, 0x8B)
TEAL_LIGHT = RGBColor(0xDC, 0xF2, 0xEE)
BAND = RGBColor(0xF7, 0xF8, 0xFA)
FONT = "Calibri"
W, H, M = 13.333, 7.5, 0.6
STAGES = ["Understand", "Make fuzzable", "Fuzz", "Decide", "Submit"]

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(W), Inches(H)
BLANK = prs.slide_layouts[6]


# ----------------------------------------------------------------------------- primitives
def text(sl, x, y, w, h, s, size=14, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, italic=False, fill=None):
    tb = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Inches(0.02)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = s
    r.font.size, r.font.bold, r.font.italic, r.font.name = Pt(size), bold, italic, FONT
    r.font.color.rgb = color
    if fill is not None:
        tb.fill.solid()
        tb.fill.fore_color.rgb = fill
    return tb


def box(sl, x, y, w, h, fill=SURFACE, line=LINE, dash=None, radius=0.1, shape=MSO_SHAPE.ROUNDED_RECTANGLE, lw=1.25):
    sh = sl.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    sh.shadow.inherit = False
    if fill is None:
        sh.fill.background()
    else:
        sh.fill.solid()
        sh.fill.fore_color.rgb = fill
    if line is None:
        sh.line.fill.background()
    else:
        sh.line.color.rgb = line
        sh.line.width = Pt(lw)
        if dash:
            sh.line.dash_style = dash
    if shape == MSO_SHAPE.ROUNDED_RECTANGLE:
        sh.adjustments[0] = radius
    tf = sh.text_frame
    tf.margin_left = tf.margin_right = Inches(0.1)
    tf.margin_top = tf.margin_bottom = Inches(0.05)
    return sh


def label(sh, s, size=13, bold=True, color=INK, sub=None, sub_size=10, sub_color=MUTED, align=PP_ALIGN.CENTER):
    tf = sh.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = s
    r.font.size, r.font.bold, r.font.name = Pt(size), bold, FONT
    r.font.color.rgb = color
    if sub:
        p2 = tf.add_paragraph()
        p2.alignment = align
        r2 = p2.add_run()
        r2.text = sub
        r2.font.size, r2.font.name = Pt(sub_size), FONT
        r2.font.color.rgb = sub_color


KINDS = {"det": (SURFACE, LINE, None), "llm": (TEAL_LIGHT, TEAL, None), "ext": (PAPER, MUTED, MSO_LINE_DASH_STYLE.DASH),
         "gate": (PAPER, ACCENT, None), "out": (NAVY, NAVY, None)}


def node(sl, x, y, w, h, s, sub=None, kind="det", size=13):
    fill, line, dash = KINDS[kind]
    sh = box(sl, x, y, w, h, fill=fill, line=line, dash=dash, lw=1.75 if kind == "gate" else 1.25)
    label(sh, s, size=size, color=PAPER if kind == "out" else INK, sub=sub, sub_color=LINE if kind == "out" else MUTED)
    return sh


def arrow(sl, x1, y1, x2, y2, color=MUTED, dashed=False, width=1.5, head=True):
    c = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    c.line.color.rgb = color
    c.line.width = Pt(width)
    if dashed:
        c.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    if head:
        ln = c.line._get_or_add_ln()
        ln.append(ln.makeelement(qn("a:tailEnd"), {"type": "triangle", "w": "med", "len": "med"}))
    return c


def poly(sl, pts, color=ACCENT, dashed=True, width=1.5):
    for (a, b) in zip(pts, pts[1:]):
        arrow(sl, a[0], a[1], b[0], b[1], color=color, dashed=dashed, width=width, head=(b is pts[-1]))


def chip(sl, cx, cy, s, color=MUTED, size=10):
    w = min(3.2, 0.075 * len(s) + 0.3)
    text(sl, cx - w / 2, cy - 0.14, w, 0.28, s, size=size, color=color, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, fill=PAPER)


def title(sl, s, sub=None):
    text(sl, M, 0.35, W - 2 * M, 0.7, s, size=30, bold=True, color=NAVY, anchor=MSO_ANCHOR.MIDDLE)
    if sub:
        text(sl, M, 1.0, W - 2 * M, 0.4, sub, size=14, color=MUTED, italic=True)


def breadcrumb(sl, current: int, y=1.5):
    """The five stages as a strip; the current one filled navy. current is 1-based; 0 = none highlighted."""
    n = len(STAGES)
    gap, bw, bh = 0.25, (W - 2 * M - 0.25 * (n - 1)) / n, 0.42
    for i, s in enumerate(STAGES, 1):
        x = M + (i - 1) * (bw + gap)
        on = i == current
        sh = box(sl, x, y, bw, bh, fill=NAVY if on else PAPER, line=NAVY if on else LINE, radius=0.3)
        label(sh, f"{i}  {s}", size=12, bold=on, color=PAPER if on else MUTED)
        if i < n:
            arrow(sl, x + bw + 0.03, y + bh / 2, x + bw + gap - 0.03, y + bh / 2, color=LINE, width=1.25)


def output_bar(sl, items: str, y=6.15):
    sh = box(sl, M, y, W - 2 * M, 0.62, fill=NAVY, line=None, radius=0.15)
    tf = sh.text_frame
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    r0 = p.add_run()
    r0.text = "Hands to the next stage:  "
    r0.font.size, r0.font.bold, r0.font.name = Pt(13), True, FONT
    r0.font.color.rgb = LINE
    r1 = p.add_run()
    r1.text = items
    r1.font.size, r1.font.name = Pt(13), FONT
    r1.font.color.rgb = PAPER


def legend(sl, y=6.95, feedback=True, gate=False):
    x = M
    for k, lab in (("det", "deterministic"), ("llm", "model-driven"), ("ext", "outside discver (OSS-CRS / target)")):
        fill, line, dash = KINDS[k]
        box(sl, x, y, 0.32, 0.22, fill=fill, line=line, dash=dash)
        text(sl, x + 0.4, y - 0.04, 2.6, 0.3, lab, size=10, color=MUTED)
        x += 2.9
    if gate:
        box(sl, x, y, 0.32, 0.22, fill=PAPER, line=ACCENT, lw=1.75)
        text(sl, x + 0.4, y - 0.04, 2.0, 0.3, "gate (fail closed)", size=10, color=MUTED)
        x += 2.2
    if feedback:
        arrow(sl, x, y + 0.11, x + 0.32, y + 0.11, color=ACCENT, dashed=True)
        text(sl, x + 0.4, y - 0.04, 2.4, 0.3, "feedback loop", size=10, color=MUTED)


def notes(sl, s):
    sl.notes_slide.notes_text_frame.text = s


def new():
    sl = prs.slides.add_slide(BLANK)
    sl.background.fill.solid()
    sl.background.fill.fore_color.rgb = PAPER
    return sl



def elbow(sl, a, b, via_x, color=MUTED, dashed=False):
    """a -> (via_x, a.y) -> (via_x, b.y) -> b, arrowhead only on the last segment."""
    (x1, y1), (x2, y2) = a, b
    poly(sl, [(x1, y1), (via_x, y1), (via_x, y2), (x2, y2)], color=color, dashed=dashed)


def rmid(sh):  # right-middle of a shape, in inches
    return sh.left / 914400 + sh.width / 914400, sh.top / 914400 + sh.height / 914400 / 2


def lmid(sh):
    return sh.left / 914400, sh.top / 914400 + sh.height / 914400 / 2


def tmid(sh):
    return sh.left / 914400 + sh.width / 914400 / 2, sh.top / 914400


def bmid(sh):
    return sh.left / 914400 + sh.width / 914400 / 2, sh.top / 914400 + sh.height / 914400


# ----------------------------------------------------------------------------- slide 1: the loop
sl = new()
title(sl, "discver in five stages", "Everything downstream exists to turn a crash into a submittable finding under a fixed budget")
ext_w, gap, y0, bh = 1.5, 0.35, 2.7, 1.35
bw = (W - 2 * M - 2 * ext_w - 2 * 0.45 - gap * 4) / 5
subs = ["language · call graph · diff · KB plan", "find, rank, write, gate harnesses", "libFuzzer / Jazzer + health",
        "dedup · KB-grounded triage · arbiter", "evidence labels · confidence tiers"]
xs, x = [], M + ext_w + 0.45
for i, (s, sub) in enumerate(zip(STAGES, subs), 1):
    node(sl, x, y0, bw, bh, f"{i}  {s}", sub=sub, kind="llm" if i in (2, 4) else "det", size=14)
    xs.append(x)
    if i < 5:
        arrow(sl, x + bw + 0.04, y0 + bh / 2, x + bw + gap - 0.04, y0 + bh / 2, color=MUTED, width=2)
    x += bw + gap
node(sl, M, y0 - 0.1, ext_w, bh + 0.2, "OSS-CRS task", sub="source · build · harnesses · diff", kind="ext", size=12)
arrow(sl, M + ext_w + 0.04, y0 + bh / 2, xs[0] - 0.04, y0 + bh / 2, color=MUTED, width=2)
node(sl, W - M - ext_w, y0 - 0.1, ext_w, bh + 0.2, "OSS-CRS submission", sub="PoVs + evidence", kind="ext", size=12)
arrow(sl, xs[-1] + bw + 0.04, y0 + bh / 2, W - M - ext_w - 0.04, y0 + bh / 2, color=MUTED, width=2)
kb_y = y0 + bh + 0.9
node(sl, xs[0], kb_y, xs[3] + bw - xs[0], 0.8, "Knowledge base — compiled offline, read-only at run time",
     sub="4,100 OSS-Fuzz vulnerability recipes · 4,993 ARVO reproducible bugs · 37 CWE playbooks", kind="det", size=13)
arrow(sl, xs[0] + bw / 2, kb_y, xs[0] + bw / 2, y0 + bh + 0.04)
arrow(sl, xs[3] + bw / 2, kb_y, xs[3] + bw / 2, y0 + bh + 0.04)
chip(sl, xs[0] + bw / 2 + 0.7, kb_y - 0.45, "strategy plan")
chip(sl, xs[3] + bw / 2 + 0.8, kb_y - 0.45, "similar past bugs")
top = y0 - 0.5
poly(sl, [(xs[2] + bw / 2, y0), (xs[2] + bw / 2, top), (xs[1] + bw / 2, top), (xs[1] + bw / 2, y0 - 0.04)])
chip(sl, (xs[1] + xs[2] + bw) / 2, top, "flat coverage → regenerate harness", color=ACCENT)
text(sl, M, kb_y + 1.05, W - 2 * M, 0.6,
     "Two model-driven stages, three deterministic ones. A model proposes; evidence decides — a harness must prove reach before it fuzzes, "
     "a finding must carry a reproducer or a confidence label before it is submitted.", size=13)
legend(sl)
notes(sl, "Say: five stages, left to right, one pass per task. Teal stages are where a language model is consulted; everything else is "
          "deterministic. The knowledge base is compiled offline and only read at run time — it informs the plan at stage 1 and the triage at "
          "stage 4. One loop worth pointing at: if fuzzing shows flat coverage, the harness goes back to stage 2 and is rewritten. "
          "Patching is a downstream stage after Submit and is not covered today.")

# ----------------------------------------------------------------------------- slide 2: understand
sl = new()
title(sl, "Stage 1 — Understand the target", "Before any fuzzer starts: what language, what code, what changed, and what history says to look for")
breadcrumb(sl, 1)
yA, hA = 2.3, 0.85
ix, iw = M, 2.0
mx, mw = 3.2, 2.6
kx, kw = 6.4, 2.5
ox = 9.5
ow = W - M - ox
i1 = node(sl, ix, yA, iw, hA, "Source tree", kind="ext")
i2 = node(sl, ix, yA + 1.1, iw, hA, "Build + harnesses", sub="provided by the project", kind="ext")
i3 = node(sl, ix, yA + 2.2, iw, hA, "Diff", sub="delta tasks only", kind="ext")
n1 = node(sl, mx, yA, mw, hA, "Language adapter", sub="src/lang — C/C++ · Go · Rust · Python · Java")
n2 = node(sl, mx, yA + 1.1, mw, hA, "Call graph + entry points", sub="public, reachable, argument shapes")
n3 = node(sl, mx, yA + 2.2, mw, hA, "Delta map", sub="functions the diff touches")
for a, b in ((i1, n1), (i2, n2), (i3, n3)):
    arrow(sl, rmid(a)[0] + 0.04, rmid(a)[1], lmid(b)[0] - 0.04, lmid(b)[1])
arrow(sl, bmid(n1)[0], bmid(n1)[1] + 0.02, tmid(n2)[0], tmid(n2)[1] - 0.04)
arrow(sl, bmid(n2)[0], bmid(n2)[1] + 0.02, tmid(n3)[0], tmid(n3)[1] - 0.04)
kb2 = node(sl, kx, yA + 0.15, kw, 1.1, "Knowledge base", sub="4,100 OSS-Fuzz recipes · 4,993 ARVO records · 37 CWE playbooks")
plan = node(sl, kx, yA + 1.95, kw, 1.1, "Strategy plan", sub="strategy_phase.py — retrieval by language, idioms, crash tokens", kind="llm")
arrow(sl, bmid(kb2)[0], bmid(kb2)[1] + 0.02, tmid(plan)[0], tmid(plan)[1] - 0.04)
arrow(sl, rmid(n2)[0] + 0.04, rmid(n2)[1], lmid(plan)[0] - 0.04, lmid(plan)[1] - 0.25)
arrow(sl, rmid(n3)[0] + 0.04, rmid(n3)[1], lmid(plan)[0] - 0.04, lmid(plan)[1] + 0.25)
card = box(sl, ox, yA, ow, 3.05, fill=PAPER, line=NAVY, lw=1.5)
text(sl, ox + 0.2, yA + 0.12, ow - 0.4, 0.4, "The plan", size=15, bold=True, color=NAVY)
text(sl, ox + 0.2, yA + 0.55, ow - 0.4, 2.4,
     "• target language and toolchain\n• ranked entry points to harness\n• bug classes to expect, from similar past projects\n"
     "• budget split — diff-reaching harnesses first in delta mode\n• which static scanners to run", size=12)
arrow(sl, rmid(plan)[0] + 0.04, rmid(plan)[1], ox - 0.04, yA + 1.5)
output_bar(sl, "a strategy plan (strategy_plan.json): ranked targets, expected bug classes, budget shares — nothing has been fuzzed yet")
legend(sl, feedback=False)
notes(sl, "Say: stage 1 is cheap and deterministic except for the plan. The adapter picks the language from the OSS-Fuzz metadata or a "
          "file census; the call graph gives entry points; if the task has a diff, the delta map finds the functions it touches. "
          "The knowledge base is queried once for projects and crashes that look like this one, and the result is a plan: what to harness "
          "first, what bug classes to expect, how to split the budget.")

# ----------------------------------------------------------------------------- slide 3: make fuzzable
sl = new()
title(sl, "Stage 2 — Make it fuzzable", "A harness is a hypothesis about how to reach the code; it earns the right to fuzz")
breadcrumb(sl, 2)
yB, yC, nw, ng = 2.35, 3.95, 2.3, 0.45
p1 = node(sl, M, yB, nw, 0.9, "Provided harnesses", sub="shipped by the project", kind="ext")
p2 = node(sl, M + nw + ng, yB, nw, 0.9, "Compile · repair", sub="one model repair on a javac error", kind="llm")
arrow(sl, rmid(p1)[0] + 0.04, rmid(p1)[1], lmid(p2)[0] - 0.04, lmid(p2)[1])
g1 = node(sl, M, yC, nw, 0.9, "Entry-point ranking", sub="public, bytes-in parsers first")
g2 = node(sl, M + nw + ng, yC, nw, 0.9, "Penalties, transitively", sub="network · LDAP · JNDI · live server")
g3 = node(sl, M + 2 * (nw + ng), yC, nw, 0.9, "Harness generator", sub="writes it; rewrites on flat coverage", kind="llm")
arrow(sl, rmid(g1)[0] + 0.04, rmid(g1)[1], lmid(g2)[0] - 0.04, lmid(g2)[1])
arrow(sl, rmid(g2)[0] + 0.04, rmid(g2)[1], lmid(g3)[0] - 0.04, lmid(g3)[1])
gx, gw, gy, gh = 9.0, 1.2, yB - 0.1, 2.9
gate = node(sl, gx, gy, gw, gh, "GATE", sub="reach probe\n+\nstatic check\n\nfail closed", kind="gate", size=14)
arrow(sl, rmid(p2)[0] + 0.04, rmid(p2)[1], gx - 0.04, yB + 0.55)
arrow(sl, rmid(g3)[0] + 0.04, rmid(g3)[1], gx - 0.04, yC + 0.35)
ax = gx + gw + 0.45
aw = W - M - ax
adm = node(sl, ax, gy + 0.75, aw, 1.4, "Admitted harnesses", sub="each proved it reaches project code", kind="out", size=14)
arrow(sl, gx + gw + 0.04, gy + gh / 2, ax - 0.04, gy + gh / 2)
text(sl, gx - 1.0, gy + gh + 0.1, gw + 2.0, 0.3, "rejected → never fuzzed, reason logged", size=11, color=ACCENT, align=PP_ALIGN.CENTER, italic=True)
arrow(sl, gx + gw / 2, gy + gh + 0.02, gx + gw / 2, gy + gh + 0.1, color=ACCENT)
fy = 5.85
poly(sl, [(W - M, fy), (bmid(g3)[0], fy), (bmid(g3)[0], bmid(g3)[1] + 0.04)])
chip(sl, bmid(g3)[0] + 1.9, fy, "from stage 3: flat coverage → regenerate", color=ACCENT)
output_bar(sl, "admitted harnesses with their build/classpath, seeds and dictionaries — and a log line for every rejected one")
legend(sl, gate=True)
notes(sl, "Say: two ways to get a harness. If the project ships one, compile it — and if javac fails, let the model fix it once. If not, "
          "rank the public entry points: parsers that take bytes or strings score high; anything that needs a network, a directory server or "
          "a live server object is penalised, following callees three levels deep. The model writes a harness for the top candidates. "
          "Nothing fuzzes until it passes the gate: a reach probe shows it actually executes project code, and a static check rejects "
          "catch-alls and other cheats. Fail closed — a rejected harness is logged, not run.")

# ----------------------------------------------------------------------------- slide 4: fuzz
sl = new()
title(sl, "Stage 3 — Fuzz with eyes open", "Run the engines, watch each harness, spend the budget where the plan says")
breadcrumb(sl, 3)
yD = 2.55
c0, c1x, c2x, ox = M, 3.6, 7.4, 11.0
w0, w1, w2 = 2.4, 3.2, 3.0
ow = W - M - ox
h1 = node(sl, c0, yD, w0, 1.0, "Admitted harnesses", sub="from stage 2", kind="out")
runners = node(sl, c1x, yD, w1, 1.0, "Runners", sub="libFuzzer (C/C++/Rust) · Jazzer (Java) · atheris (Python)")
seeds = node(sl, c1x, yD + 1.3, w1, 0.85, "Seeds + dictionaries", sub="project corpus · KB priors · previous runs")
health = node(sl, c2x, yD, w2, 1.0, "Health monitor", sub="coverage growth · exec/s · WEAK flag")
budget = node(sl, c2x, yD + 1.3, w2, 0.85, "Budget steering", sub="delta share to diff-reaching harnesses")
static = node(sl, c0, yD + 2.6, w0, 0.9, "Static scanner leads", sub="CodeQL · Semgrep · model findings")
conf = node(sl, c1x, yD + 2.6, w1, 0.9, "Directed confirmation", sub="aimed fuzzing slice, reserved budget share")
out1 = node(sl, ox, yD, ow, 1.0, "Crashes + reproducers", sub="/output/crashes · povs", kind="out")
out2 = node(sl, ox, yD + 1.3, ow, 0.85, "Health per harness", sub="HEALTHY / WEAK, health.json", kind="out")
out3 = node(sl, ox, yD + 2.6, ow, 0.9, "Confirmed static leads", sub="PoV or discarded", kind="out")
for a, b in ((h1, runners), (runners, health), (health, out1), (budget, out2), (static, conf), (conf, out3)):
    arrow(sl, rmid(a)[0] + 0.04, rmid(a)[1], lmid(b)[0] - 0.04, lmid(b)[1])
arrow(sl, tmid(seeds)[0], tmid(seeds)[1] - 0.02, bmid(runners)[0], bmid(runners)[1] + 0.04)
arrow(sl, tmid(budget)[0], tmid(budget)[1] - 0.02, bmid(health)[0], bmid(health)[1] + 0.04)
fy = 2.2
poly(sl, [(tmid(health)[0], tmid(health)[1]), (tmid(health)[0], fy), (tmid(h1)[0], fy), (tmid(h1)[0], tmid(h1)[1] - 0.04)])
chip(sl, (tmid(health)[0] + tmid(h1)[0]) / 2, fy, "flat coverage → back to stage 2, regenerate", color=ACCENT)
output_bar(sl, "crash inputs with stack traces, confirmed PoVs for static leads, and a health verdict per harness", y=6.25)
legend(sl, y=7.02)
notes(sl, "Say: the engines are standard — libFuzzer, Jazzer, atheris — what discver adds is supervision. Every harness is watched: "
          "coverage growth and execution rate decide whether it is HEALTHY or WEAK, and a flat one goes back to stage 2 to be rewritten. "
          "Budget follows the plan: in delta mode most of it goes to harnesses that reach the diff, and a reserved slice is spent trying to "
          "turn static-scanner leads into real crashing inputs. Out come crash inputs with traces, and a health verdict per harness.")

# ----------------------------------------------------------------------------- slide 5: decide
sl = new()
title(sl, "Stage 4 — Decide what is real", "From a pile of crashes to findings that carry their own evidence")
breadcrumb(sl, 4)
yE, gapE = 2.35, 0.25
steps = [("Crashes", "many per bug", "det", 1.9, 1.5), ("Signature dedup", "stack-based, address-free", "det", 1.7, 1.7),
         ("Unique bugs", "one record each", "det", 1.5, 1.4), ("KB retrieval", "similar past crashes", "det", 1.3, 1.7),
         ("Arbiter", "evidence → confidence", "llm", 1.3, 1.5)]
x, prev = M, None
for s, sub, k, hh, w in steps:
    nd = node(sl, x, yE + (1.9 - hh) / 2, w, hh, s, sub=sub, kind=k, size=12)
    if prev is not None:
        arrow(sl, rmid(prev)[0] + 0.04, rmid(prev)[1], lmid(nd)[0] - 0.04, lmid(nd)[1])
    prev, x = nd, x + w + gapE
arb = prev
tx = x + 0.2
tw = W - M - tx
t1 = node(sl, tx, yE - 0.3, tw, 0.62, "PoV-backed → submit", sub="always · evidence = pov", kind="out", size=12)
t2 = node(sl, tx, yE + 0.45, tw, 0.62, "Model / static ≥ 0.67 → submit", sub="labelled evidence = llm | static", kind="out", size=12)
t3 = node(sl, tx, yE + 1.2, tw, 0.62, "Arbiter-overruled ≥ 0.85 → submit", sub="'weak' lead, labelled", kind="out", size=12)
t4 = box(sl, tx, yE + 1.95, tw, 0.5, fill=PAPER, line=ACCENT, dash=MSO_LINE_DASH_STYLE.DASH)
text(sl, tx, yE + 1.95, tw, 0.5, "below threshold → in the report, not submitted", size=11, color=ACCENT, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, italic=True)
for t in (t1, t2, t3, t4):
    arrow(sl, rmid(arb)[0] + 0.04, rmid(arb)[1], lmid(t)[0] - 0.04, lmid(t)[1])
text(sl, M, yE + 2.55, 9.0, 0.6, "Scope rule: a crash whose root sits in a dependency is reported as bug_in_dependency — counted, never patched in the target tree.",
     size=12, color=MUTED, italic=True)
output_bar(sl, "findings with a crash signature, similar-history context, an arbiter confidence and an evidence label — ready for the submission policy")
legend(sl, feedback=False)
notes(sl, "Say: a fuzzer produces many crashes per bug, so first collapse them by a stack-based signature that ignores addresses and input "
          "bytes. Each unique bug is then looked up in the knowledge base — similar crashes in similar code, what class they were, how they "
          "were fixed — and an arbiter weighs that with the trace and the source and assigns a confidence. Submission is tiered: anything "
          "with a reproducer goes; model-only or scanner-only findings go above 0.67 with their evidence labelled; leads the arbiter "
          "overruled need 0.85. Below that it is in the report, not in the submission.")

# ----------------------------------------------------------------------------- slide 6: assembled
sl = new()
title(sl, "The whole pipeline", "Same boxes you have just seen, in one picture")
yF, hF = 2.25, 3.5
groups = [("1  UNDERSTAND", 2.5), ("2  MAKE FUZZABLE", 2.6), ("3  FUZZ", 2.4), ("4  DECIDE", 2.4), ("5  SUBMIT", 1.93)]
gx, cols = M, []
for name, gw in groups:
    box(sl, gx, yF - 0.35, gw, hF + 0.35, fill=BAND, line=None, radius=0.05)
    text(sl, gx, yF - 0.32, gw, 0.3, name, size=10, bold=True, color=MUTED, align=PP_ALIGN.CENTER)
    cols.append((gx, gw))
    gx += gw + 0.1


def col_nodes(ci, items):
    gx, gw = cols[ci]
    k = len(items)
    nh = min(0.78, (hF - 0.2 - 0.16 * (k - 1)) / k)
    y, out = yF + 0.1, []
    for s, sub, kind in items:
        out.append(node(sl, gx + 0.15, y, gw - 0.3, nh, s, sub=sub, kind=kind, size=11))
        y += nh + 0.16
    return out


def vflow(nodes_):
    for a, b in zip(nodes_, nodes_[1:]):
        arrow(sl, bmid(a)[0], bmid(a)[1] + 0.02, tmid(b)[0], tmid(b)[1] - 0.03)


c1 = col_nodes(0, [("Language adapter", None, "det"), ("Call graph · delta", None, "det"), ("Strategy plan", "KB retrieval", "llm")])
c2 = col_nodes(1, [("Entry-point ranking", "penalties", "det"), ("Harness generator", "or provided harness", "llm"), ("Gate", "reach + static, fail closed", "gate")])
c3 = col_nodes(2, [("Runners", "libFuzzer · Jazzer", "det"), ("Health + budget", None, "det"), ("Directed confirmation", "static leads", "det")])
c4 = col_nodes(3, [("Signature dedup", None, "det"), ("KB-grounded triage", None, "det"), ("Arbiter → confidence", None, "llm")])
c5 = col_nodes(4, [("Submission policy", "tiers 0.67 / 0.85", "det"), ("PoVs + evidence", "to OSS-CRS", "out"), ("Patch stage", "downstream — not today", "ext")])
vflow(c1); vflow(c2); vflow([c3[0], c3[1]]); vflow(c4); vflow([c5[0], c5[1]])
gapx = lambda ci: cols[ci][0] + cols[ci][1] + 0.05          # x of the gap after column ci
elbow(sl, (rmid(c1[1])[0] + 0.03, rmid(c1[1])[1]), (lmid(c2[0])[0] - 0.03, lmid(c2[0])[1]), gapx(0))
elbow(sl, (rmid(c1[2])[0] + 0.03, rmid(c1[2])[1]), (lmid(c2[1])[0] - 0.03, lmid(c2[1])[1]), gapx(0))
elbow(sl, (rmid(c2[2])[0] + 0.03, rmid(c2[2])[1]), (lmid(c3[0])[0] - 0.03, lmid(c3[0])[1]), gapx(1))
elbow(sl, (rmid(c3[0])[0] + 0.03, rmid(c3[0])[1]), (lmid(c4[0])[0] - 0.03, lmid(c4[0])[1]), gapx(2))
elbow(sl, (rmid(c3[2])[0] + 0.03, rmid(c3[2])[1]), (lmid(c4[0])[0] - 0.03, lmid(c4[0])[1] + 0.12), gapx(2))
elbow(sl, (rmid(c4[2])[0] + 0.03, rmid(c4[2])[1]), (lmid(c5[0])[0] - 0.03, lmid(c5[0])[1]), gapx(3))
fy = 1.65
hx, hy = lmid(c3[1])
gx_, gy_ = lmid(c2[1])
poly(sl, [(hx - 0.03, hy), (gapx(1) + 0.03, hy), (gapx(1) + 0.03, fy), (gapx(0) - 0.03, fy), (gapx(0) - 0.03, gy_), (gx_ - 0.03, gy_)])
chip(sl, (gapx(0) + gapx(1)) / 2, fy, "flat coverage → regenerate", color=ACCENT)
node(sl, M, yF + hF + 0.25, 4.2, 0.55, "OSS-CRS task: source · build · harnesses · diff", kind="ext", size=11)
node(sl, W - M - 4.4, yF + hF + 0.25, 4.4, 0.55, "OSS-CRS: PoV submission, judged on the reference build", kind="ext", size=11)
legend(sl, gate=True)
notes(sl, "Say: this is the picture from the start, now that every box has been introduced. Teal is where a model is consulted — three "
          "places. The gate between generation and fuzzing and the tiered submission policy are the two places evidence overrides the model. "
          "The patch stage exists downstream of submission; it is gated the same way (rebuild and re-run the reproducer) and is not part of today's results.")

out = Path(sys.argv[1] if len(sys.argv) > 1 else "discver-architecture.pptx")
prs.save(str(out))
print(f"{len(prs.slides)} slides -> {out}")
