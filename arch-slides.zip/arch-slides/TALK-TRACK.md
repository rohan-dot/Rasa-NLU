# discver architecture — talk track (one block per slide)

Paste the slides with *Keep Source Formatting* to carry these notes over as speaker notes; or paste the shapes into
template slides and read from here. Each stage slide ends with the dark bar: what that stage hands to the next one — say it.

## 1. discver in five stages
Five stages, left to right, one pass per task. The teal ones are where a language model is consulted; everything else is
deterministic. The knowledge base is compiled offline and only read at run time — it informs the plan at stage 1 and the
triage at stage 4. One loop worth pointing at now: if fuzzing shows flat coverage, the harness goes back to stage 2 and is
rewritten. Patching is a downstream stage after Submit and is not covered today.

## 2. Stage 1 — Understand the target
Cheap and deterministic, except for the plan. The language adapter reads the OSS-Fuzz metadata or does a file census. The
call graph gives the public entry points and their argument shapes. If the task has a diff, the delta map finds the functions
it touches. The knowledge base is queried once for projects and crashes that look like this one, and the output is a plan:
what to harness first, what bug classes to expect, how to split the budget. Nothing has been fuzzed yet.

## 3. Stage 2 — Make it fuzzable
Two ways to get a harness. If the project ships one, compile it — and if javac fails, let the model fix it once. If not, rank
the public entry points: parsers that take bytes or strings score high; anything that needs a network, a directory server or a
live server object is penalised, following callees three levels deep. The model writes a harness for the top candidates.
Nothing fuzzes until it passes the gate: a reach probe shows it actually executes project code, and a static check rejects
catch-alls and other cheats. Fail closed — a rejected harness is logged, not run.

## 4. Stage 3 — Fuzz with eyes open
The engines are standard — libFuzzer, Jazzer, atheris. What discver adds is supervision. Every harness is watched: coverage
growth and execution rate decide whether it is HEALTHY or WEAK, and a flat one goes back to stage 2 to be rewritten. Budget
follows the plan: in delta mode most of it goes to harnesses that reach the diff, and a reserved slice is spent trying to turn
static-scanner leads into real crashing inputs. Out come crash inputs with traces, confirmed PoVs for static leads, and a
health verdict per harness.

## 5. Stage 4 — Decide what is real
A fuzzer produces many crashes per bug, so first collapse them by a stack-based signature that ignores addresses and input
bytes. Each unique bug is looked up in the knowledge base — similar crashes in similar code, what class they were, how they
were fixed — and an arbiter weighs that with the trace and the source and assigns a confidence. Submission is tiered: anything
with a reproducer goes; model-only or scanner-only findings go above 0.67 with their evidence labelled; leads the arbiter
overruled need 0.85. Below that it is in the report, not in the submission. A crash rooted in a dependency is reported as
such and never patched in the target tree.

## 6. The whole pipeline
The picture from the start, now that every box has been introduced. Teal is where a model is consulted — three places. The
gate between generation and fuzzing, and the tiered submission policy, are the two places where evidence overrides the model.
The patch stage exists downstream of submission; it is gated the same way — rebuild, re-run the reproducer — and is not part
of today's results.
