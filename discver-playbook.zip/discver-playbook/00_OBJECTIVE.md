# OBJECTIVE — one run, two tracks: fuzzing & coverage AND patching

This run improves discver on both tracks. Neither may be dropped, deferred to "a later run", or reduced to
observability-only changes. The final report must contain two sections, **FUZZING & COVERAGE** and **PATCHING**,
each listing the changes shipped (files, tests, the behavioural change in one sentence) and the exact log lines
the next discver run will show. A report missing either section fails the run.

- **Track A — Fuzzing & coverage.** Spec and pre-shaped findings F1–F5: `README.md`. Tested reference
  implementation of the mechanisms discver lacks: `reference_fuzz_runner.py` (+ `test_reference_fuzz_runner.py`).
- **Track B — Patching.** Diagnosis table and pre-shaped findings P1–P9: `PATCHING.md`.
- Where the AIxCC finalists solved both: `WHERE_TO_LOOK.md`.

## Order inside this run
Track A is upstream of Track B: patches are validated only for PoV-backed crashes, PoV-backed crashes come from
fuzzing, and the primary harness currently executes a few hundred inputs per run. Therefore:
- Rounds 1–2: Track A — F1 and F2 shipped with tests (plus any of F3–F5 that fit). The research engineer's first
  hand-over to the manager is the fuzzing findings.
- Rounds 3–5: Track B — the findings the diagnosis table in `PATCHING.md` selects from the newest run's
  `patch_index.json` and `orchestrator.log`; P7 and P8 whenever cheap. The research engineer's second hand-over is
  the patching findings, with the reference-CRS mechanisms from `WHERE_TO_LOOK.md`.
- If a track's evidence shows it is already fixed, quote the log lines that prove it and move on. That is the
  only accepted reason to skip work on a track; "out of rounds" is not.

## Definition of done — judged by the next discver run
- A: the primary harness executes millions of inputs with coverage growing past its first stats line; the known
  shallow crash is reported once with its PoV; the fuzzer continues past it; new distinct crashes get PoVs; seed
  counts per harness are logged; a no-op harness is flagged and stopped; verdicts are truthful.
- B: a `validated` patch emitted for the PoV-backed crash (patch applied → rebuilt through the builder sidecar →
  the specific PoV no longer crashes → tests executed and passing) — or, if the model still never reaches
  `test_patch`, per-finding counters in `patch_index.json` (`parse_failures`, `read_only_turns`, `tool_histogram`)
  and reason strings with numbers that make the cause self-evident from the report alone.

## Invariants — the reviewer blocks any violation, on either track
- No feature flags or environment switches for the operator; discver auto-detects and logs the path it chose at startup.
- Fail loud with a specific cause: no silent skip, no bare `except`, no `continue` on a failure without a log line carrying the raw data.
- `validated` means exactly the definition above; anything less is emitted UNVALIDATED with a prominent label; never `tests_pass=True` when no test command ran.
- Health verdicts become more accurate, never more lenient.
- Never modify target source; patches are emitted under `output/patches/`. Do not modify the PoV replay oracle
  (`crash_dedup._get_crash_signature`) or the builder-sidecar wiring.
- One behavioural change per item, with a test that runs locally with fakes (no container, no network), and a log
  line naming the cause on every failure path.
- Never claim an outcome you did not run and see in a tool output.
