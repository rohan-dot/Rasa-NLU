# Patching track — decide from the evidence, then fix the plumbing that stops the model

Every patch failure in discver's history was plumbing or protocol, never "the model could not fix the bug":
silent skip (no build command) → LLM timeout → brief lacked PoV/scratch/tool context → wrong `$SRC` layout (fixed by
the libCRS builder sidecar: `apply-patch-build` / `run-pov` / `run-test`) → unparseable replies silently dropped
(fixed: `[patch-turn]` logging, validate→repair) → `attempts=15, test_calls=0, root_cause=""` on every finding,
including five `static-*` ones → auto-validation after read-only stalls and an executed-regression gate were added.
The target crash is real and reproduced: index-out-of-bounds in `X509Utils.getCnFromDn` (X509Utils.java:81); its
PoV is the empty input, so the fix is a one-line guard — the point is that the loop must reach `test_patch` with it.

## Step 1 — diagnose from the newest run (results directory) before planning anything
Read `patches/patch_index.json` and grep `orchestrator.log` for `patch-turn|llm-call|timed out|build_ok|SIDECAR|test_patch|apply_edit|UNVALIDATED`.

| what the run shows | meaning | findings to hand over |
|---|---|---|
| attempts at the budget, `test_calls=0`, `root_cause=""` | the loop never turns a reply into `apply_edit`/`test_patch` (parse failures counted as attempts, or a read-only loop) | P1, P2 |
| `test_calls>0` but `build_ok` false / "patch did not apply" | sidecar build or patch application fails | P3 |
| build ok, PoV still crashes after the patch | wrong fix or wrong site — the agent lacks the stack trace and source context | P4 |
| PoV fixed but "REGRESSION GATE NOT EXERCISED" | no test command reaches the sidecar | P5 |
| reason mentions timed out / no reply | LLM call path | P6 |
| `static-*` findings with the full iteration budget | budget burned on findings that cannot be validated by PoV replay | P7 |
| the same sink listed once per harness; an unreproduced input listed twice | dedup gap | P8 |
| `[patch-turn]` or `[llm-call]` lines absent although the code has them | the run was on stale code — say so; verify what ran | — |

## Findings (each is ONE behavioural change with tests; observability may ride along)
- **P1 — Action protocol that survives any model.** Lenient extraction (strip code fences and `<think>` blocks; first
  balanced JSON object containing the action key; tolerate trailing prose; alias tool names); repair prompt quoting the
  exact parse error, the raw reply (first 300 chars) and the schema example; after 2 consecutive parse failures switch
  that finding to a one-line minimal protocol; after 4 consecutive read-only turns demand an `apply_edit` or a stated
  reason; after an edit followed by read-only turns force `test_patch` (check whether the existing auto-validation
  covers the no-edit case). Tests: fenced JSON; JSON followed by prose; `<think>` prefix; garbage then a valid reply
  after the repair message; five read-only replies → the nudge text appears in the sixth prompt.
- **P2 — Accounting that makes the next run self-explaining.** `parse_failures`, `read_only_turns`, `tool_histogram`
  per finding in `patch_index.json` and in every `[patch-turn]` line; reason strings carry numbers
  ("no validated patch: 15 iters, 12 parse failures, 0 test calls; last parse error: …"); `root_cause` filled from the
  RCA step or the reason says why not. Test: the counters and the reason format.
- **P3 — Sidecar build observability and classification.** Log the exact sidecar command, exit code and a stderr tail;
  classify failures (`patch_apply_failed`, `compile_error`, `harness_not_produced`, `wrong_src_layout`); fail fast on
  `build_ok=False` within 2 turns with the classification in the reason. Test: a fake sidecar that fails → the reason
  carries the classification and the loop stops within 2 turns.
- **P4 — RCA context.** The dedup record carries only the sink location: thread the ASAN/Jazzer stack trace, a source
  slice around the sink (about ±60 lines), and the PoV path into the brief; record the RCA output as `root_cause`.
  Test: the brief contains the trace and the slice; `root_cause` is non-empty after the RCA step.
- **P5 — Regression gate.** Detect and run the target's test command through the sidecar (`run-test`); when none exists,
  emit UNVALIDATED "tests not exercised" — never `tests_pass=True`. Verify the existing gate; add detection if missing.
- **P6 — LLM call path** (only if the run shows timeouts): per-call log (timeout, max_tokens, prompt size, elapsed,
  outcome); adaptive retry that shrinks the request — never an identical resend; caps.
- **P7 — `static-*` findings:** build+tests-only path, at most 2 iterations, emitted UNVALIDATED "no reproducer".
- **P8 — Dedup:** the same sink across harnesses is patched once; each unreproduced input is reported once.
- **P9 (if rounds remain) — `patch_replay` entrypoint:** `python -m src.patch_replay --run-dir <LOG_DIR>` re-runs only
  phase-3 patch generation on an existing run's crash + PoV, reusing the phase-3 functions, with a `--scenario` mode of
  scripted replies to prove the oracle end to end independent of the model.

Minimum for this track in this run: the findings the table selects (P1+P2 for the 15/0 signature) shipped with
tests, plus P7 and P8 when cheap.

## From the reference CRSs (see WHERE_TO_LOOK.md)
Answer, with file:line, then propose a one-cycle port for discver: the validation gating order (build → PoV re-run →
tests → judge?), attempt limits, and what is reported when validation is incomplete; how the patch agent receives
source context (function extraction, program model, slices); repair loops for non-JSON or malformed diffs; incremental
rebuild caching; any "never claim success without independent validation" logic. Both systems assume frontier
tool-calling models and cloud infrastructure — port the mechanism, not the code, and note licenses.
