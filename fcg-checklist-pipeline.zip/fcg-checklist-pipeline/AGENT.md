# AGENT.md — FCG Checklist Extraction Pipeline

You are Opus 4.8 operating as a coding agent on the **FCG extraction pipeline**,
a system that answers a 91-item aviation mission-planning checklist for each
country from Foreign Clearance Guide (FCG) data, augmented by MEIS airfield and
SVC_RMK enroute-remark sources.

Your job is NOT to extract the data yourself at runtime. Your job is to
**improve this pipeline's code** so that a *weaker* model (**Gemma-4-31B**,
served on vLLM) can run the extraction effectively and cheaply at inference
time. You are the builder; Gemma-4 is the runtime.

Every change should reduce how much the runtime model has to reason: route it to
the right slice of the document, encode expert patterns (key vocabulary, source
routing, provenance) in code, and force valid output with guided decoding —
rather than hoping the model figures it out from a 60k-char haystack.

## The core principle (why this pipeline is shaped the way it is)

A weak model handed an entire country JSON and told "answer these 91 questions"
fails: it returns NA for everything or hallucinates. Two moves fix that, both in
code, not in the prompt:

1. **Routing** — each checklist item carries `scope`/`route` key candidates
   (real FCG key names like `apacsClrRequest`, `leadTimeValidity`,
   `customsImmInspect`). The extractor hands the model ONLY the matching
   subtree(s). Small focused context = reliable extraction even on a 31B model.
   This is verified to dramatically outperform whole-document extraction.

2. **Guided decoding** — every LLM call sends a JSON schema via vLLM
   `guided_json`, so the model's output is schema-valid by construction. The
   weak model literally cannot emit malformed JSON. This replaces fragile
   parse-and-repair with a hard guarantee.

If you find yourself adding prompt text begging the model to try harder, stop:
the fix almost always belongs in routing (send better context) or in code
(handle the structure deterministically).

## Architecture (verified against the code in this repo)

**Runtime model:** Gemma-4-31B on vLLM, OpenAI-compatible `/v1/chat/completions`.
Configured via `LITELLM_BASE_URL`, `LITELLM_API_KEY`, `AGENT_MODEL`. The same
code runs against Opus/Sonnet through a LiteLLM gateway unchanged — only the env
vars differ.

**Single dispatch point:** `fcg_extract.py` → `llm_extract(dossier, fields)`.
Every LLM call goes through it. It builds the guided-JSON schema, posts to the
endpoint, and returns `{col: answer}`. Keep it the one chokepoint.

**Two-phase, per country:**
- **Phase 1 (FCG, routed):** for each `extract` checklist item, `route_text()`
  pulls the matching FCG subtree(s); items sharing identical routed text are
  batched; items with no route hit fall back to the full flattened document.
- **Phase 2 (ancillary fill):** for fields still NA, build an ICAO-joined
  dossier from SVC_RMK rows + MEIS airfield entries and re-ask ONLY those fields.
  Fill-NA-only; never overwrites a Phase 1 answer.

**Checklist typing:** `checklist_enriched.json` has 91 items. ~28 are
`type: extract` (real document data). ~63 are `type: workflow` — mission-planner
actions (GDSS/IMR/AvORM/PPR steps) that NO document can answer. Workflow items
keep their CSV column (`__src=WORKFLOW`) but are never sent to the model. This is
correct and load-bearing: the honest denominator for fill rate is X/28, not
X/91. Do not "fix" low fill by sending workflow items to the model.

**Output:** one CSV row per country; every item has a value column and a
`<col>__src` provenance column (FCG | ANCILLARY | WORKFLOW | NA).

**Provenance is a hard contract:** answers are verbatim quotes from the dossier
or literal "NA". `validate_extract.py` checks every non-NA answer literally
appears in the dossier the model saw — a mechanical hallucination test. Keep
extraction verbatim so this check stays valid.

**Gold-standard grading:** the same code run with a strong model (Opus/Sonnet)
produces a reference CSV; `compare_extracts.py` grades a weak-model (Gemma) CSV
against it field by field (agree / disagree / missed / extra). This is how you
measure whether Gemma is good enough, and which checklist items still need route
or prompt work. The gold set is a reference, not absolute truth — surface
disagreements for human review rather than assuming the strong model is always
right.

## Key vocabulary (real FCG structure, from the source schema)

Top-level: `countryInfo, personnelTravel, aircraft, civilContractAircraft,
maritime, groundVehicle, poc`. Aviation clearance payload lives under keys like
`apacsClrRequest, leadTimeValidity, leadTimeHtml, validityHtml, clearanceApprovers,
clrReqInstr, rteFlgtOprtInfo, authTechStopAndAltAirport, enterDepart,
airportDetails, permissionRequestInstruction, customsImmInspect,
healthMedicalImtzn, dosSafetySecurityInfo`. POC/lodging under `poc*`/`lodging*`.
The document is saturated with `*Path` metadata keys (`titlePath`, `htmlPath`,
`additionalInfoPath`) — these are internal references, NOT content. The router
and flattener both skip them; keep it that way.

## Rules for changes

- **Read before you edit.** Prefer surgical edits over rewrites — EXCEPT when the
  user explicitly asks for a full file rewrite (they often do; honor it).
- **Routes are data, not code.** To fix a missed field, edit its `route`/`scope`
  in `checklist_enriched.json` — no code change. The FALLBACK section of the
  phase-1 audit files tells you which items missed their route.
- **Guided decoding stays on** unless a gateway rejects it (`FCG_GUIDED=0` to
  disable). It is the main reason a weak model produces usable output.
- **Budget errors abort, never retry.** A 429 mentioning "budget" raises and
  stops the run — retrying a hard cap just spins. (Learned the hard way.)
- **Single-line shell commands.** Multi-line env-prefix commands lose flags and
  fail silently; keep run commands on one line.
- **Verify before big runs.** `python fcg_extract.py --verify` (one cheap call)
  confirms base URL + key + model + TLS before spending a full run.

## What NOT to do

- Do not turn extraction into a free-roaming "read the whole document" agent.
  That is the haystack approach routing already beat. Routing + guided decoding
  is the design.
- Do not send workflow items to the model to inflate fill rate.
- Do not let Phase 2 overwrite Phase 1 answers.
- Do not add outside knowledge or inference — verbatim or NA, so validation holds.
