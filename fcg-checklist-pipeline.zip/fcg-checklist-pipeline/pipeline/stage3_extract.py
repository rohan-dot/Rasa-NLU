"""Stage 3: extract schema answers from each country's FCG JSON -> CSV.

Reuses every hard-won pattern from fcg_extract.py:
- async with shared semaphore (llm_client owns it)
- per-country resume via a checkpoint JSONL (safe to rerun anytime)
- constrained-JSON prompting + three-tier lenient parser
- closed-world discipline: answers must come from the provided dossier
  text; anything not present is "NA". The model is a reader here, never
  a source of clearance facts.
- raw fields over summaries: the dossier passed to the model is the raw
  country JSON flattened to text, char-capped, not a summary.

Country files: one JSON per country in FCG_COUNTRY_DIR. The country key
is the filename stem with any *_FCG2.0-style suffix stripped (same regex
convention as datalayer.py).
"""

import asyncio
import csv
import json
import re
from pathlib import Path

from . import config
from .llm_client import chat_json

_SUFFIX = re.compile(r"_FCG[\d.]*$", re.IGNORECASE)

SYSTEM_TMPL = """You extract facts from a raw Foreign Clearance Guide (FCG)
country dossier.

STRICT RULES:
- Answer ONLY from the dossier text below. If a fact is not stated in the
  dossier, the answer is exactly "NA". Never use outside knowledge.
- Each field asks one question. Answer each independently.
- Keep answers short and factual; verbatim excerpts are preferred.
- boolean answers: "true", "false", or "NA".
- number answers: bare number or "NA".

Respond ONLY with a JSON object with EXACTLY these keys:
{keys}

Field questions:
{questions}"""


def _flatten(obj, prefix="") -> list[str]:
    """Flatten country JSON to 'path: value' lines -- raw data, no summarizing."""
    lines = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            lines.extend(_flatten(v, f"{prefix}{k}."))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            lines.extend(_flatten(v, f"{prefix}{i}."))
    else:
        text = str(obj).strip()
        if text:
            lines.append(f"{prefix[:-1]}: {text}")
    return lines


def _dossier_text(path: Path) -> str:
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        text = "\n".join(_flatten(data))
    except json.JSONDecodeError:
        text = path.read_text(encoding="utf-8", errors="replace")
    return text[:config.COUNTRY_DOC_CHAR_CAP]


def _country_key(path: Path) -> str:
    return _SUFFIX.sub("", path.stem).upper()


def _load_done() -> dict[str, dict]:
    done = {}
    if config.STAGE3_CHECKPOINT_JSONL.exists():
        with open(config.STAGE3_CHECKPOINT_JSONL, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    row = json.loads(line)
                    done[row["country"]] = row
    return done


async def extract_country(path: Path, schema: list[dict],
                          system: str, fields: list[str]) -> dict:
    country = _country_key(path)
    user = f"FCG DOSSIER FOR {country}:\n\n{_dossier_text(path)}"
    resp = await chat_json(system, user)
    row = {"country": country, "source_file": path.name}
    if not isinstance(resp, dict):
        row["_status"] = "llm_failure"
        for f in fields:
            row[f] = "NA"
        return row
    row["_status"] = "ok"
    for f in fields:
        val = resp.get(f, "NA")
        if val is None or str(val).strip() == "":
            val = "NA"
        row[f] = str(val)
    return row


async def run() -> None:
    config.ensure_dirs()
    schema = json.loads(config.STAGE2_SCHEMA_JSON.read_text(encoding="utf-8"))
    if not schema:
        raise SystemExit("stage2_schema.json is empty -- nothing to extract.")

    fields = [s["field"] for s in schema]
    keys = json.dumps({f: "..." for f in fields})
    questions = "\n".join(f'- {s["field"]}: {s["question"]}'
                          + (f'  (options: {s["options"]})' if s.get("options") else "")
                          for s in schema)
    system = SYSTEM_TMPL.format(keys=keys, questions=questions)

    country_files = sorted(p for p in config.FCG_COUNTRY_DIR.glob("*.json"))
    if not country_files:
        raise SystemExit(f"No country JSON files in {config.FCG_COUNTRY_DIR}")

    done = _load_done()
    todo = [p for p in country_files if _country_key(p) not in done]
    print(f"{len(country_files)} countries, {len(done)} done, {len(todo)} to go")

    ckpt = open(config.STAGE3_CHECKPOINT_JSONL, "a", encoding="utf-8")
    try:
        tasks = [asyncio.create_task(extract_country(p, schema, system, fields))
                 for p in todo]
        for i, coro in enumerate(asyncio.as_completed(tasks), 1):
            row = await coro
            ckpt.write(json.dumps(row, ensure_ascii=False) + "\n")
            ckpt.flush()
            done[row["country"]] = row
            print(f"[{len(done)}/{len(country_files)}] {row['country']} "
                  f"({row['_status']})")
    finally:
        ckpt.close()

    # Write final CSV from the full checkpoint set (idempotent)
    cols = ["country", "source_file", "_status"] + fields
    with open(config.FINAL_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        for country in sorted(done):
            writer.writerow(done[country])

    n_fail = sum(1 for r in done.values() if r["_status"] != "ok")
    print(f"Wrote {len(done)} rows -> {config.FINAL_CSV} "
          f"({n_fail} LLM failures; rerun to retry after deleting their "
          f"lines from the checkpoint)")


if __name__ == "__main__":
    asyncio.run(run())
