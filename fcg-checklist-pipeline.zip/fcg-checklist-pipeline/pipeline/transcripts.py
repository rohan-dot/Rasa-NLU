"""Normalize Zoom transcripts of mixed format (.txt, .vtt, .docx) to clean text.

Output format per transcript: one line per utterance, "SPEAKER: text",
consecutive lines from the same speaker merged. Timestamps and cue
numbers stripped. Deterministic, no LLM involved.
"""

import re
from pathlib import Path

_TS_LINE = re.compile(
    r"^\d{2}:\d{2}(?::\d{2})?[.,]\d{3}\s*-->\s*\d{2}:\d{2}(?::\d{2})?[.,]\d{3}")
_CUE_NUM = re.compile(r"^\d+\s*$")
_INLINE_TS = re.compile(r"\[?\(?\d{1,2}:\d{2}(?::\d{2})?\)?\]?")
_SPEAKER = re.compile(r"^([A-Za-z][\w .'\-]{0,60}):\s*(.*)$")


def _read_docx(path: Path) -> str:
    from docx import Document  # lazy import
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def _read_raw(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return _read_docx(path)
    return path.read_text(encoding="utf-8", errors="replace")


def _looks_like_vtt(text: str) -> bool:
    head = text[:2000]
    return "WEBVTT" in head or bool(_TS_LINE.search(head))


def _clean_vtt(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if (not line or line.startswith(("WEBVTT", "NOTE", "STYLE"))
                or _CUE_NUM.match(line) or _TS_LINE.match(line)):
            continue
        lines.append(line)
    return lines


def _clean_plain(text: str) -> list[str]:
    lines: list[str] = []
    for raw in text.splitlines():
        line = _INLINE_TS.sub("", raw).strip()
        if line:
            lines.append(line)
    return lines


def _merge_speakers(lines: list[str]) -> str:
    """Merge consecutive utterances by the same speaker into one line."""
    out: list[tuple[str, str]] = []  # (speaker, text)
    for line in lines:
        m = _SPEAKER.match(line)
        if m:
            speaker, text = m.group(1).strip(), m.group(2).strip()
            if out and out[-1][0] == speaker:
                out[-1] = (speaker, (out[-1][1] + " " + text).strip())
            else:
                out.append((speaker, text))
        else:
            if out:
                out[-1] = (out[-1][0], (out[-1][1] + " " + line).strip())
            else:
                out.append(("UNKNOWN", line))
    return "\n".join(f"{s}: {t}" for s, t in out if t)


def normalize_transcript(path: Path) -> str:
    text = _read_raw(path)
    lines = _clean_vtt(text) if _looks_like_vtt(text) else _clean_plain(text)
    return _merge_speakers(lines)


def normalize_all(src_dir: Path, dst_dir: Path) -> list[Path]:
    """Normalize every transcript in src_dir; returns list of written files."""
    dst_dir.mkdir(parents=True, exist_ok=True)
    written = []
    exts = {".txt", ".vtt", ".docx"}
    for path in sorted(src_dir.iterdir()):
        if path.suffix.lower() not in exts or path.name.startswith("."):
            continue
        clean = normalize_transcript(path)
        dst = dst_dir / (path.stem + ".clean.txt")
        dst.write_text(clean, encoding="utf-8")
        written.append(dst)
    return written
