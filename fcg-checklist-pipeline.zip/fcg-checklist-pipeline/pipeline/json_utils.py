"""Three-tier JSON parsing: strict -> auto-repair -> regex salvage.

Mirrors the pattern proven in fcg_extract.py: model output is sometimes
truncated or wrapped in markdown fences; never let one bad response kill
a batch run.
"""

import json
import re
from typing import Any, Optional

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)
_OBJ_RE = re.compile(r"\{.*\}", re.DOTALL)


def _strip_fences(text: str) -> str:
    m = _FENCE_RE.search(text)
    return m.group(1) if m else text


def _repair(text: str) -> str:
    """Cheap fixes for the common failure modes we actually see."""
    t = text.strip()
    # Trailing commas before } or ]
    t = re.sub(r",\s*([}\]])", r"\1", t)
    # Truncated output: balance braces/brackets by appending closers
    opens = t.count("{") - t.count("}")
    if opens > 0:
        # If we're mid-string, close the string first
        if t.count('"') % 2 == 1:
            t += '"'
        t += "}" * opens
    sq_opens = t.count("[") - t.count("]")
    if sq_opens > 0:
        t += "]" * sq_opens
    return t


def parse_json_lenient(text: str) -> Optional[Any]:
    """Return parsed JSON or None. Never raises."""
    if not text:
        return None
    candidate = _strip_fences(text)

    # Tier 1: strict
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass

    # Tier 2: auto-repair
    try:
        return json.loads(_repair(candidate))
    except json.JSONDecodeError:
        pass

    # Tier 3: regex salvage of the largest object-looking span
    m = _OBJ_RE.search(candidate)
    if m:
        for attempt in (m.group(0), _repair(m.group(0))):
            try:
                return json.loads(attempt)
            except json.JSONDecodeError:
                continue
    return None
