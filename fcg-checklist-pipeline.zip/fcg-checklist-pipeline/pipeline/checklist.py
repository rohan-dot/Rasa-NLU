"""Parse the checklist .docx into structured items with stable IDs.

Deterministic first: numbered paragraphs, headings, and bullets become
item boundaries. If that yields suspiciously few items (structure the
regexes don't recognize), an LLM-assisted segmentation fallback is
available -- but it only SEGMENTS text; it never invents content, and
every item keeps its verbatim body from the document.

Output: checklist_items.jsonl, one object per line:
  {"id": "CL-001", "number": "3.1", "title": "...", "body": "..."}

This file is a HUMAN REVIEW GATE. Eyeball it before running stage 1.
"""

import asyncio
import json
import re
from pathlib import Path

from . import config
from .llm_client import chat_json

_NUMBERED = re.compile(r"^\s*(\d+(?:\.\d+)*[.)]?|[A-Za-z][.)]|[•\-\u2022])\s+(.*)$")


def _paragraphs(docx_path: Path) -> list[tuple[str, str]]:
    """Return (style_name, text) for each non-empty paragraph."""
    from docx import Document
    doc = Document(str(docx_path))
    out = []
    for p in doc.paragraphs:
        text = p.text.strip()
        if text:
            style = (p.style.name or "") if p.style is not None else ""
            out.append((style, text))
    # Tables often hold checklist rows too
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                out.append(("TableRow", " | ".join(cells)))
    return out


def _is_item_start(style: str, text: str) -> bool:
    if style.startswith("Heading"):
        return True
    if style.startswith("List"):
        return True
    if style == "TableRow":
        return True
    return bool(_NUMBERED.match(text))


def parse_deterministic(docx_path: Path) -> list[dict]:
    paras = _paragraphs(docx_path)
    items: list[dict] = []
    current: dict | None = None
    for style, text in paras:
        if _is_item_start(style, text):
            if current:
                items.append(current)
            m = _NUMBERED.match(text)
            number = m.group(1).rstrip(".)") if m else ""
            title_src = m.group(2) if m else text
            title = title_src.split(". ")[0][:120].strip()
            current = {"number": number, "title": title, "body": text}
        elif current:
            current["body"] += "\n" + text
        # leading preamble before first item is intentionally dropped
    if current:
        items.append(current)
    for i, item in enumerate(items, 1):
        item["id"] = f"CL-{i:03d}"
    return items


async def parse_llm_fallback(docx_path: Path) -> list[dict]:
    """Segment via LLM when deterministic parsing under-detects.

    The model returns character offsets / boundary lines only; bodies are
    sliced verbatim from the source text so no content is paraphrased.
    """
    paras = _paragraphs(docx_path)
    numbered_lines = [f"[{i}] {text}" for i, (_, text) in enumerate(paras)]
    full = "\n".join(numbered_lines)

    system = ("You segment a checklist document into individual checklist items. "
              "Respond ONLY with JSON: {\"items\": [{\"start_line\": int, "
              "\"title\": \"short title\"}]}. start_line is the [n] index where "
              "each item begins. Do not rewrite or summarize content.")
    items: list[dict] = []
    # Chunk to stay inside context comfortably
    chunk_size = 200
    for offset in range(0, len(numbered_lines), chunk_size):
        chunk = "\n".join(numbered_lines[offset:offset + chunk_size])
        resp = await chat_json(system, chunk)
        if not resp or "items" not in resp:
            continue
        for entry in resp["items"]:
            try:
                items.append({"start_line": int(entry["start_line"]),
                              "title": str(entry.get("title", ""))[:120]})
            except (KeyError, TypeError, ValueError):
                continue
    items.sort(key=lambda x: x["start_line"])
    out: list[dict] = []
    for i, entry in enumerate(items):
        start = entry["start_line"]
        end = items[i + 1]["start_line"] if i + 1 < len(items) else len(paras)
        if not (0 <= start < len(paras)):
            continue
        body = "\n".join(text for _, text in paras[start:end])
        out.append({"id": f"CL-{len(out) + 1:03d}", "number": "",
                    "title": entry["title"] or body.split("\n")[0][:120],
                    "body": body})
    return out


def load_items(path: Path = None) -> list[dict]:
    path = path or config.CHECKLIST_ITEMS_JSONL
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_items(items: list[dict], path: Path = None) -> Path:
    path = path or config.CHECKLIST_ITEMS_JSONL
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    return path


def main() -> None:
    config.ensure_dirs()
    items = parse_deterministic(config.CHECKLIST_DOCX)
    if len(items) < config.MIN_CHECKLIST_ITEMS_EXPECTED:
        print(f"Deterministic parse found only {len(items)} items; "
              f"falling back to LLM-assisted segmentation.")
        items = asyncio.run(parse_llm_fallback(config.CHECKLIST_DOCX))
    path = write_items(items)
    print(f"Wrote {len(items)} items -> {path}")
    print("REVIEW GATE: inspect this file before running stage 1.")


if __name__ == "__main__":
    main()
