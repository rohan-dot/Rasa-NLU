"""Stage 1: read call transcripts and flag which checklist items matter.

Key design choice (agreed): the model sees the checklist ITEM INDEX
(IDs + titles) while reading each transcript, so fuzzy mentions
("the customs stuff") resolve directly to canonical item IDs -- no
post-hoc fuzzy matching.

Output stage1_flagged.json:
{
  "flags": [
    {"item_id": "CL-014", "priority": "must_check",
     "rationale": "...", "quote": "...", "transcript": "call2.clean.txt"}
  ],
  "unmatched_mentions": [ {"quote": "...", "transcript": "..."} ]
}

Priorities: must_check | nice_to_have | explicitly_skip
(explicitly_skip captures "we don't need X" statements -- as useful as
positive flags for trimming a 10-page checklist.)
"""

import asyncio
import json

from . import config
from .checklist import load_items
from .llm_client import chat_json

SYSTEM = """You analyze a call transcript against a checklist item index.
Identify every checklist item the participants discuss as important to
check, deprioritized, or explicitly skipped.

Rules:
- item_id MUST be copied exactly from the provided index. If a mention
  cannot be mapped to any listed item, put it under unmatched_mentions
  instead. Never invent IDs.
- quote must be a short verbatim excerpt from the transcript.
- priority is one of: must_check, nice_to_have, explicitly_skip.

Respond ONLY with JSON:
{"flags": [{"item_id": "...", "priority": "...", "rationale": "...",
            "quote": "..."}],
 "unmatched_mentions": [{"quote": "...", "note": "..."}]}"""


def _chunk(text: str, size: int) -> list[str]:
    """Chunk on line boundaries so utterances stay intact."""
    chunks, cur, cur_len = [], [], 0
    for line in text.splitlines():
        if cur_len + len(line) > size and cur:
            chunks.append("\n".join(cur))
            cur, cur_len = [], 0
        cur.append(line)
        cur_len += len(line) + 1
    if cur:
        chunks.append("\n".join(cur))
    return chunks


async def flag_transcript(name: str, text: str, index_block: str) -> dict:
    flags, unmatched = [], []
    for i, chunk in enumerate(_chunk(text, config.TRANSCRIPT_CHUNK_CHARS)):
        user = (f"CHECKLIST ITEM INDEX:\n{index_block}\n\n"
                f"TRANSCRIPT ({name}, part {i + 1}):\n{chunk}")
        resp = await chat_json(SYSTEM, user)
        if not resp:
            print(f"  WARNING: no parseable response for {name} part {i + 1}")
            continue
        for f in resp.get("flags", []) or []:
            f["transcript"] = name
            flags.append(f)
        for u in resp.get("unmatched_mentions", []) or []:
            u["transcript"] = name
            unmatched.append(u)
    return {"flags": flags, "unmatched_mentions": unmatched}


def _merge(per_transcript: list[dict], valid_ids: set[str]) -> dict:
    """Merge across calls; highest priority wins on conflicts, but
    conflicts are preserved for human review."""
    rank = {"must_check": 2, "nice_to_have": 1, "explicitly_skip": 0}
    by_id: dict[str, dict] = {}
    dropped = []
    for result in per_transcript:
        for f in result["flags"]:
            iid = f.get("item_id", "")
            if iid not in valid_ids:
                dropped.append(f)          # hallucinated / bad ID -> quarantine
                continue
            if f.get("priority") not in rank:
                f["priority"] = "nice_to_have"
            cur = by_id.get(iid)
            if cur is None:
                by_id[iid] = {**f, "evidence": [dict(f)], "conflict": False}
            else:
                cur["evidence"].append(dict(f))
                if cur["priority"] != f["priority"]:
                    cur["conflict"] = True
                if rank[f["priority"]] > rank[cur["priority"]]:
                    cur["priority"] = f["priority"]
                    cur["rationale"] = f.get("rationale", cur.get("rationale"))
    unmatched = [u for r in per_transcript for u in r["unmatched_mentions"]]
    return {"flags": sorted(by_id.values(), key=lambda x: x["item_id"]),
            "unmatched_mentions": unmatched,
            "dropped_bad_ids": dropped}


async def run() -> None:
    config.ensure_dirs()
    items = load_items()
    valid_ids = {it["id"] for it in items}
    index_block = "\n".join(
        f'{it["id"]}  {it["number"]}  {it["title"]}' for it in items)

    files = sorted(config.TRANSCRIPTS_CLEAN_DIR.glob("*.clean.txt"))
    if not files:
        raise SystemExit("No cleaned transcripts found. Run preprocess first.")

    results = []
    for path in files:                       # sequential: keeps logs readable
        print(f"Stage 1: {path.name}")
        results.append(await flag_transcript(
            path.name, path.read_text(encoding="utf-8"), index_block))

    merged = _merge(results, valid_ids)
    config.STAGE1_FLAGGED_JSON.write_text(
        json.dumps(merged, indent=2, ensure_ascii=False), encoding="utf-8")

    n_conflicts = sum(1 for f in merged["flags"] if f["conflict"])
    print(f"Flagged {len(merged['flags'])} items "
          f"({n_conflicts} with cross-call priority conflicts, "
          f"{len(merged['unmatched_mentions'])} unmatched mentions, "
          f"{len(merged['dropped_bad_ids'])} bad IDs quarantined)")
    print(f"-> {config.STAGE1_FLAGGED_JSON}")


if __name__ == "__main__":
    asyncio.run(run())
