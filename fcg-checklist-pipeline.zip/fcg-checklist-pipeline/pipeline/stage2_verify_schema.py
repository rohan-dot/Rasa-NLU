"""Stage 2: verify stage-1 flags against FULL checklist item text, then
generate the stage-3 extraction schema.

Two-pass extract-then-verify, per the pattern proven in fcg_extract.py:
stage 1 discovered candidates from an index; stage 2 now sees each item's
complete body plus the transcript evidence and either confirms or rejects
the match.

For each confirmed item it emits one or more extraction FIELDS. Hard rule
learned from the FCG extractor: NO COMPOUND QUESTIONS. "Lead time AND
HAZMAT" as one question caused all-NA output; each field asks exactly one
thing. If a checklist item genuinely covers two facts, it becomes two
fields.

Outputs:
  stage2_verified.json  -- confirmed/rejected items with reasons
  stage2_schema.json    -- ordered field list for stage 3:
      [{"field": "customs_lead_time", "item_id": "CL-014",
        "question": "...single question...", "answer_type": "text"}]

stage2_schema.json is a HUMAN REVIEW GATE. Edit it freely before stage 3.
"""

import asyncio
import json
import re

from . import config
from .checklist import load_items
from .llm_client import chat_json

SYSTEM = """You are building an extraction schema for aviation Foreign
Clearance Guide (FCG) country data.

You are given ONE checklist item (full text) and the call-transcript
evidence that flagged it. Decide:
1. confirmed: does the evidence genuinely refer to this item? (true/false)
2. If confirmed, define extraction fields to pull the item's answer from
   a country's FCG dossier.

STRICT RULES for fields:
- Each field asks EXACTLY ONE question about ONE fact. Never combine two
  facts (e.g. lead time and HAZMAT must be separate fields).
- field names: lowercase snake_case, <= 40 chars, unique, descriptive.
- question: phrased for a model reading a raw FCG country dossier; must be
  answerable with a short factual value or verbatim excerpt.
- answer_type: one of "text", "number", "boolean", "enum".
- If answer_type is "enum", include "options": [...].
- Prefer 1 field; use up to 3 only if the item truly covers multiple facts.

Respond ONLY with JSON:
{"confirmed": true/false, "reject_reason": "... or null",
 "fields": [{"field": "...", "question": "...", "answer_type": "...",
             "options": null}]}"""

_SNAKE = re.compile(r"^[a-z][a-z0-9_]{0,39}$")


async def verify_item(item: dict, flag: dict) -> dict:
    evidence = json.dumps(flag.get("evidence", []), ensure_ascii=False, indent=2)
    user = (f"CHECKLIST ITEM {item['id']} ({item.get('number', '')}):\n"
            f"{item['body']}\n\n"
            f"PRIORITY FROM CALLS: {flag.get('priority')}\n"
            f"TRANSCRIPT EVIDENCE:\n{evidence}")
    resp = await chat_json(SYSTEM, user)
    if not resp:
        return {"item_id": item["id"], "confirmed": False,
                "reject_reason": "no parseable LLM response", "fields": []}
    resp["item_id"] = item["id"]
    resp["priority"] = flag.get("priority")
    return resp


def _sanitize_schema(verified: list[dict]) -> list[dict]:
    schema, seen = [], set()
    for v in verified:
        if not v.get("confirmed"):
            continue
        for f in v.get("fields", []) or []:
            name = str(f.get("field", "")).strip()
            question = str(f.get("question", "")).strip()
            if not _SNAKE.match(name) or not question:
                continue
            base, n = name, 2
            while name in seen:
                name = f"{base}_{n}"
                n += 1
            seen.add(name)
            atype = f.get("answer_type", "text")
            if atype not in ("text", "number", "boolean", "enum"):
                atype = "text"
            schema.append({"field": name, "item_id": v["item_id"],
                           "priority": v.get("priority"),
                           "question": question, "answer_type": atype,
                           "options": f.get("options") if atype == "enum" else None})
    return schema


async def run() -> None:
    config.ensure_dirs()
    flagged = json.loads(config.STAGE1_FLAGGED_JSON.read_text(encoding="utf-8"))
    items_by_id = {it["id"]: it for it in load_items()}

    tasks = []
    for flag in flagged["flags"]:
        item = items_by_id.get(flag["item_id"])
        if item:
            tasks.append(verify_item(item, flag))
    verified = list(await asyncio.gather(*tasks))

    schema = _sanitize_schema(verified)

    config.STAGE2_VERIFIED_JSON.write_text(
        json.dumps(verified, indent=2, ensure_ascii=False), encoding="utf-8")
    config.STAGE2_SCHEMA_JSON.write_text(
        json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8")

    n_conf = sum(1 for v in verified if v.get("confirmed"))
    print(f"Verified {n_conf}/{len(verified)} items -> "
          f"{len(schema)} extraction fields")
    print(f"-> {config.STAGE2_VERIFIED_JSON}")
    print(f"-> {config.STAGE2_SCHEMA_JSON}")
    print("REVIEW GATE: edit stage2_schema.json (add/remove/reword fields) "
          "before running stage 3.")


if __name__ == "__main__":
    asyncio.run(run())
