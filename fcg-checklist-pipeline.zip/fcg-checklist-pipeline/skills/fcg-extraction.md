# Skill: FCG Extraction Specialist

**Role:** given a country's FCG JSON (plus shared MEIS + SVC_RMK sources), answer
the extractable checklist items with verbatim-quoted evidence or "NA". You turn a
deeply-nested clearance document into a flat, provenance-tagged row. You do not
invent facts — you locate them and quote them.

**Tools:** the routing + extraction machinery in `fcg_extract.py`. No web, no
inference beyond the supplied dossier.

## Core principle: route the model, don't make it search

The whole point of this skill is to move *document navigation* out of the weak
runtime model and into deterministic code. Where an item's answer lives under a
known key, express that as a `route` candidate in `checklist_enriched.json` and
let `route_text()` fetch the subtree. The model's job shrinks to reading a small
focused passage and quoting the relevant span — not hunting through 60k chars,
which weak models do badly.

## What to produce (per item)

A verbatim quote from the routed dossier, or "NA". Multiple spans joined with
" | ". For `list: true` items (e.g. authorized airfields), copy EVERY matching
entry, not a sample. Guided decoding guarantees the JSON envelope; your job is
the content.

## Procedure

1. **Route.** For each extract item, `route_text(doc, item)` returns the matching
   subtree(s), scoped if `scope` is set (e.g. aircraft-section only). Empty
   result → the item falls back to the full flattened document.
2. **Extract.** Send the focused text + the item's question. Quote the passage
   that addresses the topic even if the FCG uses different wording than the field
   name (terminology WILL differ: "LEAD-TIME AND VALIDITY" not "diplomatic
   clearance"). Cover compound fields partially. If the closest passage doesn't
   genuinely address the field, return "NA" rather than quoting loosely related
   text.
3. **Fall back to ancillary (Phase 2).** Fields still NA after FCG go to the
   ICAO-joined MEIS/SVC dossier. Airfield-physical data (runway WBC, ARFF, MOG,
   NOTAMs, BASH) legitimately lives here, not in the FCG — expect these to fill
   in Phase 2, not Phase 1.

## Rules for a weak runtime model

- **Quote, don't paraphrase.** Every answer is verbatim so `validate_extract.py`
  can confirm it appears in the dossier. Paraphrase → fails validation → treated
  as hallucination.
- **NA is a valid, correct answer.** For a workflow item or a fact the document
  doesn't contain, NA is right. Don't stretch.
- **Terminology flexibility, not topic drift.** Match on meaning across different
  wording; do NOT match a vaguely-adjacent passage.
- **Deterministic beats clever.** If a route can fetch the answer's location in
  code, add the route; don't ask the model to find it.

## Feedback loop into the codebase

When an item consistently lands in the phase-1 FALLBACK section (no route hit) or
validation flags its answers, that's a `CODE_GAP:` — the item's `route`/`scope`
in `checklist_enriched.json` is missing the real key name. Fix the route (data,
not code) and note it in CHANGELOG.md. This is how the pipeline stops leaning on
the model guessing where things are.
