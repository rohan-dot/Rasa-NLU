# FCG Checklist Extraction Pipeline

Three-stage LLM pipeline: call transcripts identify which items of a large
FCG checklist matter, those items become an extraction schema, and the schema
is applied to every country's FCG JSON to produce one compliance CSV.

## Architecture principles (do not violate)

1. **Closed-world extraction.** In stage 3 the LLM answers ONLY from the
   dossier text it is given. Missing fact = literal "NA". The LLM is a
   reader/judge, never a source of clearance facts.
2. **Raw data over summaries.** Country dossiers are flattened raw JSON,
   char-capped — never pre-summarized.
3. **No compound questions.** One field = one fact = one question.
   Compound questions historically caused all-NA extractions.
4. **Extract-then-verify.** Stage 1 discovers from an index; stage 2
   re-checks against full item text before anything enters the schema.
5. **Resumable everything.** Stage 3 checkpoints per country
   (`stage3_checkpoint.jsonl`); reruns skip completed countries. Never
   delete checkpoints to "clean up" — that is the resume state.
6. **Deterministic where possible.** Transcript normalization and checklist
   parsing are regex/python-docx first; LLM segmentation is a fallback that
   only segments, never rewrites.

## Layout

```
pipeline/
  config.py               env-driven settings (endpoint, paths, knobs)
  llm_client.py           async OpenAI-compatible client (LiteLLM proxy)
  json_utils.py           three-tier lenient JSON parser
  transcripts.py          .txt/.vtt/.docx -> clean "SPEAKER: text" files
  checklist.py            checklist.docx -> checklist_items.jsonl
  stage1_flag_items.py    transcripts x item index -> stage1_flagged.json
  stage2_verify_schema.py verify + generate stage2_schema.json
  stage3_extract.py       country JSONs x schema -> final CSV
  run_pipeline.py         orchestrator with review gates
data/
  transcripts/            INPUT: raw Zoom transcripts (mixed formats OK)
  checklist/checklist.docx INPUT: the big checklist Word doc
  fcg_countries/          INPUT: one JSON per country
  work/                   checkpoints + intermediates (gitignore-able but
                          KEEP during a run — resume state lives here)
  out/fcg_checklist_extract.csv  FINAL deliverable
```

## Configuration

All via env vars (see `pipeline/config.py`). Most important:

- `FCG_LLM_BASE_URL` (default `http://localhost:4000/v1` — LiteLLM proxy)
- `FCG_LLM_MODEL` (default `claude-opus-4-8`)
- `FCG_CONCURRENCY` (default 4 — raise carefully; LiteLLM rate limits apply)
- `FCG_COUNTRY_DOC_CHAR_CAP` (default 12000)
- Input paths: `FCG_TRANSCRIPTS_DIR`, `FCG_CHECKLIST_DOCX`, `FCG_COUNTRY_DIR`

To repoint at the air-gapped vLLM/Gemma endpoint later: set base URL, model
name, and nothing else changes.

## Workflow (with human review gates)

**No Claude Code needed.** `python agent.py` starts an interactive agent
session: Claude (via the LiteLLM proxy) reads this brief, runs stages
through whitelisted tools, presents gate artifacts, and edits the schema
on request. Guardrails (command whitelist, repo path confinement, y/N
terminal confirmation before stage3) are enforced in Python. The manual
commands below work identically without the agent:

```
python -m pipeline.run_pipeline status       # check what exists
python -m pipeline.run_pipeline preprocess   # transcripts + checklist
        ── GATE 1: review work/checklist_items.jsonl ──
python -m pipeline.run_pipeline stage1
python -m pipeline.run_pipeline stage2
        ── GATE 2: review/edit work/stage2_schema.json ──
python -m pipeline.run_pipeline stage3
```

**Gates are mandatory on first run.** At Gate 1 confirm the checklist split
into sensible items (IDs stable, bodies verbatim). At Gate 2 confirm every
field asks exactly one question and reword anything awkward — this schema
is the contract for the expensive stage-3 run over all countries.

Also review after stage 1: `stage1_flagged.json` contains
`unmatched_mentions` (things discussed on calls that mapped to no item)
and `conflict: true` flags (calls disagreed on priority). Surface both to
the user; they are decisions, not noise.

## Agent conduct rules

- Run stages ONE AT A TIME via `run_pipeline.py`; never bypass it.
- STOP at each gate and present the artifact for review. Do not proceed
  on your own judgment. Do not use `--yes` unless explicitly told to.
- If stage 3 shows `llm_failure` rows: report them, remove those lines
  from `stage3_checkpoint.jsonl`, rerun stage3 (it will retry only those).
- If deterministic checklist parsing under-detects, the LLM fallback runs
  automatically — but flag this to the user at Gate 1, since segmentation
  quality then depends on the model.
- Prefer editing `stage2_schema.json` over editing prompts when field
  results look wrong: reword the question first, rerun stage3 for a few
  test countries, then full run.
- Testing a schema change cheaply: copy 3–5 country JSONs to a temp dir,
  point `FCG_COUNTRY_DIR` at it, run stage3, inspect CSV.
- Deliver complete updated files when modifying code, not diffs.

## Dependencies

`pip install openai python-docx` (see requirements.txt). No pandas needed.
