---
name: fcg-checklist-pipeline
description: Run or debug the FCG checklist extraction pipeline (transcripts -> flagged checklist items -> extraction schema -> per-country CSV). Use this skill whenever the user mentions the checklist pipeline, call transcripts, flagged items, the extraction schema, stage 1/2/3, checklist_items, stage2_schema, the compliance CSV, or asks to process FCG country JSONs against checklist questions — even if they don't say "pipeline" explicitly. Also use it when they report bad extraction results, NA-heavy columns, or want to add/reword schema fields.
---

# FCG Checklist Pipeline Skill

You are driving a three-stage, gate-controlled pipeline. Read `CLAUDE.md`
at the repo root first — it holds the architecture principles and agent
conduct rules. The short version of your job: run one stage, stop at
gates, show the human the gate artifact, wait.

## Stage sequence

| Step | Command | Output to inspect |
|------|---------|-------------------|
| 0 | `python -m pipeline.run_pipeline status` | what exists already |
| 1 | `python -m pipeline.run_pipeline preprocess` | `data/work/checklist_items.jsonl` **GATE** |
| 2 | `python -m pipeline.run_pipeline stage1` | `stage1_flagged.json` (check `unmatched_mentions`, `conflict` flags) |
| 3 | `python -m pipeline.run_pipeline stage2` | `data/work/stage2_schema.json` **GATE** |
| 4 | `python -m pipeline.run_pipeline stage3` | `data/out/fcg_checklist_extract.csv` |

## At each gate

**Gate 1 (checklist items):** show the user item count, first 5 and last 5
items, and any items with suspiciously short/long bodies. Ask: "Do these
boundaries look right?" If deterministic parsing fell back to LLM
segmentation, say so explicitly.

**Gate 2 (schema):** show every field as `field_name — question`. Verify
none are compound (two facts in one question — split them). Invite edits;
apply them directly to `stage2_schema.json`. This file is meant to be
hand-edited.

## Common fixes

- **All-NA column in final CSV** → the question is compound or unanswerable
  from dossier text. Reword in `stage2_schema.json`, test on 3–5 countries
  (point `FCG_COUNTRY_DIR` at a temp dir with copies), then delete
  `stage3_checkpoint.jsonl` ONLY IF a full re-extract is wanted; otherwise
  add a new field and rerun (rows already done keep old fields).
- **`llm_failure` rows** → remove those countries' lines from
  `stage3_checkpoint.jsonl`, rerun stage3.
- **Endpoint errors** → check LiteLLM proxy is up at `FCG_LLM_BASE_URL`;
  json-mode rejection is auto-handled (client falls back).
- **Transcript parsed badly** → check `data/work/transcripts_clean/*.clean.txt`;
  formats supported are .txt/.vtt/.docx.

## Never do

- Never run `all --yes` unless the user explicitly asks to skip gates.
- Never let the LLM supply clearance facts not present in a dossier.
- Never summarize dossiers before extraction; raw flattened JSON only.
- Never delete `data/work/` mid-run; it is resume state.
