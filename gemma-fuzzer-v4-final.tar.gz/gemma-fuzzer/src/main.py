"""
main.py — gemma-fuzzer orchestrator (v4).

Phase 0: Build call graph via tree-sitter (or regex fallback)
Phase 1: Pre-fuzzing — prescan + codebase map + multi-agent pipeline
Phase 2: Fuzzing + continuous strategies + parallel harnesses
Phase 3: Final analysis and summary
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from crash_analyzer import CrashAnalyzer
from fuzzer import LibFuzzerRunner
from llm_client import VLLMClient
from strategies import StrategyOrchestrator
from code_analysis import build_callgraph
from agents import AgentOrchestrator

LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"


def parse_args():
    p = argparse.ArgumentParser(description="gemma-fuzzer orchestrator")
    p.add_argument("--build-dir", required=True)
    p.add_argument("--src-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--seed-dir", default=None)
    p.add_argument("--log-dir", default="/var/log/gemma-fuzzer")
    p.add_argument("--harness", required=True)
    p.add_argument("--vllm-host", default="127.0.0.1")
    p.add_argument("--vllm-port", default="8000")
    p.add_argument("--vllm-model", default="gpt-oss-120b")
    p.add_argument("--fuzz-timeout", type=int, default=3600)
    p.add_argument("--fuzz-jobs", type=int, default=1)
    p.add_argument("--llm-seed-interval", type=int, default=120)
    return p.parse_args()


def setup_logging(log_dir):
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO, format=LOG_FORMAT,
        handlers=[
            logging.StreamHandler(sys.stderr),
            logging.FileHandler(Path(log_dir) / "orchestrator.log"),
        ],
    )


def run_harness_background(harness_bin, output_dir, timeout, log):
    """Run a generated harness in a background thread."""
    name = Path(harness_bin).stem
    crash_dir = Path(output_dir) / "crashes" / name
    corpus_dir = Path(output_dir) / "corpus" / name
    crash_dir.mkdir(parents=True, exist_ok=True)
    corpus_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        harness_bin, str(corpus_dir),
        f"-artifact_prefix={crash_dir}/",
        f"-max_total_time={timeout}",
        "-detect_leaks=0", "-max_len=65536", "-timeout=30",
    ]

    log.info("[harness-bg] Starting: %s (%ds)", name, timeout)
    try:
        env = os.environ.copy()
        env["ASAN_OPTIONS"] = "abort_on_error=1:symbolize=1:detect_leaks=0"
        subprocess.run(cmd, capture_output=True, timeout=timeout + 30, env=env)

        pov_dir = Path(output_dir) / "povs"
        for cf in crash_dir.glob("crash-*"):
            shutil.copy2(cf, pov_dir / f"{name}-{cf.name}")
            log.info("[harness-bg] *** CRASH from %s: %s ***", name, cf.name)
    except subprocess.TimeoutExpired:
        log.info("[harness-bg] %s finished (timeout).", name)
    except Exception as exc:
        log.error("[harness-bg] %s failed: %s", name, exc)


def main():
    args = parse_args()
    setup_logging(args.log_dir)
    log = logging.getLogger("gemma-fuzzer")

    log.info("=" * 60)
    log.info("gemma-fuzzer v4.0 (tree-sitter + parallel agents)")
    log.info("  harness:      %s", args.harness)
    log.info("  build_dir:    %s", args.build_dir)
    log.info("  src_dir:      %s", args.src_dir)
    log.info("  fuzz_timeout: %ds", args.fuzz_timeout)
    log.info("  vllm:         %s:%s (%s)", args.vllm_host, args.vllm_port, args.vllm_model)
    log.info("=" * 60)

    output_dir = Path(args.output_dir)
    pov_dir = output_dir / "povs"
    corpus_dir = output_dir / "corpus"
    crash_dir = output_dir / "crashes"
    for d in [pov_dir, corpus_dir, crash_dir]:
        d.mkdir(parents=True, exist_ok=True)

    # ── Initialize components ─────────────────────────────────────

    llm = VLLMClient(args.vllm_host, args.vllm_port, args.vllm_model)
    analyzer = CrashAnalyzer(llm, args.src_dir, args.output_dir)
    strategies = StrategyOrchestrator(
        llm, args.src_dir, args.build_dir, args.output_dir, args.harness,
    )
    runner = LibFuzzerRunner(
        args.build_dir, args.harness, str(corpus_dir),
        str(crash_dir), args.seed_dir, args.fuzz_jobs,
    )

    # ══════════════════════════════════════════════════════════════
    # PHASE 0: BUILD CALL GRAPH
    # ══════════════════════════════════════════════════════════════

    log.info("╔══════════════════════════════════════════════════╗")
    log.info("║  PHASE 0: Building Call Graph                    ║")
    log.info("╚══════════════════════════════════════════════════╝")

    call_graph = build_callgraph(args.src_dir)
    log.info(call_graph.to_summary())

    # ══════════════════════════════════════════════════════════════
    # PHASE 1: PRE-FUZZING ANALYSIS
    # ══════════════════════════════════════════════════════════════

    log.info("╔══════════════════════════════════════════════════╗")
    log.info("║  PHASE 1: Pre-Fuzzing LLM Analysis              ║")
    log.info("╚══════════════════════════════════════════════════╝")

    # Strategy round 1: prescan + codebase map + audit + seeds
    pre_results = strategies.run_round(str(corpus_dir))
    for r in pre_results:
        log.info("  [pre-fuzz] %s: %d findings (%.1fs)",
                r.strategy_name, r.findings, r.elapsed)

    # Multi-agent pipeline
    if len(call_graph.functions) > 0:
        log.info("╔══════════════════════════════════════════════════╗")
        log.info("║  Multi-Agent Pipeline                            ║")
        log.info("╚══════════════════════════════════════════════════╝")

        agent_orch = AgentOrchestrator(
            llm, call_graph, args.src_dir, args.output_dir,
            fuzz_seconds=min(120, args.fuzz_timeout // 4),
        )
        pipeline_result = agent_orch.run_pipeline(
            max_scan_targets=8, max_exploit_targets=3,
        )

        # Collect generated harnesses for background fuzzing
        for h in agent_orch.generated_harnesses:
            strategies.generated_harnesses.append(h)

        # Feed crashes to strategy engine
        for exploit in agent_orch.all_exploits:
            if exploit.crashed:
                strategies.add_crash(
                    f"{exploit.finding.bug_type}: {exploit.finding.description}",
                    {"crash_type": exploit.finding.bug_type,
                     "affected_function": exploit.finding.function,
                     "root_cause": exploit.finding.description},
                )

        log.info("[pipeline] Results: %s",
                json.dumps(pipeline_result) if pipeline_result else "none")
    else:
        log.warning("Empty call graph — skipping multi-agent pipeline.")

    # ══════════════════════════════════════════════════════════════
    # PHASE 2: FUZZING + CONTINUOUS STRATEGIES
    # ══════════════════════════════════════════════════════════════

    log.info("╔══════════════════════════════════════════════════╗")
    log.info("║  PHASE 2: Fuzzing + Continuous Strategies       ║")
    log.info("╚══════════════════════════════════════════════════╝")

    runner.start(duration=args.fuzz_timeout)
    log.info("LibFuzzer launched for %d seconds.", args.fuzz_timeout)

    # Start generated harnesses in background
    threads = []
    for h in strategies.get_generated_harnesses():
        t = threading.Thread(
            target=run_harness_background,
            args=(h, args.output_dir, args.fuzz_timeout, log),
            daemon=True,
        )
        t.start()
        threads.append(t)

    # Main loop
    crashes_processed = 0
    last_strategy = time.monotonic()

    while runner.is_running():
        time.sleep(5)

        # Process crashes from main fuzzer
        for crash in runner.get_new_crashes(since_idx=crashes_processed):
            log.info("CRASH: %s (%s)", crash.crash_type, crash.crash_file)
            report = analyzer.analyze_crash(crash.crash_file, crash.stack_trace)
            if crash.crash_file and Path(crash.crash_file).exists():
                shutil.copy2(crash.crash_file, pov_dir / Path(crash.crash_file).name)
            summary = crash.crash_type
            if report and report.get("root_cause"):
                summary = f"{crash.crash_type}: {report['root_cause']}"
            strategies.add_crash(summary, report)
            crashes_processed += 1

        # Periodic strategy rounds
        now = time.monotonic()
        if (now - last_strategy) >= args.llm_seed_interval:
            strategies.run_round(str(corpus_dir))
            last_strategy = now

    # ══════════════════════════════════════════════════════════════
    # PHASE 3: FINAL ANALYSIS
    # ══════════════════════════════════════════════════════════════

    log.info("╔══════════════════════════════════════════════════╗")
    log.info("║  PHASE 3: Final Analysis                        ║")
    log.info("╚══════════════════════════════════════════════════╝")

    runner.wait()

    for crash in runner.get_new_crashes(since_idx=crashes_processed):
        analyzer.analyze_crash(crash.crash_file, crash.stack_trace)
        if crash.crash_file and Path(crash.crash_file).exists():
            shutil.copy2(crash.crash_file, pov_dir / Path(crash.crash_file).name)

    for t in threads:
        t.join(timeout=10)

    # Summary
    total_crashes = len(runner.state.crashes)
    total_povs = len(list(pov_dir.glob("*")))
    total_bugs = len(list((output_dir / "bugs").glob("*"))) if (output_dir / "bugs").exists() else 0
    total_seeds = len(list((output_dir / "seeds").glob("*"))) if (output_dir / "seeds").exists() else 0
    total_harnesses = len(strategies.get_generated_harnesses())

    log.info("=" * 60)
    log.info("gemma-fuzzer v4.0 — FINAL RESULTS")
    log.info("  Total executions:      %d", runner.state.total_execs)
    log.info("  Unique crashes:        %d", total_crashes)
    log.info("  PoVs:                  %d", total_povs)
    log.info("  Bug reports:           %d", total_bugs)
    log.info("  LLM-generated seeds:   %d", total_seeds)
    log.info("  Generated harnesses:   %d", total_harnesses)
    log.info("  Strategy rounds:       %d", strategies.round_number)
    log.info("")
    log.info("Strategy breakdown:")
    for r in strategies.results_log:
        log.info("  %-20s  %3d findings  (%5.1fs)",
                r.strategy_name, r.findings, r.elapsed)
    log.info("=" * 60)


if __name__ == "__main__":
    main()
