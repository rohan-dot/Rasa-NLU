"""
llm_client.py — Direct vLLM client (no LiteLLM).

Talks to vLLM's OpenAI-compatible /v1/chat/completions endpoint.
Falls back gracefully if the LLM is unreachable (fuzzing continues
without LLM guidance).
"""

from __future__ import annotations

import logging
import time
from openai import OpenAI

logger = logging.getLogger("gemma-fuzzer.llm")


class VLLMClient:
    """Thin wrapper around vLLM's OpenAI-compatible API."""

    def __init__(self, host: str, port: str, model: str):
        self.model = model
        self.base_url = f"http://{host}:{port}/v1"
        self.client = OpenAI(
            api_key="not-needed",       # vLLM doesn't require a key
            base_url=self.base_url,
        )
        self._available: bool | None = None
        logger.info("vLLM client configured: %s  model=%s", self.base_url, model)

    # ── health check ──────────────────────────────────────────────
    def is_available(self) -> bool:
        """Check if vLLM is reachable. Caches after first success."""
        if self._available is True:
            return True
        try:
            self.client.models.list()
            self._available = True
            logger.info("vLLM is reachable.")
            return True
        except Exception as exc:
            logger.warning("vLLM unreachable (%s). LLM features disabled.", exc)
            self._available = False
            return False

    # ── chat completion ───────────────────────────────────────────
    def chat(
        self,
        system: str,
        user: str,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> str | None:
        """Send a chat completion request. Returns None on failure."""
        if not self.is_available():
            return None
        try:
            t0 = time.monotonic()
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
            )
            elapsed = time.monotonic() - t0
            text = resp.choices[0].message.content
            logger.debug("LLM response (%0.1fs, %d chars)", elapsed, len(text or ""))
            return text
        except Exception as exc:
            logger.error("LLM request failed: %s", exc)
            return None
