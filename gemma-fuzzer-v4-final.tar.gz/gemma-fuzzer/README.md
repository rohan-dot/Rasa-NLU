# gemma-fuzzer

An LLM-guided LibFuzzer CRS for [OSS-CRS](https://github.com/ossf/oss-crs).

Uses your vLLM model to enhance fuzzing with:
- **Crash analysis** — ASAN stack traces sent to the LLM for triage, root-cause analysis, and CWE classification.
- **Seed generation** — The LLM periodically suggests new seed inputs targeting unexplored code paths.
- **Graceful degradation** — If vLLM is unreachable, fuzzing continues normally without LLM features.

## Two Modes

| | Standalone | OSS-CRS (Docker) |
|---|---|---|
| **Use when** | No Docker access | Full OSS-CRS orchestration |
| **Entry point** | `./run_standalone.sh` | `uv run oss-crs run` |
| **Target build** | Manual (`clang -fsanitize=...`) or `./build_target.sh` | Automatic via OSS-CRS |
| **Artifacts** | Local `./output/` directory | `uv run oss-crs artifacts` |
| **Same Python code?** | Yes | Yes |

---

## Standalone Mode (no Docker)

### Prerequisites

- Python 3.10+
- clang (with ASAN/LibFuzzer support)
- vLLM running on localhost:8000 (optional)

### Step 1: Build a target

**Option A — use the helper script (supported projects):**
```bash
sudo apt install clang libxml2-dev
chmod +x build_target.sh
./build_target.sh ~/oss-fuzz/projects/libxml2
```

**Option B — manual build (any project):**
```bash
clang -g -O1 -fsanitize=address,fuzzer \
    -I/usr/include/libxml2 \
    ~/oss-fuzz/projects/libxml2/xml_read_memory_fuzzer.c \
    -lxml2 -lz -llzma \
    -o xml_fuzzer
```

### Step 2: Run

```bash
chmod +x run_standalone.sh

# Basic
./run_standalone.sh ./build/libxml2/xml_read_memory_fuzzer

# With options
./run_standalone.sh ./build/libxml2/xml_read_memory_fuzzer \
    --src-dir ~/oss-fuzz/projects/libxml2 \
    --timeout 600 \
    --vllm-model gpt-oss-120b
```

### Step 3: Check results

```bash
ls output/xml_read_memory_fuzzer/povs/     # crash-triggering inputs
ls output/xml_read_memory_fuzzer/bugs/     # LLM-generated bug reports (JSON)
cat output/xml_read_memory_fuzzer/logs/orchestrator.log
```

---

## OSS-CRS Mode (Docker — for your coworker)

### Prerequisites

- Docker >= 20.10 (with socket access)
- Python 3.10+, uv, Git
- vLLM accessible from Docker containers

### Important: vLLM host binding

vLLM must bind to `0.0.0.0` (not `127.0.0.1`) so Docker containers can reach it:
```bash
CUDA_VISIBLE_DEVICES=0,1 \
python -m vllm.entrypoints.openai.api_server \
    --model /path/to/model \
    --served-model-name gpt-oss-120b \
    --dtype bfloat16 \
    --tensor-parallel-size 2 \
    --gpu-memory-utilization 0.85 \
    --max-model-len 8192 \
    --host 0.0.0.0 --port 8000
```

### Find Docker bridge IP (Linux)

```bash
ip addr show docker0 | grep inet
# typically 172.17.0.1 — update VLLM_HOST in oss-crs/crs.yaml if different
```

### Run

```bash
git clone https://github.com/ossf/oss-crs.git ~/oss-crs
git clone https://github.com/google/oss-fuzz.git ~/oss-fuzz
cd ~/oss-crs

uv run oss-crs prepare \
    --compose-file /path/to/gemma-fuzzer/compose.yaml

uv run oss-crs build-target \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2

uv run oss-crs run \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2 \
    --target-harness xml \
    --timeout 600

uv run oss-crs artifacts \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2 \
    --target-harness xml
```

---

## Configuration

| Variable | Standalone default | Docker default | Description |
|----------|-------------------|----------------|-------------|
| `VLLM_HOST` | `127.0.0.1` | `172.17.0.1` | vLLM server hostname |
| `VLLM_PORT` | `8000` | `8000` | vLLM server port |
| `VLLM_MODEL` | `gpt-oss-120b` | `gpt-oss-120b` | Model name in vLLM |
| `FUZZ_TIMEOUT` | `3600` | `3600` | Fuzzing duration (seconds) |
| `FUZZ_JOBS` | `1` | `1` | Parallel LibFuzzer workers |
| `LLM_SEED_INTERVAL` | `120` | `120` | Seconds between LLM seed rounds |

---

## Project Structure

```
gemma-fuzzer/
├── run_standalone.sh               # YOUR entry point (no Docker)
├── build_target.sh                 # Helper: build OSS-Fuzz targets locally
├── src/                            # Shared Python code (both modes)
│   ├── main.py                     # Orchestrator
│   ├── llm_client.py               # Direct vLLM client
│   ├── fuzzer.py                   # LibFuzzer management
│   ├── crash_analyzer.py           # LLM crash analysis + seed gen
│   └── requirements.txt
├── oss-crs/                        # COWORKER's entry point (Docker)
│   ├── crs.yaml
│   ├── build.hcl
│   ├── asan-builder.Dockerfile
│   └── docker-compose/
│       ├── fuzzer.Dockerfile
│       └── run-fuzzer.sh
├── bin/compile_target
├── compose.yaml
├── litellm-config.example.yaml
└── README.md
```

## License

MIT
