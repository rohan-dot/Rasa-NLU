#!/bin/bash
# build_target.sh — Build an OSS-Fuzz target locally (no Docker needed).
#
# This script automates the manual build process for common OSS-Fuzz projects.
# It uses clang with ASAN + LibFuzzer instrumentation.
#
# Usage:
#   ./build_target.sh <oss-fuzz-project-dir> [harness_name]
#
# Examples:
#   # Build libxml2 (auto-detects harnesses)
#   ./build_target.sh ~/oss-fuzz/projects/libxml2
#
#   # Build a specific harness
#   ./build_target.sh ~/oss-fuzz/projects/libxml2 xml
#
#   # Build cjson
#   ./build_target.sh ~/oss-fuzz/projects/cjson
#
# Output: ./build/<project_name>/<harness_binary>

set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Usage: $0 <oss-fuzz-project-dir> [harness_filter]"
    echo ""
    echo "Supported projects (auto-build):"
    echo "  libxml2, cjson, zlib, libpng, libtiff"
    echo ""
    echo "For unsupported projects, you'll need to build manually."
    echo "This script will still show you the general approach."
    exit 1
fi

PROJECT_DIR="$(realpath "$1")"
HARNESS_FILTER="${2:-}"
PROJECT_NAME="$(basename "$PROJECT_DIR")"
BUILD_OUT="$(pwd)/build/${PROJECT_NAME}"

mkdir -p "$BUILD_OUT"

# Compiler settings
export CC="${CC:-clang}"
export CXX="${CXX:-clang++}"
FUZZ_FLAGS="-g -O1 -fsanitize=address,fuzzer"
FUZZ_LINK_FLAGS="-fsanitize=address,fuzzer"
NOFUZZ_FLAGS="-g -O1 -fsanitize=address -fsanitize=fuzzer-no-link"

echo "============================================="
echo " Building: $PROJECT_NAME"
echo " From:     $PROJECT_DIR"
echo " Output:   $BUILD_OUT"
echo " CC:       $CC"
echo "============================================="

# ── Project-specific build logic ──────────────────────────────────

case "$PROJECT_NAME" in

    libxml2)
        echo "[build] libxml2 — using system libxml2-dev"
        echo "[build] Install deps: sudo apt install libxml2-dev"

        for harness_src in "$PROJECT_DIR"/*_fuzzer.c "$PROJECT_DIR"/*_fuzzer.cc; do
            [ -f "$harness_src" ] || continue
            name="$(basename "${harness_src%.*}")"

            if [ -n "$HARNESS_FILTER" ] && [[ "$name" != *"$HARNESS_FILTER"* ]]; then
                continue
            fi

            echo "[build] Compiling: $name"
            $CC $FUZZ_FLAGS \
                -I/usr/include/libxml2 \
                "$harness_src" \
                -lxml2 -lz -llzma -lm \
                -o "$BUILD_OUT/$name" 2>&1 || {
                echo "[build] FAILED: $name (may need additional -I or -l flags)"
                continue
            }
            echo "[build] OK: $BUILD_OUT/$name"
        done
        ;;

    cjson|cJSON)
        echo "[build] cJSON — building from source in project dir"
        CJSON_SRC="$PROJECT_DIR"

        # cJSON is typically header-only or single .c file
        for harness_src in "$PROJECT_DIR"/*_fuzzer.c "$PROJECT_DIR"/*fuzzer*.c; do
            [ -f "$harness_src" ] || continue
            name="$(basename "${harness_src%.*}")"

            if [ -n "$HARNESS_FILTER" ] && [[ "$name" != *"$HARNESS_FILTER"* ]]; then
                continue
            fi

            echo "[build] Compiling: $name"
            $CC $FUZZ_FLAGS \
                -I"$CJSON_SRC" \
                "$harness_src" \
                -lm \
                -o "$BUILD_OUT/$name" 2>&1 || {
                echo "[build] FAILED: $name"
                continue
            }
            echo "[build] OK: $BUILD_OUT/$name"
        done
        ;;

    *)
        echo "[build] No auto-build recipe for '$PROJECT_NAME'."
        echo ""
        echo "Manual build steps:"
        echo ""
        echo "  1. Build the library with ASAN (no fuzzer yet):"
        echo "     export CC=clang"
        echo "     export CFLAGS=\"$NOFUZZ_FLAGS\""
        echo "     cd <library-source> && ./configure && make"
        echo ""
        echo "  2. Compile the harness with LibFuzzer + link the library:"
        echo "     clang $FUZZ_FLAGS \\"
        echo "         -I<library-headers> \\"
        echo "         $PROJECT_DIR/<harness>.c \\"
        echo "         -L<library-build> -l<library> \\"
        echo "         -o $BUILD_OUT/<harness>"
        echo ""
        echo "  3. Run with gemma-fuzzer:"
        echo "     ./run_standalone.sh $BUILD_OUT/<harness>"
        echo ""

        # List available harness source files
        echo "Harness files found in project dir:"
        find "$PROJECT_DIR" -name "*fuzz*" -o -name "*harness*" | head -20 || true
        exit 0
        ;;
esac

# ── Copy seed corpora if present ──────────────────────────────────
for corpus in "$PROJECT_DIR"/*_seed_corpus* "$PROJECT_DIR"/seeds "$PROJECT_DIR"/corpus; do
    [ -e "$corpus" ] || continue
    echo "[build] Copying seed corpus: $(basename "$corpus")"
    cp -r "$corpus" "$BUILD_OUT/" 2>/dev/null || true
done

# ── Copy dictionaries if present ──────────────────────────────────
for dict in "$PROJECT_DIR"/*.dict; do
    [ -f "$dict" ] || continue
    echo "[build] Copying dictionary: $(basename "$dict")"
    cp "$dict" "$BUILD_OUT/"
done

# ── Summary ───────────────────────────────────────────────────────
echo ""
echo "Build complete. Harness binaries:"
find "$BUILD_OUT" -maxdepth 1 -type f -executable | while read -r bin; do
    echo "  $bin"
done

echo ""
echo "Run with:"
echo "  ./run_standalone.sh $BUILD_OUT/<harness_name>"
