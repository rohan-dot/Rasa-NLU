// build.hcl — Docker buildx bake for gemma-fuzzer
// Context ".." = project root (gemma-fuzzer/) so COPY commands
// in the Dockerfile can find src/ and oss-crs/

group "default" {
  targets = ["gemma-fuzzer-base"]
}

target "gemma-fuzzer-base" {
  context    = ".."
  dockerfile = "oss-crs/docker-compose/fuzzer.Dockerfile"
  tags       = ["gemma-fuzzer-base:latest"]
}
