# Task 00 — map the code and the evidence (read-only)

## Map
This task makes NO edits. Its finish() summary becomes MAP.md and is given to every later task, so make it precise:
file:line for everything, nothing from memory.

## Study first
The results root holds the runs: `latest/` (the most recent real run — the one that executed the CURRENT src/, so its
log is the ground truth for what the current code does, including any `[<module>] failed:` lines from wrapped modules)
and `prev*/` (earlier runs). `latest/` is STAGED: read `latest/STAGED.md` or `latest/INVENTORY.txt` (every file of the raw run with size, mtime, path) FIRST and in full. Layout: flat copies of the discver log dir
at the top (`orchestrator.log`, `libcrs-pov.log`, `libcrs-seed.log`, `crs-bug-candidate.log`, `static_findings.json`); the
raw oss-crs run directories under `latest/run/{LOG_DIR,SHARED_DIR,SUBMIT_DIR,REBUILD_OUT_DIR}` (text files only); EVERY
file of those dirs, binaries included, in `latest/*_listing.txt` (size, mtime, path — REBUILD_OUT_DIR is what
apply-patch-build produced, SUBMIT_DIR what was submitted); the container's `/output` dirs by name when present
(`patches/`, `povs/`, `generated_harnesses/`, `bugs/`, `crashes/`, `health.json`, `REPORT.md`, `report_run_*.md`); the
validation cache at `latest/patches/validation/<id>/`; a hex dump of every PoV / crash input in `latest/hex/`. Grep, then
read only the matching lines:
- latest: `grep -nE "fuzz thresholds|probe |deep phase|keep_going|no-op|noop|saturated, not no-op|seeds|\[seeds\]|\[dict\]|\[harness_reach\]|failed:|NEW CRASH|stopped|FINAL RESULTS|run health|\[(DEAD|WEAK|HEALTHY)\]|SATURATED|patch-turn|llm-call|BUG_IN_DEPENDENCY|diff_mismatch|build oracle path|SIDECAR|\[sidecar\]|candidate patch|run-pov|rebuild|Client Error|harness-discovery|compile failed|source harnesses found|candidates ranked|harness-gen|llm-adapt|persist\]|Validated patches|Unvalidated patches"` over `latest/orchestrator.log`;
  read `latest/health.json` and `latest/patches/patch_index.json` in full if present; `latest/report_run_*.md` lines 1–200;
  every `latest/*_listing.txt`; `list_files latest/run/SUBMIT_DIR` and `latest/run/SHARED_DIR` and read the small text
  files there (what the CRS exchanged and submitted); every file in `latest/hex/` (which reproducers exist and which are 0-byte);
  `latest/libcrs-pov.log` and `latest/libcrs-seed.log` (the sidecar's own view — a 0-byte file means it never ran anything).
  Mirrored output dirs (discver copies /output here at the end of the run): read `latest/patches/` in full (what survived
  of the fix loop), every source in `latest/generated_harnesses/` plus any probe/compile log next to it, `latest/unique_bugs/`,
  and the `.txt` traces in `latest/crashes/`.
  REBUILD_OUT_DIR is the tree apply-patch-build produced: `grep -i "x509utils\|build\.log\|\.log$\|\.java$" latest/rebuild_out_listing.txt`;
  read any build log found there; if `X509Utils.java` is present, read its lines 70–100 and quote the guard the patch
  added (compare with the original lines quoted in the `[patch-turn] … read_source` entries of orchestrator.log). The mtime
  of `X509Utils.class` against the apply-patch-build timestamp says whether the rebuild compiled the patched source.
  Quote every `[<module>] failed: <error>` line verbatim — each one is a shipped change that died at runtime — and
  every `[sidecar] cmd=[…] exit=<n>` line with its stderr tail: those are the oracle's actual answers.
- prev: the same grep over `prev*/orchestrator.log`; `prev*/patches/patch_index.json` in full.
- CRSBench evidence, if a `crsbench_*/` folder exists in the results root (alongside `latest/`): `experiment.yaml`
  (which problems, budgets, timeouts), `csv/*.csv` (the outcome per problem — read the header, find the hit/miss/score
  and timing columns), `logs/` and `support/` (runner side), and `orchestrator_logs/*.txt` — ONE discver run per
  benchmark problem. For EVERY log: `grep -nE "Target language|harnesses: provided|FINAL RESULTS|Confirmed crashes:|LLM analysis findings|Validated patches|Unvalidated patches|Overall:|\[submit|arbiter|held|patch\[|SIDECAR|\] failed:"`
  and build a table problem × (language, harnesses, confirmed crashes, LLM findings, held/overruled, patches, health,
  csv outcome, wall time). Name every problem where the csv says miss but the log shows a triage-VALID or
  arbiter-overruled finding — those are the strictness losses; and every problem that ended by timeout before the fix
  loop. Put this table in MAP.md under "CRSBench evidence".
Repo (root=repo), grep then read the matching functions:
- fuzzer launch: `jazzer|-fork|max_total_time|artifact_prefix|keep_going|ignore_crashes|run_fuzzer|runs/|subprocess|Popen`
- probe / deep phase, if present: `probe|deep|keep_going|DEDUP_TOKEN|saturat`
- no-op detector: `noop|no-op|flat|uninstrumented`
- seeds: `seed|corpus|pb_seeds|DISCVER_WIRE_SEEDS|dict`
- stats / health: `exec/s|execs|cov:|HEALTHY|WEAK|DEAD|SATURATED|peak coverage|liveness`
- harness generation: `GenFuzzer|SinkFuzzer|generate_harness|bug_swarm|fuzzerTestOneInput|javac`
- patch loop: `json\.loads|parse|apply_edit|test_patch|read_source|max_iter|attempts|root_cause|static-|patch-turn|llm-call`
- oracle / sidecar (do-not-touch zone): `_get_crash_signature|apply-patch-build|run-pov|run-test|SIDECAR|ContainerPatchBuilder`
- the LLM client used by the patch loop and by seed generation (shared or separate?)
Then `run`: `python -m py_compile src/*.py && python -m pytest -q tests 2>&1 | tail -15` (baseline; do not fix anything).

## Deliverable (finish summary — this exact structure)
```
CODE MAP
fuzzer launch:      <file:line of the function that builds the fuzzer command; in src/ or an external script? exact flags it passes>
probe / deep phase: <present? file:line; is the deep phase reachable from the normal run path? if not, what stops it?>
no-op detector:     <file:line; the exact condition; does it check crashes? the startup line it prints>
stats parsing:      <file:line that parses exec/cov lines; where exec rate is computed>
health checker:     <file:line that decides DEAD/WEAK/HEALTHY and emits the SATURATED verdict>
seeds:              <file:line generating LLM seeds; file:line writing them to a corpus dir; which dir the runner reads; how the harness consumes input (FuzzedDataProvider calls?)>
harness generation: <file:line of the generator; how a generated harness is compiled and launched; where its launch command is built (src/ or external)>
harness selection:  <file:line choosing primary vs background harnesses; budget split>
patch loop:         <file:line of the agent loop; prompt builder; reply parser (the json.loads/regex line); what happens on parse failure; attempts counter; max iterations; static-* handling; what fills root_cause>
LLM client:         <file:line; shared between patch loop and seeds? timeouts/max_tokens>
sidecar/oracle:     <file:line of ContainerPatchBuilder/sidecar calls and crash_dedup._get_crash_signature>  (DO NOT TOUCH)
dead/duplicate paths: <any second implementation of a stage that is NOT what the orchestrator calls>
TESTS
baseline:           <exact last lines of pytest: N passed / N failed, names of pre-existing failures>
test style:         <pytest? fixtures? how existing tests fake the LLM/fuzzer, with file:line to copy>
EVIDENCE
latest:             <one line per harness: execs, cov a→b, corpus a→b, verdict; the 3–5 log lines around any stop; every `[<module>] failed:` line verbatim; which of the expected new log lines (fuzz thresholds … AND no observed crashes / seeds mined= / dict / [lead] / [replay] / harnesses: provided=) are present and which are absent>
prev:               <one line per harness; one line per patch_index entry: crash_id, status, attempts, test_calls, skip_cause, reason verbatim>
<[patch-turn] / [llm-call] lines present? yes/no with counts, both runs>
```
