# Task 59 — turn triage-VALID static/LLM findings into PoV-backed ones: directed confirmation

## Condition
Only if `src/lang/__init__.py` exists (task 51). Uses the strategy plan (task 56) and KB input shapes (task 55) when
present; works without them with a plain seed generator.

## Goal
Latest runs end with findings that are `triage-VALID, NOT PoV-backed / NOT fuzz-confirmed` and are never fuzzed toward.
Add a bounded confirmation stage after the primary deep phase: for each triage-VALID finding with confidence ≥
`DISCVER_CONFIRM_MIN_CONFIDENCE` (default 0.67), in descending confidence, up to `DISCVER_CONFIRM_BUDGET_PCT` (default 15)
percent of the total fuzz budget:
1. find a harness that reaches the finding's function — an existing harness whose coverage report (probe) lists it,
   else the highest-ranked entry point (task 19/36) from which the call graph reaches it within 4 edges, generating a
   harness through the existing gated path;
2. seed it toward the sink: format-aware seeds for the function's parameter types, the KB's input shapes for that CWE
   when available, the libFuzzer dictionary plus the finding's string literals;
3. run a directed slice (`-max_total_time` = the finding's share; `-focus_function` when the engine supports it);
4. a crash whose signature's top project frame is the finding's function (or within 2 frames) promotes the finding to
   PoV-backed with the reproducer, logged `[confirm] <id> CONFIRMED by <harness> after <execs> execs → PoV <path>`;
   otherwise `[confirm] <id> not confirmed (<execs> execs, cov <a>→<b>, reach=<yes|no>)` and the finding stays as it was.
Verdicts are never loosened: a non-crashing slice changes nothing; a crash is deduped and confirmed exactly like any other.

## Study first
- CRSBench logs (`crsbench_*/orchestrator_logs/*.txt`): for the problems scored as misses, which held findings name a
  function that an existing harness's `coverage_report` reached — those are the confirmations this stage would have
  attempted; count them and the fuzz budget that was left unused at the end of those runs.
- where the deep phase ends and the fix loop starts (`main.py`), the budget accounting, the probe's coverage report per
  harness, `rank_entry_points`, the seed generator (task 12/13), the gate for generated harnesses (16/17).

## Change (src/confirm_findings.py + one call site)
- The stage above, with the budget guard and per-finding accounting written to `/output/confirm/<id>.json`; summary
  line `Confirmation: <n> tried, <k> confirmed, <m> unreachable, budget <s>s`.
- Safety: wrapped; `[confirm] failed: <error>` → the run proceeds to the fix loop as today.

## Tests to add (tests/test_confirm_findings.py) — fakes (fake coverage reports, fake runner that crashes on cue)
- a reachable finding with a crash in its function → CONFIRMED, PoV recorded, dedup called once; a crash elsewhere →
  not confirmed; unreachable → skipped with the line; budget cap honoured across three findings; disabled when below
  the confidence threshold; the summary counts.

## Acceptance
```
python -m pytest -q tests/test_confirm_findings.py
```

## Do not touch
Crash dedup/confirmation semantics, health verdicts, the fix loop, sidecar; anything outside src/ and tests/.
