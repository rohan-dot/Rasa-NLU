# Task 50 — map every Java-bound function in discver to the language-adapter method it belongs to

## Goal
discver is being made language-agnostic (C, C++, Go, Rust, Python, Java) behind a `LanguageAdapter` interface. This task
produces the map that the extraction (task 51) follows: `src/lang/COUPLING_MAP.md` — one row per Java/Jazzer-bound
function: `file:line | function | adapter method | what it assumes | C/C++ | Go | Rust | Python equivalent`.
Adapter methods: `detect`, `fuzz_engines`, `launch_argv`, `parse_stats`, `parse_crash` (type, frames, signature),
`harness_discover`, `harness_compile`, `harness_synthesize`, `coverage_probe`, `static_scanners`, `seed_shapes`,
`patch_context`. A second section lists modules that are already language-free.

## Study first
- repo: `grep -rn -i "jazzer\|--cp=\|target_class\|javac\|\.java\b\|fuzzerTestOneInput\|FuzzedDataProvider\|tree_sitter_java\|tree-sitter-java\|\bat [a-z]\+\.\|LDAP\|JNDI\|XXE\|Deserialization\|coverage_report\|\.jar\b\|JAVA_HOME\|ClassNotFound\|StackOverflow\|IndexOutOfBounds" src/ | grep -v "^src/lang/"` —
  every hit is either mapped or explained as a comment/string that does not bind behaviour.
- MAP.md for the stage each hit belongs to.

## Change (src/lang/COUPLING_MAP.md only — this task writes one file and no code)
- The table above, complete: the header states the grep used and the number of hits; every behaviour-binding hit has a row.
- Section "already language-free": orchestrator phases, probe/health thresholds, dedup logic shape, patch loop, sidecar,
  persistence, check_run — each with file:line evidence that nothing Java-specific is inside.
- Section "shared libFuzzer family": which of today's Jazzer launch flags are plain libFuzzer flags (`-max_total_time`,
  `-dict`, `-artifact_prefix`, `-print_final_stats`, corpus dirs) and which are Jazzer-only (`--cp`, `--target_class`,
  `--keep_going`, agent path) — this becomes the shared launcher in task 51.

## Tests to add (tests/test_language_coupling_map.py)
- the file exists, has ≥ 25 table rows, every `file:line` in it points at an existing file and a line that contains the
  named function or a call to it, and every adapter method name appears at least once.

## Acceptance
```
python -m pytest -q tests/test_language_coupling_map.py
```

## Do not touch
Any `.py` file; anything outside src/ and tests/.
