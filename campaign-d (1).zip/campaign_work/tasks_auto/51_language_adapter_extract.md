# Task 51 — extract `LanguageAdapter` with Java as the only implementation and a shared libFuzzer-family launcher — zero behaviour change

## Goal
Create `src/lang/` (interface + registry) and `src/lang/java.py`, move every Java-bound function from
`src/lang/COUPLING_MAP.md` (task 50) behind the interface, and switch the call sites to `adapter.<method>()`. The fuzzer
launch becomes one shared path: libFuzzer-family flags (corpus dirs, `-max_total_time`, `-dict`, `-artifact_prefix`,
`-print_final_stats`, `-timeout`, `-rss_limit_mb`) built once, with the adapter contributing only its engine-specific
part (for Java: `--cp`, `--target_class`, `--keep_going`, the agent path). Nothing a Java run prints or executes may
change: the proof is a golden test captured BEFORE the first edit.

## Study first
- `src/lang/COUPLING_MAP.md` (if task 50 did not land, build the map yourself first from the same grep).
- results: `latest/run/LOG_DIR/auto/discver/crashes/` — copy 2–3 real Jazzer trace `.txt` files into
  `tests/fixtures/java/` as golden inputs for crash parsing/signatures; the launch command printed at
  `Actual command (latest:188)` in MAP.md; the harness-discovery lines.

## Change (src/)
- Step 1, before any move: write `tests/test_lang_java_golden.py` that, with the existing fakes, records the launch argv
  for a fake build dir, the harness-discovery log lines, the crash signatures of the fixture traces, the probe command and
  the health block text — as literal expected values in the test — and run it green on the current code.
- Step 2: `src/lang/__init__.py` (`LanguageAdapter` abstract methods per the map, `get_adapter(name)`, `REGISTRY`),
  `src/lang/base.py` (shared libFuzzer-family launcher/stats parsing), `src/lang/java.py` (moved code, unchanged logic).
  Call sites import the adapter; the orchestrator holds one `adapter` for the run (`java` hard-selected for now — task 53
  adds detection).
- Step 3: the golden test still passes byte-for-byte; the full suite stays at baseline.
- Safety: `get_adapter` failure → `[lang] failed: <error>` and the Java adapter is used.

## Tests to add
- `tests/test_lang_java_golden.py` (above) and `tests/test_lang_registry.py` (registry returns the Java adapter; every
  abstract method is implemented by it; the shared launcher composes flags in a stable order).

## Acceptance
```
python -m pytest -q tests/test_lang_java_golden.py tests/test_lang_registry.py
```

## Do not touch
Any log line or argv a Java run produces (the golden test enforces it); sidecar invocations; the diff producer;
anything outside src/ and tests/.
