# Task 53 — language detection and adapter selection with a clean unsupported path

## Condition
Only if `src/lang/__init__.py` exists (task 51 landed). Otherwise finish() with that fact and make NO edits.

## Goal
Replace the hard-selected Java adapter with detection: `FUZZING_LANGUAGE` env (set by OSS-Fuzz builders) → the project's
`project.yaml` `language:` → a file census weighted by build files (`pom.xml`/`build.gradle`/`build.xml` → java,
`CMakeLists.txt`/`configure`/`Makefile`+`.c/.cc/.cpp` → c_cpp, `go.mod` → go, `Cargo.toml` → rust,
`pyproject.toml`/`setup.py` → python). Startup line: `Target language: c_cpp (source: FUZZING_LANGUAGE)` or
`(source: census .c=812 .h=301 CMakeLists.txt)`. A language with no adapter stops cleanly:
`unsupported language: <x> — adapters: [java, c_cpp, go, rust, python]`, writes the report and health files with that
reason, exit code 0 — never a traceback.

## Study first
- the current `Target language: java (custom-harness compile: False)` line and what reads that setting (`grep -rn "Target language\|custom-harness" src/`);
  how the orchestrator obtains the adapter after task 51.

## Change (src/lang/detect.py + the one orchestrator call site)
- `detect(root, env) -> (name, source, details)`; precedence as above; census ignores vendored/test fixture dirs
  (`third_party`, `vendor`, `node_modules`, `fuzz/corpus`); ties resolved by build files, then by count.
- Mixed projects (Java + C JNI, Python + C extension): the language of the fuzz harnesses wins (entries found by task 52),
  logged as `mixed: java 60% / c_cpp 40% → harnesses are java`.

## Tests to add (tests/test_lang_detect.py) — fake trees
- each precedence source alone; env beats yaml beats census; the census on a fake C tree, a Go tree, a Rust tree, a
  Python tree, a mixed tree; the unsupported path writes the report and returns normally; the startup line format.

## Acceptance
```
python -m pytest -q tests/test_lang_detect.py tests/test_lang_java_golden.py
```

## Do not touch
Java behaviour (golden test); sidecar; anything outside src/ and tests/.
