# Task 54 — static scanners per language, offline, plus the tool manifest Ashok bakes into the image

## Condition
Only if `src/lang/__init__.py` exists (task 51 landed). Otherwise finish() with that fact and make NO edits.

## Goal
Each adapter's `static_scanners()` returns the scanners to run for its language — Semgrep with vendored rule files and,
where available, CodeQL packs — and their findings are normalised into the existing `static_findings.json` shape so the
rest of discver (triage, the fix loop, task 45's submission tiers) needs no change. Nothing is downloaded at run time:
a scanner binary that is not on PATH is logged `scanner semgrep unavailable — skipped` and the run continues. The task
also writes `src/tools/manifest.yaml` (binary, version, source URL, size, licence, languages) and
`src/tools/Dockerfile.snippet` (the RUN lines) so the image build is a copy-paste.

## Study first
- today's Java static pass (`grep -rn "static_findings\|sinks\|prescan\|codebase_map\|cross_file_audit" src/`): the
  finding shape (file, function, line, cwe, confidence, source) and where the results are consumed.
- ROOTS: any `semgrep-rules` / `codeql` reference root; the CWE playbooks from task 55 if present.

## Change (src/lang/<lang>.py static_scanners, src/static_runner.py, src/tools/)
- `src/tools/rules/semgrep/<lang>/*.yaml`: a starter rule set per language (≈15 rules) for the CWE classes that matter
  (C/C++: CWE-120/121/122/125/787/415/416/190; Go: 22/78/89/400; Rust: unsafe blocks, 190, 22; Python: 78/89/22/502/95;
  Java: the existing sink list as rules) — with the official pack to vendor named in the manifest.
- `static_runner.run(adapter, root) -> findings`: invokes each available scanner with a timeout, parses SARIF/JSON,
  normalises, dedups against the LLM static pass by (file, function, cwe), logs
  `[static] <scanner> <lang>: <n> findings in <s>s` or the unavailable line.

## Tests to add (tests/test_static_runner.py) — fake scanner binaries (shell stubs printing canned SARIF/JSON)
- stub semgrep → findings normalised with the right fields; missing binary → skipped line, run continues; timeout → logged,
  partial results kept; the manifest parses and lists every language; every rule file is valid YAML with an `id`, a
  `message` and a `metadata.cwe`.

## Acceptance
```
python -m pytest -q tests/test_static_runner.py
```

## Do not touch
The LLM static passes (prescan/codebase_map/cross_file_audit); sidecar; anything outside src/ and tests/.
