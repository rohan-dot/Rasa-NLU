# Task 52 — crash-report parsers and harness-entry detection for C/C++, Go, Rust, Python

## Condition
Only if `src/lang/__init__.py` exists (task 51 landed). Otherwise finish() with that fact and make NO edits.

## Goal
Per language, two things the adapter needs before anything else runs: `parse_crash(text) -> CrashInfo(type, sanitizer,
frames[(file, function, line)], signature)` and `harness_entries(root, out_dir) -> [HarnessRef]`. Real report shapes:
- C/C++: ASan (`ERROR: AddressSanitizer: heap-buffer-overflow … READ of size … #0 0x… in func file.c:line:col`),
  UBSan (`file.c:line:col: runtime error: …`), MSan (`use-of-uninitialized-value`), LeakSanitizer, libFuzzer
  `deadly signal` / `timeout` / `out-of-memory`; entries: binaries in `$OUT` exporting `LLVMFuzzerTestOneInput` (`nm`),
  sources containing it.
- Go: `panic: runtime error: index out of range [5] with length 3` + goroutine trace lines `pkg.Func(...)\n\t/src/x.go:12`;
  entries: `func FuzzXxx(f *testing.F)` / libFuzzer binaries from go-118-fuzz-build.
- Rust: `thread '<unnamed>' panicked at 'index out of bounds: …', src/lib.rs:12:5` (+ ASan for unsafe); entries:
  `fuzz_target!(` and cargo-fuzz binaries in `$OUT`.
- Python (Atheris): ` === Uncaught Python exception: ===\nIndexError: …\nTraceback …\n  File "/src/x.py", line 12, in TestOneInput`;
  entries: scripts in `$OUT` calling `atheris.Setup`/`TestOneInput`.
Signature = (type, top ≤ 3 project frames) — project frames are those under the source root, never under the fuzzer runtime.
The Java parser is the moved code from task 51 and stays byte-identical (golden test).

## Study first
- `src/lang/java.py` parse_crash and harness discovery (the shape to mirror); `crash_dedup.py` for how the signature is
  consumed; ROOTS `oss-fuzz-vulns` if present: `grep -rl "crash_type\|crash_state" | head` and read 20 entries per
  language for the real crash-type vocabulary and frame formats.

## Change (src/lang/{c_cpp,go,rust,python}.py)
- The two methods each, registered in `REGISTRY`; `parse_stats` reuses the shared libFuzzer parser; unknown report text →
  `CrashInfo(type="unknown", …)` with the first 200 chars kept, never an exception.

## Tests to add (tests/test_lang_parsers.py) — fixtures authored under tests/fixtures/<lang>/ from the shapes above
- each language: one report per crash type → the right type, sanitizer, frames and a stable signature; runtime frames
  (libFuzzer, atheris, Go runtime) excluded from the signature; garbage text → "unknown".
- entries: a fake `$OUT` with a binary stub + sources per language → the right harness list; Java golden unchanged.

## Acceptance
```
python -m pytest -q tests/test_lang_parsers.py tests/test_lang_java_golden.py
```

## Do not touch
`src/lang/java.py` behaviour; sidecar; anything outside src/ and tests/.
