# Task 57 — patch context per language, with fix exemplars from the workshop

## Condition
Only if `src/lang/__init__.py` exists (task 51 landed). Otherwise finish() with that fact and make NO edits.

## Goal
The patch agent's first message is built from the adapter: `adapter.patch_context(finding)` renders the crash in that
language's terms (sanitizer report → file:line, the frame list, the crash type's meaning, the language's idiomatic fix
shapes — bounds check / length validation / safe API in C; error return in Go; `get()`/checked arithmetic in Rust;
exception handling in Python) and, when a KB is present, appends up to 3 fix exemplars for the same (language, CWE or
crash type) from `kb/exemplars/` with a one-line note each. The Java prompt stays byte-identical when no KB is present
(golden test); the diff producer, sidecar and verdicts do not change.

## Study first
- the prompt builder in `patch_generator.py` (`grep -n "root_cause\|def build.*prompt\|SYSTEM" src/patch_generator.py`);
  task 23's RCA context; `src/lang/java.py`; `src/workshop/retrieve.py` exemplar lookup if present.

## Change (src/lang/<lang>.py patch_context, src/patch_generator.py one call site)
- Rendered context ≤ 2,500 characters; exemplars trimmed to the hunk around the fix; log
  `[patch] context: lang=<l> frames=<n> exemplars=<k>`.

## Tests to add (tests/test_patch_context.py)
- each language renders the right idioms from a fixture CrashInfo; exemplars appended when a fake KB has them, omitted
  (with the log line) when it doesn't; Java golden prompt unchanged without a KB.

## Acceptance
```
python -m pytest -q tests/test_patch_context.py tests/test_lang_java_golden.py
```

## Do not touch
The diff producer, sidecar, verdict classes; anything outside src/ and tests/.
