# Task 56 — the strategy phase: profile the target, retrieve recipes, emit a ranked discovery plan the run follows

## Condition
Only if `src/workshop/retrieve.py` exists (task 55 landed). Otherwise finish() with that fact and make NO edits.

## Goal
A new phase right after the call graph (PHASE 0): profile the target with `workshop.profile`, retrieve the k nearest
historical recipes from the KB at `DISCVER_KB` (default `/opt/discver/kb`), and write `/output/strategy_plan.json` plus
log lines, one per item, with the reason:
`[strategy] 1. fuzz X509Utils.getCnFromDn(String) sanitizer=jazzer dict=dn-tokens static=cwe-129 — 312 similar findings: string-split parsers, index OOB`.
The plan feeds, without replacing anything: a prior boost in `rank_entry_points` (task 19/36) for planned entry points,
dictionary tokens appended to the libFuzzer dict (task 13), and the static rule selection (task 54). At the end of the
run `/output/strategy_outcomes.json` records, per recipe, what the run found (crashes, leads, nothing), so the KB can be
re-weighted offline. No KB at the path → `[strategy] no KB at <path> — default plan` and the run proceeds exactly as today.

## Study first
- `src/workshop/retrieve.py` and `profile.py`; `src/harness_entry_points.py` (where a prior can be added);
  the dictionary writer; `static_runner` (task 54) if present; the phase banner helper used by PHASE 0/1.

## Change (src/strategy_phase.py + three small hooks)
- `run_strategy_phase(root, call_graph, adapter) -> Plan`; hooks read `plan` if present and log what they used:
  `harness-gen: prior +<n> for <method> (strategy item <i>)`, `[dict] +<n> tokens from strategy`, `[static] rules from strategy: […]`.
- Outcomes recorded by signature match against the finding list at the end of the run.
- Safety: wrapped; `[strategy] failed: <error>` → default plan.

## Tests to add (tests/test_strategy_phase.py) — fake KB from the task-55 fixture, fake call graph
- the plan ranks the string-parser first with the reason; the three hooks consume it and log; no KB → default-plan line
  and identical behaviour of the hooks; outcomes file written with the right per-recipe results.

## Acceptance
```
python -m pytest -q tests/test_strategy_phase.py tests/test_lang_java_golden.py
```

## Do not touch
The gate, the probe, the health verdicts, the patch loop, sidecar; anything outside src/ and tests/.
