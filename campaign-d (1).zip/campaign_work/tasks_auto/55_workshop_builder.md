# Task 55 — the workshop: build the knowledge base from how real bugs were found and fixed

## Goal
`python3 src/workshop/build_kb.py --osv <refs/oss-fuzz-vulns> [--arvo <refs/ARVO-Meta>] [--cwe <cwec.xml>] --out <kb dir>`
compiles, offline, a knowledge base the strategy phase (task 56) and the patch context (task 57) read:
- `kb/recipes.jsonl` — one record per historical finding: language, project, crash type, sanitizer, harness name,
  **function-name tokens from the crash state** (the top frames: `png_read_row` → `png, read, row`), fix commit URL,
  CWE when derivable from the crash type. This is the "how it was found" data: (code features → recipe → outcome).
- `kb/cwe_playbooks/<CWE>.yaml` — per language: sources, sinks, sanitizer/detector, dictionary tokens, typical fix
  pattern, what a valid fix must preserve (from the CWE XML where present, else a hand-written seed set for the top 25).
- `kb/exemplars/` — fix diffs for the N most common (language, crash type) pairs, fetched with `--fetch-fixes N` when the
  network allows (git, bounded, cached), skipped otherwise with a count of what was skipped.
- `kb/index.json` — token → recipe ids inverted index, plus counts per language and crash type.
`--dry-run-target <project root>` profiles a codebase with discver's own call graph (function-name tokens per public
function, parsing/decoding idioms, formats handled) and prints the discovery plan the strategy phase would emit — the
check that the idea works before task 56 wires it in.

## Study first
- ROOTS `oss-fuzz-vulns`: the OSV record layout (`vulns/<project>/*.yaml`: `affected[].ecosystem_specific` / `database_specific`
  with crash_type, crash_state, sanitizer, fuzzer, fuzz_target; `references` with the fix commit); count records per language.
- repo: `src/code_analysis.py` (call graph / FunctionInfo) for the profiler; `src/languages.py` tree-sitter loading.
- If `oss-fuzz-vulns` is not under ROOTS: build everything from a tiny fixture and say so — the real build runs later.

## Change (src/workshop/ — a package; nothing in the run path changes in this task)
- `osv_ingest.py`, `cwe_ingest.py`, `profile.py` (shared with task 56), `build_kb.py` (CLI), `retrieve.py`
  (`plan(profile, kb, k) -> ranked recipes with reasons`: token overlap + language match + crash-type prior).
- Deterministic output; every record carries its source file; the CLI prints counts and the top 10 crash types per language.

## Tests to add (tests/test_workshop.py) — a 30-record fake OSV tree + a 3-entry fake CWE XML under tests/fixtures/workshop/
- the build produces all four outputs with the expected counts; tokens extracted from crash states; a profile of a fake
  Java tree with `getCnFromDn(String)` retrieves a string-parsing index-OOB recipe above an LDAP-connector recipe, with the
  reason text; the dry run prints a plan; `--fetch-fixes` with no network skips cleanly.

## Acceptance
```
python -m pytest -q tests/test_workshop.py
```

## Do not touch
The run path (main.py and friends); anything outside src/ and tests/.
