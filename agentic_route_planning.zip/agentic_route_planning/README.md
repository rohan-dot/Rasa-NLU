# Agentic Route Planning

Plans FCG-compliant military flight routes and evaluates them against routes humans actually flew.

**Design rule:** math decides geometry, the model decides feasibility. Distances, borders, fuel
range, lead-time arithmetic and route search are deterministic code. The LLM does one job: read
the raw Foreign Clearance Guide text for each country the route touches and answer, in strict
JSON, "can we use this country in this role on this date, and what is the minimum lead time."
Every piece of FCG text the model read, and what it answered, is written to disk for each run.

## Folder

```
agentic_route_planning/
├── country_route_planner.py   the planner (agent)
├── compare_routes.py          human route vs planner route: numbers + explanation + LLM judge
├── route_judge.py             the judge prompt/logic used by compare_routes (also runnable alone)
├── aircraft_specs.csv         type, range_nm, min_runway_ft, burn_lb_per_nm, fuel_capacity_lb
├── fuel_rates.csv             DLA fuel prices (optional)
├── avoid_countries.csv        manual geopolitical block/avoid list
├── custom_airports.csv        airports missing from OurAirports; auto-grows via station lookup
├── env.example.sh             LLM backend settings -> copy to env.sh
├── run_example.sh             end-to-end example
├── requirements.txt
├── runs/                      one folder per planner run (created automatically)
└── extras_eval/               optional: ablation / penalty sweep / plots / pptx deck builder
```

## Data you supply (put next to the scripts)

| file | what | where from |
|---|---|---|
| `fcg_extract.csv` | one row per country (`alpha3`), raw FCG checklist columns | your FCG extraction pipeline |
| `mapping.csv` | alpha3 -> country name | yours |
| `countries_codes_and_coordinates.csv` | iso2, iso3, lat, lon per country | public (tadast) |
| `airports.csv` | OurAirports dump | https://ourairports.com/data/ |
| `ne_110m_admin_0_countries.geojson` | country polygons | Natural Earth (public domain) |

Column names the judge reads are listed in `FEASIBILITY_COLS` at the top of the planner; at load
time it prints which configured fields are missing from your extract and which extract columns it
is not reading, so you can keep them in sync when the extract changes.

## Setup

```bash
pip install -r requirements.txt --break-system-packages
cp env.example.sh env.sh      # fill in ONE backend, then:  source env.sh
```

### LLM backends (pick by env, override with `--llm`)

| backend | when | env |
|---|---|---|
| `gateway` | LiteLLM or any OpenAI-compatible remote (current: GPT 5.6 "sol") | `LITELLM_BASE_URL`, `LITELLM_API_KEY`, `AGENT_MODEL` |
| `vllm` | a local OpenAI-compatible server: vLLM, Ollama, llama.cpp | `VLLM_URL`, `VLLM_MODEL` |
| `hf` | a model folder on disk, loaded in-process (no server; needs torch+transformers) | `LOCAL_MODEL_PATH` |

Auto-select: `AGENT_MODEL` set -> gateway; else `LOCAL_MODEL_PATH` set -> hf; else vllm.
`LLM_BACKEND=...` or `--llm ...` forces one. Every script prints `[llm] backend: ...` at start.
No `temperature` is sent (GPT 5.x rejects it); gateway calls get `GATEWAY_MAX_TOKENS` (default
6000) and retry at 4x if a reasoning model returns an empty body.

## 1. Plan a mission

```bash
python country_route_planner.py "KSUU to FKKD" --aircraft C-17 --auto-stops --date 2026-12-15 --risk --alternatives 3
python country_route_planner.py "KLRF to DGAA via stops in TJSJ and GVAC" --aircraft C-130 --auto-stops --date 2026-12-15 --risk
python country_route_planner.py "round trip KSUU to FKKD via DGAA" --aircraft C-17 --auto-stops --date 2026-12-15 --risk --optimize-order
```

Mission text can be plain English: `A to B`, `A to B to C`, `from A to B via C and D`,
`A to B with stops in C, D`, `A to B stopping at C then D and back`, `round trip A to B via C`,
`... returning to X`. Anything the rules cannot parse goes to the LLM, which must return the
sequence as JSON; the parsed sequence is printed so you can confirm it. Tokens are ICAO codes,
FCG airport codes, country codes or names. An ICAO code unknown locally is looked up in the
NOAA/FAA station directory (free), validated, and cached in `custom_airports.csv`; the planner
never guesses a country for something that looks like an airport code.

Flags: `--aircraft TYPE` (from aircraft_specs.csv) · `--auto-stops` (insert fuel stops so no leg
exceeds 85% of range) · `--optimize-order` (reorder interior required stops, first/last fixed) ·
`--risk` (State Dept advisory feed; Level 4 block, Level 3 avoid; avoid_countries.csv always applies)
· `--alternatives N` (show top-N corridor options per leg with fuel feasibility) ·
`--clearance-penalty NM` (default 300) · `--wx` · `--traffic` · `--verbose` · `--no-llm` ·
`--list COUNTRY` (designated airports) · `--out DIR`.

### What a run writes — `runs/<timestamp>/`

| file | content |
|---|---|
| `plan_log.txt` | everything printed: resolution, risk, corridors, verdicts, FINAL PLAN, route options, briefing |
| `fcg_evidence.txt` | **for every country/role the judge read:** the exact FCG text given to the model, its verdict JSON, and what the code enforced (lead time) — plus the risk-layer sources |
| `fcg_evidence.json` | same, machine-readable |
| `last_run_blocks.json` | the plan: required stops, full stop chain, auto stops, blocked countries, corridor options, config |

(`last_run_blocks.json` is also written to the working directory for the extras.)

### How it decides

Per leg, three corridor candidates — direct great circle, penalized country-graph Dijkstra,
stepping-stone Dijkstra via intermediate countries — scored by

```
score = NM + 300 x countries needing overflight clearance + 1,500 x risk-listed countries
```

lowest wins; the great circle wins unless bending saves more than 300 NM per clearance avoided
or it crosses a blocked country. Blocked = FCG-denied for this date, State Dept Level 4, or the
manual list; never crossed. Fuel stops: Dijkstra over FCG-designated airports, +400 NM per
landing (+600 for a non-designated fallback). Judge verdicts feed back (deny -> block -> replan)
until the plan converges. All weights are flags/constants, not beliefs; the penalty sweep in
`extras_eval/` shows sensitivity.

## 2. Compare with the human route

```bash
python compare_routes.py --human "KSUU,TJSJ,DGAA,FKKD"            # latest run, auto-detected
python compare_routes.py --human "..." --blocks-file runs/20261215_101500/last_run_blocks.json
python compare_routes.py --human "..." --required "KSUU,DGAA,FKKD"  # override required stops
python compare_routes.py --human "..." --runs 1 --no-judge --chart  # options
```

Writes `comparison_<ts>.md` (+ `.json`) into the run folder:

1. **Numbers** — whole itinerary: stops, total NM, en-route landings, countries needing clearance,
   legs over 85% range, blocked countries touched; per-leg rows for both routes.
2. **Per segment** — when the mission has required stops, both routes are split at them and each
   segment (A->C, C->D, D->A) is compared on its own, with deltas and "identical" flags.
3. **Explanation** — deterministic plain English: differences, compliance, fuel, bottom line.
4. **LLM judge** — the model sees raw facts for both routes + FCG text for every country touched
   + the date's denials (never the planner's score or penalties), picks a winner, runs N times
   (default 3) and reports agreement, confidence, compliance per route, key reasons, what the
   humans may have known that the planner does not, risks in the winner, and a 150-250 word
   explanation.

The human route must contain the required stops in the same order; otherwise the per-segment
section is skipped and it says why.

## 3. Extras (optional, `extras_eval/`)

Run from the package root with the scripts copied up or `PYTHONPATH=.`:
`eval_routes.py` (geometry precision/recall vs polygons, 4-config ablation, penalty sweep, judge
labeling sheet), `eval_plots.py` (figures), `eval_explain.py` (plain-English readout),
`build_eval_deck.py` (pptx). Need matplotlib / python-pptx.

## Known limits

No fuel burn/winds/MOG/NOTAMs; FCG extract quality bounds the judge; State Dept advisories are
country-level; lead time is calendar arithmetic from today; the judge-accuracy labeling study
(extras) is not yet done. When the human route beats the planner, the judge's "what the humans may
have known" list is the backlog of constraints to encode next.
