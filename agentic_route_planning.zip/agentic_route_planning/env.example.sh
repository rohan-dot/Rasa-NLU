# source this (after editing) before running:   source env.sh
# ---- pick ONE LLM backend -------------------------------------------------
# (1) LiteLLM gateway / any OpenAI-compatible remote (current setup, GPT 5.6 "sol")
export LITELLM_BASE_URL="https://<your-gateway>/v1"
export LITELLM_API_KEY="<key>"
export AGENT_MODEL="gpt-5.6-sol"
export AGENT_TLS_VERIFY=false            # only if the gateway cert is self-signed
export GATEWAY_MAX_TOKENS=6000           # reasoning models need headroom

# (2) local OpenAI-compatible server (vLLM / Ollama / llama.cpp) - unset AGENT_MODEL first
# export LLM_BACKEND=vllm
# export VLLM_URL="http://localhost:8000/v1/chat/completions"
# export VLLM_MODEL="google/gemma-4-31b-it"

# (3) in-process model from a folder on disk (no server) - needs torch+transformers
# export LLM_BACKEND=hf
# export LOCAL_MODEL_PATH="/path/to/saved_model_dir"
# export LOCAL_MAX_NEW_TOKENS=1200
