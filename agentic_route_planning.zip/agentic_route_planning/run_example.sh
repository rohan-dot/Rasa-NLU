#!/usr/bin/env bash
# End-to-end example. Edit the mission, date, aircraft and the human route.
set -e
source ./env.sh 2>/dev/null || { echo "copy env.example.sh to env.sh and fill it in"; exit 1; }

# 1. plan (plain-English mission). Outputs -> runs/<timestamp>/
python country_route_planner.py "KSUU to FKKD via stops in DGAA" \
    --aircraft C-17 --auto-stops --date 2026-12-15 --risk --alternatives 3

# 2. compare with what the humans actually flew (same required stops, in order).
#    Reads the latest runs/<timestamp>/ automatically; writes comparison_<ts>.md there.
python compare_routes.py --human "KSUU,TJSJ,DGAA,FKKD"
