#!/usr/bin/env python3
"""
Agentic flight route planner — v3 (airport-precise stops).

What v3 adds over v2:
  * OurAirports airports.csv join: every airport code extracted from your FCG
    `entry_exit_airports_summary` gets real lat/lon (ICAO `ident` join).
  * STAGE-GRAPH OPTIMIZATION: for a query like "hog to dur to fleur", each
    stop expands into ALL designated candidate airports for that country
    (from YOUR FCG data). A dynamic program then picks one airport per stop
    minimizing total great-circle distance. Alternates are shown with their
    distance penalty so users see what they gave up.
  * If the user types a specific airport (e.g. KCHS), that stop is pinned to
    it (candidate set of one).
  * Country-level overflight feasibility (LLM, plan-check-replan) unchanged.
    LLM also vets each CHOSEN stop airport against the FCG text; a denied
    airport is removed from the candidate set and the DP re-runs.
  * --list mode: show designated airports for one country, with coordinates
    and LLM-structured usable/restricted verdicts.

Data files required (all in the working directory, all offline-friendly):
  fcg_extract.csv                        your FCG constraints (country-level)
  mapping.csv                            your code -> country name
  countries_codes_and_coordinates.csv    tadast gist (alpha-2, alpha-3, lat/lon)
  airports.csv                           OurAirports dump (ident, lat/lon)

Usage:
  python country_route_planner.py "hog to dur to fleur to hog"
  python country_route_planner.py "kchs to sazb to scdl to segu to kvps to kchs"
  python country_route_planner.py "usa to chl" --no-llm
  python country_route_planner.py "dur" --list
"""

import argparse
import heapq
import json
import math
import os
import re
import sys
from collections import OrderedDict

import pandas as pd
import requests

# ----------------------------------------------------------------------------
# CONFIG
# ----------------------------------------------------------------------------
FCG_CSV      = "fcg_extract.csv"
MAPPING_CSV  = "mapping.csv"
COORDS_CSV   = "countries_codes_and_coordinates.csv"
AIRPORTS_CSV = "airports.csv"            # OurAirports dump
FUEL_CSV     = "fuel_rates.csv"          # DLA standard prices (optional file)
AIRCRAFT_CSV = "aircraft_specs.csv"      # optional: type,range_nm,min_runway_ft,notes
AIRCRAFT = None                          # set by --aircraft: dict or {"type": name}
AUTO_STOPS = False                       # set by --auto-stops (needs aircraft range)
LANDING_PENALTY_NM = 400.0               # cost of one extra landing in auto-stop search
AUTO_STOP_DETOUR_FACTOR = 1.5            # candidate stops within this x direct distance
AUTO_STOP_SET = set()                    # airports inserted automatically (for reports)
AUTO_STOP_FALLBACK = True                # also consider OurAirports large airports
NON_DESIGNATED_PENALTY_NM = 600.0        # extra cost for a non-FCG-designated stop
AUTO_STOP_FALLBACK_TYPES = {"large_airport"}
# Which DLA fuel codes to show in the per-stop fuel note
FUEL_CODES_SHOWN = ["JP8", "JAA", "IA1", "NA1"]

VLLM_URL = os.environ.get("VLLM_URL", "http://localhost:8000/v1/chat/completions")
VLLM_MODEL = os.environ.get("VLLM_MODEL", "gemma-4-31B-it")
LLM_TIMEOUT  = 120
K_NEIGHBOURS = 8
MAX_LEG_NM   = 2200.0                    # country-graph edge cap in NM; None = off
MAX_ALTERNATES_SHOWN = 4                 # per stop, in the report

# --- Ocean-preference routing ---
# For each leg, a DIRECT great-circle corridor is compared against the
# land (country-graph) route. Score = distance_nm + CLEARANCE_PENALTY_NM
# per country needing overflight clearance. Lower score wins, so an
# oceanic leg with 0-2 clearances beats a long land chain.
CORRIDOR_SAMPLE_NM    = 50.0    # great-circle sampling step
# Exact overflight detection using Natural Earth borders, if the file is
# present (and shapely is installed). Otherwise the centroid-radius model
# below is used. Recommended: download ne_110m_admin_0_countries.geojson.
NE_FILE = "ne_110m_admin_0_countries.geojson"
POLYGON_SAMPLE_NM = 15.0        # track sampling step for polygon checks
_POLY = None                    # lazily loaded {iso3: geometry}
_POLY_TREE = None
CORRIDOR_RADIUS_NM    = 150.0   # a country is "overflown" if its centroid
                                # is within this distance of the track
                                # (centroid approximation — see docs)
# Large countries: a track can cross their territory far from the centroid,
# so give them a bigger effective radius (~ half the sqrt of land area).
# Precise answer needs boundary polygons (Natural Earth) — future upgrade.
COUNTRY_RADIUS_NM = {
    "RUS": 1500, "CAN": 1100, "USA": 950, "CHN": 950, "BRA": 900,
    "AUS": 900, "GRL": 750, "IND": 600, "ARG": 650, "KAZ": 600,
    "DZA": 550, "COD": 500, "SAU": 500, "MEX": 500, "IDN": 700,
    "SDN": 450, "LBY": 450, "IRN": 450, "MNG": 450, "PER": 400,
    "TCD": 400, "NER": 400, "AGO": 400, "MLI": 400, "ZAF": 400,
    "COL": 350, "ETH": 350, "BOL": 350, "MRT": 350, "EGY": 350,
    "TZA": 350, "NGA": 350, "VEN": 350, "PAK": 350, "MOZ": 350,
    "TUR": 350, "CHL": 500, "ZMB": 300, "MMR": 350, "AFG": 300,
    "SOM": 300, "UKR": 300, "MDG": 350, "KEN": 300, "FRA": 300,
    "YEM": 300, "THA": 300, "ESP": 300, "TKM": 300, "CMR": 300,
    "PNG": 300, "SWE": 350, "UZB": 300, "MAR": 300, "IRQ": 300,
    "NOR": 400, "FIN": 350, "JPN": 350, "VNM": 300, "MYS": 300,
    "PHL": 350, "NZL": 350, "DEU": 250,
}
CLEARANCE_PENALTY_NM  = 300.0   # detour NM one clearance is "worth"
# Stepping-stone corridor search (routes via 1-2 intermediate countries,
# e.g. USA -> JPN -> THA across the Pacific). Hops have NO length cap.
STONE_MAX_HOP_NM      = 4500    # longest single hop between stones
STONE_BACKTRACK_NM    = 600     # allow stones this much 'backwards'
STEPPING_DETOUR_FACTOR = 1.6    # ignore stones making route > 1.6x direct

# --- Geopolitical risk / avoid list ---
RISK_CSV = "avoid_countries.csv"     # manual: code,action,reason,date
                                     # action = block | avoid (penalty)
RISK_AVOID_PENALTY_NM = 1500.0       # extra NM penalty for 'avoid' countries
STATE_DEPT_RSS = "https://travel.state.gov/_res/rss/TAsTWs.xml"
RISK_CACHE = "risk_cache.json"       # cached feed for offline runs
RISK_LEVEL_ACTION = {4: "block", 3: "avoid"}   # State Dept levels -> action
RISK_EXTRA = {}                      # filled at runtime: code -> extra NM
USE_RISK_FEED = False                # set by --risk

FCG_CODE_COL = "alpha3"     # new extract: ISO3 code column
# Columns the agent scans for designated airport codes
AIRPORT_COL  = "Country_Specific_Entry_Exit_Airfield_Restrictions"
AIRPORT_COL_2 = "Airfield_Detail_Aircraft_Suitability_Destinations_AND_Alternates"
# Columns whose text goes into the fuel/payment note per stop
PAYMENT_COLS = ["AIR_Card_Acceptance", "Cash_Payment_Requirement",
                "Paying_Agent_Requirement", "Landing_and_Handling_Fees"]
# The judge reads these fields (new extract's checklist column names).
FEASIBILITY_COLS = [
    "overflight_raw",
    "Diplomatic_Clearance_Lead_Time",
    "Country_Specific_Entry_Exit_Airfield_Restrictions",
    "Customs_Procedures",
    "Immigration_Requirements",
    "Agriculture_Quarantine",
    "HazMat_Clearance_Requirements",
    "HazMat_Ground_Handling",
    "Operating_Hours",
    "Ops_Hrs_Quiet_Hrs_Holiday_Weekend_Ops_Servicing_Hours_TA",
    "Holiday_Closures",
    "Airfield_Detail_Aircraft_Suitability_Destinations_AND_Alternates",
    "Runway_Taxiway_Apron_Weight_Bearing_Capacity_WBC_Length_and_Width",
    "Daylight_Only_VFR_Only_Restrictions",
    "NOTAMs",
    "Maximum_On_Ground_MOG",
    "Other_Pertinent_Notes_Msn_or_Info_Remarks",
]
# Max characters of each field included in the LLM dossier. None = unlimited.
DOSSIER_CHAR_CAP = 2500
CUSTOM_AIRPORTS_CSV = "custom_airports.csv"   # optional: ident,name,latitude_deg,longitude_deg,iso3
# Set by --verbose: print each country's full dossier as it is judged.
VERBOSE = False
# OurAirports rows to accept as landable candidates
AIRPORT_TYPES_OK = {"large_airport", "medium_airport", "small_airport"}

COORD_OVERRIDES = {
    # "XKS": ("Kosovo", 42.6, 20.9),
    # "DGA": ("Diego Garcia", -7.3, 72.4),
}

# ----------------------------------------------------------------------------
# 1. LOADING (fail-fast)
# ----------------------------------------------------------------------------

def _clean(s):
    return s.strip().strip('"').strip() if isinstance(s, str) else s


def load_coords(path: str) -> pd.DataFrame:
    """tadast gist: returns iso3, iso2, country, lat, lon (one row per iso3)."""
    df = pd.read_csv(path)
    df.columns = [c.strip().strip('"') for c in df.columns]
    col_map = {}
    for c in df.columns:
        lc = c.lower()
        if "alpha-3" in lc:
            col_map[c] = "iso3"
        elif "alpha-2" in lc:
            col_map[c] = "iso2"
        elif "latitude" in lc:
            col_map[c] = "lat"
        elif "longitude" in lc:
            col_map[c] = "lon"
        elif lc == "country":
            col_map[c] = "country"
    df = df.rename(columns=col_map)
    missing = {"iso3", "iso2", "lat", "lon", "country"} - set(df.columns)
    if missing:
        sys.exit(f"[FATAL] coords CSV missing {missing}; found {list(df.columns)}")
    for c in ("iso3", "iso2", "country"):
        df[c] = df[c].map(_clean)
    for c in ("lat", "lon"):
        df[c] = pd.to_numeric(df[c].map(_clean), errors="coerce")
    df["iso3"] = df["iso3"].str.upper()
    df["iso2"] = df["iso2"].str.upper()
    df = (df.dropna(subset=["lat", "lon"])
            .drop_duplicates(subset="iso3", keep="first"))
    df["lat"] = df["lat"].astype(float)
    df["lon"] = df["lon"].astype(float)
    if COORD_OVERRIDES:
        extra = pd.DataFrame(
            [{"iso3": k, "iso2": "", "country": v[0],
              "lat": float(v[1]), "lon": float(v[2])}
             for k, v in COORD_OVERRIDES.items() if k not in set(df["iso3"])])
        if len(extra):
            df = pd.concat([df, extra], ignore_index=True)
    if df.empty:
        sys.exit("[FATAL] coords CSV parsed to 0 usable rows.")
    print(f"[load] coords: {len(df)} countries with lat/lon")
    return df[["iso3", "iso2", "country", "lat", "lon"]]


def load_mapping(path: str) -> dict:
    mapping = {}
    with open(path, encoding="utf-8-sig") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line or "," not in line:
                continue
            code, name = line.split(",", 1)
            code = code.strip().strip('"').upper()
            name = name.strip().strip('"')
            if i == 0 and (code.lower() in ("code", "airport", "abbr")
                           or name.lower() in ("name", "country")):
                continue
            mapping[code] = name
    if not mapping:
        sys.exit("[FATAL] mapping.csv parsed to 0 entries.")
    print(f"[load] mapping: {len(mapping)} codes")
    return mapping


def load_fcg(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    if FCG_CODE_COL not in df.columns:
        sys.exit(f"[FATAL] FCG CSV lacks '{FCG_CODE_COL}'; "
                 f"found {list(df.columns)}")
    df[FCG_CODE_COL] = (df[FCG_CODE_COL].astype(str)
                        .str.strip().str.upper()
                        .str.replace(r"_FCG.*$", "", regex=True))
    print(f"[load] FCG: {len(df)} country rows, {len(df.columns)} columns")
    # Audit: which configured fields the judge/fuel note will actually see
    present = [c for c in FEASIBILITY_COLS if c in df.columns]
    missing = [c for c in FEASIBILITY_COLS if c not in df.columns]
    print(f"[load] judge reads {len(present)}/{len(FEASIBILITY_COLS)} "
          f"configured fields")
    if missing:
        print(f"[load] WARNING judge fields NOT in this extract: {missing}")
        unused = [c for c in df.columns
                  if c not in FEASIBILITY_COLS and c not in PAYMENT_COLS
                  and c not in (FCG_CODE_COL, "country", "country_name",
                                "alpha2", "alpha3")]
        print(f"[load] columns in extract the judge does NOT read: {unused}")
    pay_missing = [c for c in PAYMENT_COLS if c not in df.columns]
    if pay_missing:
        print(f"[load] WARNING payment fields NOT in this extract: {pay_missing}")
    return df


def load_ourairports(path: str, coords: pd.DataFrame) -> pd.DataFrame:
    """OurAirports airports.csv -> index of ICAO ident -> name/lat/lon/iso3."""
    usecols = ["ident", "type", "name", "latitude_deg", "longitude_deg",
               "iso_country"]
    df = pd.read_csv(path, usecols=usecols)
    df = df[df["type"].isin(AIRPORT_TYPES_OK)].copy()
    df["ident"] = df["ident"].astype(str).str.strip().str.upper()
    df["iso_country"] = df["iso_country"].astype(str).str.strip().str.upper()
    df["latitude_deg"] = pd.to_numeric(df["latitude_deg"], errors="coerce")
    df["longitude_deg"] = pd.to_numeric(df["longitude_deg"], errors="coerce")
    df = df.dropna(subset=["latitude_deg", "longitude_deg"])
    # alpha-2 -> alpha-3 bridge via the countries file
    a2_to_a3 = dict(zip(coords["iso2"], coords["iso3"]))
    df["iso3"] = df["iso_country"].map(a2_to_a3)
    df = df.dropna(subset=["iso3"]).drop_duplicates(subset="ident",
                                                    keep="first")
    # Optional custom_airports.csv: ident,name,latitude_deg,longitude_deg,iso3
    # for fields missing/renamed in OurAirports (e.g. MPPA ex-Howard AFB).
    # Custom rows override OurAirports rows with the same ident.
    try:
        cu = pd.read_csv(CUSTOM_AIRPORTS_CSV)
        cu["ident"] = cu["ident"].astype(str).str.strip().str.upper()
        cu["iso3"] = cu["iso3"].astype(str).str.strip().str.upper()
        cu["type"] = cu.get("type", "custom")
        cu["iso_country"] = cu.get("iso_country", "")
        cu = cu[["ident", "type", "name", "latitude_deg", "longitude_deg",
                 "iso_country", "iso3"]].dropna(subset=["latitude_deg", "longitude_deg"])
        df = pd.concat([cu, df[~df["ident"].isin(cu["ident"])]], ignore_index=True)
        print(f"[load] custom airports: {', '.join(cu['ident'])}")
    except FileNotFoundError:
        pass
    df = df.set_index("ident")
    print(f"[load] OurAirports: {len(df)} usable airports "
          f"({', '.join(sorted(AIRPORT_TYPES_OK))})")
    return df


AWC_STATION_URL = "https://aviationweather.gov/api/data/stationinfo"


def lookup_station_online(icao, ourairports):
    """Official NOAA/FAA station directory (free, no key). Returns a row dict
    shaped like an OurAirports record, or None. Country alpha-2 is converted
    with the same bridge OurAirports uses, so a wrong country cannot slip in."""
    try:
        r = requests.get(AWC_STATION_URL, params={"ids": icao, "format": "json"},
                         timeout=15)
        r.raise_for_status()
        hits = [h for h in r.json() if str(h.get("icaoId", "")).upper() == icao]
    except Exception as e:
        print(f"[resolve] station lookup failed for {icao}: {e}")
        return None
    if not hits:
        return None
    h = hits[0]
    a2_to_a3 = dict(zip(ourairports["iso_country"], ourairports["iso3"]))
    iso3 = a2_to_a3.get(str(h.get("country", "")).upper())
    if not iso3 or h.get("lat") is None or h.get("lon") is None:
        return None
    return {"type": "station_lookup", "name": str(h.get("site", icao)),
            "latitude_deg": float(h["lat"]), "longitude_deg": float(h["lon"]),
            "iso_country": str(h.get("country", "")).upper(), "iso3": iso3}


def cache_custom_airport(icao, rec):
    """Append a resolved station to custom_airports.csv so the next run is offline."""
    try:
        new = not os.path.exists(CUSTOM_AIRPORTS_CSV)
        with open(CUSTOM_AIRPORTS_CSV, "a") as f:
            if new:
                f.write("ident,name,latitude_deg,longitude_deg,iso3,type,notes\n")
            f.write(f"{icao},\"{rec['name']}\",{rec['latitude_deg']},{rec['longitude_deg']},"
                    f"{rec['iso3']},{rec['type']},auto-added from aviationweather.gov\n")
    except Exception as e:
        print(f"[resolve] could not cache {icao}: {e}")


AIRPORT_CODE_RE = re.compile(r"\b[A-Z0-9]{3,4}\b")
AIRPORT_STOPWORDS = {
    "THE", "AND", "FOR", "NOT", "ALL", "ANY", "PER", "VIA", "ICAO", "IATA",
    "AOE", "N/A", "TBD", "UTC", "GMT", "VIP", "CIQ", "PPR", "NOTAM", "HRS",
}


def build_airport_index(fcg: pd.DataFrame, ourairports: pd.DataFrame):
    """Two products:
       airport_to_country : code -> FCG country code (for resolving input)
       candidates         : country code -> [airport codes WITH coordinates]
    """
    airport_to_country, collisions = {}, set()
    extract_cols = [c for c in (AIRPORT_COL, AIRPORT_COL_2)
                    if c in fcg.columns]
    if not extract_cols:
        # Auto-detect: any column whose name looks like entry/exit/airfield
        pat = re.compile(r"(entry|exit|airfield|airport|alternate|aerodrome)",
                         re.IGNORECASE)
        extract_cols = [c for c in fcg.columns
                        if pat.search(c) and c != FCG_CODE_COL]
        if extract_cols:
            print(f"[airports] configured columns missing; auto-detected "
                  f"{extract_cols}")
        else:
            print(f"[airports] no entry/exit/airfield column found in "
                  f"{list(fcg.columns)[:12]}... — airport features off. "
                  f"Set AIRPORT_COL in CONFIG to the right column name.")
            return {}, {}
    country_codes = set(fcg[FCG_CODE_COL])
    for _, row in fcg.iterrows():
        text = " ".join(str(row.get(c, "") or "") for c in extract_cols)
        for tok in AIRPORT_CODE_RE.findall(text.upper()):
            if tok in AIRPORT_STOPWORDS or tok in country_codes:
                continue
            if tok.isdigit():
                continue
            # Only pure-alphabetic tokens can be ICAO (4) / IATA (3) codes.
            # Aircraft types (MD11, A340, B777, AN24), runway designators
            # (02R, 13L) and units (15KT, 49FT) all contain digits.
            if not tok.isalpha():
                continue
            if tok in airport_to_country and \
                    airport_to_country[tok] != row[FCG_CODE_COL]:
                collisions.add(tok)
                continue
            airport_to_country[tok] = row[FCG_CODE_COL]
    for tok in collisions:
        airport_to_country.pop(tok, None)

    candidates, no_coords = {}, []
    for ap, ctry in airport_to_country.items():
        if ap in ourairports.index:
            candidates.setdefault(ctry, []).append(ap)
        else:
            no_coords.append(ap)
    print(f"[airports] {len(airport_to_country)} codes extracted from FCG; "
          f"{sum(len(v) for v in candidates.values())} matched to OurAirports "
          f"coords across {len(candidates)} countries")
    if no_coords:
        print(f"[airports] no coords (unusable for distance optimization, "
              f"still listed): {sorted(no_coords)[:30]}"
              f"{' ...' if len(no_coords) > 30 else ''}")
    return airport_to_country, candidates


def build_dataset():
    coords = load_coords(COORDS_CSV)
    mapping = load_mapping(MAPPING_CSV)
    fcg = load_fcg(FCG_CSV)
    ourairports = load_ourairports(AIRPORTS_CSV, coords)
    fcg_codes = set(fcg[FCG_CODE_COL])
    joined = fcg_codes & set(coords["iso3"])
    unmatched = sorted(fcg_codes - set(coords["iso3"]))
    print(f"[join] {len(joined)}/{len(fcg_codes)} FCG codes matched to coords")
    if unmatched:
        print(f"[join] unmatched: {unmatched}")
    if len(joined) < 2:
        sys.exit("[FATAL] fewer than 2 FCG countries have coordinates.")
    nodes = coords[coords["iso3"].isin(joined)].set_index("iso3")
    fcg_idx = fcg.drop_duplicates(FCG_CODE_COL).set_index(FCG_CODE_COL)
    airport_to_country, candidates = build_airport_index(fcg, ourairports)
    airport_to_country = {a: c for a, c in airport_to_country.items()
                          if c in nodes.index}
    candidates = {c: aps for c, aps in candidates.items() if c in nodes.index}
    return nodes, fcg_idx, mapping, airport_to_country, candidates, ourairports

# ----------------------------------------------------------------------------
# 2. RESOLUTION (closed world; countries and airports)
# ----------------------------------------------------------------------------

def resolve_waypoint(user_token, mapping, nodes, airport_to_country, use_llm,
                     ourairports=None):
    tok = user_token.strip().upper()
    if tok in nodes.index:
        return tok, None
    if tok in airport_to_country:
        return airport_to_country[tok], tok
    # Fallback: any airport in OurAirports is a valid user-typed waypoint,
    # even if not listed in the FCG entry/exit text (e.g. home base KCHS).
    if ourairports is not None and tok in ourairports.index:
        ctry = str(ourairports.loc[tok, "iso3"])
        if ctry in nodes.index:
            print(f"[resolve] '{tok}' found in OurAirports -> {ctry} "
                  f"({ourairports.loc[tok, 'name']}) "
                  f"[not in FCG entry/exit list — flagged for review]")
            return ctry, tok
    name_to_code = {v.upper(): k for k, v in mapping.items()}
    if tok in name_to_code and name_to_code[tok] in nodes.index:
        return name_to_code[tok], None
    hit = nodes[nodes["country"].str.upper() == tok]
    if len(hit) == 1:
        return hit.index[0], None
    hit = nodes[nodes["country"].str.upper().str.contains(re.escape(tok))]
    if len(hit) == 1:
        return hit.index[0], None
    if re.fullmatch(r"[A-Z][A-Z0-9]{3}", tok) and ourairports is not None:
        # ICAO-looking code unknown locally -> ask the official NOAA/FAA station
        # directory (same free source as --wx), validate, cache it, carry on.
        rec = lookup_station_online(tok, ourairports)
        if rec is not None and rec["iso3"] in nodes.index:
            ourairports.loc[tok] = rec
            cache_custom_airport(tok, rec)
            print(f"[resolve] '{tok}' not in OurAirports; found via aviationweather.gov "
                  f"-> {rec['iso3']} ({rec['name']}) [cached to {CUSTOM_AIRPORTS_CSV}]")
            return rec["iso3"], tok
        sys.exit(f"[FATAL] '{tok}' looks like an ICAO airport code but is not in "
                 f"OurAirports, {CUSTOM_AIRPORTS_CSV}, the FCG entry/exit list, or the "
                 f"aviationweather.gov station directory. Add it to {CUSTOM_AIRPORTS_CSV} "
                 f"(ident,name,latitude_deg,longitude_deg,iso3) or use the country name. "
                 f"Refusing to guess a country for it.")
    if use_llm:
        valid_countries = sorted(nodes.index)
        sample_airports = sorted(airport_to_country)[:400]
        ans = llm_json(
            f"The user wrote '{user_token}'. Match to EITHER one ISO alpha-3 "
            f"COUNTRY code from:\n{valid_countries}\nOR one AIRPORT code "
            f"from:\n{sample_airports}\nCountry codes mean countries "
            f"(FRA=France, never Frankfurt).\n"
            f'Respond ONLY JSON: {{"kind": "country"|"airport"|null, '
            f'"code": "XXX"|null}}') or {}
        code = (ans.get("code") or "").upper()
        if ans.get("kind") == "country" and code in nodes.index:
            print(f"[resolve] LLM: '{user_token}' -> country {code} [validated]")
            return code, None
        if ans.get("kind") == "airport" and code in airport_to_country:
            print(f"[resolve] LLM: '{user_token}' -> airport {code} [validated]")
            return airport_to_country[code], code
    sys.exit(f"[FATAL] cannot resolve '{user_token}' to any country or "
             f"airport in your dataset.")

# ----------------------------------------------------------------------------
# 3. GEOMETRY
# ----------------------------------------------------------------------------

def haversine_nm(lat1, lon1, lat2, lon2):
    r = 3440.065          # Earth radius in NAUTICAL MILES
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = (math.sin(dphi / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2)
    return 2 * r * math.asin(math.sqrt(a))


def airport_pt(ap, ourairports):
    row = ourairports.loc[ap]
    return float(row["latitude_deg"]), float(row["longitude_deg"])


def build_graph(nodes, k=K_NEIGHBOURS, max_leg_nm=MAX_LEG_NM):
    codes = list(nodes.index)
    pts = {c: (float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"]))
           for c in codes}
    graph = {c: {} for c in codes}
    for c in codes:
        dists = []
        for o in codes:
            if o == c:
                continue
            d = haversine_nm(*pts[c], *pts[o])
            if max_leg_nm is None or d <= max_leg_nm:
                dists.append((d, o))
        dists.sort()
        for d, o in dists[:k]:
            graph[c][o] = d
            graph[o][c] = d
    print(f"[graph] {len(codes)} country nodes, "
          f"{sum(len(v) for v in graph.values()) // 2} edges (k={k})")
    return graph


def dijkstra(graph, src, dst, blocked):
    dist, prev, pq, seen = {src: 0.0}, {}, [(0.0, src)], set()
    while pq:
        d, u = heapq.heappop(pq)
        if u in seen:
            continue
        seen.add(u)
        if u == dst:
            break
        for v, w in graph[u].items():
            if v in blocked and v != dst:
                continue
            nd = d + w
            if nd < dist.get(v, float("inf")):
                dist[v], prev[v] = nd, u
                heapq.heappush(pq, (nd, v))
    if dst not in dist:
        return None, None
    path = [dst]
    while path[-1] != src:
        path.append(prev[path[-1]])
    return list(reversed(path)), dist[dst]


def gc_sample(p1, p2, step_nm=CORRIDOR_SAMPLE_NM):
    """Sample points along the great circle between (lat,lon) p1 and p2."""
    lat1, lon1 = map(math.radians, p1)
    lat2, lon2 = map(math.radians, p2)
    v1 = (math.cos(lat1) * math.cos(lon1),
          math.cos(lat1) * math.sin(lon1), math.sin(lat1))
    v2 = (math.cos(lat2) * math.cos(lon2),
          math.cos(lat2) * math.sin(lon2), math.sin(lat2))
    dot = max(-1.0, min(1.0, sum(a * b for a, b in zip(v1, v2))))
    ang = math.acos(dot)
    total_nm = ang * 3440.065
    n = max(2, int(total_nm / step_nm) + 1)
    pts = []
    for i in range(n + 1):
        f = i / n
        if ang < 1e-9:
            w1, w2 = 1 - f, f
        else:
            w1 = math.sin((1 - f) * ang) / math.sin(ang)
            w2 = math.sin(f * ang) / math.sin(ang)
        x, y, z = (w1 * a + w2 * b for a, b in zip(v1, v2))
        norm = math.sqrt(x * x + y * y + z * z)
        x, y, z = x / norm, y / norm, z / norm
        pts.append((math.degrees(math.asin(z)),
                    math.degrees(math.atan2(y, x))))
    return pts, total_nm


def load_polygons():
    """Load Natural Earth admin-0 polygons once. Returns (dict, tree) or
    (None, None) if unavailable."""
    global _POLY, _POLY_TREE
    if _POLY is not None:
        return _POLY, _POLY_TREE
    try:
        from shapely.geometry import shape
        from shapely.strtree import STRtree
        gj = json.load(open(NE_FILE, encoding="utf-8"))
    except Exception as e:
        _POLY, _POLY_TREE = {}, None
        print(f"[geom] polygons unavailable ({e.__class__.__name__}); using "
              f"centroid-radius approximation")
        return _POLY, _POLY_TREE
    polys, geoms, codes = {}, [], []
    for f in gj["features"]:
        pr = f["properties"]
        iso = str(pr.get("ISO_A3", "-99"))
        if iso in ("-99", "", "None"):
            iso = str(pr.get("ADM0_A3", "-99"))
        if iso == "-99":
            continue
        g = shape(f["geometry"])
        polys[iso.upper()] = g
        geoms.append(g)
        codes.append(iso.upper())
    _POLY = polys
    # shapely 2.x STRtree.query returns indices; 1.8 returns geometries
    _POLY_TREE = (STRtree(geoms), codes, {id(g): c for g, c in zip(geoms, codes)})
    print(f"[geom] exact overflight detection: {len(polys)} country borders")
    return _POLY, _POLY_TREE


def direct_corridor(p1, p2, nodes, endpoints):
    """Countries the direct great-circle track crosses.

    Exact (polygon) mode when Natural Earth borders are available: a country
    is overflown iff a sampled track point lies inside its border.
    Fallback: centroid-radius approximation. Endpoint countries excluded
    from the clearance count but included in the corridor list."""
    polys, tree = load_polygons()
    if polys:
        from shapely.geometry import Point
        samples, total_nm = gc_sample(p1, p2, step_nm=POLYGON_SAMPLE_NM)
        strtree, codes, by_id = tree
        near = {}
        for idx, (lat, lon) in enumerate(samples):
            pt = Point(lon, lat)
            for hit in strtree.query(pt):
                code = codes[int(hit)] if isinstance(hit, (int,)) or \
                    hasattr(hit, "__index__") else by_id.get(id(hit))
                if code is None:
                    continue
                if code in near or code not in nodes.index:
                    continue
                if polys[code].contains(pt):
                    near[code] = idx
        ordered = sorted(near, key=near.get)
        clearances = [c for c in ordered if c not in endpoints]
        return [endpoints[0]] + clearances + [endpoints[1]], clearances, total_nm
    samples, total_nm = gc_sample(p1, p2)
    max_r = max([CORRIDOR_RADIUS_NM] + list(COUNTRY_RADIUS_NM.values()))
    # bounding-box prefilter (radius in degrees, generous) for speed
    pad = max_r / 60.0 + 1.0
    lat_min = min(s[0] for s in samples) - pad
    lat_max = max(s[0] for s in samples) + pad
    lons = [s[1] for s in samples]
    wraps = (max(lons) - min(lons)) > 180   # crosses antimeridian
    near = {}   # code -> first sample index where the track is within radius
    for c in nodes.index:
        clat, clon = float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
        radius = max(CORRIDOR_RADIUS_NM, COUNTRY_RADIUS_NM.get(c, 0))
        if not (lat_min <= clat <= lat_max):
            continue
        if not wraps and not (min(lons) - pad <= clon <= max(lons) + pad):
            continue
        for idx, (slat, slon) in enumerate(samples):
            if haversine_nm(clat, clon, slat, slon) <= radius:
                near[c] = idx
                break
    ordered = sorted(near, key=near.get)              # along-track order
    clearances = [c for c in ordered if c not in endpoints]
    corridor = [endpoints[0]] + clearances + [endpoints[1]]
    return corridor, clearances, total_nm


def corridor_score(nm, clearances):
    """distance + per-country clearance cost (+ geopolitical risk extra)."""
    return nm + sum(CLEARANCE_PENALTY_NM + RISK_EXTRA.get(c, 0.0)
                    for c in clearances)


# ----------------------------------------------------------------------------
# GEOPOLITICAL RISK: manual avoid list + US State Dept advisories (free RSS)
# ----------------------------------------------------------------------------

def load_manual_risk(path=RISK_CSV):
    """avoid_countries.csv -> {code: (action, reason)}"""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        return {}
    out = {}
    for _, r in df.iterrows():
        code = str(r.get("code", "")).strip().upper()
        action = str(r.get("action", "avoid")).strip().lower()
        if code and action in ("block", "avoid"):
            out[code] = (action, f"manual list: {r.get('reason', '')}")
    print(f"[risk] manual avoid list: {len(out)} countries")
    return out


def fetch_state_dept_risk(nodes, mapping, use_feed):
    """Parse 'Country - Level N: ...' titles from the State Dept RSS.
    Returns {code: (action, reason)} for levels in RISK_LEVEL_ACTION.
    Uses/refreshes a local cache so offline runs still get the last fetch."""
    import datetime as _dt
    titles, source = None, None
    if use_feed:
        try:
            r = requests.get(STATE_DEPT_RSS, timeout=20)
            r.raise_for_status()
            titles = re.findall(r"<title>(.*?)</title>", r.text, re.DOTALL)
            json.dump({"fetched": _dt.datetime.now().isoformat(),
                       "titles": titles}, open(RISK_CACHE, "w"))
            source = "live feed"
        except Exception as e:
            print(f"[risk] State Dept feed unavailable: {e}")
    if titles is None:
        try:
            cache = json.load(open(RISK_CACHE))
            titles, source = cache["titles"], f"cache from {cache['fetched'][:16]}"
        except Exception:
            print("[risk] no advisory data (no feed, no cache)")
            return {}
    name_to_code = {str(nodes.loc[c, "country"]).upper(): c
                    for c in nodes.index}
    name_to_code.update({v.upper(): k for k, v in mapping.items()})
    out = {}
    for t in titles:
        m = re.match(r"\s*(.+?)\s*[-–]\s*Level\s*(\d)", t)
        if not m:
            continue
        name, level = m.group(1).strip().upper(), int(m.group(2))
        action = RISK_LEVEL_ACTION.get(level)
        if not action:
            continue
        code = name_to_code.get(name)
        if not code:   # loose match: advisory name contained in dataset name
            for nm, c in name_to_code.items():
                if name in nm or nm in name:
                    code = c
                    break
        if code:
            out[code] = (action, f"State Dept Level {level} ({source})")
    print(f"[risk] State Dept advisories: {len(out)} countries at Level 3/4 "
          f"({source})")
    return out


def apply_risk(nodes, mapping, use_feed):
    """Combine manual list (wins) + advisories. Returns (hard_block set,
    notes dict code -> reason). Fills RISK_EXTRA for 'avoid' countries."""
    risk = fetch_state_dept_risk(nodes, mapping, use_feed)
    risk.update(load_manual_risk())          # manual overrides feed
    hard, notes = set(), {}
    RISK_EXTRA.clear()
    for code, (action, reason) in risk.items():
        if code not in nodes.index:
            continue
        notes[code] = f"{action.upper()} — {reason}"
        if action == "block":
            hard.add(code)
        else:
            RISK_EXTRA[code] = RISK_AVOID_PENALTY_NM
    if hard:
        print(f"[risk] hard-blocked overflight: {sorted(hard)}")
    if RISK_EXTRA:
        print(f"[risk] penalized (avoid if possible): {sorted(RISK_EXTRA)}")
    return hard, notes


def stepping_stone_corridors(p_src, p_dst, src, dst, nodes, blocked,
                             direct_nm):
    """Dijkstra over countries as stepping stones (any path length).

    Nodes: 'SRC' (origin airport point), every non-blocked country centroid,
    'DST' (destination airport point). An edge u->v is the great-circle hop
    between them; it exists only if the hop overflies no blocked country and
    is <= STONE_MAX_HOP_NM. Edge cost = hop NM + clearance cost of every
    country the hop overflies (+ the stone itself). Hop corridors are
    computed lazily and cached, so only hops the search actually considers
    are evaluated.

    Returns list of (score, label, corridor_countries, total_nm, clearances)
    — best path first, followed by a few 1-stone alternates for display."""
    cent = {c: (float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"]))
            for c in nodes.index if c not in blocked}
    pos = dict(cent)
    pos["SRC"], pos["DST"] = p_src, p_dst
    # forward-progress filter: only consider stones within the detour ellipse
    stones = [c for c, pc in cent.items()
              if c not in (src, dst)
              and haversine_nm(*p_src, *pc) + haversine_nm(*pc, *p_dst)
              <= STEPPING_DETOUR_FACTOR * direct_nm]
    code_of = {"SRC": src, "DST": dst}

    hop_cache = {}
    def hop(u, v):
        key = (u, v)
        if key not in hop_cache:
            a, b = code_of.get(u, u), code_of.get(v, v)
            _, clear, nm = direct_corridor(pos[u], pos[v], nodes, (a, b))
            clear = [c for c in clear if c not in (src, dst)]
            ok = not (set(clear) & blocked)
            hop_cache[key] = (clear, nm, ok)
        return hop_cache[key]

    INF = float("inf")
    dist = {"SRC": 0.0}
    prev = {}
    pq = [(0.0, "SRC")]
    seen = set()
    d_to_dst = {c: haversine_nm(*cent[c], *p_dst) for c in stones}
    while pq:
        d, u = heapq.heappop(pq)
        if u in seen:
            continue
        seen.add(u)
        if u == "DST":
            break
        # neighbours: DST always; stones that make forward progress
        u_to_dst = haversine_nm(*pos[u], *p_dst)
        neigh = ["DST"] + [c for c in stones
                           if c not in seen and c != u
                           and d_to_dst[c] <= u_to_dst + STONE_BACKTRACK_NM]
        for v in neigh:
            hop_nm = haversine_nm(*pos[u], *pos[v])
            if v != "DST" and hop_nm > STONE_MAX_HOP_NM:
                continue
            clear, nm, ok = hop(u, v)
            if not ok:
                continue
            step = nm + sum(CLEARANCE_PENALTY_NM + RISK_EXTRA.get(c, 0.0)
                            for c in clear)
            if v != "DST":
                step += CLEARANCE_PENALTY_NM + RISK_EXTRA.get(v, 0.0)
            nd = d + step
            if nd < dist.get(v, INF):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(pq, (nd, v))

    out = []
    if "DST" in dist:
        path = ["DST"]
        while path[-1] != "SRC":
            path.append(prev[path[-1]])
        path.reverse()
        # assemble along-track corridor and true NM
        seen_c, clear_all, total = set(), [], 0.0
        for u, v in zip(path, path[1:]):
            clear, nm, _ = hop(u, v)
            total += nm
            for c in clear + ([v] if v not in ("SRC", "DST") else []):
                if c not in seen_c and c not in (src, dst):
                    seen_c.add(c)
                    clear_all.append(c)
        stones_used = [s for s in path if s not in ("SRC", "DST")]
        label = ("via " + " -> ".join(stones_used)) if stones_used else "DIRECT"
        out.append((corridor_score(total, clear_all), label,
                    [src] + clear_all + [dst], total, clear_all))
    # a few 1-stone alternates for the report
    alts = []
    for x in stones:
        c1, n1, ok1 = hop("SRC", x)
        c2, n2, ok2 = hop(x, "DST")
        if not (ok1 and ok2):
            continue
        seen_c, clear = set(), []
        for c in c1 + [x] + c2:
            if c not in seen_c and c not in (src, dst):
                seen_c.add(c)
                clear.append(c)
        nm = n1 + n2
        alts.append((corridor_score(nm, clear), f"via {x}",
                     [src] + clear + [dst], nm, clear))
    alts.sort(key=lambda t: t[0])
    out.extend(alts[:5])
    return out

# ----------------------------------------------------------------------------
# 4. STAGE-GRAPH AIRPORT SELECTION (dynamic program)
# ----------------------------------------------------------------------------

def choose_airports(stop_countries, pinned, candidates, ourairports, nodes,
                    banned):
    """Pick one airport per stop minimizing total consecutive-leg distance.

    stop_countries : ordered country codes for the stops
    pinned         : dict stage_index -> airport code the user typed
    candidates     : country -> [airport codes with coords]
    banned         : set of airport codes vetoed by the feasibility agent
    Countries with no usable candidate fall back to a synthetic
    'CENTROID:<code>' point at the country centroid.

    Returns (chosen list, total_nm, per-stage candidate cost table).
    """
    def stage_options(i, ctry):
        if i in pinned:
            ap = pinned[i]
            if ap in banned:
                sys.exit(f"[FATAL] user-pinned airport {ap} was judged "
                         f"infeasible; pick another.")
            if ap in ourairports.index:
                return [ap]
            print(f"[stage] pinned {ap} has no coords; using centroid of {ctry}")
            return [f"CENTROID:{ctry}"]
        opts = [a for a in candidates.get(ctry, []) if a not in banned]
        return opts or [f"CENTROID:{ctry}"]

    def pt(opt):
        if opt.startswith("CENTROID:"):
            c = opt.split(":", 1)[1]
            return float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
        return airport_pt(opt, ourairports)

    stages = [stage_options(i, c) for i, c in enumerate(stop_countries)]

    # DP over stages
    INF = float("inf")
    cost = [{opt: (0.0 if i == 0 else INF) for opt in stages[i]}
            for i in range(len(stages))]
    back = [dict() for _ in stages]
    for i in range(1, len(stages)):
        for cur in stages[i]:
            pcur = pt(cur)
            for prv in stages[i - 1]:
                c_new = cost[i - 1][prv] + haversine_nm(*pt(prv), *pcur)
                if c_new < cost[i][cur]:
                    cost[i][cur] = c_new
                    back[i][cur] = prv
    last = min(cost[-1], key=cost[-1].get)
    total = cost[-1][last]
    chosen = [last]
    for i in range(len(stages) - 1, 0, -1):
        chosen.append(back[i][chosen[-1]])
    chosen.reverse()

    # Alternates report: best achievable total if stage i were forced to alt
    alternates = []
    for i, ctry in enumerate(stop_countries):
        alts = []
        for opt in stages[i]:
            if opt == chosen[i]:
                continue
            # cheap estimate: swap the single stop, keep neighbours fixed
            delta = 0.0
            if i > 0:
                delta += (haversine_nm(*pt(chosen[i - 1]), *pt(opt))
                          - haversine_nm(*pt(chosen[i - 1]), *pt(chosen[i])))
            if i < len(stages) - 1:
                delta += (haversine_nm(*pt(opt), *pt(chosen[i + 1]))
                          - haversine_nm(*pt(chosen[i]), *pt(chosen[i + 1])))
            alts.append((delta, opt))
        alts.sort()
        alternates.append(alts[:MAX_ALTERNATES_SHOWN])
    return chosen, total, alternates

# ----------------------------------------------------------------------------
# LLM plumbing
# ----------------------------------------------------------------------------

LAST_CORRIDOR_LOG = []      # filled by plan(); used by narrate() for route options
SHOW_ALTERNATIVES = 0       # set by --alternatives N
# "gateway" (LiteLLM: LITELLM_BASE_URL/LITELLM_API_KEY/AGENT_MODEL) or "vllm" (local VLLM_URL).
# Default comes from env LLM_BACKEND, else gateway if AGENT_MODEL is set, else vllm.
# Every eval script imports this module, so setting the env once switches them all.
GATEWAY_MAX_TOKENS = int(os.environ.get("GATEWAY_MAX_TOKENS", "6000"))
# Backends: gateway = LiteLLM/OpenAI-compatible remote (LITELLM_BASE_URL, LITELLM_API_KEY, AGENT_MODEL)
#           vllm    = any OpenAI-compatible local server (VLLM_URL, VLLM_MODEL) - vLLM, Ollama, llama.cpp
#           hf      = in-process transformers model from a local folder (LOCAL_MODEL_PATH)
LLM_BACKEND = os.environ.get("LLM_BACKEND") or (
    "gateway" if os.environ.get("AGENT_MODEL") else
    "hf" if os.environ.get("LOCAL_MODEL_PATH") else "vllm")
_GW = {"client": None, "model": None}


def _gateway():
    if _GW["client"] is None:
        import httpx
        from openai import OpenAI
        base, key, model = (os.environ.get("LITELLM_BASE_URL"), os.environ.get("LITELLM_API_KEY"),
                            os.environ.get("AGENT_MODEL"))
        if not (base and key and model):
            sys.exit("[FATAL] --llm gateway needs LITELLM_BASE_URL, LITELLM_API_KEY, AGENT_MODEL")
        verify = os.environ.get("AGENT_TLS_VERIFY", "true").lower() not in ("0", "false", "no")
        _GW["client"] = OpenAI(base_url=base, api_key=key,
                               http_client=httpx.Client(verify=verify, timeout=LLM_TIMEOUT))
        _GW["model"] = model
        print(f"[llm] gateway model {model}")
    return _GW["client"], _GW["model"]


_HF = {"tok": None, "model": None}


def _hf_chat(messages):
    """In-process local model: LOCAL_MODEL_PATH is a folder saved with
    save_pretrained (or a HF cache dir). No server needed. Needs transformers+torch."""
    if _HF["model"] is None:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        path = os.environ.get("LOCAL_MODEL_PATH")
        if not path:
            sys.exit("[FATAL] --llm hf needs LOCAL_MODEL_PATH=<folder with the saved model>")
        print(f"[llm] loading local model from {path} ...")
        _HF["tok"] = AutoTokenizer.from_pretrained(path)
        _HF["model"] = AutoModelForCausalLM.from_pretrained(
            path, torch_dtype="auto", device_map="auto")
    tok, model = _HF["tok"], _HF["model"]
    ids = tok.apply_chat_template(messages, add_generation_prompt=True, return_tensors="pt")
    ids = ids.to(model.device)
    out = model.generate(ids, max_new_tokens=int(os.environ.get("LOCAL_MAX_NEW_TOKENS", "1200")),
                         do_sample=False)
    return tok.decode(out[0][ids.shape[-1]:], skip_special_tokens=True)


def llm_chat(prompt, system="You are a precise flight-clearance analyst. "
             "Follow output format instructions exactly."):
    messages = [{"role": "system", "content": system}, {"role": "user", "content": prompt}]
    if LLM_BACKEND == "hf":
        return _hf_chat(messages)
    if LLM_BACKEND == "gateway":
        client, model = _gateway()
        # Reasoning models (GPT 5.x) spend hidden "thinking" tokens out of the same
        # budget; a small max_tokens yields an EMPTY reply with finish_reason=length.
        for budget in (GATEWAY_MAX_TOKENS, GATEWAY_MAX_TOKENS * 4):
            r = client.chat.completions.create(model=model, messages=messages, max_tokens=budget)
            txt = (r.choices[0].message.content or "").strip()
            if txt:
                return txt
            fin = getattr(r.choices[0], "finish_reason", "")
            print(f"[llm] empty reply (finish_reason={fin}, budget={budget}); retrying larger")
        return ""
    payload = {"model": VLLM_MODEL, "messages": messages, "temperature": 0.0, "max_tokens": 800}
    r = requests.post(VLLM_URL, json=payload, timeout=LLM_TIMEOUT)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def llm_json(prompt):
    try:
        txt = llm_chat(prompt)
    except Exception as e:
        print(f"[llm] call failed: {e}")
        return None
    m = re.search(r"\{.*\}", txt, re.DOTALL)
    if not m:
        print(f"[llm] no JSON in reply: {txt[:200]!r}")
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        print(f"[llm] bad JSON: {m.group(0)[:200]!r}")
        return None

# ----------------------------------------------------------------------------
# LIVE TRAFFIC (OpenSky Network) — optional, requires internet
# ----------------------------------------------------------------------------
OPENSKY_URL = "https://opensky-network.org/api/states/all"
TRAFFIC_TIMEOUT = 20          # seconds per query
TRAFFIC_PAD_DEG = 1.5         # corridor padding around each leg, degrees


def leg_bbox(p1, p2, pad=TRAFFIC_PAD_DEG):
    lamin = min(p1[0], p2[0]) - pad
    lamax = max(p1[0], p2[0]) + pad
    lomin = min(p1[1], p2[1]) - pad
    lomax = max(p1[1], p2[1]) + pad
    return (max(lamin, -90), max(lomin, -180),
            min(lamax, 90), min(lomax, 180))


def opensky_traffic(bbox):
    """Return list of aircraft states in bbox, or None if unreachable."""
    lamin, lomin, lamax, lomax = bbox
    try:
        r = requests.get(OPENSKY_URL,
                         params={"lamin": lamin, "lomin": lomin,
                                 "lamax": lamax, "lomax": lomax},
                         timeout=TRAFFIC_TIMEOUT)
        r.raise_for_status()
        states = r.json().get("states") or []
    except Exception as e:
        print(f"[traffic] OpenSky unavailable: {e}")
        return None
    out = []
    for s in states:
        # OpenSky state vector indices:
        # 1=callsign 2=origin_country 5=lon 6=lat 7=baro_alt 9=velocity
        out.append({
            "callsign": (s[1] or "").strip() or "?",
            "origin_country": s[2],
            "lon": s[5], "lat": s[6],
            "alt_m": s[7], "vel_ms": s[9],
        })
    return out


def traffic_report(chosen, corridors, nodes, ourairports):
    """Query live traffic per leg; print a compact situation picture."""
    def pt(opt):
        if opt.startswith("CENTROID:"):
            c = opt.split(":", 1)[1]
            return float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
        return airport_pt(opt, ourairports)

    print("\n=== LIVE TRAFFIC (OpenSky) ===")
    print(f"  SNAPSHOT as of "
          f"{__import__('datetime').datetime.now():%Y-%m-%d %H:%M local} — "
          f"current airborne picture only, NOT a forecast for the mission "
          f"date. Re-run with --traffic on launch day.")
    any_data = False
    for a, b in zip(chosen, chosen[1:]):
        bbox = leg_bbox(pt(a), pt(b))
        states = opensky_traffic(bbox)
        if states is None:
            print(f"  {a} -> {b}: traffic data unavailable")
            continue
        any_data = True
        airborne = [s for s in states if s["alt_m"] and s["alt_m"] > 300]
        high = [s for s in airborne if s["alt_m"] > 8000]
        print(f"  {a} -> {b}: {len(states)} aircraft in corridor box "
              f"({len(airborne)} airborne, {len(high)} above FL260)")
        for s in sorted(airborne, key=lambda x: -(x['alt_m'] or 0))[:5]:
            print(f"      {s['callsign']:<9} {s['origin_country']:<20} "
                  f"alt {s['alt_m']:>7,.0f} m  "
                  f"({(s['vel_ms'] or 0) * 1.94384:,.0f} kt)")
    if not any_data:
        print("  (no leg returned data — offline or rate-limited; "
              "plan is unaffected)")
    return any_data


# ----------------------------------------------------------------------------
# WEATHER (aviationweather.gov) — free, no API key, official NOAA/FAA source
# ----------------------------------------------------------------------------
AWC_METAR_URL = "https://aviationweather.gov/api/data/metar"
AWC_TAF_URL   = "https://aviationweather.gov/api/data/taf"
WX_TIMEOUT    = 20


def fetch_wx(icao):
    """Return (metar_text, taf_text) for an ICAO, None entries on failure."""
    metar = taf = None
    try:
        r = requests.get(AWC_METAR_URL,
                         params={"ids": icao, "format": "raw"},
                         timeout=WX_TIMEOUT)
        if r.ok and r.text.strip():
            metar = r.text.strip().splitlines()[0]
    except Exception as e:
        print(f"[wx] METAR fetch failed for {icao}: {e}")
    try:
        r = requests.get(AWC_TAF_URL,
                         params={"ids": icao, "format": "raw"},
                         timeout=WX_TIMEOUT)
        if r.ok and r.text.strip():
            taf = r.text.strip()
    except Exception as e:
        print(f"[wx] TAF fetch failed for {icao}: {e}")
    return metar, taf


def weather_report(chosen, use_llm):
    """METAR/TAF per chosen stop airport; optional LLM plain-language gist."""
    print("\n=== WEATHER (aviationweather.gov) ===")
    print(f"  SNAPSHOT as of "
          f"{__import__('datetime').datetime.now():%Y-%m-%d %H:%M local} — "
          f"METAR = current conditions, TAF = next ~24-30h only. NOT valid "
          f"for the mission date; re-run with --wx on launch day.")
    collected = []
    for ap in dict.fromkeys(chosen):          # unique, order-preserving
        if ap.startswith("CENTROID:"):
            print(f"  {ap}: no airport chosen — skipping wx")
            continue
        metar, taf = fetch_wx(ap)
        if not metar and not taf:
            print(f"  {ap}: no weather data (not a reporting station, "
                  f"or offline)")
            continue
        if metar:
            print(f"  {ap} METAR: {metar}")
        if taf:
            print(f"  {ap} TAF:   {taf.splitlines()[0]}"
                  + ("  [...]" if len(taf.splitlines()) > 1 else ""))
        collected.append((ap, metar, taf))
    if use_llm and collected:
        gist = llm_chat(
            "Decode these aviation weather reports for a flight crew in "
            "plain language (<=120 words total). Highlight anything "
            "operationally significant (low ceilings/visibility, strong "
            "wind, thunderstorms, icing); say 'benign' where nothing "
            "stands out.\n" + "\n".join(
                f"{ap}:\nMETAR: {m or '(none)'}\nTAF: {t or '(none)'}"
                for ap, m, t in collected))
        print("\n  Plain-language summary:\n  " + gist.replace("\n", "\n  "))
    return bool(collected)

# ----------------------------------------------------------------------------
# 5. FEASIBILITY AGENT
# ----------------------------------------------------------------------------

def country_dossier(code, fcg):
    if code not in fcg.index:
        return "(no FCG data for this country)"
    row = fcg.loc[code]
    cap = DOSSIER_CHAR_CAP or 10 ** 9
    parts = [f"[{c}]\n{str(row[c]).strip()[:cap]}"
             for c in FEASIBILITY_COLS
             if c in row.index and pd.notna(row[c]) and str(row[c]).strip()]
    return "\n\n".join(parts) if parts else \
        "(FCG row present but all fields empty)"


def judge_country(code, name, role, travel_date, fcg, airport=None,
                  airport_in_fcg=True):
    if airport and not str(airport).startswith("CENTROID:"):
        if airport_in_fcg:
            via = (f" The plan lands at airport '{airport}' here; confirm it "
                   f"is listed/permitted in the entry-exit data.")
        else:
            via = (f" The plan lands at airport '{airport}' here. This "
                   f"airport was chosen by the user and is NOT in the "
                   f"entry-exit list; do not deny for that reason alone — "
                   f"judge only the country-level rules and flag caution if "
                   f"the data requires using designated airports of entry. "
                   f"Runway/weight/MOG notes about OTHER named airfields do not "
                   f"apply to this airport.")
    elif role != "overflight":
        via = (" No specific airport is fixed yet; the planner will choose among "
               "this country's airfields. Deny ONLY if country-level rules forbid "
               "landing or NO listed airfield could work; if one listed airfield is "
               "unsuitable (runway/weight/MOG) just say so in the reason and allow "
               "with caution so a different airfield can be chosen.")
    else:
        via = ""
    dossier = country_dossier(code, fcg)
    if VERBOSE:
        print(f"\n----- DOSSIER {code} ({name}) [{role}"
              + (f", airport {airport}" if airport else "") + "] -----")
        print(dossier)
        print("----- END DOSSIER -----\n")
    # Days available for clearance processing
    import datetime as _dt
    try:
        mission = _dt.date.fromisoformat(str(travel_date))
        days_until = (mission - _dt.date.today()).days
    except ValueError:
        days_until = None
    days_txt = (f"Today is {_dt.date.today().isoformat()}; the mission is "
                f"{days_until} days away." if days_until is not None else "")
    ac_txt = ""
    if AIRCRAFT:
        ac_txt = (f"Aircraft: {AIRCRAFT['type']}"
                  + (f" (needs ~{AIRCRAFT['min_runway_ft']:,.0f} ft runway)"
                     if AIRCRAFT.get("min_runway_ft") else "")
                  + ". Apply any aircraft-type-specific rules in the data "
                    "(armed/combat aircraft restrictions, C-17/ER "
                    "requirements, weight bearing/runway limits, MOG).\n")
    ans = llm_json(
        f"Planned mission date: {travel_date}. {days_txt}\n{ac_txt}"
        f"Country: {name} ({code}). Role: {role} "
        f"({'overflight only' if role == 'overflight' else 'landing/departure'})."
        f"{via}\nOfficial clearance data:\n---\n{dossier}"
        f"\n---\nBased ONLY on the data above, can we use this country in "
        f"this role? Consider overflight permission, entry/exit and customs "
        f"rules if landing, and lead times. Extract the MINIMUM lead time in "
        f"days required for this role (business days ~ x1.4 calendar days; "
        f"null if none stated). If data is missing or ambiguous, allow but "
        f"flag caution.\n"
        f'Respond ONLY JSON: {{"allowed": true/false, "caution": true/false, '
        f'"airport_ok": true/false, "min_lead_days": <int or null>, '
        f'"reason": "<one sentence>"}}')
    if not ans or "allowed" not in ans:
        ans = {"allowed": True, "caution": True, "airport_ok": True,
               "reason": "LLM verdict unavailable; unverified."}
    ans.setdefault("airport_ok", True)
    EVIDENCE_LOG.append({"country": code, "name": str(name), "role": role,
                         "airport": airport, "mission_date": str(travel_date),
                         "days_until": days_until, "aircraft": (AIRCRAFT or {}).get("type"),
                         "fcg_text_given_to_model": dossier,
                         "model_verdict": dict(ans)})
    # Deterministic lead-time enforcement (the LLM only extracts the number)
    lead = ans.get("min_lead_days")
    if isinstance(lead, (int, float)) and days_until is not None \
            and lead > days_until:
        msg = (f"LEAD TIME NOT MET: requires {int(lead)} days, only "
               f"{days_until} available. ")
        if role == "overflight":
            ans["allowed"] = False
        ans["caution"] = True
        ans["reason"] = msg + str(ans.get("reason", ""))
        EVIDENCE_LOG[-1]["code_enforcement"] = msg.strip()
        EVIDENCE_LOG[-1]["final_verdict"] = dict(ans)
    return ans

# ----------------------------------------------------------------------------
# FUEL (DLA standard prices, offline file; optional)
# ----------------------------------------------------------------------------

def load_fuel_rates(path=FUEL_CSV):
    """Optional fuel_rates.csv: code,description,usd_per_gallon."""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        print(f"[fuel] {path} not found — fuel notes disabled")
        return {}
    df["code"] = df["code"].astype(str).str.strip().str.upper()
    rates = {r["code"]: (r["description"], float(r["usd_per_gallon"]))
             for _, r in df.iterrows()}
    print(f"[fuel] {len(rates)} DLA fuel rates loaded")
    return rates


def load_aircraft(type_name, path=AIRCRAFT_CSV):
    """Resolve --aircraft to a spec dict. Unknown types still work (judge
    context only); known types also constrain range."""
    if not type_name:
        return None
    want = type_name.strip().upper().replace("-", "").replace(" ", "")
    try:
        df = pd.read_csv(path)
        for _, r in df.iterrows():
            have = str(r["type"]).strip().upper().replace("-", "").replace(" ", "")
            if have == want:
                spec = {"type": str(r["type"]), "range_nm": float(r["range_nm"]),
                        "min_runway_ft": float(r["min_runway_ft"]),
                        "notes": str(r.get("notes", "")),
                        "burn_lb_per_nm": (float(r["burn_lb_per_nm"])
                                           if "burn_lb_per_nm" in r and pd.notna(r["burn_lb_per_nm"]) else None),
                        "fuel_capacity_lb": (float(r["fuel_capacity_lb"])
                                             if "fuel_capacity_lb" in r and pd.notna(r["fuel_capacity_lb"]) else None)}
                print(f"[aircraft] {spec['type']}: range {spec['range_nm']:,.0f} NM, "
                      f"min runway {spec['min_runway_ft']:,.0f} ft")
                return spec
    except FileNotFoundError:
        pass
    print(f"[aircraft] '{type_name}' not in {path} — no range enforcement; "
          f"type still passed to the clearance judge")
    return {"type": type_name}


def make_fuel_notes(stop_countries, fcg, fuel_rates):
    """One note per stop: DLA rates + that country's AIR Card / cash text."""
    if not fuel_rates:
        return []
    rate_line = ", ".join(
        f"{c} ${fuel_rates[c][1]:.2f}/gal"
        for c in FUEL_CODES_SHOWN if c in fuel_rates)
    notes = []
    for ctry in stop_countries:
        pay = ""
        if ctry in fcg.index:
            bits = []
            for col in PAYMENT_COLS:
                if col in fcg.columns and pd.notna(fcg.loc[ctry].get(col)) \
                        and str(fcg.loc[ctry][col]).strip():
                    bits.append(f"{col}: "
                                f"{str(fcg.loc[ctry][col]).strip()[:150]}")
            pay = " | ".join(bits)[:400]
        notes.append(f"DLA rates: {rate_line}"
                     + (f" | payment ({ctry}): {pay}" if pay
                        else f" | payment ({ctry}): no AIR Card/cash data "
                             f"in FCG"))
    return notes


def auto_stop_search(p_src, src_ctry, src_ap, p_dst, dst_ctry, dst_ap,
                     candidates, ourairports, nodes, blocked, banned,
                     range_nm):
    """Dijkstra over FCG-designated airports to insert fuel/staging stops so
    that no leg exceeds 85% of aircraft range.

    Edge u->v exists if leg <= cap and its overflight corridor crosses no
    blocked country. Edge cost = leg NM + clearance cost of overflown
    countries + (for a landing) CLEARANCE_PENALTY for the stop country +
    LANDING_PENALTY_NM. Returns ordered list of inserted airport codes
    (possibly empty if the direct leg fits), or None if no chain exists."""
    cap = 0.85 * range_nm
    direct = haversine_nm(*p_src, *p_dst)
    if direct <= cap:
        return []
    # candidate pool: designated airports with coords, inside detour ellipse
    pool = {}
    for ctry, aps in candidates.items():
        for ap in aps:
            if ap in banned or ap in (src_ap, dst_ap):
                continue
            if ctry in blocked:
                continue          # never land in a blocked country
            p = airport_pt(ap, ourairports)
            if haversine_nm(*p_src, *p) + haversine_nm(*p, *p_dst) \
                    <= AUTO_STOP_DETOUR_FACTOR * direct:
                pool[ap] = (p, ctry)
    n_designated = len(pool)
    fallback = set()
    if AUTO_STOP_FALLBACK and "type" in ourairports.columns:
        big = ourairports[ourairports["type"].isin(AUTO_STOP_FALLBACK_TYPES)]
        for ap, r in big.iterrows():
            if ap in pool or ap in banned or ap in (src_ap, dst_ap):
                continue
            ctry = str(r["iso3"])
            if ctry in blocked or ctry not in nodes.index:
                continue
            p = (float(r["latitude_deg"]), float(r["longitude_deg"]))
            if haversine_nm(*p_src, *p) + haversine_nm(*p, *p_dst) \
                    <= AUTO_STOP_DETOUR_FACTOR * direct:
                pool[ap] = (p, ctry)
                fallback.add(ap)
    pos = {ap: v[0] for ap, v in pool.items()}
    ctry_of = {ap: v[1] for ap, v in pool.items()}
    pos["SRC"], pos["DST"] = p_src, p_dst
    ctry_of["SRC"], ctry_of["DST"] = src_ctry, dst_ctry
    print(f"[auto-stops] {src_ap or src_ctry}->{dst_ap or dst_ctry}: direct "
          f"{direct:,.0f} NM > cap {cap:,.0f} NM; {n_designated} FCG-designated "
          f"candidate stops + {len(fallback)} large-airport fallbacks "
          f"(+{NON_DESIGNATED_PENALTY_NM:.0f} NM each)")

    hop_cache = {}
    def hop(u, v):
        key = (u, v)
        if key not in hop_cache:
            _, clear, nm = direct_corridor(pos[u], pos[v], nodes,
                                           (ctry_of[u], ctry_of[v]))
            ok = not (set(clear) & blocked)
            hop_cache[key] = (clear, nm, ok)
        return hop_cache[key]

    INF = float("inf")
    dist, prev, pq, seen = {"SRC": 0.0}, {}, [(0.0, "SRC")], set()
    d_to_dst = {ap: haversine_nm(*pos[ap], *p_dst) for ap in pool}
    while pq:
        d, u = heapq.heappop(pq)
        if u in seen:
            continue
        seen.add(u)
        if u == "DST":
            break
        u_to_dst = haversine_nm(*pos[u], *p_dst)
        neigh = ["DST"] + [ap for ap in pool
                           if ap not in seen and ap != u
                           and d_to_dst[ap] <= u_to_dst + STONE_BACKTRACK_NM]
        for v in neigh:
            leg = haversine_nm(*pos[u], *pos[v])
            if leg > cap:
                continue
            clear, nm, ok = hop(u, v)
            if not ok:
                continue
            step = nm + sum(CLEARANCE_PENALTY_NM + RISK_EXTRA.get(c, 0.0)
                            for c in clear)
            if v != "DST":
                step += (CLEARANCE_PENALTY_NM + RISK_EXTRA.get(ctry_of[v], 0.0)
                         + LANDING_PENALTY_NM)
                if v in fallback:
                    step += NON_DESIGNATED_PENALTY_NM
            nd = d + step
            if nd < dist.get(v, INF):
                dist[v], prev[v] = nd, u
                heapq.heappush(pq, (nd, v))
    if "DST" not in dist:
        return None
    path = ["DST"]
    while path[-1] != "SRC":
        path.append(prev[path[-1]])
    path.reverse()
    stops = [s for s in path if s not in ("SRC", "DST")]
    print("[auto-stops] inserted: " + (" -> ".join(
        s + (" (non-designated, verify)" if s in fallback else "")
        for s in stops) or "(none)"))
    return stops


def expand_auto_stops(stop_countries, pinned, candidates, ourairports, nodes,
                      blocked, banned, range_nm):
    """Insert auto stops between each pair of user waypoints. Returns new
    (stop_countries, pinned, auto_set)."""
    def point(i):
        if i in pinned and pinned[i] in ourairports.index:
            return airport_pt(pinned[i], ourairports), pinned[i]
        c = stop_countries[i]
        return (float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])), None

    new_c, new_p, auto = [], {}, set()
    for i in range(len(stop_countries) - 1):
        pa, apa = point(i)
        pb, apb = point(i + 1)
        new_p_idx = len(new_c)
        new_c.append(stop_countries[i])
        if i in pinned:
            new_p[new_p_idx] = pinned[i]
        inserted = auto_stop_search(pa, stop_countries[i], apa, pb,
                                    stop_countries[i + 1], apb, candidates,
                                    ourairports, nodes, blocked, banned,
                                    range_nm)
        if inserted is None:
            sys.exit(f"[FATAL] --auto-stops: no chain of designated airports "
                     f"connects {apa or stop_countries[i]} to "
                     f"{apb or stop_countries[i+1]} within "
                     f"{0.85*range_nm:,.0f} NM legs avoiding {sorted(blocked)}.")
        for ap in inserted:
            new_p[len(new_c)] = ap
            new_c.append(str(ourairports.loc[ap, "iso3"]))
            auto.add(ap)
    last = len(stop_countries) - 1
    new_p_idx = len(new_c)
    new_c.append(stop_countries[last])
    if last in pinned:
        new_p[new_p_idx] = pinned[last]
    return new_c, new_p, auto


OPTIMIZE_ORDER = False      # --optimize-order: reorder interior required stops
EVIDENCE_LOG = []           # every (country, role) the judge read: FCG text + verdict
RUN_DIR = None              # runs/<timestamp>/ for this run's outputs


def optimize_stop_order(stop_countries, pinned, tokens, nodes, ourairports):
    """Keep first and last waypoint fixed, try every order of the interior
    required stops, pick the shortest total great-circle distance. Interior
    count is small (mission itineraries), so brute force is exact and instant."""
    import itertools
    def pt(i):
        if i in pinned and pinned[i] in ourairports.index:
            return airport_pt(pinned[i], ourairports)
        c = stop_countries[i]
        return float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
    n = len(stop_countries)
    interior = list(range(1, n - 1))
    if len(interior) > 8:
        print("[order] more than 8 interior stops; keeping user order")
        return stop_countries, pinned, tokens
    def total(order):
        seq = [0] + list(order) + [n - 1]
        return sum(haversine_nm(*pt(a), *pt(b)) for a, b in zip(seq, seq[1:]))
    base = total(interior)
    best, best_nm = interior, base
    for perm in itertools.permutations(interior):
        d = total(perm)
        if d < best_nm - 1e-6:
            best, best_nm = list(perm), d
    if best == interior:
        print(f"[order] user order is already shortest ({base:,.0f} NM)")
        return stop_countries, pinned, tokens
    seq = [0] + best + [n - 1]
    new_c = [stop_countries[i] for i in seq]
    new_p = {k: pinned[i] for k, i in enumerate(seq) if i in pinned}
    new_t = [tokens[i] for i in seq]
    print(f"[order] reordered interior stops: {' -> '.join(new_t)} "
          f"({base:,.0f} NM -> {best_nm:,.0f} NM, saves {base-best_nm:,.0f} NM)")
    return new_c, new_p, new_t


def write_evidence_dump(path, query, travel_date, risk_notes, risk_block):
    """Human-readable record of exactly what the judge read from the FCG for
    every country/role, the model's answer, and what the code enforced."""
    L = [f"FCG EVIDENCE DUMP", f"mission: {query}", f"date: {travel_date}",
         f"aircraft: {(AIRCRAFT or {}).get('type')}", f"llm backend: {LLM_BACKEND}",
         f"fcg fields read: {', '.join(c for c in FEASIBILITY_COLS)}", ""]
    L += ["== RISK LAYER (not from FCG) =="]
    for c, why in sorted(risk_notes.items()):
        L.append(f"  {c}: {'BLOCK' if c in risk_block else 'AVOID'} - {why}")
    L += ["", f"== FCG JUDGE: {len(EVIDENCE_LOG)} country/role reads =="]
    for e in EVIDENCE_LOG:
        v = e.get("final_verdict") or e["model_verdict"]
        L += ["", "-" * 78,
              f"{e['country']} ({e['name']})  role={e['role']}"
              + (f"  airport={e['airport']}" if e.get("airport") else "")
              + f"  days_until_mission={e.get('days_until')}",
              f"VERDICT: {'ALLOWED' if v.get('allowed') else 'DENIED'}"
              + (" (caution)" if v.get("caution") else "")
              + (f"  min_lead_days={v.get('min_lead_days')}" if v.get("min_lead_days") is not None else "")
              + (f"  airport_ok={v.get('airport_ok')}" if e.get("airport") else ""),
              f"REASON: {v.get('reason')}"]
        if e.get("code_enforcement"):
            L.append(f"CODE ENFORCED: {e['code_enforcement']}")
        L += ["FCG TEXT GIVEN TO MODEL:", e["fcg_text_given_to_model"].rstrip()]
    open(path, "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"[export] FCG evidence -> {path}")


# ---------------------------------------------------------------------------
# Natural-language mission parsing
# ---------------------------------------------------------------------------
_STOP_WORDS = r"(?:via|through|by way of|with (?:a )?stops? (?:in|at)|stopping (?:in|at|by)|stops? (?:in|at)|then)"
_STOP_LEAD = r"^(?:(?:a |with )?stops? (?:in|at|by)\s+|stopping (?:in|at|by)\s+)"


def parse_mission(text, use_llm):
    """Turn free text into the canonical 'A to B to C' form.
    Handles: 'A to B', 'A to B to C', 'fly from A to B via C and D',
    'A to B with stops in C, D', 'A to B stopping at C then D and back',
    'round trip A to B via C', '... returning to A'. Anything else -> LLM."""
    raw = text.strip().rstrip(".")
    t = raw
    # already canonical?  "A to B [to C ...]" with no itinerary words
    if not re.search(r"\b(via|stop|stops|stopping|through|then|back|return|returning|round|from|fly|plan|by way of)\b", t, re.I) \
            and len(re.split(r"\s+to\s+", t, flags=re.I)) >= 2:
        return t
    rt, back_to = False, None
    if re.search(r"\bround[- ]?trip\b", t, re.I):
        rt = True
        t = re.sub(r"\bround[- ]?trip\b", " ", t, flags=re.I)
    m = re.search(r"\b(?:and\s+)?(?:then\s+)?(?:back|return|returning)(?:\s+to\s+(?P<b>[A-Za-z0-9][A-Za-z0-9 .'()-]*?))?\s*$", t, re.I)
    if m:
        rt, back_to = True, (m.group("b") or "").strip() or None
        t = t[:m.start()].rstrip(" ,")
    t = re.sub(r"^\s*(?:please\s+)?(?:do|plan|fly|route|go|take)\s+", "", t, flags=re.I)
    t = re.sub(r"^\s*(?:a|an|the)\s+", "", t, flags=re.I)
    t = re.sub(r"^\s*(?:flight|mission|route|trip)\s+", "", t, flags=re.I)
    t = re.sub(r"^\s*from\s+", "", t, flags=re.I).strip()
    m = re.match(r"(?P<a>.+?)\s+to\s+(?P<b>.+?)(?:\s+" + _STOP_WORDS + r"\s+(?P<mid>.+))?$", t, flags=re.I)
    if not m:
        return _llm_parse_mission(raw, use_llm)
    a, b, mid = m.group("a").strip(), m.group("b").strip(), (m.group("mid") or "").strip()
    mid = re.sub(_STOP_LEAD, "", mid, flags=re.I)
    stops = [s.strip() for s in re.split(r"\s*(?:,|\band\b|\bthen\b)\s*", mid, flags=re.I) if s.strip()] if mid else []
    seq = [a] + stops + [b]
    if rt and seq[-1].upper() != (back_to or a).upper():
        seq.append(back_to or a)
    if any(re.search(r"\s", s) and not re.fullmatch(r"[A-Za-z .'()-]+", s) for s in seq):
        return _llm_parse_mission(raw, use_llm)      # something odd left in a token
    out = " to ".join(seq)
    if out.lower() != raw.lower():
        print(f"[mission] parsed: '{raw}' -> '{out}'")
    return out


def _llm_parse_mission(text, use_llm):
    if not use_llm:
        sys.exit(f"[FATAL] could not parse mission '{text}'. Use 'A to B to C' or enable the LLM.")
    ans = llm_json(
        "Extract the flight itinerary from this request. Airports are ICAO codes or names; "
        "countries are names or codes. Keep the order the user intends (origin, required "
        "stops in order, destination; if it is a round trip, the final destination is the "
        "origin). Do NOT add stops the user did not ask for.\n"
        f"Request: {text}\n"
        'Respond ONLY JSON: {"sequence": ["<origin>", "<stop>", ..., "<destination>"], '
        '"round_trip": true/false}') or {}
    seq = [str(s).strip() for s in ans.get("sequence", []) if str(s).strip()]
    if len(seq) < 2:
        sys.exit(f"[FATAL] could not parse mission '{text}' (LLM returned {ans})")
    if ans.get("round_trip") and seq[-1].upper() != seq[0].upper():
        seq.append(seq[0])
    out = " to ".join(seq)
    print(f"[mission] parsed by LLM: '{text}' -> '{out}'  (check this is what you meant)")
    return out


def plan(query, travel_date, use_llm):
    query = parse_mission(query, use_llm)
    (nodes, fcg, mapping, airport_to_country,
     candidates, ourairports) = build_dataset()

    tokens = [t for t in re.split(r"\s+to\s+", query.strip(),
                                  flags=re.IGNORECASE) if t.strip()]
    if len(tokens) < 2:
        sys.exit('[FATAL] query must be "A to B" or "A to B to C [to A]"')

    stop_countries, pinned = [], {}
    for i, t in enumerate(tokens):
        ctry, ap = resolve_waypoint(t, mapping, nodes,
                                    airport_to_country, use_llm, ourairports)
        stop_countries.append(ctry)
        if ap:
            pinned[i] = ap
    if OPTIMIZE_ORDER and len(stop_countries) > 3:
        stop_countries, pinned, tokens = optimize_stop_order(
            stop_countries, pinned, tokens, nodes, ourairports)
    round_trip = (stop_countries[0] == stop_countries[-1]
                  and len(stop_countries) > 2)
    print("[route] stops: " + " -> ".join(
        f"{c}({pinned[i]})" if i in pinned else c
        for i, c in enumerate(stop_countries))
        + ("  [round trip]" if round_trip else ""))

    graph = build_graph(nodes)
    fuel_rates = load_fuel_rates()
    user_stops, user_pinned = list(stop_countries), dict(pinned)
    if AUTO_STOPS and not (AIRCRAFT and AIRCRAFT.get("range_nm")):
        sys.exit("[FATAL] --auto-stops needs --aircraft <type> with a range "
                 "in aircraft_specs.csv")
    risk_block, risk_notes = apply_risk(nodes, mapping, USE_RISK_FEED)
    for c in risk_block & set(stop_countries):
        print(f"[risk] WARNING: stop country {c} is on the block list "
              f"({risk_notes[c]}) — landing there is the user's call")
    verdicts, blocked, banned_airports = OrderedDict(), set(), set()
    blocked |= (risk_block - set(stop_countries))   # never overfly these
    global STONE_MAX_HOP_NM, MAX_LEG_NM
    if AIRCRAFT and AIRCRAFT.get("range_nm"):
        cap = 0.85 * AIRCRAFT["range_nm"]   # 15% fuel reserve margin
        if cap < STONE_MAX_HOP_NM:
            STONE_MAX_HOP_NM = cap
            print(f"[aircraft] hop length capped at {cap:,.0f} NM "
                  f"(85% of {AIRCRAFT['type']} range)")
    overridden_stages = {}   # stage idx -> (user airport, original objection)
    for c, why in risk_notes.items():
        verdicts[(c, "risk", None)] = {"allowed": c not in risk_block,
                                       "caution": True, "reason": why}

    # Outer loop: choose airports -> validate stops+corridors -> ban/block ->
    # re-choose. Each iteration permanently removes something, so it converges.
    global AUTO_STOP_SET
    for outer in range(1, 11):
        if AUTO_STOPS:
            stop_countries, pinned, AUTO_STOP_SET = expand_auto_stops(
                user_stops, user_pinned, candidates, ourairports, nodes,
                blocked, banned_airports, AIRCRAFT["range_nm"])
            print("[route] with auto stops: " + " -> ".join(
                f"{c}({pinned[i]})" if i in pinned else c
                for i, c in enumerate(stop_countries)))
        fuel_notes = make_fuel_notes(stop_countries, fcg, fuel_rates)
        chosen, total_nm, alternates = choose_airports(
            stop_countries, pinned, candidates, ourairports, nodes,
            banned_airports)
        print(f"[opt {outer}] chosen airports: "
              + " -> ".join(chosen) + f"  ({total_nm:,.0f} NM direct)")

        # corridors per leg: compare DIRECT great-circle (ocean-preferring)
        # vs land country-graph route, scored by distance + clearance burden
        def stop_pt(opt):
            if opt.startswith("CENTROID:"):
                c = opt.split(":", 1)[1]
                return float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
            return airport_pt(opt, ourairports)

        corridors, corridor_log = [], []
        global LAST_CORRIDOR_LOG
        for i, (a, b) in enumerate(zip(stop_countries, stop_countries[1:])):
            if a == b:
                corridors.append([a])
                continue
            pa, pb = stop_pt(chosen[i]), stop_pt(chosen[i + 1])
            cands = []   # (score, label, corridor, nm, clearances)
            # Option 1: direct great circle between the chosen airports
            d_corr, d_clear, d_nm = direct_corridor(pa, pb, nodes, (a, b))
            d_blocked = [c for c in d_clear if c in blocked]
            if not d_blocked:
                cands.append((corridor_score(d_nm, d_clear),
                              "DIRECT", d_corr, d_nm, d_clear))
            # Option 2: land route through the country graph, with
            # clearance-penalized edge weights (minimizes countries, not miles)
            pgraph = {u: {v: w + CLEARANCE_PENALTY_NM + RISK_EXTRA.get(v, 0.0)
                          for v, w in nb.items()}
                      for u, nb in graph.items()}
            l_path, _ = dijkstra(pgraph, a, b, blocked)
            if l_path:
                l_clear = [c for c in l_path if c not in (a, b)]
                l_nm = sum(graph[u][v] for u, v in zip(l_path, l_path[1:]))
                cands.append((corridor_score(l_nm, l_clear),
                              "LAND graph", l_path, l_nm, l_clear))
            # Option 3: stepping stones (1-2 intermediates, uncapped hops,
            # e.g. USA -> JPN -> THA across the Pacific)
            cands.extend(stepping_stone_corridors(
                pa, pb, a, b, nodes, blocked, d_nm))
            if not cands:
                sys.exit(f"[FATAL] no corridor {a}->{b}: direct crosses "
                         f"blocked {d_blocked} and no land/stepping-stone "
                         f"route avoids {sorted(blocked)}.\n"
                         f"        Many of these are LEAD TIME denials — try a "
                         f"later --date, or add an intermediate stop as a "
                         f"waypoint (e.g. '... to rjtt to ... to {b}').")
            cands.sort(key=lambda t: t[0])
            best = cands[0]
            corridors.append(best[2])
            LAST_CORRIDOR_LOG = corridor_log
            corridor_log.append({
                "leg": f"{chosen[i]} -> {chosen[i + 1]}",
                "leg_nm_direct": round(haversine_nm(*pa, *pb)),
                "countries": f"{a} -> {b}",
                "chosen": {"option": best[1], "nm": round(best[3]),
                           "clearances": list(best[4]),
                           "score": round(best[0])},
                "alternatives": [{"option": c_[1], "nm": round(c_[3]),
                                  "clearances": list(c_[4]),
                                  "score": round(c_[0])} for c_ in cands[1:5]],
                "direct_rejected_blocked": d_blocked})
            print(f"    [corridor {a}->{b}] {best[1]}: {best[3]:,.0f} NM, "
                  f"{len(best[4])} clearances "
                  f"({', '.join(best[4]) or 'none - international waters'})")
            for alt in cands[1:4]:
                print(f"        alt {alt[1]}: {alt[3]:,.0f} NM, "
                      f"{len(alt[4])} clearances")
            if d_blocked:
                print(f"        (direct rejected: crosses blocked "
                      f"{d_blocked})")

        if not use_llm:
            return (chosen, total_nm, alternates, stop_countries,
                    corridors, verdicts, nodes, ourairports, [],
                    fuel_notes)

        changed = False
        pinned_set = set(pinned.values())
        # judge stop countries (+ their chosen airports)
        for i, (ctry, ap) in enumerate(zip(stop_countries, chosen)):
            key = (ctry, "stop", ap)
            if key not in verdicts:
                v = judge_country(ctry, nodes.loc[ctry, "country"], "stop",
                                  travel_date, fcg, ap,
                                  airport_in_fcg=(ap in airport_to_country))
                # Deterministic guard: a USER-PINNED airport outside the FCG
                # designated list must not be denied merely for being
                # unlisted. Downgrade any denial of such an airport to a
                # caution — the user chose it (e.g. home base) deliberately.
                if ap in pinned_set and ap not in AUTO_STOP_SET \
                        and ap not in airport_to_country and \
                        not (v["allowed"] and v.get("airport_ok", True)):
                    print(f"    [OVERRIDE] {ctry}/{ap}: user-pinned, "
                          f"non-designated airport — denial downgraded to "
                          f"caution ({v['reason']})")
                    overridden_stages[i] = (ap, v["reason"])
                    v = {"allowed": True, "airport_ok": True, "caution": True,
                         "reason": f"User-pinned non-designated airport; "
                                   f"review: {v['reason']}"}
                verdicts[key] = v
                ok = v["allowed"] and v.get("airport_ok", True)
                print(f"    [{'OK ' if ok else 'DENY'}] stop {ctry}/{ap}: "
                      f"{v['reason']}")
                if not v["allowed"]:
                    sys.exit(f"[FATAL] stop country {ctry} infeasible: "
                             f"{v['reason']}")
                if not v.get("airport_ok", True) \
                        and not ap.startswith("CENTROID:") \
                        and (ap not in pinned_set or ap in AUTO_STOP_SET):
                    banned_airports.add(ap)
                    changed = True
                    if ap in AUTO_STOP_SET:
                        print(f"    auto stop {ap} rejected — re-searching")
        # judge overflight countries in corridors
        for path in corridors:
            for code in path:
                if code in stop_countries:
                    continue
                key = (code, "overflight", None)
                if key in verdicts:
                    v = verdicts[key]
                else:
                    v = judge_country(code, nodes.loc[code, "country"],
                                      "overflight", travel_date, fcg)
                    verdicts[key] = v
                    print(f"    [{'OK ' if v['allowed'] else 'DENY'}] "
                          f"overflight {code}: {v['reason']}")
                if not v["allowed"] and code not in blocked:
                    blocked.add(code)
                    changed = True
        if not changed:
            # Export FCG-derived constraints so eval_routes.py can replay
            # the routing under exactly these blocks (--blocks-file).
            try:
                json.dump({"query": query, "date": travel_date,
                           "blocked_countries": sorted(blocked),
                           "banned_airports": sorted(banned_airports),
                           "stops": list(chosen),
                           "stop_countries": list(stop_countries),
                           "auto_stops": sorted(AUTO_STOP_SET),
                           "required_stops": [a for a in chosen if a not in AUTO_STOP_SET],
                           "required_tokens": list(tokens),
                           "round_trip": bool(round_trip),
                           "aircraft": AIRCRAFT,
                           "corridors": corridor_log,
                           "total_nm": round(total_nm),
                           "fuel_notes": fuel_notes,
                           "config": {"clearance_penalty_nm": CLEARANCE_PENALTY_NM,
                                      "landing_penalty_nm": LANDING_PENALTY_NM,
                                      "risk_avoid_penalty_nm": RISK_AVOID_PENALTY_NM,
                                      "non_designated_penalty_nm": NON_DESIGNATED_PENALTY_NM,
                                      "range_fraction": 0.85},
                           "verdicts": {f"{c}/{r}/{a}": v
                                        for (c, r, a), v in verdicts.items()}},
                          open("last_run_blocks.json", "w"), indent=1)
                print("[export] FCG-derived blocks -> last_run_blocks.json")
                if RUN_DIR:
                    import shutil
                    shutil.copy("last_run_blocks.json", os.path.join(RUN_DIR, "last_run_blocks.json"))
                    write_evidence_dump(os.path.join(RUN_DIR, "fcg_evidence.txt"),
                                        query, travel_date, risk_notes, risk_block)
                    json.dump(EVIDENCE_LOG, open(os.path.join(RUN_DIR, "fcg_evidence.json"), "w"),
                              indent=1, default=str)
            except Exception as e:
                print(f"[export] could not write last_run_blocks.json: {e}")
            suggestions = suggest_compliant_alternatives(
                overridden_stages, stop_countries, pinned, candidates,
                ourairports, nodes, banned_airports, chosen, total_nm,
                travel_date, fcg, verdicts, airport_to_country)
            return (chosen, total_nm, alternates, stop_countries,
                    corridors, verdicts, nodes, ourairports, suggestions,
                    fuel_notes)
        print(f"    replanning (banned airports: {sorted(banned_airports)}; "
              f"blocked countries: {sorted(blocked)})")
    sys.exit("[FATAL] plan did not stabilise within 10 iterations.")


def suggest_compliant_alternatives(overridden_stages, stop_countries, pinned,
                                   candidates, ourairports, nodes,
                                   banned_airports, chosen, total_nm,
                                   travel_date, fcg, verdicts,
                                   airport_to_country):
    """For each user-pinned airport the judge objected to, compute the best
    fully-compliant alternative route (that stage unpinned, restricted to
    FCG-designated candidates) and judge the substitute airport."""
    suggestions = []
    for i, (user_ap, objection) in overridden_stages.items():
        ctry = stop_countries[i]
        if not candidates.get(ctry):
            suggestions.append({
                "stage": i, "country": ctry, "user_airport": user_ap,
                "objection": objection, "alt": None,
                "note": "no FCG-designated airport with coordinates in this "
                        "country — no compliant alternative exists"})
            continue
        pinned2 = {k: v for k, v in pinned.items() if k != i}
        alt_chosen, alt_total, _ = choose_airports(
            stop_countries, pinned2, candidates, ourairports, nodes,
            banned_airports)
        alt_ap = alt_chosen[i]
        key = (ctry, "stop", alt_ap)
        if key not in verdicts:
            v = judge_country(ctry, nodes.loc[ctry, "country"], "stop",
                              travel_date, fcg, alt_ap,
                              airport_in_fcg=(alt_ap in airport_to_country))
            verdicts[key] = v
        v = verdicts[key]
        suggestions.append({
            "stage": i, "country": ctry, "user_airport": user_ap,
            "objection": objection, "alt": alt_ap,
            "alt_route": alt_chosen, "alt_total_nm": alt_total,
            "delta_nm": alt_total - total_nm,
            "alt_verdict": v})
    return suggestions


def narrate(chosen, total_nm, alternates, stop_countries, corridors,
            verdicts, nodes, ourairports, suggestions, fuel_notes,
            travel_date, use_llm):
    def ap_name(ap):
        if ap.startswith("CENTROID:"):
            c = ap.split(":", 1)[1]
            return f"{nodes.loc[c, 'country']} centroid (no designated " \
                   f"airport with coords)"
        return f"{ap} ({ourairports.loc[ap, 'name']})"

    print("\n=== FINAL PLAN ===")
    for i, (ctry, ap) in enumerate(zip(stop_countries, chosen)):
        print(f"Stop {i + 1}: {nodes.loc[ctry, 'country']} ({ctry}) — "
              f"{ap_name(ap)}"
              + ("  [AUTO fuel/staging stop]" if ap in AUTO_STOP_SET else ""))
        if fuel_notes:
            print(f"        fuel: {fuel_notes[i]}")
        alts = alternates[i]
        if alts:
            for delta, alt in alts:
                print(f"        alt: {ap_name(alt)}  ({delta:+,.0f} NM)")
    print("\nLegs:")
    for i, ((a, b), corridor) in enumerate(
            zip(zip(chosen, chosen[1:]), corridors)):
        def pt(opt):
            if opt.startswith("CENTROID:"):
                c = opt.split(":", 1)[1]
                return float(nodes.loc[c, "lat"]), float(nodes.loc[c, "lon"])
            return airport_pt(opt, ourairports)
        d = haversine_nm(*pt(a), *pt(b))
        print(f"  {a} -> {b}: {d:,.0f} NM | overflight corridor: "
              f"{' -> '.join(corridor)}")
        if AIRCRAFT and AIRCRAFT.get("range_nm") \
                and d > 0.85 * AIRCRAFT["range_nm"]:
            print(f"      WARNING: leg exceeds 85% of {AIRCRAFT['type']} "
                  f"range ({AIRCRAFT['range_nm']:,.0f} NM) — add a fuel-stop "
                  f"waypoint to this leg")
    print(f"Total direct distance: {total_nm:,.0f} NM")
    if SHOW_ALTERNATIVES and LAST_CORRIDOR_LOG:
        rng = (AIRCRAFT or {}).get("range_nm")
        burn = (AIRCRAFT or {}).get("burn_lb_per_nm")
        cap_lb = (AIRCRAFT or {}).get("fuel_capacity_lb")
        print(f"\n=== ROUTE OPTIONS PER LEG (top {SHOW_ALTERNATIVES}; score = NM + "
              f"{CLEARANCE_PENALTY_NM:.0f}/clearance + risk) ===")
        for c in LAST_CORRIDOR_LOG:
            opts = [c["chosen"]] + c.get("alternatives", [])[:max(0, SHOW_ALTERNATIVES - 1)]
            print(f"{c['leg']}  ({c['countries']})")
            for k, o in enumerate(opts):
                nm = o["nm"]
                fuel = ""
                if rng:
                    ok = nm <= 0.85 * rng
                    fuel = f" | fuel: {'OK' if ok else 'EXCEEDS 85% range'} ({nm/rng*100:.0f}% of range)"
                    if burn:
                        est = nm * burn
                        fuel += f", ~{est:,.0f} lb burn"
                        if cap_lb:
                            fuel += f" ({est/cap_lb*100:.0f}% of capacity)"
                tag = "CHOSEN" if k == 0 else f"option {k}"
                print(f"   {tag:9} {o['option']:<28} {nm:>6,} NM  "
                      f"{len(o['clearances'])} clearances [{' '.join(o['clearances']) or 'water'}]  "
                      f"score {o['score']:,}{fuel}")
            if c.get("direct_rejected_blocked"):
                print(f"   (great circle rejected: crosses blocked {c['direct_rejected_blocked']})")
        print("Options are ordered by score; a longer option with fewer clearances may be "
              "preferable when fuel allows — the exchange rate is the clearance penalty.")
    cautions = {k: v for k, v in verdicts.items() if v.get("caution")}
    if cautions:
        print("Cautions:")
        for (code, role, ap), v in cautions.items():
            tag = f"{code}/{ap}" if ap else code
            print(f"  - {tag} ({role}): {v['reason']}")
    if suggestions:
        print("\n=== COMPLIANT ALTERNATIVES (your requested airport drew "
              "objections) ===")
        for s in suggestions:
            print(f"Stop {s['stage'] + 1} ({s['country']}): you requested "
                  f"{s['user_airport']}")
            print(f"    objection: {s['objection']}")
            if s.get("alt") is None:
                print(f"    {s['note']}")
                continue
            av = s["alt_verdict"]
            status = ("compliant" if av["allowed"]
                      and av.get("airport_ok", True) else "also objected")
            print(f"    suggested: {ap_name(s['alt'])} [{status}] — "
                  f"{av['reason']}")
            print(f"    revised route: {' -> '.join(s['alt_route'])} "
                  f"({s['alt_total_nm']:,.0f} NM, "
                  f"{s['delta_nm']:+,.0f} NM vs your request)")
        print("Your requested route above remains the primary plan; the "
              "alternatives are ready if the cautions are disqualifying.")
    if use_llm:
        summary = llm_chat(
            f"Mission date {travel_date}.\nStops and chosen airports:\n"
            + "\n".join(f"{c}: {a}" for c, a in zip(stop_countries, chosen))
            + "\nOverflight corridors per leg:\n"
            + "\n".join(" -> ".join(p) for p in corridors)
            + "\nVerdicts:\n"
            + json.dumps({f"{c}/{r}/{a}": v
                          for (c, r, a), v in verdicts.items()}, indent=1)
            + ("\nCompliant alternative suggestions (user-requested airports "
               "drew objections):\n"
               + json.dumps([{k: v for k, v in s.items()
                              if k != "alt_verdict"} for s in suggestions],
                            indent=1)
               if suggestions else "")
            + "\nCorridor country lists are in flight order.\n"
              "Write a short operational briefing (<=220 words) in PLAIN "
              "TEXT: no LaTeX, no markdown symbols, use '->' for arrows. "
              "Cover: per-leg "
              "rationale, why each airport was chosen, required lead-time "
              "actions, cautions, and if alternatives exist, a one-line "
              "recommendation on requested-vs-alternative airports.")
        print("\n=== BRIEFING ===\n" + summary)

# ----------------------------------------------------------------------------
# --list MODE
# ----------------------------------------------------------------------------

def list_airports(country_query, use_llm):
    (nodes, fcg, mapping, airport_to_country,
     candidates, ourairports) = build_dataset()
    code, _ = resolve_waypoint(country_query, mapping, nodes,
                               airport_to_country, use_llm, ourairports)
    name = nodes.loc[code, "country"]
    print(f"\n=== ENTRY/EXIT AIRPORTS: {name} ({code}) ===")
    extracted = sorted(a for a, c in airport_to_country.items() if c == code)
    for ap in extracted:
        if ap in ourairports.index:
            r = ourairports.loc[ap]
            print(f"  {ap}: {r['name']}  "
                  f"({r['latitude_deg']:.3f}, {r['longitude_deg']:.3f})")
        else:
            print(f"  {ap}: (no coordinates in OurAirports)")
    if not extracted:
        print("  (none extracted from FCG text)")
    print(f"\n=== FULL FCG DOSSIER: {name} ({code}) ===")
    print(country_dossier(code, fcg))
    raw = ""
    if code in fcg.index and AIRPORT_COL in fcg.columns:
        raw = str(fcg.loc[code].get(AIRPORT_COL, "") or "").strip()
    restr = ""
    if code in fcg.index and AIRPORT_COL_2 in fcg.columns:
        restr = str(fcg.loc[code].get(AIRPORT_COL_2, "") or "").strip()
    if use_llm and (raw or restr):
        ans = llm_json(
            f"Country: {name} ({code}). Official entry/exit airport data:\n"
            f"---\n{raw}\n---\nAirfield restrictions:\n---\n"
            f"{restr or '(none)'}\n---\nBased ONLY on this text, list the "
            f"designated airports and their status. Use ONLY airports "
            f"mentioned in the text — never invent.\n"
            f'Respond ONLY JSON: {{"usable": [{{"code": "...", '
            f'"conditions": "<short or empty>"}}], '
            f'"restricted_or_prohibited": [{{"code": "...", '
            f'"reason": "<short>"}}], "notes": "<one sentence>"}}')
        if ans:
            print("\n=== STRUCTURED VERDICT (LLM, grounded in text above) ===")
            for a in ans.get("usable", []):
                cond = f" — {a['conditions']}" if a.get("conditions") else ""
                print(f"  USABLE     {a.get('code', '?')}{cond}")
            for a in ans.get("restricted_or_prohibited", []):
                print(f"  RESTRICTED {a.get('code', '?')} — "
                      f"{a.get('reason', '')}")
            if ans.get("notes"):
                print(f"  Notes: {ans['notes']}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("query",
                    help='mission in plain words: "KSUU to FKKD", "KLRF to DGAA via stops in '
                         'TJSJ and GVAC", "round trip KSUU to FKKD via DGAA" — or one country with --list')
    ap.add_argument("--date", required=True, help="mission date YYYY-MM-DD (lead times depend on it)")
    ap.add_argument("--out", default=None,
                    help="output folder (default runs/<timestamp>); gets plan_log.txt, "
                         "last_run_blocks.json, fcg_evidence.txt/.json")
    ap.add_argument("--no-llm", action="store_true")
    ap.add_argument("--list", action="store_true",
                    help="list designated entry/exit airports for a country")
    ap.add_argument("--verbose", action="store_true",
                    help="print each country's full FCG dossier as judged")
    ap.add_argument("--traffic", action="store_true",
                    help="query OpenSky for live aircraft along each leg "
                         "(requires internet; failures are non-fatal)")
    ap.add_argument("--llm", choices=["vllm", "gateway", "hf"], default=None,
                    help="gateway = LiteLLM (AGENT_MODEL); vllm = local OpenAI-compatible server "
                         "(VLLM_URL/VLLM_MODEL); hf = in-process model from LOCAL_MODEL_PATH")
    ap.add_argument("--optimize-order", action="store_true",
                    help="reorder the interior required stops (first/last fixed) "
                         "to minimise total distance; default keeps your order")
    ap.add_argument("--alternatives", type=int, default=0,
                    help="show the top-N corridor options per leg with fuel feasibility")
    ap.add_argument("--clearance-penalty", type=float, default=None,
                    help="override NM penalty per clearance (default 300)")
    ap.add_argument("--aircraft", default=None,
                    help="aircraft type (e.g. C-17); constrains hop range "
                         "and informs clearance judging")
    ap.add_argument("--auto-stops", action="store_true",
                    help="insert fuel/staging stops automatically so no leg "
                         "exceeds 85%% of aircraft range (needs --aircraft)")
    ap.add_argument("--risk", action="store_true",
                    help="fetch US State Dept travel advisories (free RSS) "
                         "and block/penalize Level 4/3 countries; the manual "
                         "avoid_countries.csv is always applied")
    ap.add_argument("--wx", action="store_true",
                    help="fetch METAR/TAF for each stop airport from "
                         "aviationweather.gov (free, no key; non-fatal)")
    args = ap.parse_args()
    import datetime as _dt
    try:
        _dt.date.fromisoformat(args.date)
    except ValueError:
        sys.exit(f"[FATAL] --date '{args.date}' is not a valid YYYY-MM-DD "
                 f"date. Lead-time checks depend on it.")
    if _dt.date.fromisoformat(args.date) < _dt.date.today():
        sys.exit(f"[FATAL] --date {args.date} is in the past; every lead-time check would fail.")
    use_llm = not args.no_llm
    if not args.list:
        RUN_DIR = args.out or os.path.join("runs", _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        os.makedirs(RUN_DIR, exist_ok=True)

        class _Tee:
            def __init__(self, *s): self.s = s
            def write(self, d):
                for x in self.s: x.write(d)
            def flush(self):
                for x in self.s: x.flush()
        _logf = open(os.path.join(RUN_DIR, "plan_log.txt"), "w", encoding="utf-8")
        sys.stdout = _Tee(sys.__stdout__, _logf)
        print(f"[run] outputs -> {RUN_DIR}/")
    if args.verbose:
        VERBOSE = True
    if args.risk:
        USE_RISK_FEED = True
    if args.llm:
        LLM_BACKEND = args.llm
    print(f"[llm] backend: {LLM_BACKEND}")
    SHOW_ALTERNATIVES = args.alternatives
    OPTIMIZE_ORDER = args.optimize_order
    if args.clearance_penalty is not None:
        CLEARANCE_PENALTY_NM = args.clearance_penalty
        print(f"[config] clearance penalty {CLEARANCE_PENALTY_NM:.0f} NM")
    if args.aircraft:
        AIRCRAFT = load_aircraft(args.aircraft)
    if args.auto_stops:
        AUTO_STOPS = True
    if args.list:
        list_airports(args.query, use_llm)
        sys.exit(0)
    result = plan(args.query, args.date, use_llm)
    narrate(*result, args.date, use_llm)
    chosen_, _, _, _, corridors_, _, nodes_, ourairports_, _, _ = result
    if args.traffic:
        traffic_report(chosen_, corridors_, nodes_, ourairports_)
    if args.wx:
        weather_report(chosen_, use_llm)
