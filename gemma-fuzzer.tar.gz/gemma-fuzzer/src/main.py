"""
main.py — gemma-fuzzer orchestrator.

Workflow:
1. Start LibFuzzer on the target harness
2. Periodically check for new crashes
3. Analyze crashes with Gemma (via vLLM)
4. Copy crash files to PoV output dir (auto-submitted by libCRS daemon)
5. Periodically ask Gemma for new seed suggestions
6. Wait for fuzzer to finish
"""

from __future__ import annotations

import argparse
import logging
import shutil
import sys
import time
from pathlib import Path

from crash_analyzer import CrashAnalyzer
from fuzzer import LibFuzzerRunner
from llm_client import VLLMClient

LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="gemma-fuzzer orchestrator")
    p.add_argument("--build-dir",   required=True)
    p.add_argument("--src-dir",     required=True)
    p.add_argument("--output-dir",  required=True)
    p.add_argument("--seed-dir",    default=None)
    p.add_argument("--log-dir",     default="/var/log/gemma-fuzzer")
    p.add_argument("--harness",     required=True)
    p.add_argument("--vllm-host",   default="host.docker.internal")
    p.add_argument("--vllm-port",   default="8000")
    p.add_argument("--vllm-model",  default="google/gemma-3-1b-it")
    p.add_argument("--fuzz-timeout", type=int, default=3600)
    p.add_argument("--fuzz-jobs",    type=int, default=1)
    p.add_argument("--llm-seed-interval", type=int, default=120,
                   help="Seconds between LLM seed generation rounds")
    return p.parse_args()


def setup_logging(log_dir: str) -> None:
    """Configure logging to both stderr and a file."""
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    handlers = [
        logging.StreamHandler(sys.stderr),
        logging.FileHandler(Path(log_dir) / "orchestrator.log"),
    ]
    logging.basicConfig(
        level=logging.INFO,
        format=LOG_FORMAT,
        handlers=handlers,
    )


def main() -> None:
    args = parse_args()
    setup_logging(args.log_dir)
    logger = logging.getLogger("gemma-fuzzer")
    logger.info("=" * 60)
    logger.info("gemma-fuzzer starting")
    logger.info("  harness:      %s", args.harness)
    logger.info("  build_dir:    %s", args.build_dir)
    logger.info("  fuzz_timeout: %ds", args.fuzz_timeout)
    logger.info("  vllm:         %s:%s (%s)", args.vllm_host, args.vllm_port, args.vllm_model)
    logger.info("=" * 60)

    output_dir = Path(args.output_dir)
    pov_dir = output_dir / "povs"
    corpus_dir = output_dir / "corpus"
    crash_dir = output_dir / "crashes"
    pov_dir.mkdir(parents=True, exist_ok=True)
    corpus_dir.mkdir(parents=True, exist_ok=True)
    crash_dir.mkdir(parents=True, exist_ok=True)

    # ── Initialize components ─────────────────────────────────────

    llm = VLLMClient(
        host=args.vllm_host,
        port=args.vllm_port,
        model=args.vllm_model,
    )

    analyzer = CrashAnalyzer(
        llm=llm,
        src_dir=args.src_dir,
        output_dir=args.output_dir,
    )

    runner = LibFuzzerRunner(
        build_dir=args.build_dir,
        harness=args.harness,
        corpus_dir=str(corpus_dir),
        crash_dir=str(crash_dir),
        seed_dir=args.seed_dir,
        jobs=args.fuzz_jobs,
    )

    # ── Start fuzzing ─────────────────────────────────────────────

    runner.start(duration=args.fuzz_timeout)
    logger.info("LibFuzzer launched for %d seconds.", args.fuzz_timeout)

    # ── Main loop: monitor crashes + periodic LLM seed generation ─

    crashes_processed = 0
    last_seed_gen = 0.0
    crash_summaries: list[str] = []

    # Generate initial seeds with LLM before fuzzer warms up
    logger.info("Generating initial LLM seeds...")
    analyzer.generate_seeds(args.harness, [])
    last_seed_gen = time.monotonic()

    while runner.is_running():
        time.sleep(5)  # poll interval

        # ── Process new crashes ──
        new_crashes = runner.get_new_crashes(since_idx=crashes_processed)
        for crash in new_crashes:
            logger.info(
                "Processing crash: %s (%s)",
                crash.crash_type, crash.crash_file,
            )

            # Analyze with LLM
            report = analyzer.analyze_crash(
                crash_file=crash.crash_file,
                stack_trace=crash.stack_trace,
            )

            # Copy crash file to PoV dir (auto-submitted by libCRS daemon)
            if crash.crash_file and Path(crash.crash_file).exists():
                pov_dest = pov_dir / Path(crash.crash_file).name
                shutil.copy2(crash.crash_file, pov_dest)
                logger.info("PoV copied: %s", pov_dest)

            # Track summary for seed generation context
            summary = crash.crash_type
            if report and report.get("root_cause"):
                summary = f"{crash.crash_type}: {report['root_cause']}"
            crash_summaries.append(summary)

        crashes_processed += len(new_crashes)

        # ── Periodic LLM seed generation ──
        now = time.monotonic()
        if (now - last_seed_gen) >= args.llm_seed_interval:
            logger.info("Running periodic LLM seed generation...")
            count = analyzer.generate_seeds(args.harness, crash_summaries)
            last_seed_gen = now

    # ── Final summary ─────────────────────────────────────────────

    runner.wait()

    # Process any remaining crashes
    final_crashes = runner.get_new_crashes(since_idx=crashes_processed)
    for crash in final_crashes:
        analyzer.analyze_crash(crash.crash_file, crash.stack_trace)
        if crash.crash_file and Path(crash.crash_file).exists():
            pov_dest = pov_dir / Path(crash.crash_file).name
            shutil.copy2(crash.crash_file, pov_dest)
        crash_summaries.append(crash.crash_type)

    total_crashes = len(runner.state.crashes)
    total_povs = len(list(pov_dir.glob("*")))
    total_bugs = len(list((output_dir / "bugs").glob("*")))

    logger.info("=" * 60)
    logger.info("gemma-fuzzer finished")
    logger.info("  Total executions: %d", runner.state.total_execs)
    logger.info("  Unique crashes:   %d", total_crashes)
    logger.info("  PoVs submitted:   %d", total_povs)
    logger.info("  Bug reports:      %d", total_bugs)
    logger.info("=" * 60)


if __name__ == "__main__":
    main()
