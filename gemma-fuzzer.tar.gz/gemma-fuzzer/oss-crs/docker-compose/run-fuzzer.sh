#!/bin/bash
# oss-crs/docker-compose/run-fuzzer.sh
# Entry point for gemma-fuzzer runtime.
# Orchestrates: build output download → LibFuzzer → LLM analysis → PoV submission
set -euo pipefail

echo "============================================="
echo " gemma-fuzzer v0.1.0"
echo " Target: ${OSS_CRS_TARGET:-unknown}"
echo " Harness: ${OSS_CRS_TARGET_HARNESS:-unknown}"
echo " CPUs: ${OSS_CRS_CPUSET:-all}"
echo "============================================="

# ── 1. Download build outputs ──
echo "[init] Downloading build outputs..."
libCRS download-build-output asan/build /opt/target/build
libCRS download-build-output asan/src   /opt/target/src
echo "[init] Build outputs ready."

# ── 2. Register artifact submission directories ──
mkdir -p /output/{povs,seeds,bugs}

# These run as background daemons — they watch directories and submit
# new files to OSS-CRS automatically.
libCRS register-submit-dir pov           /output/povs  &
libCRS register-submit-dir seed          /output/seeds &
libCRS register-submit-dir bug-candidate /output/bugs  &

# Persist agent logs so they're visible via `oss-crs artifacts`
mkdir -p /var/log/gemma-fuzzer
libCRS register-log-dir /var/log/gemma-fuzzer

# ── 3. Fetch any bootup seeds (from --seed-dir flag) ──
mkdir -p /input/seeds
libCRS fetch seed /input/seeds || true

# ── 4. Launch the Python orchestrator ──
echo "[init] Starting orchestrator..."
exec /opt/gemma-fuzzer/venv/bin/python3 /opt/gemma-fuzzer/src/main.py \
    --build-dir    /opt/target/build \
    --src-dir      /opt/target/src \
    --output-dir   /output \
    --seed-dir     /input/seeds \
    --log-dir      /var/log/gemma-fuzzer \
    --harness      "${OSS_CRS_TARGET_HARNESS}" \
    --vllm-host    "${VLLM_HOST:-host.docker.internal}" \
    --vllm-port    "${VLLM_PORT:-8000}" \
    --vllm-model   "${VLLM_MODEL:-google/gemma-3-1b-it}" \
    --fuzz-timeout "${FUZZ_TIMEOUT:-3600}" \
    --fuzz-jobs    "${FUZZ_JOBS:-1}" \
    --llm-seed-interval "${LLM_SEED_INTERVAL:-120}"
