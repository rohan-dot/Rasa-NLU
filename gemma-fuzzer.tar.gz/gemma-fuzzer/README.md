# gemma-fuzzer

An LLM-guided LibFuzzer CRS for [OSS-CRS](https://github.com/ossf/oss-crs).

Uses **Gemma 3 1B** (served via vLLM) to enhance fuzzing with:
- **Crash analysis** — ASAN stack traces are sent to the LLM for triage, root-cause analysis, and CWE classification.
- **Seed generation** — The LLM periodically suggests new seed inputs targeting unexplored code paths.
- **Graceful degradation** — If vLLM is unreachable, fuzzing continues normally without LLM features.

## Prerequisites

| Requirement | Version |
|-------------|---------|
| Docker      | >= 20.10 (for `host.docker.internal` support) |
| Python      | >= 3.10 |
| uv          | latest |
| Git         | latest |
| vLLM        | running on `localhost:8000` with Gemma 3 1B loaded |

### Check Docker access

```bash
docker info          # must succeed
docker run --rm hello-world   # must pull and run
```

If Docker is not available, check if Podman is installed (`podman info`).
Podman is Docker-compatible and works with OSS-CRS.

### Start vLLM

```bash
# Example — adjust model path/name for your 4-bit quantized Gemma
vllm serve google/gemma-3-1b-it \
    --host 0.0.0.0 \
    --port 8000 \
    --quantization awq   # or gptq, depending on your quant format
```

Verify it's running:
```bash
curl http://localhost:8000/v1/models
```

## Quick Start

```bash
# 1. Clone OSS-CRS and this repo
git clone https://github.com/ossf/oss-crs.git ~/oss-crs
git clone https://github.com/google/oss-fuzz.git ~/oss-fuzz
cd /path/to/gemma-fuzzer

# 2. Prepare (builds Docker images)
cd ~/oss-crs
uv run oss-crs prepare \
    --compose-file /path/to/gemma-fuzzer/compose.yaml

# 3. Build the target (e.g., libxml2)
uv run oss-crs build-target \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2

# 4. Run the CRS (10-minute example)
uv run oss-crs run \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2 \
    --target-harness xml \
    --timeout 600

# 5. Check results
uv run oss-crs artifacts \
    --compose-file /path/to/gemma-fuzzer/compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2 \
    --target-harness xml
```

## Configuration

Environment variables (set in compose.yaml → `additional_env` or via `.env`):

| Variable | Default | Description |
|----------|---------|-------------|
| `VLLM_HOST` | `host.docker.internal` | vLLM server hostname (from inside Docker) |
| `VLLM_PORT` | `8000` | vLLM server port |
| `VLLM_MODEL` | `google/gemma-3-1b-it` | Model name as registered in vLLM |
| `FUZZ_TIMEOUT` | `3600` | Total fuzzing duration in seconds |
| `FUZZ_JOBS` | `1` | Number of parallel LibFuzzer workers |
| `LLM_SEED_INTERVAL` | `120` | Seconds between LLM seed generation rounds |

### Linux host networking

On Linux, `host.docker.internal` may not resolve. Use your Docker bridge IP instead:

```bash
ip addr show docker0   # look for inet address, typically 172.17.0.1
```

Then set `VLLM_HOST=172.17.0.1` in your compose or `.env`.

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                gemma-fuzzer container                  │
│                                                       │
│  ┌─────────────┐    ┌──────────────┐                 │
│  │  LibFuzzer   │───▶│ Crash files  │                 │
│  │  (process)   │    │ /output/     │                 │
│  └─────────────┘    │  crashes/    │                 │
│                      └──────┬───────┘                 │
│                             │                         │
│                      ┌──────▼───────┐                 │
│                      │ Orchestrator  │                 │
│                      │ (main.py)     │                 │
│                      └──┬────────┬──┘                 │
│                         │        │                    │
│              ┌──────────▼─┐  ┌───▼──────────┐        │
│              │ PoV output  │  │ LLM analysis │        │
│              │ /output/    │  │ crash_        │        │
│              │  povs/      │  │ analyzer.py   │        │
│              └─────────────┘  └───┬──────────┘        │
│                                   │                   │
│              ┌────────────────────▼─────────────┐     │
│              │ Bug reports        Seeds          │     │
│              │ /output/bugs/   /output/seeds/    │     │
│              └──────────────────────────────────┘     │
│                                                       │
│  libCRS daemons watch /output/{povs,seeds,bugs}       │
│  and auto-submit artifacts to OSS-CRS                 │
└───────────────────────┬───────────────────────────────┘
                        │ http (OpenAI-compat API)
                        ▼
              ┌─────────────────┐
              │  vLLM server     │
              │  (host machine)  │
              │  :8000/v1        │
              │  Gemma 3 1B      │
              └─────────────────┘
```

## Project Structure

```
gemma-fuzzer/
├── oss-crs/
│   ├── crs.yaml                        # CRS configuration
│   ├── build.hcl                       # Docker buildx bake
│   ├── asan-builder.Dockerfile         # Target build phase
│   └── docker-compose/
│       ├── fuzzer.Dockerfile           # Run phase container
│       └── run-fuzzer.sh               # Entry script
├── src/
│   ├── main.py                         # Orchestrator
│   ├── llm_client.py                   # Direct vLLM client
│   ├── fuzzer.py                       # LibFuzzer management
│   ├── crash_analyzer.py               # LLM crash analysis + seeds
│   └── requirements.txt
├── bin/
│   └── compile_target                  # Build script
├── compose.yaml                        # OSS-CRS compose file
├── litellm-config.example.yaml         # Optional LiteLLM fallback
└── README.md
```

## Debugging

```bash
# Check container logs
docker compose logs gemma-fuzzer_fuzzer

# Shell into a running container
docker compose exec gemma-fuzzer_fuzzer bash

# Check if vLLM is reachable from inside Docker
docker run --rm curlimages/curl curl http://host.docker.internal:8000/v1/models

# View CRS agent logs (persisted to host)
uv run oss-crs artifacts --compose-file ./compose.yaml \
    --fuzz-proj-path ~/oss-fuzz/projects/libxml2 \
    --target-harness xml
```

## License

MIT
