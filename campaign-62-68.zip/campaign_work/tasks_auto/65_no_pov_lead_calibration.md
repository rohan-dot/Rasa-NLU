# Task 65 — three rounds of one model are not three witnesses: calibrate confidence for leads without a PoV, and keep non-exploitable classes out of the submit tier

## Goal
Run of 2026-11-12 (`results/latest/orchestrator.log`): the only submission of the run was an analysis lead — a non-volatile
field in `Messages.java` read from a synchronized getter — that went `[triage] Round 1/3: VALID … Round 3/3: VALID` →
`[triage] FINAL: VALID (3/3 VALID)` → `LIKELY VULNERABILITY (unverified — no PoV) … Triage confidence: 1.0 … All three review
rounds independently confirmed` → submitted at the `llm` tier (`submission_counts: … 'llm': 1`). Meanwhile every lead that
pointed into the vendored jars was correctly rejected (`exists only inside precompiled JARs … cannot be confirmed`). The
failure is calibration: (1) three rounds of the same model with the same context are correlated, not independent, so "3/3"
cannot produce 1.0; (2) a memory-visibility / thread-safety observation is not a vulnerability in any scoring sense and must
not clear the submit tier without a reproducer; (3) task 58's KB grounding should have pulled the score down — OSS-Fuzz/ARVO
history has no neighbours for this class. In CRSBench terms this is a "not-vulnerable" submission that costs precision.

## Study first
- results: `grep -nE "\[triage\]|\[arbiter\]|LIKELY VULNERABILITY|Triage confidence|submission_counts|\[submit\]" results/latest/orchestrator.log`
  — the full triage of the Messages.java lead and of the rejected jar-internal leads (what evidence each round cited).
- repo: `triage_table.py` (58: how KB neighbours enter the score), the arbiter and the "3 rounds" loop, `submission_policy.py`
  (45: tiers 0.67 / 0.85, evidence labels), the CWE/class assigned to the lead.

## Change (src/)
1. **Correlated rounds.** Agreement among rounds of the same model is a vote, not evidence: `confidence_rounds = 0.5 + 0.1 × (agreeing − 1)`
   capped at 0.7. Confidence above 0.7 for a no-PoV lead requires at least one external support: a sanitizer/static-scanner hit at
   the same location, a reach probe showing the location is reachable from a harness, or ≥ 2 KB neighbours of the same class
   (58). Log the breakdown: `[triage] <id>: rounds=3/3 (0.70) + support: kb=0 reach=no scanner=no → 0.70`.
2. **Class gate for no-PoV submission.** A lead without a reproducer can enter the `llm`/`static` submit tiers only if its class is
   in the exploitable set (memory safety, injection, XXE/XML, deserialization, path traversal, SSRF, auth/crypto misuse, DoS with a
   concrete trigger). Concurrency/visibility, resource hygiene, style, logging, "missing null check" without a reachable caller →
   `report-only` with the reason: `[submit] <id>: class <cwe> not submittable without PoV → report`. Still written to REPORT.md.
3. **Honest banner.** `LIKELY VULNERABILITY` is used only when confidence ≥ the submit tier after 1–2; otherwise `ANALYSIS LEAD
   (not submitted)`. "All three review rounds independently confirmed" is never printed for same-model rounds.
4. **Delta-safe.** PoV-backed findings are untouched; thresholds unchanged (0.67 / 0.85); this only changes how the score is
   computed and which classes may use the no-PoV tiers.
5. Safety: wrapped; `[triage_calibration] failed: <error>` → today's scoring.

## Tests (tests/test_no_pov_lead_calibration.py) — fakes only (scripted rounds, fake KB, fake reach/scanner)
- the Messages.java lead: 3/3 VALID, no support, class concurrency → confidence 0.70, class gate → report-only, no submission,
  banner `ANALYSIS LEAD`.
- same rounds + 2 KB neighbours + scanner hit, class injection → confidence > 0.7, submitted at `llm` tier with the breakdown line.
- a PoV-backed finding → unchanged path and numbers (golden).
- jar-internal leads from the run → still INVALID exactly as today (golden on the rejection reason).

## Acceptance
```
python -m pytest -q tests/test_no_pov_lead_calibration.py
```

## Do not touch
Submission thresholds; PoV-backed handling; the arbiter's rejection logic for unconfirmable locations; anything outside src/ and tests/.
