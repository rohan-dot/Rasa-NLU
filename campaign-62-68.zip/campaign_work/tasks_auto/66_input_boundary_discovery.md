# Task 66 — input-boundary discovery: find where untrusted bytes enter a project and which call decodes them; rank harnesses there; say so when none is found

## Goal
A CRS must work on a repo it has never seen without a human writing a task or a harness for it. discver's entry-point
ranking (19/36) scores *project methods*. That misses the most common shape of a real service: **external bytes enter
through a framework or library decoder, and project code only ever sees the decoded object.** JMS/Kafka/UCI listeners,
Spring `@RequestBody`, Go `http.Handler` + `json.Unmarshal`, Rust axum `Json<T>` + serde, Flask routes + `json.loads` /
`yaml.load` / `pickle.loads`. In every one of these the parser is the attack surface, the listener cannot be invoked
(it needs a live transport), and the project method that takes the decoded object scores as "clean" — so discver
fuzzes a setter-built stub and never touches the parser. Nothing in the log says so.
This task adds a language-agnostic **boundary** concept: `(callback, payload type, decoder, encoder, transport-to-stub,
downstream project methods)`, found by *shape*, never by library name; ranked above every ordinary method; and,
when none is found, reported loudly. Task 67 generates the harness from the record.
Gaps found later on new repos are fixed by adding a fixture to the matrix below and generalising the detector — never by
a repo-specific task.

## Definitions (language-agnostic; each `src/lang/<lang>.py` adapter supplies the patterns)
- **Callback**: a project function that receives already-decoded external data. Found by shape:
  (a) a project type implements/extends/embeds a type from OUTSIDE the project and overrides one of its methods whose
  parameter type is also from outside the project (Java/Go interface, Rust trait impl, Python subclass);
  (b) a framework handler marker: Java `@RequestBody`, `@PostMapping/@PutMapping` with a body, `@KafkaListener`,
  `@JmsListener`, `@RabbitListener`, `@MessageMapping`, JAX-RS `@POST`; Go `http.HandlerFunc`/`ServeHTTP`, gRPC service
  methods, sarama/kafka-go consumer handlers; Rust axum/actix/warp handlers with `Json<T>`/`Bytes`/`String` extractors,
  tonic service methods; Python Flask/FastAPI/Django route functions, `on_message`-style consumer callbacks;
  (c) raw-bytes entry with no decoder: `main(argv)`, file/socket reads, `LLVMFuzzerTestOneInput` — recorded, ranked as
  today.
- **Decoder** for payload type T: the call that turns bytes/text into T. Search order: (1) project code reachable from the
  callback (callees, depth ≤ 3) — `json.Unmarshal(data, &v)`, `serde_json::from_slice`, `json.loads`, `yaml.safe_load`,
  `pickle.loads`, `ObjectMapper.readValue`, `Unmarshaller.unmarshal`, `parseFrom`; (2) when the callback already receives
  T decoded (the listener case), the **dependency API**: a public method shaped `read|parse|unmarshal|decode|
  deserialize|from<Format>|readValue|parseFrom|fromJson(<InputStream|Reader|byte[]|String|File>[, Class<T>])` returning
  T or `<T extends B>` with B a supertype of the payload; Java via a pure-Python class-file reader over the classpath
  jars (constant pool, access flags, descriptors, `Signature` attribute; no `javap` dependency); Go/Rust/Python via the
  vendored/module sources when present (`vendor/`, `~/go/pkg/mod`, `~/.cargo/registry`, site-packages) — otherwise
  record "decoder: dependency, source unavailable" and the adapter's default decoder for the format if the payload type
  tells it (serde derive → serde_json; protobuf-generated → `parseFrom`/`prost::Message::decode`). Record how the
  decoder instance is obtained when not static: a public static factory/loader in the same package returning the
  decoder's interface, a public no-arg constructor, or the framework default.
- **Encoder**: the inverse call, paired when found (`write|marshal|serialize|to<Format>|writeValue*`, `json.Marshal`,
  `serde_json::to_vec`, `json.dumps`) — task 67 uses it for round-trip seeds.
- **Transport-to-stub**: the non-project types the callback's enclosing type needs to be constructed (constructor
  params, struct fields set by a framework) — what a harness must fake.
- **Downstream**: project functions the callback passes the payload to (so a harness can bypass an unconstructible
  callback and still take the production path from the next hop).

## Fixture matrix — the spec. `tests/fixtures/boundaries/<name>/` are tiny projects written BY THIS TASK (10–60 lines
each, no build, no network); the detector must handle every row, and every row is a test:
| fixture | language | callback shape | decoder location | expected record |
|---|---|---|---|---|
| java-listener | Java | class implements non-project `Listener<T>`, `handle(T)`; ctor takes `Transport` | dependency jar (test builds a tiny jar with `zipfile` holding hand-assembled class bytes for `Decoder.read(Reader, Class<T>)` + `write(Writer,T)`) | decoder from jar, obtain via static loader, transport `Transport`, downstream `Service.process(T)` |
| java-springbody | Java | `@PostMapping` + `@RequestBody Foo` | framework default (Jackson) | decoder `ObjectMapper.readValue`, no transport |
| java-jms | Java | `onMessage(javax.jms.Message)` + `ObjectMapper.readValue(text, Foo.class)` in callee | project code | decoder in project, depth 1 |
| go-http-json | Go | `func (s *S) ServeHTTP(w, r)` → `json.NewDecoder(r.Body).Decode(&req)` | project code | decoder `encoding/json`, payload `req` type, encoder `json.Marshal` |
| rust-axum | Rust | `async fn h(Json(p): Json<Payload>)`, `#[derive(Deserialize)]` | framework default (serde_json) | decoder `serde_json::from_slice`, encoder `to_vec` |
| py-flask-yaml | Python | `@app.route(..., methods=["POST"])` → `yaml.load(request.data)` | project code | decoder `yaml.load` (unsafe flag noted), encoder `yaml.dump` |
| c-main-file | C | `main(argc, argv)` → `fopen`/`fread` → `parse_buf(buf, n)` | raw bytes | raw-bytes boundary, downstream `parse_buf` |
| cpp-span-parser | C++20 | header-only library: `class PacketView { PacketView(std::span<const std::byte>); … }` + field accessors; no listener, no main | raw bytes | raw-bytes boundary at the span constructor; it ranks FIRST among C/C++ candidates (bytes-in parsers are the native libFuzzer shape) |
| cpp-nlohmann | C++ | gRPC/handler function receives `std::string body` → `nlohmann::json::parse(body)` → fields drive array sizes | project code | decoder `nlohmann::json::parse`, downstream the function that reads the fields |
| rust-tonic | Rust | `#[tonic::async_trait] impl Svc for S { async fn op(&self, req: Request<OpReq>) }`, `OpReq` prost-generated | framework default (prost) | decoder `prost::Message::decode`, encoder `encode_to_vec`, no transport (call the method with the decoded message) |
| rust-udp-raw | Rust | `UdpSocket::recv_from(&mut buf)` → `parse_packet(&buf[..n])` | raw bytes | raw-bytes boundary, downstream `parse_packet` |
| negative-control | Java | provided harness `X509Fuzzer` + `X509Utils.getCnFromDn(String)` (the java-ant-byo shape) | none | `[boundary] none found`; ranking unchanged; the warning line below fires |
| real-world-1 | Java | `refs/oms-ghost-detector` (skipped if absent): 12 readers `implements MessageListener<XxxMT>`; payload classes carry NO annotations; decoder only in `local-repo/uci/cal/uci-cal-api/2.5.0gd/uci-cal-api-2.5.0gd.jar` as `uci.Externalizer.read(Reader, Class<T>)`, `T extends uci.UCIType`, obtained via `uci.service.ExternalizerLoader.getExternalizer()`; transport `uci.AbstractServiceBusConnection` | jar, by shape + bound | 12 callbacks sharing one decoder; encoder `write(Writer, T)`; downstream `MsgProcManager.<processXxx>` |
| real-world-2 | mixed | `refs/ams-gra-hello-world-sk` (skipped if absent; cloned with `--recurse-submodules`): 14 submodules — C++20 VITA packet library (`libraries/ams-vita`), C++ skills with `nlohmann::json`, Rust tonic/axum/UDP services, Python DDS test harness, one JS app | per component | one record set PER COMPONENT (task 68 defines components): ams-vita → `cpp-span-parser` shape; skills → `cpp-nlohmann`; sleet/graupel → `rust-axum`+`rust-tonic`; squall/supercell → `rust-tonic`+`rust-udp-raw`; la-cal-harness → none; worldview → `language unsupported: javascript` |
Add a row whenever a new repo defeats the detector. The table, not any one repo, is what "works" means.

## Study first (repo)
- `src/lang/*.py` adapters (51–53): FunctionInfo fields (params, class, implements/extends, annotations, calls),
  the call-graph API, where per-language pattern tables belong. Task 29's classpath discovery (`harness_sources.py`)
  for locating dependency jars/sources. `rank_entry_points` (19/36): where the "needs server object" penalty applies
  and how `harness-gen: ranked` is printed. `strategy_phase.py` (56): plan lines. `REPORT.md`/`health.json` writers.

## Change (src/ — new `input_boundary.py`; pattern tables in each `src/lang/<lang>.py`; one call in Phase 0; one in ranking)
- Run after language detection; write `output/input_boundaries.json` (records as defined above, plus `confidence`:
  `exact` when the decoder was found by signature, `default` when inferred from the framework/type, `unavailable` when
  only the format is known).
- Log once: `[boundary] <n> input boundaries: <Callback>(<Payload>) ← <decoder> [<where>] ×<count>` (callbacks sharing a
  decoder grouped), or **`[boundary] none found — generated harnesses will exercise project methods with synthesized
  arguments only; parser surface NOT covered unless a provided harness reaches it`**. That warning also goes into
  `REPORT.md` under "Coverage caveats" and into `health.json` (`boundary_coverage: none|partial|decoder`). This line is
  the contract with the operator: a repo that defeats discver is visible in one grep, not after a weak run.
- Ranking: a boundary with a decoder (`exact` or `default`) is a candidate of its own kind, above every method
  candidate; line `… <Callback>(<Payload>) score=<s> [boundary: <callback shape>, decoder <name>, stub <Transport>]`.
  The task-36 "needs server object" penalty does not apply to boundary candidates (67 stubs the transport); it still
  applies to ordinary methods. Raw-bytes boundaries rank as today.
- Strategy (56): one plan line per decoder: `[strategy] k. boundary: <decoder> feeds <n> callbacks — harness at the decoder`.
- CLI: `python3 src/input_boundary.py --root <dir> [--language L]` prints the records (used by the fixture tests and by
  the operator on any new repo before a run).
- Safety: wrapped; `[input_boundary] failed: <error>` with traceback → today's ranking, and the warning line still prints.

## Tests (tests/test_input_boundary.py) — one test per fixture row + unit tests on the shape matcher
- every fixture row: the CLI on the fixture dir yields exactly the expected record(s) (callback, payload, decoder,
  obtain path, encoder, transport, downstream, confidence).
- shape matcher: `read(String)` returning `Object` with no bound does NOT match a payload; `<T extends B>` matches only
  when B is a supertype of the payload; a project method named `read` that takes the payload (not bytes) is not a decoder.
- negative-control: no record, the warning line, `boundary_coverage: none`, ranking identical to the current snapshot.
- ranking: boundary above clean method; line format; task-36 penalty still fires for a non-boundary method.
- the class-file reader: round-trips the test-built jar; `javap` cross-check when present, skipped otherwise.

## Acceptance
```
python -m pytest -q tests/test_input_boundary.py
python3 src/input_boundary.py --root campaign_work/refs/oms-ghost-detector   # 12 callbacks, uci.Externalizer.read — paste in the report
```

## Do not touch
The gate (16), the static check (17), the generator prompt (35 — task 67 owns it); sidecar; crash_dedup._get_crash_signature;
anything outside src/ and tests/.
