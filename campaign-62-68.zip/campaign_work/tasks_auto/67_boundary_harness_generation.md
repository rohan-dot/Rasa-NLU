# Task 67 — generate the harness at the boundary record: fuzz bytes → decoder → callback, transport stubbed, seeds by round-trip encoding — for any project 66 produces a record for

## Goal
Task 66 produces a `(callback, payload, decoder, encoder, transport, downstream)` record for any repo, in any supported
language. This task turns a record into a harness without knowing anything about the repo:
```
fuzz bytes → (byte 0 picks the payload type when one decoder feeds several callbacks)
          → decoder(bytes-or-text, PayloadType)        // the real parser — dependency or framework
          → callback(payload)  with the transport stubbed   // the production path
```
The reason it does not happen today is one sentence in task 35's prompt: "when a parameter type is abstract or a
heavyweight object (X509Certificate, streams, parsed documents), prefer a minimal stub whose getters return
fuzz-derived values over parsing real objects from random bytes." Right for `X509Utils.getPrettySignature(X509Certificate)`
(a `CertificateFactory` parse rejects nearly every input and reaches no project code), wrong at a boundary, where the
parse IS the surface. The two cases are told apart by 66's record, never by the model's guess.

## Scope sign-off
MAP.md and tasks 36/38 mark the generator prompt (35) do-not-touch. This task is the sign-off: the one rule above is
split as described; every other byte of the prompt is golden-tested unchanged.

## Fixtures
The task-66 matrix (`tests/fixtures/boundaries/*`) is the spec here too: each row with a decoder must yield a prompt
and an accepted harness shape (fake LLM). `refs/ghost-harness/UciMessageFuzzer.java` is the reference output for
`real-world-1` — its header comments give the design choices and why; the generator must arrive at the same choices
from the record alone (default package; catch only the decoder's and callback's declared exceptions; fresh state per
input; no network/files/env; one harness dispatching on byte 0 when one decoder feeds many callbacks — not N harnesses).
Note what going through the callback buys: in `real-world-1`, `handleMessage` catches `Exception`, so a boundary
harness surfaces only decoder faults, sanitizer hits and `Error`s — exactly right, because the processor NPEs a
setter-built harness would "find" are swallowed in production and are not bugs. The boundary path self-corrects that.

## Study first (repo)
- The per-language harness generators (Java: `java_harness_agent.py`; the C/Rust/Go/Python paths from 51–53 — note
  which are reuse-first and have no generator yet), the regen feedback loop (35), `harness_repair.py` (38), how a
  generated harness is compiled/built per language (29 javac path + classpath; cargo-fuzz; atheris; go test fuzz) and
  gated (16 reach probe, 17 static check). Where discver places `<Harness>_seed_corpus` / `<Harness>.dict` so the fuzzer
  picks them up. `output/input_boundaries.json` (66).

## Change (src/)
1. **Prompt rule split (35).** (a) unchanged for non-boundary parameters: stub heavyweight types, never parse random
   bytes. (b) for a boundary candidate, templated from the record, language-neutral wording: "This function receives
   data that enters the process through `<decoder signature>` [`<where>`]; obtain the decoder via `<obtain path>`;
   feed the fuzz input to it (text formats: the remaining bytes as a string; binary: as bytes) and pass the result to
   `<callback>`. Catch only `<decoder's declared failure>` and `<callback's declared failure>` — never a catch-all.
   Stub the transport: a minimal implementation of `<transport>` whose `<methods the enclosing type's constructor
   calls>` return inert values (a no-op reader, a fixed id); nothing that opens a socket or file. If the enclosing type
   still cannot be constructed, call `<downstream>` and say so in a header comment. One decoder feeding `<n>` callbacks
   → one harness, first byte selects the payload type."
   The per-language adapter supplies the harness skeleton (Jazzer `fuzzerTestOneInput(FuzzedDataProvider)`;
   `LLVMFuzzerTestOneInput`; cargo-fuzz `fuzz_target!`; atheris `TestOneInput`; Go `FuzzXxx(f *testing.F)`).
2. **Acceptor.** Before compile/gate, the generated source must reference the decoder call and the callback or
   downstream, and contain no catch-all (`catch (Exception|Throwable`, bare `except:`/`except Exception`, `recover()`,
   `.unwrap_or_default()` around the decode). Otherwise
   `harness-gen: <name>: boundary harness does not call the decoder — regenerating` once, then the usual gate; a second
   miss → `harness-gen: <name>: boundary harness rejected (decoder not called)` and the candidate is skipped (never
   silently replaced by a setter-built harness).
3. **Seeds + dictionary (when 66 paired an encoder).** The prompt also asks for a `seeds()` function building a few valid
   payloads through setters/builders/struct literals with mandatory header fields set; discver compiles a tiny seed
   writer alongside the harness (same classpath/toolchain), runs it once, and writes `<Harness>_seed_corpus/NN`
   (byte 0 = type index, rest = encoded payload) and `<Harness>.dict` from the element/field names in the encoded seeds.
   Log `harness-gen: <Harness>: <n> round-trip seeds, dict <m> tokens`; no encoder → `no encoder — no seeds`, continue.
4. **Compile, gate, name, report.** Same build path and gate as any generated harness for that language; display name
   `<Callback> (boundary harness)`; header comment `// boundary: <Callback> ← <decoder> [<where>]`; one repair pass
   via 38 on build failure. `REPORT.md`/`health.json`: boundary harnesses under their own heading with decoder and
   location, so a reader sees that the parser was fuzzed and whether a finding sits in a dependency or in the project.
5. Safety: wrapped; `[boundary_harness] failed: <error>` → today's generation for that candidate, and the 66 warning
   logic still reports `boundary_coverage`.

## Tests (tests/test_boundary_harness_generation.py) — fake LLM, fake build, fake gate; fixture records from 66
- prompt per fixture row with a decoder (java-listener, java-springbody, java-jms, go-http-json, rust-axum,
  py-flask-yaml, real-world-1 if present): contains the decoder signature, obtain path, payload type(s), transport
  stub instruction naming the methods to stub, the exceptions to catch, the one-harness-dispatch instruction when
  `count > 1`; does NOT contain the stub-heavyweight rule.
- prompt for a non-boundary candidate (the `getPrettySignature(X509Certificate)` fixture from the 35/38 tests):
  byte-identical to the current prompt (golden file).
- acceptor: fake LLM returns the reference harness → accepted; returns a setter-only harness → regen line, second
  miss → rejected line, no fallback harness registered; a harness with `catch (Exception` → rejected by the acceptor
  before the gate.
- seeds: fake encoder → corpus files with byte 0 = index and the encoded text; dict contains the tag/field names;
  no encoder → the no-seeds line and no corpus dir.
- names and report heading.

## Acceptance
```
python -m pytest -q tests/test_boundary_harness_generation.py tests/test_input_boundary.py
```

## Do not touch
Gate (16) and static-check (17) logic; sidecar; crash_dedup._get_crash_signature; the non-boundary prompt text
(golden-tested); anything outside src/ and tests/.
