# Task 63 — hundreds of timeouts consumed the whole budget: deduplicate hangs by stack, cap them, diagnose "initialisation exceeds the timeout", and mark a slow harness WEAK

## Goal
Run of 2026-11-12 on oms-ghost-detector (`results/latest/orchestrator.log`): from the first fuzzing round to the end of the
7000 s budget, `[fuzzer] NON-CRASH [hang] UciXmlFuzzer — timeout=<sha1> (limit 25)` followed by
`[hang] Hang/OOM finding written: hangs/hang-<hash>.json`, hundreds of times, one file per input, across `=== Strategy Round N ===`
up to round 30+. 300 timeouts × 25 s is the budget. No crash, no coverage, and the harvest phase at the end had hundreds of files
to process. Cause here: the UCI externalizer's first use builds a JAXB context (tens of seconds) and in `-fork` mode every child
pays it on its first input, inside `-timeout=25` — so every child dies as a hang. discver must (a) recognise that pattern and say
so, (b) never write unbounded hang files, (c) report a slow harness as WEAK with the exec rate, (d) treat genuine repeated hangs as
ONE finding class with a stack, not hundreds.

## Study first
- results: `grep -c "NON-CRASH \[hang\]" results/latest/orchestrator.log`; `grep -nE "Starting libFuzzer|-fork|-timeout|exec/s|Total execs|health" results/latest/orchestrator.log | head -40`
  — the libFuzzer argv, fork settings, and whatever stats lines are logged; `ls results/latest/hangs | head` and read one
  `hang-*.json` if staged (what it records: input hash, stderr tail, stack?).
- repo: the fuzzer wrapper (`fuzzer.py`): how timeouts are classified (`NON-CRASH [hang]`), where `hangs/*.json` is written, what
  Jazzer prints on timeout (thread dump → top frames are available), `run_health.py` thresholds
  (`probe=120s saturated_if_execs<5000&crash>=1 or crash_rate>=0.5; keep_going=1000; noop_if_flat_for=300s`), how exec/s is
  sampled from libFuzzer's `#<n> … exec/s: <k>` lines.

## Change (src/)
1. **Hang signature + dedup + cap.** A timeout gets a signature from the top N project/library frames of Jazzer's thread dump
   (fallback: the deepest non-JDK frame; fallback: "no stack"). First occurrence per signature → `hangs/<sig>/` with the input and
   the stack; later ones increment a counter. Hard cap per harness: `DISCVER_MAX_HANG_FILES` default 20 — beyond it, count only.
   Summary line every round: `[hang] <harness>: <n> timeouts, <k> distinct stacks (top: <frame> ×<c>)`.
2. **Init-exceeds-timeout diagnosis.** If timeouts occur at the first execution of (nearly) every fork child — detectable from the
   libFuzzer child output (`#1`/`#2` exec count at the time of the timeout) or from identical top frames in class-initialisation /
   `<clinit>` / `fuzzerInitialize`-less startup paths — log ONCE:
   `[hang] <harness>: every child times out on its first input — one-time initialisation exceeds -timeout=<t>s; this is a harness
   defect, not a bug. Generated Java harnesses: init belongs in fuzzerInitialize() (task 62). Provided harness: raise -timeout for
   this harness to <4t> and continue.` Then actually raise the per-harness timeout once and continue; if it still happens, mark the
   harness WEAK (`reason=init_timeout`) and release its budget to the others.
3. **Slow-harness health.** exec/s sampled from the stats lines; below `DISCVER_MIN_EXEC_RATE` (default 20/s) after the probe
   window → health WEAK `reason=slow (<k> exec/s)`, surfaced in `health.json` and `REPORT.md` with the hang summary. A harness
   whose only outputs are timeouts never counts as HEALTHY.
4. **Hang as a finding class.** When hangs are NOT init-related (exec count > 1 when they occur) and share a stack, emit one
   finding `timeout/<sig>` with the smallest reproducer, the stack, and a note `not PoV-scorable in CRSBench; reportable as
   CWE-400/776-class`; it goes through triage (58) like any finding, submission tier per policy (45) — never auto-submitted as a crash.
5. Safety: wrapped; `[hang_guard] failed: <error>` → today's behaviour but with the file cap still enforced.

## Tests (tests/test_hang_storm.py) — fakes only (scripted libFuzzer stderr with Jazzer timeout dumps)
- 300 scripted timeouts with 3 distinct stacks → 3 `hangs/<sig>/` dirs, counters 100 each, at most `DISCVER_MAX_HANG_FILES` files, the round summary line.
- timeouts at exec #1 of every child → the init diagnosis line once; timeout raised once; second storm → WEAK `init_timeout`, budget released.
- scripted stats `exec/s: 3` after the probe → WEAK `slow (3 exec/s)` in health.json; `exec/s: 500` → not slow.
- non-init hangs sharing a stack → one `timeout/<sig>` finding with reproducer + stack, routed to triage, never to the crash submit path.
- `health.json` / `REPORT.md` carry the hang summary.

## Acceptance
```
python -m pytest -q tests/test_hang_storm.py
```

## Do not touch
Crash (non-timeout) handling; crash_dedup._get_crash_signature; sidecar; the libFuzzer argv except the per-harness `-timeout` raise
described above; anything outside src/ and tests/.
