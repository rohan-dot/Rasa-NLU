# Task 64 — guided_json is rejected by the gateway on every call: detect once, disable for the run, stop paying for the 400

## Goal
Run of 2026-11-12 (`results/latest/orchestrator.log`), pb_seeds and other LLM calls:
`HTTP/1.1 400 Bad Request` … `Error code: 400 - {'error': {'message': 'litellm.BadRequestError: AnthropicException - … The model
returned the following errors: guided_json: Extra inputs are not permitted …` followed by a retry without the field that succeeds.
`DISCVER_GUIDED_JSON=on(default)` sends a vLLM-only request field; through LiteLLM to an Anthropic model every call fails first.
Each failure costs a round trip and log noise, for the whole run. Zero-config rule: discver must notice and adapt, not require
`DISCVER_GUIDED_JSON=off` from the operator.

## Study first
- results: `grep -n "guided_json\|400 Bad Request" results/latest/orchestrator.log | head` — count how many calls paid the 400.
- repo: the LLM client (`vLLM client configured: …` line; `DISCVER_GUIDED_JSON` in `feature_flags.py`), where `guided_json`
  is attached to requests, the existing retry-without-it path.

## Change (src/)
- On the first 400 whose body matches `guided_json` + (`Extra inputs are not permitted` | `unknown` | `unsupported`), set a
  run-level `guided_json_supported=False`, log once:
  `[llm] gateway rejects guided_json (<model> via <url>) — disabled for this run; structured output falls back to prompt + validation`,
  and never attach the field again in this run. The existing per-call retry remains for the first call only.
- Record it in `health.json` (`llm.guided_json: unsupported`) and the startup banner on later runs if a cache file exists
  (`output/llm_capabilities.json`, keyed by model+url) so the first call of the next run does not pay either.
- Safety: wrapped; on any error fall back to today's retry-per-call behaviour.

## Tests (tests/test_guided_json_autodisable.py) — fake HTTP
- first call 400 with the exact body from the log → disabled line once; second and later requests carry no `guided_json`; the
  first call is retried once without it and succeeds.
- a 400 for an unrelated reason → not disabled; existing retry/backoff unchanged.
- capability cache written and honoured on the next client construction.

## Acceptance
```
python -m pytest -q tests/test_guided_json_autodisable.py
```

## Do not touch
Prompt content; retry/backoff policy for other errors; anything outside src/ and tests/.
