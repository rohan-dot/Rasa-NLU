# Task 68 — build from a path: given only a project directory, detect the build system, build into the OSS-Fuzz layout, then run the normal pipeline (boundary discovery → harness generation → fuzz)

## Goal
After 66/67 discver can find the input boundary and write the harness. The remaining human step for an arbitrary repo
is the build: today someone writes a `build.sh` per target (OSS-CRS) or lays out a build dir by hand (standalone).
For the common build systems that step is mechanical, so discver does it: `--project-dir <repo>` with no build dir →
`src/local_build.py` detects the build system, runs a default build that produces the OSS-Fuzz `$OUT` layout the rest
of discver already consumes, and logs exactly what it ran. Inside OSS-CRS the per-target `build.sh` then becomes one
line: `python3 /opt/discver/src/local_build.py --project "$SRC/project" --out "$OUT"`.
When the default build fails it says so and stops — never a silent half-build.

## Study first (repo)
- `src/main.py`: how the source dir, the build/harness dir and the sanitizer are supplied today (CLI flags and/or the
  OSS-CRS paths `/opt/target/src`, `/opt/target/build`); the `ContainerPatchBuilder` build-command hook (the patch
  oracle needs a local rebuild command — this task must register one per build system so patches can be re-verified
  standalone). Task 29's classpath derivation and `harness_sources.py`; `src/lang/*.py` toolchain facts (51–53);
  `src/tools/manifest.yaml` (54) for what the image is expected to contain.
- `refs/ghost-harness/build.sh`: the Maven recipe this task generalises (plain classes jar + `dependency:copy-dependencies`
  + jazzer in `$OUT` + one launcher per provided `*Fuzzer.java`, launcher carries the `LLVMFuzzerTestOneInput` marker).

## Change (src/ — new `local_build.py`; `main.py` gains `--project-dir` (+ optional `--out`, `--sanitizer`, `--component`))
**Components first.** A path is not one project; it is a tree of build roots. Before any build:
- `git submodule update --init --recursive --depth 1` when `.gitmodules` exists (a dir that is a registered submodule
  but empty is reported as `[components] <path>: submodule not initialised` — never silently treated as "no code").
- Walk the tree (skip `.git`, `node_modules`, `target`, `build`, `vendor`, `third_party`); a **component** is a
  directory holding a build marker whose parent holds none (`Cargo.toml` with `[workspace]` wins over member crates;
  a `CMakeLists.txt` with `project(...)` wins over subdirectory lists). Language per component from the marker + file
  census (53). Write `output/components.json`: `[{path, language, build_system, supported}]`, and log
  `[components] <n> found: libraries/ams-vita (c++, cmake), sensors/squall (rust, cargo), viz/worldview (javascript —
  unsupported, skipped), …`. A single-root repo is one component with path `.`.
- Everything downstream runs PER COMPONENT: build, boundary discovery (66), harness generation (67), fuzzing (budget
  split evenly, a component that fails to build frees its share), triage, report. `report.json` entries gain
  `component` and `language`; `REPORT.md` gets one section per component plus a one-table roll-up at the top
  (component · language · built? · harnesses · boundary coverage · findings). `--component <path>` restricts a run.
- A component that fails to build is `[build] cannot build <component>: <reason>` in log + REPORT.md + health.json
  and the run CONTINUES with the others; the run fails only when no component builds.
Detection per component, in order, by marker file; each builder writes `$OUT/<component>/` and returns
`(harness_launchers, classpath_or_libs, rebuild_cmd)`; logs `[build] <component> system=<name> cmd=<argv>` and the tail
of the tool output on failure:
- **Java/Maven** (`pom.xml`): `mvn [-s settings.xml] -q -DskipTests package dependency:copy-dependencies
  -DincludeScope=runtime -DoutputDirectory=$OUT`; plain `target/classes` → `$OUT/app-classes.jar`; jazzer from
  `$JAZZER_DIR`/image; compile `fuzz/*Fuzzer.java` if any, launcher per class. Multi-module: `-pl` the module that
  contains `src/main/java`, or all with `-am`.
- **Java/Gradle** (`build.gradle[.kts]`): `gradle -q assemble` + a generated `printRuntimeClasspath` init script; same layout.
- **C/C++** (`CMakeLists.txt` | `configure`/`autogen.sh` | `Makefile`): `CC=clang CXX=clang++ CFLAGS/CXXFLAGS=
  "-fsanitize=fuzzer-no-link,address -g -O1"` (undefined when `--sanitizer undefined`), out-of-tree CMake build or
  `./configure && make`; link every provided `LLVMFuzzerTestOneInput` source found under `fuzz*/`, `tests/fuzz*`,
  `*_fuzzer.c*` against the built static libs with `-fsanitize=fuzzer,address` → `$OUT/<name>`; copy `*.dict`,
  `*_seed_corpus.zip`, `*.options` beside them. No fuzz sources and no `fuzz*` build target → `[build] C/C++ project
  built, no provided harness; harness generation decides` (67 handles the boundary case; raw `main` is a raw-bytes boundary).
- **Rust** (`Cargo.toml`): `cargo build`; if `fuzz/Cargo.toml` exists, `cargo fuzz build -s address` and copy
  `fuzz/target/*/release/<target>` to `$OUT`; otherwise build only, generation decides.
- **Go** (`go.mod`): `go build ./...`; provided `Fuzz*` funcs in `*_test.go` → `go test -c -fuzz` style targets per the
  Go adapter; otherwise build only.
- **Python** (`pyproject.toml`|`setup.py`|`requirements.txt`): venv, `pip install -e .` (or `-r requirements.txt`),
  atheris; provided `fuzz*/*.py` with `TestOneInput` → launcher scripts.
- Unknown / failed → `[build] cannot build <dir>: <reason>` into the log, `REPORT.md` and `health.json`
  (`build: failed`), exit of the run with a non-zero status. Never fall through to fuzzing a half-built tree.
- `rebuild_cmd` is registered with the patch oracle so `ContainerPatchBuilder` can rebuild after a candidate patch in
  standalone mode (the same command, run on the patched tree, into a scratch `$OUT`).
- **Toolchains — where they come from, and the two hard constraints:**
  1. `src/local_build.py` is a SINGLE FILE, standard library only, no imports from the rest of discver. It must run
     inside an OSS-Fuzz base-builder image (jvm / base / rust / go / python) where it is `COPY`'d into the target's
     build context, exactly like a hand-written `build.sh` is today. Those images already carry the toolchain
     (JDK+Maven+Gradle+jazzer; clang+cmake; cargo+cargo-fuzz; go; python3+atheris). When run from discver's own tree it
     is imported as a module; when run standalone it is `python3 local_build.py --project … --out …`.
  2. Nothing is downloaded at run time. `src/tools/manifest.yaml` (task 54) gains the build toolchain with versions
     (maven, gradle, cmake, clang, cargo + cargo-fuzz, go, python3 + atheris, jazzer) and `src/tools/Dockerfile.snippet`
     gains the RUN lines for the discver image; a new `src/tools/setup_standalone.sh` installs the same set on a plain
     box with conda (`conda create -n discver-tools -c conda-forge openjdk=17 maven gradle cmake clang rust cargo go
     python=3.11`, `pip install atheris`, `cargo install cargo-fuzz`, jazzer from its GitHub release into `$JAZZER_DIR`).
     `python3 src/local_build.py --check-tools` prints one line per language: present/missing, with versions.
  A missing tool is `[build] <tool> unavailable (see src/tools/manifest.yaml)` and a failed build — never a download.
  Maven/Gradle/cargo/go/pip fetch *project dependencies* from their registries at build time; that is inherent and
  allowed (it is what OSS-Fuzz does); a repo's `settings.xml` / vendored `local-repo/` / `vendor/` is honoured.
- Safety: wrapped; `[local_build] failed: <error>` with traceback → the run stops with `build: failed`.

## Fixture matrix (tests/fixtures/builds/<name>/, tiny projects written by this task; builds run only when the
## toolchain is present — `pytest.mark.skipif(shutil.which(...) is None)`, so the suite stays green on a box without it)
| fixture | system | provided harness | expected |
|---|---|---|---|
| maven-plain | pom.xml, one class, one `fuzz/EchoFuzzer.java` | yes | `$OUT/EchoFuzzer` launcher, `app-classes.jar`, deps |
| maven-settings | pom.xml + settings.xml + local-repo/ with a vendored jar (the UCI shape) | no | builds, `no provided harness` line |
| gradle-plain | build.gradle | yes | launcher present |
| cmake-lib | CMakeLists.txt static lib + `fuzz/parse_fuzzer.c` | yes | `$OUT/parse_fuzzer` links, runs `-runs=10` |
| cmake-nofuzz | CMakeLists.txt, `main.c` reads a file | no | builds, raw-bytes boundary left to 66 |
| cargo-fuzz | Cargo.toml + fuzz/ | yes | `$OUT/<target>` |
| go-mod | go.mod + `FuzzParse` | yes | launcher |
| py-atheris | pyproject + `fuzz/fuzz_parse.py` | yes | launcher |
| unknown | a directory with a README only | — | `[build] cannot build` + `build: failed`, non-zero exit |
| monorepo | root with `.gitmodules` (fake, pre-populated submodule dirs) holding `libs/parse/CMakeLists.txt` (C++), `svc/Cargo.toml` (Rust), `web/package.json` (JS), one empty registered submodule dir | mixed | `components.json` with 3 components + the JS one `unsupported`; the empty submodule reported; each supported component built under `$OUT/<component>/`; roll-up table in REPORT.md; a deliberately broken component (`CMakeLists.txt` referencing a missing lib) → `cannot build` line and the run continues |
| real-world-1 | `refs/oms-ghost-detector` (skipped if absent or no network for Maven) | no | one component `.`, `maven-settings` path; `$OUT/./` has `app-classes.jar`, `uci-cal-api-2.5.0gd.jar`, jazzer |
| real-world-2 | `refs/ams-gra-hello-world-sk` (skipped if absent; needs clang ≥ 15 for C++20, cargo) | no | 14 components found; `viz/worldview` unsupported; `libraries/ams-vita` (header-only, CMake) builds; components needing DDS/gRPC libraries that are absent report `cannot build … : <reason>` and the run continues |

## Tests (tests/test_local_build.py)
- detection: each fixture → the right system by marker file, in the stated precedence (pom.xml beats a stray Makefile).
- each buildable fixture (skipped without its toolchain): `$OUT` contents as in the table; the launcher runs `-runs=10`
  and exits 0; the `[build] system=… cmd=…` line; `rebuild_cmd` re-runs successfully on an untouched tree.
- unknown → the failure line in log + REPORT.md + health.json, non-zero exit, no fuzzing started (fake fuzzer not called).
- `main.py --project-dir <fixture>` end-to-end with fakes for everything after the build: the build is invoked once,
  then boundary discovery (66) and harness generation (67) receive `$OUT` and the project dir.

## Acceptance
```
python -m pytest -q tests/test_local_build.py
```

## Do not touch
The fuzzer wiring once `$OUT` exists; the gate (16/17); sidecar; crash_dedup._get_crash_signature; anything outside
src/ and tests/.
