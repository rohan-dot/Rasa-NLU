# Task 62 — generated Java harnesses were never compiled: detect the capability instead of declaring it unsupported, never "fuzz anyway" a binary that fails the probe, and put one-time init in fuzzerInitialize()

## Goal
Run of 2026-11-12 on oms-ghost-detector (log staged at `results/latest/orchestrator.log`):
`[lang] adapter=java plugin=java (custom-harness compile: False)` (line ~12) and later
`[regulator] Skipping harness compilation (Java: custom-harness compilation unsupported (prebuilt-only)); relying on the prebuilt
harness + coverage-guided fuzzing. Findings still recorded. Set FORCE_HARNESS_COMPILE=1 to override.`
Consequence: `GenFuzzer0` and `RegenFuzzer_0` were written as source, then
`[harness] WARNING: '/output/generated_harnesses/GenFuzzer0' did not respond to a libFuzzer '-help=1' probe — it may be un-loadable
(missing shared lib / ABI mismatch) or not a libFuzzer binary. Fuzzing it anyway; watch for a 0-exec exit.` →
`[harness_reach] … does not reach target → dropped` → regenerated → same. Stage 2 contributed nothing; only the provided harness fuzzed.
The build dir had everything a compile needs (69 entries: `app` jars, `jazzer_agent_deploy.jar`, `jazzer_driver`, JDK in the image).
The project rule is zero configuration for the operator: a capability must be detected, not declared, and a flag must never be the
only way to get the default behaviour.

## Study first
- results: `grep -nE "custom-harness compile|Skipping harness compilation|FORCE_HARNESS_COMPILE|-help=1|harness_reach|GenFuzzer|RegenFuzzer" results/latest/orchestrator.log`
  — the full sequence for both generated harnesses; note the 69-entry build-dir listing (`harness-discovery:` lines) that shows the jars.
- repo: where `custom-harness compile` is decided (`src/lang/java.py` capability / `src/lang/base.py`), the regulator that prints the
  skip line, `FORCE_HARNESS_COMPILE` handling; task 29's javac path and classpath derivation (`harness_sources.py`) — the compile
  machinery exists and worked for provided sources; the generated-harness writer (`java_harness_agent.py`) and the launcher it writes;
  the `-help=1` probe and the "Fuzzing it anyway" branch; the Java harness template.

## Change (src/)
1. **Capability = detection.** For Java, custom-harness compile is supported iff `javac` is on PATH (or `$JAVA_HOME/bin/javac`),
   a Jazzer API jar is findable (`$JAZZER_API_PATH`, `$OUT/jazzer_api_deploy.jar`, or the agent jar which contains the API package),
   and a classpath can be derived from the build dir (task-29 derivation). Log once:
   `[lang] java custom-harness compile: supported (javac=<path>, jazzer api=<path>, classpath=<n> jars)` or
   `[lang] java custom-harness compile: unavailable — <which precondition failed>`. `FORCE_HARNESS_COMPILE` stays as an override
   but is never required for the default.
2. **Compile what is generated**, through the task-29 path, into the generated-harness dir, and write the same launcher shape as
   OSS-Fuzz (`--cp`, `--target_class`, `LLVMFuzzerTestOneInput` marker). Compile failure → one repair pass (38) → else
   `harness-gen: <name>: compile failed — skipped (<javac tail>)`. Never hand an uncompiled source to the fuzzer.
3. **Probe failure is a skip, not a warning.** A harness that fails the `-help=1` probe is not run:
   `[harness] <name>: failed libFuzzer probe — skipped (<stderr head>)`; it counts as a generation failure for the regen loop
   (35), not as flat coverage.
4. **Generated Java harness template:** one-time initialisation (object mappers, parsers, contexts, schema loading, any
   `*Loader.get*()` / `*Factory.newInstance()`) goes in `public static void fuzzerInitialize()`; the template includes a warm-up
   call of the decoder on a tiny input inside a narrow catch; `fuzzerTestOneInput` returns early on < 2 bytes and on inputs over
   a size cap; the rule is stated in the generator prompt (task 35) so the model follows it. Golden test on the X509 fixture keeps
   the non-boundary prompt byte-identical except for this added rule.
5. Safety: wrapped; `[harness_compile] failed: <error>` with traceback → the skip line, never "fuzz anyway".

## Tests (tests/test_java_harness_compile_autodetect.py) — fakes only (fake PATH, fake build dir with jar names from the log)
- build dir listing from the run (jars + jazzer files) + fake javac on PATH → capability supported, the log line with counts.
- no javac → unavailable line naming javac; no jazzer api → unavailable line naming it; `FORCE_HARNESS_COMPILE=1` with javac
  present behaves identically to detection (no second code path).
- generated source → fake javac called with a classpath containing the build-dir jars → launcher written with marker + `--target_class`.
- fake javac fails twice (compile + repair) → the skipped line, fuzzer never invoked for it.
- probe failure → skipped line, regen loop sees a generation failure, fuzzer never invoked.
- template: generated source contains `fuzzerInitialize` with the init calls moved out of `fuzzerTestOneInput`; X509 golden prompt
  diff is exactly the added rule.

## Acceptance
```
python -m pytest -q tests/test_java_harness_compile_autodetect.py
```

## Do not touch
Provided-harness compile (29) semantics; the gate (16/17); sidecar; crash_dedup._get_crash_signature; anything outside src/ and tests/.
