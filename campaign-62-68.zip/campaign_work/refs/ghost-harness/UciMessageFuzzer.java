// UciMessageFuzzer.java  (v2 — fuzzerInitialize + warm-up + seed writer)
//
// Offline Jazzer harness for oms-ghost-detector. Default package on purpose (launchers and
// discver address it by bare class name). Place at <repo>/fuzz/UciMessageFuzzer.java.
//
// WHY v2: the UCI externalizer's first use builds a JAXB context over thousands of generated
// classes and loads an 8 MB schema — tens of seconds. In libFuzzer fork mode every child pays
// that on its FIRST INPUT, inside the per-input timeout (25 s), so every child dies as a "hang"
// and the run produces nothing but hang files. Jazzer's fuzzerInitialize() runs once per process
// BEFORE fuzzing and is not timed — all one-time cost goes there, plus a warm-up parse.
//
// Flow per input:  byte 0 picks 1 of 12 UCI message types
//                  rest = UCI XML  → externalizer.read(StringReader, XxxMT.class)   (the real parser)
//                  → MsgProcManager.processXxx(msg)                                 (the real handlers)
// UCIException is the declared failure for malformed XML / missing mandatory elements → swallowed.
// Everything else (NPE, ISE, StackOverflowError, sanitizer hits) propagates to Jazzer = finding.
//
// Seeds:  java -cp <launcher classpath> UciMessageFuzzer --write-seeds <dir>
//         writes one skeleton message per type through the library's own encoder (byte 0 = type
//         index, then XML) — structurally valid starting points for the fuzzer. build.sh zips them.

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import uci.Externalizer;
import uci.UCIException;
import uci.UCIType;
import uci.service.ExternalizerLoader;
import uci.types.SystemID_Type;

import uci.types.GhostDetectorActivityMT;
import uci.types.GhostDetectorCapabilityMT;
import uci.types.GhostDetectorCapabilityStatusMT;
import uci.types.GhostDetectorCommandStatusMT;
import uci.types.GhostDetectorSettingsCommandStatusMT;
import uci.types.ProductLocationMT;
import uci.types.ProductMetadataMT;
import uci.types.ServiceStatusDataRequestStatusMT;
import uci.types.ServiceStatusMT;
import uci.types.SubsystemStatusDataRequestStatusMT;
import uci.types.SubsystemStatusMT;
import uci.types.SystemStatusMT;

import com.ng.oa.monitor.processors.MsgProcManager;
import com.ng.oa.monitor.state.PlayerStates;

public class UciMessageFuzzer {

    /** XML attacks are small; very large documents only make slow, uninformative executions. */
    private static final int MAX_INPUT = 16 * 1024;

    private static Externalizer EXT;
    private static SystemID_Type SYS_ID;

    private static SystemID_Type sysId() {
        return new SystemID_Type()
                .setUUID(UUID.fromString("00000000-0000-0000-0000-000000000001"))
                .setDescriptiveLabel("fuzz");
    }

    /**
     * Jazzer calls this once per process before the first input; it is NOT subject to -timeout.
     * Everything expensive and one-time lives here.
     */
    public static void fuzzerInitialize() throws Exception {
        EXT = ExternalizerLoader.getExternalizer();
        SYS_ID = sysId();
        // Warm-up: force JAXB context + schema loading now, not on the first (timed) input.
        try {
            EXT.read(new StringReader("<SystemStatus/>"), SystemStatusMT.class);
        } catch (UCIException expected) {
            // malformed on purpose; the point was the initialisation
        }
        // Touch the processor stack once too (class loading, static state).
        new MsgProcManager(SYS_ID, new PlayerStates(SYS_ID));
    }

    public static void fuzzerTestOneInput(FuzzedDataProvider data) {
        int remaining = data.remainingBytes();
        if (remaining < 2 || remaining > MAX_INPUT) {
            return;
        }
        int which = data.consumeByte() & 0xFF;
        String xml = data.consumeRemainingAsString();
        if (xml.isEmpty()) {
            return;
        }
        // Fresh state + manager per input: no cross-input contamination; constructors touch no bus.
        PlayerStates states = new PlayerStates(SYS_ID);
        MsgProcManager mgr = new MsgProcManager(SYS_ID, states);
        try {
            dispatch(which % 12, xml, mgr);
        } catch (UCIException expected) {
            // declared failure for malformed XML / missing mandatory elements — not a finding
        }
    }

    private static void dispatch(int which, String xml, MsgProcManager mgr) throws UCIException {
        switch (which) {
            case 0:  mgr.procesSystemStatus(EXT.read(new StringReader(xml), SystemStatusMT.class)); break;
            case 1:  mgr.processServiceStatus(EXT.read(new StringReader(xml), ServiceStatusMT.class)); break;
            case 2:  mgr.procesSubsystemStatus(EXT.read(new StringReader(xml), SubsystemStatusMT.class)); break;
            case 3:  mgr.processServiceStatusDataRequestStatus(EXT.read(new StringReader(xml), ServiceStatusDataRequestStatusMT.class)); break;
            case 4:  mgr.processSubsystemStatusDataRequestStatus(EXT.read(new StringReader(xml), SubsystemStatusDataRequestStatusMT.class)); break;
            case 5:  mgr.processGhostDetectorCapability(EXT.read(new StringReader(xml), GhostDetectorCapabilityMT.class)); break;
            case 6:  mgr.processGhostDetectorCapabilityStatus(EXT.read(new StringReader(xml), GhostDetectorCapabilityStatusMT.class)); break;
            case 7:  mgr.processGhostDetectorCommandStatus(EXT.read(new StringReader(xml), GhostDetectorCommandStatusMT.class)); break;
            case 8:  mgr.processGhostDetectorActivity(EXT.read(new StringReader(xml), GhostDetectorActivityMT.class)); break;
            case 9:  mgr.processProductLocation(EXT.read(new StringReader(xml), ProductLocationMT.class)); break;
            case 10: mgr.processProductMetadata(EXT.read(new StringReader(xml), ProductMetadataMT.class)); break;
            default: mgr.processGhostDetectorSettingsCommandStatus(EXT.read(new StringReader(xml), GhostDetectorSettingsCommandStatusMT.class)); break;
        }
    }

    // ------------------------------------------------------------------ seeds + smoke test
    private static final UCIType[] SKELETONS = {
            new SystemStatusMT(), new ServiceStatusMT(), new SubsystemStatusMT(),
            new ServiceStatusDataRequestStatusMT(), new SubsystemStatusDataRequestStatusMT(),
            new GhostDetectorCapabilityMT(), new GhostDetectorCapabilityStatusMT(), new GhostDetectorCommandStatusMT(),
            new GhostDetectorActivityMT(), new ProductLocationMT(), new ProductMetadataMT(),
            new GhostDetectorSettingsCommandStatusMT(),
    };

    /** One skeleton message per type, encoded by the library itself; byte 0 = type index. */
    private static void writeSeeds(Path dir) throws Exception {
        Files.createDirectories(dir);
        int written = 0;
        for (int i = 0; i < SKELETONS.length; i++) {
            StringWriter sw = new StringWriter();
            try {
                EXT.write(sw, SKELETONS[i]);
            } catch (UCIException e) {
                System.err.println("seed " + i + " (" + SKELETONS[i].getClass().getSimpleName() + ") skipped: " + e.getMessage());
                continue;
            }
            byte[] xml = sw.toString().getBytes(StandardCharsets.UTF_8);
            byte[] out = new byte[xml.length + 1];
            out[0] = (byte) i;
            System.arraycopy(xml, 0, out, 1, xml.length);
            Files.write(dir.resolve(String.format("seed-%02d-%s", i, SKELETONS[i].getClass().getSimpleName())), out);
            written++;
        }
        System.out.println(written + " seeds written to " + dir);
    }

    /**
     * java -cp <cp> UciMessageFuzzer                      → smoke test (externalizer loads offline, no bus, no CALConfig)
     * java -cp <cp> UciMessageFuzzer --write-seeds <dir>  → seed corpus
     */
    public static void main(String[] args) throws Exception {
        long t0 = System.currentTimeMillis();
        fuzzerInitialize();
        System.out.println("externalizer = " + EXT.getClass().getName() + "  (init " + (System.currentTimeMillis() - t0) + " ms)");
        if (args.length == 2 && "--write-seeds".equals(args[0])) {
            writeSeeds(Paths.get(args[1]));
            return;
        }
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < 20; i++) {
            try {
                dispatch(i % 12, "<x><y/></x>", new MsgProcManager(SYS_ID, new PlayerStates(SYS_ID)));
            } catch (UCIException expected) {
                // fine
            }
        }
        System.out.println("20 parses in " + (System.currentTimeMillis() - t1) + " ms  (should be a few ms each after init)");
        System.out.println("OK - offline path works");
    }
}
