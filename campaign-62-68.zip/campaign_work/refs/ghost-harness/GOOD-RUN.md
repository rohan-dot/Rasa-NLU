# oms-ghost-detector — getting a good run (fixes for what the Nov 12 log showed)

Three things went wrong last time, in order of damage. All three are fixed below without touching discver's code.

| Symptom in the log | Cause | Fix |
|---|---|---|
| hundreds of `NON-CRASH [hang] … timeout (limit 25)` + `Hang/OOM finding written` | the UCI externalizer's first use builds a JAXB context over thousands of classes (tens of seconds); in fork mode every child pays it on its first input, inside the 25 s timeout → every child dies as a "hang" | harness v2: all one-time work in `fuzzerInitialize()` (untimed) + warm-up; `UciMessageFuzzer.java` in this folder |
| `[regulator] Skipping harness compilation (Java: custom-harness compilation unsupported (prebuilt-only))` → GenFuzzer0 / RegenFuzzer_0 never compiled, 0 reach, dropped | adapter capability flag | env `FORCE_HARNESS_COMPILE=1` |
| `litellm.BadRequestError … guided_json: Extra inputs are not permitted` on LLM calls | vLLM-only request field sent to the Anthropic route | env `DISCVER_GUIDED_JSON=off` |

## 1. Target: rebuild with harness v2

- Put `fuzz/UciMessageFuzzer.java` **in the repo tree** (Dockerfile: uncomment the `COPY UciMessageFuzzer.java $SRC/project/fuzz/…` line)
  so discver also sees the source (`source harnesses found: [UciMessageFuzzer]`).
- `build.sh` (this folder) compiles it, writes the launcher, and now also produces `UciMessageFuzzer_seed_corpus.zip`
  (12 skeleton messages encoded by the library itself) and `UciMessageFuzzer.dict` (element names + XML tokens). OSS-Fuzz/OSS-CRS pick both up by name.
- Remove the old `UciXmlFuzzer` launcher/jar from `$OUT` so the budget does not go to the slow harness.

## 2. Two-minute check before spending a run (inside the built target, or anywhere with the `$OUT` dir)

```
java -cp "$OUT:$OUT/app-classes.jar:$(printf '%s:' $OUT/*.jar)" UciMessageFuzzer
```
Prints `externalizer = … (init NNNN ms)`, `20 parses in M ms`, `OK - offline path works`.
- `init` of 10–60 s is expected — that is the cost that used to kill every fork child; it now happens before fuzzing.
- `20 parses` should be a few ms each. If a single parse takes seconds, stop and tell me: then the parser itself is slow and the fix is different.

```
$OUT/UciMessageFuzzer -runs=3000
```
Watch the libFuzzer stat lines: `exec/s` in the hundreds or more, and **no** `timeout` lines. That is the whole test.

## 3. discver container env (compose `environment:` of the discver service)

```
FORCE_HARNESS_COMPILE=1
DISCVER_GUIDED_JSON=off
```
Optional, precision-first for this target (PoV-backed findings always submit; nothing without a reproducer does):
```
DISCVER_SUBMIT_MIN_CONFIDENCE=1.1
DISCVER_SUBMIT_WEAK_MIN_CONFIDENCE=1.1
```
(Last run's only submission was a non-volatile-field "race" rated 1.0 by three rounds of the same model — a false positive. These two
lines keep that class out until the calibration fix lands. Confirm the names once on lair: `grep -rhoE 'DISCVER_SUBMIT[A-Z_]*' src | sort -u`.)
KB mount unchanged.

## 4. Run

Same command as always, but `--target-harness auto` (not the explicit name) so provided and generated harnesses both run.

## 5. First ten minutes of orchestrator.log — pass/fail

```
grep -nE "source harnesses found|custom-harness compile|Skipping harness compilation|\[seeds\]|\[strategy\] (KB|no KB)" orchestrator.log | head
grep -c "NON-CRASH \[hang\]" orchestrator.log
grep -nE "harness_reach\].*reaches|harness_reach\].*dropped" orchestrator.log | head
```
Pass looks like: `source harnesses found: [UciMessageFuzzer]; built by project: [UciMessageFuzzer]`; no "Skipping harness compilation" line;
`[seeds] UciMessageFuzzer: 12+ files`; hang count near zero in the first minutes; at least one generated harness `reaches target`;
`[strategy] KB /opt/discver/kb: …`.

If hangs still pile up **after** this fix, that is no longer initialisation — it is the parser itself choking on inputs (an XML
denial-of-service class). Keep the run, tell me, and the discver-side fix (deduplicate hangs by stack, cap them, mark the harness
slow) becomes the next campaign task.
