# oms-ghost-detector as an OSS-CRS target (for Ashok)

Four files, same shape as any OSS-Fuzz project:

```
oms-ghost-detector/          <- the OSS-CRS target dir
  project.yaml               language: jvm, sanitizer address
  Dockerfile                 base-builder-jvm; clones the repo; drops the harness into fuzz/
  build.sh                   mvn package + deps -> $OUT, compiles the harness, writes the launcher
  UciMessageFuzzer.java      the harness (default package)
```

Set it up exactly like the CRSBench Java targets, run discver on it with the
usual settings. Nothing discver-side changes.

## Why a provided harness

discver's entry-point ranker only sees *project* methods. The one surface worth
fuzzing here — the UCI XML parse — lives in the vendored `uci-externalizer-xml`
jar and is only called from the `readers/`, which need a live ActiveMQ bus.
So, unaided, discver would rank the processors/DTOs, build message objects via
setters, and most likely report a few NPEs in the processors that don't
catch-all. The harness makes the parse path reachable:

```
fuzz bytes -> byte[0] picks 1 of 12 UCI message types
           -> rest parsed:  ExternalizerLoader.getExternalizer().read(StringReader(xml), XxxMT.class)
           -> dispatched:   MsgProcManager.processXxx(msg)      (same call the readers make)
```

`UCIException` is the declared failure for malformed XML / missing mandatory
fields and is swallowed; anything else propagates to Jazzer. discver treats it
as a provided harness (task 29; task 38 repairs it if javac complains) and still
generates its own on top — strictly additive.

Every symbol was checked against the vendored jars: all 12 `processXxx`
names and parameter types (`procesSystemStatus` / `procesSubsystemStatus`
carry the repo's own typo — kept so it compiles), `Externalizer.read(Reader,
Class<T>)`, `ExternalizerLoader.getExternalizer()`, `PlayerStates(SystemID_Type)`,
`MsgProcManager(SystemID_Type, PlayerStates)`, the `SystemID_Type` fluent setters.

## What to expect

- Startup: `Target language: java` (from `FUZZING_LANGUAGE=jvm`), then
  `source harnesses found: [UciMessageFuzzer]; built by project: [UciMessageFuzzer]`.
- Health: should be HEALTHY (XML parsing grows coverage steadily); if it reads
  WEAK, send `health.json` and the first 200 lines of `orchestrator.log`.
- Findings: few. A sanitizer hit inside the parse will be classified
  `bug_in_dependency` (the jar, not the repo) — report it, it won't be patched.
  NPE-class findings in `processors/` are the only in-repo candidates.
- Unverified until built once: that `ExternalizerLoader` initialises with no
  `CALConfig.xml` / `OMS_CAL_CONFIG`. It should (that config belongs to the bus
  layer in `uci-cal-jms`, not the parser). If the harness dies at class-init,
  `build.sh` prints the smoke-test command; run it and send the stack trace.

## Build notes

- Maven downloads Spring Boot 2.7.12 / Jackson / log4j from Central at image
  build time, into the repo's `local-repo/` (its `settings.xml` points there).
  The `uci-cal-*` jars are already in that folder.
- The app is source level 8; the base image's JDK compiles it with warnings.
- Standalone (no OSS-CRS): `export JAZZER_DIR=<unpacked Jazzer release>` and
  run `bash build.sh` from the repo root; everything lands in `./out/`.
