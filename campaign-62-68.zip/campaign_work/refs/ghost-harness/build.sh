#!/bin/bash -eu
# Generic build.sh for ANY Maven-based Java repo set up as an OSS-CRS / OSS-Fuzz target.
# Nothing in here names a project or a harness:
#   - finds the project by its pom.xml (OSS-Fuzz: $SRC/<repo>; standalone: cwd or script dir)
#   - builds it, drops app classes + runtime deps + jazzer in $OUT (what discver's own
#     harness generator compiles against — so a repo with NO fuzz/ dir is fine)
#   - compiles every provided fuzz/*Fuzzer.java it finds and writes one launcher per class
#
# Inside the OSS-Fuzz base-builder-jvm image $SRC, $OUT, $JAZZER_API_PATH and the jazzer
# binaries in $OUT are provided. Standalone: set JAZZER_DIR to an unpacked Jazzer release.

# --- locate the project
if   [ -f "${PWD}/pom.xml" ]; then PROJECT="$PWD"
elif [ -n "${SRC:-}" ] && [ -d "$SRC" ]; then
  PROJECT="$(find "$SRC" -maxdepth 2 -name pom.xml -printf '%h\n' | head -1)"
else PROJECT="$(cd "$(dirname "$0")" && pwd)"; fi
[ -f "$PROJECT/pom.xml" ] || { echo "build.sh: no pom.xml found under $PROJECT" >&2; exit 1; }
: "${OUT:=$PROJECT/out}"
mkdir -p "$OUT"
cd "$PROJECT"
echo "[build] project: $PROJECT"

# --- 1. build + collect runtime deps. Use the repo's settings.xml if it has one
#        (UCI repos point it at their vendored local-repo/).
SETTINGS=(); [ -f settings.xml ] && SETTINGS=(-s settings.xml)
mvn "${SETTINGS[@]}" -q -DskipTests clean package \
    dependency:copy-dependencies -DincludeScope=runtime -DoutputDirectory="$OUT"
# plain classes, not the Boot-repackaged jar (BOOT-INF/ is useless on a classpath)
( cd target/classes && jar cf "$OUT/app-classes.jar" . )

# --- 2. jazzer
if [ ! -f "$OUT/jazzer_driver" ]; then
  : "${JAZZER_DIR:?standalone build: set JAZZER_DIR to the unpacked Jazzer release}"
  cp "$JAZZER_DIR/jazzer_driver" "$JAZZER_DIR/jazzer_agent_deploy.jar" "$OUT/"
fi
JAZZER_API="${JAZZER_API_PATH:-${JAZZER_DIR:-}/jazzer_api_deploy.jar}"
BUILD_CP="$OUT/app-classes.jar:$JAZZER_API:$(printf '%s:' "$OUT"/*.jar)"

# --- 3. provided harnesses (optional): fuzz/*Fuzzer.java or *Fuzzer.java at the root
write_launcher() {  # $1 = class name (default package)
cat > "$OUT/$1" <<EOF
#!/bin/bash
# LLVMFuzzerTestOneInput for fuzzer detection.
this_dir=\$(dirname "\$0")
if [[ "\$@" =~ (^| )-runs=[0-9]+(\$| ) ]]; then mem_settings='-Xmx1900m:-Xss900k'; else mem_settings='-Xmx2048m:-Xss1024k'; fi
cp="\$this_dir"
for j in "\$this_dir"/*.jar; do case "\$j" in *jazzer_agent_deploy.jar|*jazzer_api_deploy.jar) ;; *) cp="\$cp:\$j" ;; esac; done
LD_LIBRARY_PATH="\${JVM_LD_LIBRARY_PATH:-}":\$this_dir \\
"\$this_dir/jazzer_driver" --agent_path="\$this_dir/jazzer_agent_deploy.jar" --cp="\$cp" \\
  --target_class=$1 --jvm_args="\$mem_settings" "\$@"
EOF
chmod +x "$OUT/$1"
}

RUN_CP="$OUT:$OUT/app-classes.jar:$(printf '%s:' "$OUT"/*.jar)"
n=0
for src in fuzz/*Fuzzer.java ./*Fuzzer.java; do
  [ -f "$src" ] || continue
  cls="$(basename "$src" .java)"
  javac -source 8 -target 8 -cp "$BUILD_CP" -d "$OUT" "$src"
  write_launcher "$cls"
  n=$((n+1))
  echo "[build] provided harness: $cls"
  # --- seeds + dictionary, if the harness supports `--write-seeds <dir>` (UciMessageFuzzer does).
  #     OSS-Fuzz convention: $OUT/<Harness>_seed_corpus.zip and $OUT/<Harness>.dict are picked up automatically.
  seeds="$(mktemp -d)"
  if java -cp "$RUN_CP" "$cls" --write-seeds "$seeds" >/dev/null 2>&1 && [ -n "$(ls -A "$seeds")" ]; then
    rm -f "$OUT/${cls}_seed_corpus.zip"
    ( cd "$seeds" && zip -q -j "$OUT/${cls}_seed_corpus.zip" ./* )
    {
      # element names the library itself emits, plus the usual XML attack tokens
      cat "$seeds"/* | tr -d '\000' | grep -ohE '</?[A-Za-z_][A-Za-z0-9_:.-]*' | sed 's|^</|<|' | sort -u | sed 's/.*/"&"/'
      printf '%s\n' '"<?xml version=\"1.0\"?>"' '"<!DOCTYPE"' '"<!ENTITY"' '"SYSTEM"' '"PUBLIC"' '"&amp;"' '"&lt;"' '"<![CDATA["' '"]]>"' '"xmlns="' '"xsi:type="'
    } > "$OUT/$cls.dict"
    echo "[build] $cls: $(ls "$seeds" | wc -l) seeds -> ${cls}_seed_corpus.zip, dict $(wc -l < "$OUT/$cls.dict") tokens"
  else
    echo "[build] $cls: no seed writer (or it failed) — fuzzing without a seed corpus"
  fi
  rm -rf "$seeds"
done
[ "$n" -eq 0 ] && echo "[build] no provided harness — discver generates its own against $OUT"
echo "[build] done -> $OUT"
echo "[build] smoke test (prints init time and per-parse time):  java -cp \"$RUN_CP\" <Harness>"
