# Campaign 62–68 — one run, from a tree at task 61

Order matters and is baked into the numbers: 62–65 fix what the Nov 12 run showed (no flags needed afterwards),
66–68 add the capabilities (boundary discovery, boundary harness generation, build-from-path with components).

From the folder that holds `campaign.py` and `campaign_work/` (single-line commands, no trailing backslashes):

1. rm -f campaign_work/tasks_auto/6[2-8]_*.md            # drop any earlier copies of 62–64 (campaign-e) to avoid duplicate numbers
2. unzip -o campaign-62-68.zip -d .
3. mkdir -p campaign_work/results/latest && cp <ghost_ex_orchestrator.log> campaign_work/results/latest/orchestrator.log
   (the Nov 12 oms-ghost-detector log; hangs/ and health.json too if you have them. Tasks 62–65 read it; they still run without it.)
4. git clone --depth 1 https://github.com/open-arsenal/oms-ghost-detector campaign_work/refs/oms-ghost-detector
   git clone --depth 1 --recurse-submodules --shallow-submodules https://github.com/open-arsenal/ams-gra-hello-world-sk campaign_work/refs/ams-gra-hello-world-sk
5. python3 campaign.py --only 62,63,64,65,66,67,68

62  Java custom-harness compile DETECTED (javac + jazzer api + classpath), never "unsupported"; probe failure = skip; generated
    Java harnesses get fuzzerInitialize().                                   removes FORCE_HARNESS_COMPILE
63  Hang storm: dedup by stack, cap files, diagnose init-exceeds-timeout, WEAK on low exec/s, repeated real hangs = one finding.
64  guided_json rejected → disabled for the run after the first 400, cached.   removes DISCVER_GUIDED_JSON=off
65  No-PoV leads: same-model rounds cap at 0.7 without support; non-exploitable classes report-only without a reproducer.
66  Input-boundary discovery (12-shape fixture matrix, 2 real-world rows), ranked first, loud `[boundary] none found`.
67  Boundary harness generation at the decoder, transport stubbed, round-trip seeds; rejects a harness that skips the decoder.
68  Build from a path: submodules, components per build root, Maven/Gradle/CMake/Cargo/Go/Python, per-component report roll-up,
    stdlib-only local_build.py, tools manifest + setup_standalone.sh + --check-tools.

Expect the longest campaign so far (afternoon + overnight). Gate as always: baseline suite + the seven new test files.

Proof on your box afterwards:
  python3 src/input_boundary.py --root campaign_work/refs/oms-ghost-detector      # 12 handleMessage callbacks, uci.Externalizer.read
  python3 src/local_build.py --check-tools
Then the FULL zip to Ashok: java-ant-byo first (regression), then oms-ghost-detector with NO provided harness and NO extra env vars
(Dockerfile: comment out the COPY of UciMessageFuzzer.java). The log must show `(boundary harness)` and no hang storm.
refs/ghost-harness/ keeps the hand-written v2 harness + GOOD-RUN.md as the fallback for a run before the campaign lands.
