# Task 155 — a crash found through a harness discver wrote itself becomes a reproducer for the project's own harness — or is reported plainly as "found through a generated harness only"

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
discver writes its own harnesses (generated, boundary, closer-to-target). A crash found through one of them is real evidence of a
defect, but the oracle in OSS-CRS builds only the project's own (provided) harnesses, and benchmarks accept reproducers only for those.
So such a crash cannot be verified by the oracle, cannot be patched through it and cannot be submitted — today it simply stays
"unverified", with nothing in the report explaining why. That is the most common way a real bug found by discver ends up unverified.
End state: for every reproduced crash whose harness is not a provided one, discver tries to express it through a provided harness; on
success the finding continues through the oracle, patching and submission like any other; on failure it is reported in its own section
as "reproduced through a generated harness only", with the harness source and input attached and a plain statement that reachability
from the project's real entry points is unproven.

## Precondition — check before editing
How findings record their harness and whether it is provided or generated (`grep -rnE "provided|generated|boundary|origin" src/ | grep -i harness | head`);
the reproducer verification of task 150 (use it if present; otherwise the existing reproduction path) and the oracle of task 151 (use it
if present). State in finish() which were available.

## Study first
Findings, harness origin, reproducer verification (150), the oracle and its baseline reproduction (151), the call graph and target
paths (143), the LLM client with schemas (132), the scheduler queue (144), the report model (134); docs/ARCHITECTURE.md.

## Change
1. **Which findings**: reproduced crashes (task 150's sense, signature drift included) whose harness origin is generated, boundary or
   closer-to-target. Findings from provided harnesses are untouched.
2. **Direct replay first**: run the crashing input against each provided harness of the same component (≤ 3, ranked by call-graph
   distance from the harness entry to the crashing function). Same crash type and same top project frame → translated.
3. **Model-assisted translation** when direct replay fails: one request per provided harness (site `translate_reproducer`, schema: a list
   of up to 4 candidate inputs as base64 or escaped strings) with, under 6 KB: both harness sources, the call path from each harness entry to
   the crashing function with its branch conditions, the crashing function's source, the original input and what it decodes to at the
   crashing call (values of the arguments, when the generated harness makes them visible). Every candidate goes through reproducer
   verification; accepted only with the same crash type and the same top project frame. At most 2 requests per provided harness per
   finding; refused → final, the finding falls through to step 5.
4. **On success**: the finding gains the provided harness and reproducer (the original stays attached), then follows the normal path:
   oracle baseline reproduction, patching, submission. `[translate] <finding>: <generated harness> → <provided harness> (direct | model, attempt <n>)`.
5. **On failure**: status `reproduced via generated harness only`; `output/findings/generated_only/<id>/` holds the generated harness
   source, its build command, the input and the crash output; the report's "Unverified findings" section lists it with the reason
   (`no provided harness reaches <function>` when the call graph shows no path; `translation failed` otherwise).
6. Jobs come from the scheduler queue (type `translate`, ahead of generic seed work) when 144 exists; time-bounded by the deadline helpers.

## Tests (tests/test_translate_reproducers.py) — fixture harnesses (generated + provided, generic names), fake runner, fake LLM, fake oracle
- same input format → direct replay reproduces with the same top frame → finding translated, oracle path used, no LLM call.
- different format → fake LLM returns a translated input → verified → finding continues to patching/submission with both reproducers.
- the model's input crashes elsewhere (different top frame) → rejected; two failed attempts → `reproduced via generated harness only`
  with its folder and report entry; no provided path in the call graph → that reason, no LLM call.
- refusal → final, no rewording, generated-only status.
- caps (≤ 3 provided harnesses, ≤ 2 requests each); provided-harness findings untouched (golden).

## Acceptance
```
python -m pytest -q tests/test_translate_reproducers.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals and oracle commands; the submission format and thresholds.
