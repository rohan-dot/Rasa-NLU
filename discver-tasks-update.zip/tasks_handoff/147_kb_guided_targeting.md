# Task 147 — let the knowledge base decide where to look and what to try, and measure whether it helps: a ranking prior for targets, dictionary tokens from playbooks, hints for directed inputs, an on/off comparison in every report

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
The knowledge base (historical vulnerability findings distilled from public datasets: recipes per language, crash type, sink and
code idiom; per-weakness playbooks with sources, sinks, typical inputs and dictionary tokens) is used today for the strategy plan's
text and for triage grounding (MAP.md). It does not influence WHERE discver fuzzes or WHAT inputs it tries — the two things that
decide whether a bug is found. End state: (1) target ranking gets a knowledge-base prior — functions whose idioms and sinks match
historical bug recipes for their language rank higher, with the matching recipes named; (2) each target's dictionary gains tokens
from the matching playbooks; (3) directed-input requests carry short hints from the best-matching recipes; (4) the effect is
MEASURED: every report states which targets were boosted and what happened to them, and one setting turns the guidance off so two
runs can be compared. Without a knowledge base everything works exactly as before, with a caveat in the report.

## Precondition — check before editing
The target set and dictionaries from task 143 may or may not exist (docs/ARCHITECTURE.md, `../CAMPAIGN.md`). Without them: apply the
prior to the strategy phase's ranking only, skip the dictionary and hint parts, keep the measurement for ranked functions, and say so
in finish().

## Study first
The knowledge-base loader and format (recipes and playbooks: which fields exist — language, crash type, sink, idiom, tokens,
dictionary entries); the retrieval and scoring already used by the strategy phase (token weights, idiom matches, per-target lines);
triage grounding; the target set, ranking and dictionary code (143); directed-input prompts (145); the registry (131); the report model
(134); the knowledge-base loader's "none found / incompatible" handling (171, if landed); docs/ARCHITECTURE.md.

## Change
1. **Ranking prior.** For every candidate target, the existing retrieval score against the knowledge base (normalized 0–1) becomes a
   prior: `rank_score = base_score × (1 + w × kb_score)` with `w` a registry setting (default 0.3). In delta mode every changed function
   stays a target — the prior only orders them. Line per boosted target:
   `[targets] kb prior: <function> +<pct>% (recipes: <ids>, idiom: <name>)`.
2. **Dictionary tokens.** For each target, the playbooks matching its language and the weakness classes plausible at the target (sinks
   present on its path) contribute their dictionary tokens: at most 50 per target, after the path tokens from 143, within 143's total cap,
   each group preceded by a comment line `# kb:<playbook>`. `[targets] dict <harness>: +<n> kb tokens (<playbooks>)`.
3. **Hints for directed inputs.** Directed-seed and boundary requests (145) include the one-line descriptions of the top two matching
   recipes (≤ 300 characters total) under a "Historical patterns" heading — only when a knowledge base is loaded; without one the
   prompts are byte-identical to today (golden).
4. **Measurement.** Per target in the report: `kb_boost` (value and recipes), reached (round), crashed. A summary line in REPORT.md and
   health.json: `knowledge-base guidance <on|off>: boosted targets k — reached r1/k, crashed c1; other targets m — reached r2/m, crashed c2`.
   Setting `kb_guidance` (default on); `off` disables 1–3 while keeping the measurement, so a pair of runs gives a direct comparison.
5. **No or incompatible knowledge base** → no prior, no tokens, no hints; the report caveat says guidance was unavailable.
6. docs/ARCHITECTURE.md: how the knowledge base influences targeting, and how to read the comparison.

## Tests (tests/test_kb_guided_targeting.py) — a tiny fixture knowledge base (a few recipes and one playbook, generic names), fixture targets
- the prior reorders targets as expected and names the recipes; delta mode keeps every changed function as a target.
- dictionary: kb tokens added after path tokens, labelled, capped at 50 per target and within the total cap.
- hints appear only with a knowledge base; without one, directed prompts are byte-identical (golden).
- measurement block and summary line; `kb_guidance=off` → ordering, dictionaries and prompts identical to the no-KB case, measurement present.
- missing / incompatible knowledge base → no changes, caveat present.

## Acceptance
```
python -m pytest -q tests/test_kb_guided_targeting.py
```

## Do not touch
The knowledge-base file formats (read only); triage grounding behaviour; crash_dedup._get_crash_signature; sidecar internals.
