# Task 158 — nothing discver saw is hidden: reproducible crashes in dependency code reported as dependency bugs, and same-signature crashes that look like a different bug kept as "possibly distinct"

max_turns: 170

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Two ways a real bug disappears from results even though discver saw it:
1. Crashes and leads located in dependency code (precompiled archives and jars, vendored or system libraries) are rejected as
   unconfirmable or out of scope. A REPRODUCIBLE crash in a library reached through the project's input is a real security problem for
   the project and for everyone using that library version.
2. Deduplication by signature can merge two different bugs that share their top frames — a read and a write overflow in the same
   function, different allocation sites, different project call paths — and the second never appears anywhere.
End state: reproducible dependency crashes are reported as their own class with the dependency, version and the project frame that
called into it; same-signature crashes that differ in what matters are kept and reported as possibly distinct. The signature function
itself is not changed.

## Study first
The arbiter/triage rule that rejects dependency locations (`grep -rnE "precompiled|dependency|BUG_IN_DEPENDENCY|jar" src/ | head -30`);
how frames are classified project vs dependency (adapters' crash parsers); dedup and where duplicates are counted (150);
build metadata that names dependencies and versions (jar manifests and names, lock files, `go.mod`, `Cargo.lock`, `pkg-config`, library
sonames); the patch loop's eligibility (153, 154); the report model (134); docs/ARCHITECTURE.md.

## Change
1. **Dependency bugs**: a reproduced crash whose top frames are all in dependency code → class `dependency_bug`: kept, reproduced (150),
   reported with dependency name and version (from build metadata; `unknown` when not determinable), the first project frame that called
   into it, and the reproducer. Not submitted by default (registry setting `publish_dependency_bugs`). Patching: skipped with
   `fix belongs in <dependency> <version>` — unless the dependency's source is vendored inside the repository, in which case it is patched
   like project code. Leads WITHOUT a reproducer in dependency code stay rejected by the arbiter, but are listed under "Dependency leads
   (unconfirmed)" instead of vanishing.
2. **Possibly distinct duplicates**: when a new crash maps to an existing signature, compare crash kind and access type (READ vs WRITE,
   use-after-free vs overflow), access size, the top allocation/free frames, and the project frame sequence beyond the signature depth; any
   difference → keep it as `possibly_distinct` linked to the original, with its reproducer, reproduced and reported separately ("possibly a
   different bug hidden by deduplication"). It is published separately only if its crash kind differs; otherwise it stays report-only.
3. **Report**: sections "Dependency bugs", "Dependency leads (unconfirmed)", "Possibly distinct duplicates", each with folders on disk.

## Tests (tests/test_nothing_hidden.py) — recorded crash reports (native and JVM), fixture build metadata
- crash with all top frames in a library → `dependency_bug` with name/version and calling project frame; not submitted; patch skipped
  with the reason; vendored dependency → patched like project code.
- unconfirmed dependency lead → listed, still rejected.
- same signature, READ vs WRITE → `possibly_distinct`, published separately; same signature, same kind, different deeper project frames →
  `possibly_distinct`, report-only; truly identical → plain duplicate as before.
- report sections present; the signature function untouched (its output unchanged on the fixtures).

## Acceptance
```
python -m pytest -q tests/test_nothing_hidden.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals; submission thresholds and format.
