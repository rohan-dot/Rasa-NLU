# Task 157 — catch bugs that do not crash: property oracles in generated harnesses — round-trip checks, contract invariants, differential comparison — armed only after they hold on the whole corpus

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Sanitizers detect memory and undefined-behaviour errors; Jazzer detects injection-style bugs. Logic errors — a parser that accepts
input it must reject, a decoder and encoder that disagree, a length or bound the function's own contract forbids, two code paths that
give different answers for the same input — produce no crash, so fuzzing never reports them. End state: discver's generated and
boundary harnesses can carry property oracles that turn a violated property into a crash of a distinct class, `property_violation`.
False positives are the risk, so a property is armed only after it holds on every input in the current corpus, and violations are
reproduced, minimized and triaged with the property's text — reported, not submitted, by default.

## Study first
The boundary records and their encoder/decoder pairs (input-boundary discovery and boundary harness generation), the harness
generators and their per-language skeletons, the target set (143), reproducer verification (150), triage, the report model (134), the
LLM client (132); property-based seed generation if present (`grep -rnE "pb_seeds|property|invariant" src/ | head`); docs/ARCHITECTURE.md.

## Change
1. **Round-trip property** (no model needed): where a boundary record pairs an encoder with the decoder, the boundary harness checks
   `decode(encode(decode(x))) == decode(x)` (compared after the adapter's normalization) and that `encode(decode(x))` decodes without
   error; a mismatch aborts with `discver-property: round-trip: <field path>`.
2. **Contract invariants** (site `property_invariants`): for a target function, the model proposes up to 5 invariants from its
   documentation, its assertions, its callers' checks and its return-value contract, each as a small check in the harness language
   (bounds on lengths and counts, relations between outputs and inputs, "rejected inputs stay rejected"). Refused or invalid replies →
   no invariants, round-trip only.
3. **Differential property**: when the project (or a dependency the call graph reaches) has two implementations of the same decoder or
   format (detected by matching signatures and names), the harness feeds both and compares normalized outputs.
4. **Burn-in before arming**: each property is compiled into the harness and replayed over the entire current corpus; any property that
   fails during burn-in is discarded with `[property] <harness>: discarded <name> — fails on <k> corpus inputs`; armed properties are
   logged `[property] <harness>: armed <n> (<names>)`.
5. **Violations**: the abort message makes the crash parser classify it as `property_violation` with the property name; it is reproduced
   twice (150), minimized, and triaged with the property text and the input; report-only by default (registry setting to publish);
   never presented as a memory-safety crash; patching is attempted only when triage marks it a real defect.
6. Per-language abort mechanism: C/C++ `abort()` after a stderr line; Java a dedicated exception class Jazzer reports as a finding;
   Python a dedicated exception; Go `panic`; Rust `panic!`.

## Tests (tests/test_property_oracles.py) — fixture decoder/encoder pair with an asymmetry bug (generic names), fake LLM, fake engine
- the round-trip property detects the asymmetry; the crash is classified `property_violation` with the property name.
- an invariant that fails on corpus inputs is discarded during burn-in (line); one that holds is armed.
- a violation is reproduced twice, appears in the report as report-only with the property text; never in the crash submission path.
- refusal → round-trip only; differential property on two fixture implementations of the same format.
- harnesses without a boundary encoder and without targets are unchanged (golden).

## Acceptance
```
python -m pytest -q tests/test_property_oracles.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals; submission thresholds and format; the non-property text of generator prompts.
