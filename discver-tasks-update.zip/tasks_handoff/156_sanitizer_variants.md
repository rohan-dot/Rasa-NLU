# Task 156 — fuzz with more than one bug detector: UndefinedBehaviorSanitizer and (where feasible) MemorySanitizer builds for C/C++, overflow checks for Rust, the race detector for Go, every Jazzer detector on — sharing one corpus, verified with the detector that found the bug

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
A crash is only reported when a detector notices it. C/C++ targets are built with one configuration (AddressSanitizer — MAP.md
shows the build flags). AddressSanitizer does not see signed integer overflow, invalid shifts, misaligned or null-member access,
out-of-bounds indexes into arrays inside structures, integer division by zero, or reads of uninitialized memory — whole classes of
real bugs that fuzzing reaches and silently passes over. OSS-Fuzz builds every project with several sanitizers for exactly this
reason. The same gap exists in other languages: Rust fuzz builds are optimized without overflow checks, Go fuzzing runs without the
race detector, and a Jazzer detector disabled by a flag is a bug class never reported. End state: each component gets the detector
variants that make sense for its language and dependencies; variants share one corpus; the scheduler gives them fuzz time; every
finding records the variant that found it and is reproduced, verified and patched with that variant; the report says which detectors
ran and which classes were NOT covered, and why.

## Study first
How components are built and with which flags (the build-from-path builders, the native link recipe — task 141, the OSS-CRS build
layout in `$OUT`); how the sanitizer is chosen today (`grep -rnE "fsanitize|SANITIZER|sanitizer" src/ | head -40`); the UBSan and MSan
flag sets OSS-Fuzz uses (`grep -rnE "SANITIZER_FLAGS_(undefined|memory)|fsanitize=undefined" <oss-fuzz ref root> | head`); how the
scheduler (144) allocates fuzz time and how corpora are stored; reproducer verification (150) and the oracle (151); Rust (cargo-fuzz),
Go and Jazzer invocation in the adapters; docs/ARCHITECTURE.md.

## Change
1. **Variant plan per component** (`[sanitizers] <component>: address, undefined, memory (skipped: <reason>)`), from the adapter:
   - C/C++: `address` (existing); `undefined` with the OSS-Fuzz UBSan flag set and no recovery, so undefined behaviour aborts and is
     reported; `memory` only when feasible — every linked object instrumented (pure C/C++ with dependencies built from source in the
     same build, no prebuilt third-party libraries, C++ standard library instrumented or unused) — otherwise skipped with the reason
     (`uninstrumented dependency <lib>`), because MemorySanitizer reports false positives through uninstrumented code.
   - Rust: an `overflow` variant built with debug assertions and overflow checks enabled.
   - Go: a `race` variant (race detector) for packages that start goroutines or import sync primitives.
   - JVM: confirm every Jazzer bug detector is enabled (none disabled by flags); log the list; configure detectors that need a target
     setting (e.g. allowed hosts for the SSRF detector) from the run's context.
2. **Builds**: standalone mode builds each variant with the builders into `<out>/<component>/<variant>/`; OSS-CRS mode uses the variant
   builds the infrastructure provides (detected in the build output) and, when only one exists, records the caveat
   `only <sanitizer> build available — not covered: <classes>`. A variant that fails to build is skipped with its reason; the others run.
3. **Fuzzing**: variants are harness instances the scheduler allocates time to (defaults: `undefined` 30 %, `memory` 15 % of the
   component's fuzz time; registry settings) and share one corpus (inputs found by one variant seed the others).
4. **Findings**: every finding records its variant; reproduction (150) uses that variant's binary and sanitizer options; the same
   signature found by two variants is one finding listing both. The oracle: a finding from a variant the oracle cannot build is verified
   locally and reported `verified locally (<variant>); oracle builds <other> only` — never silently dropped; the local oracle builds the
   finding's variant.
5. **Report**: per component — variants run or skipped with reasons, fuzz time per variant, findings per variant, and the classes not
   covered.

## Tests (tests/test_sanitizer_variants.py) — fake builds, fake engine output in UBSan/MSan/race/overflow styles
- C fixture → plan `address, undefined, memory`; a fixture linking a prebuilt library → `memory` skipped with the library named.
- variant build flags (UBSan set with no recovery; MSan flags) and output dirs; one variant failing to build → others run.
- scheduler shares and shared corpus (an input found by `address` appears in the `undefined` corpus).
- a UBSan report (`runtime error: signed integer overflow`) parsed as a finding with variant `undefined`; reproduction uses that binary.
- OSS-CRS layout with only one build → caveat listing the uncovered classes; oracle mismatch wording.
- Rust `overflow` and Go `race` argv; Jazzer detector list logged, none disabled.

## Acceptance
```
python -m pytest -q tests/test_sanitizer_variants.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals and oracle commands; the OSS-CRS build itself; the submission format.
