# Task 159 — a component that fails to build gets a bounded repair ladder before it is given up: standard fallbacks per build system, then model-proposed edits to build files only

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Repositories in the wild often fail the default build for reasons unrelated to the code under test: warnings promoted to errors
under clang, optional features that need libraries not installed, test or documentation targets that need extra tools, a missing
configure step, plugins that need the network. Today such a component is reported `cannot build` and nothing in it is fuzzed or
patched. End state: before giving up, discver walks a bounded repair ladder — deterministic fallbacks per build system, then
model-proposed edits restricted to build configuration in a scratch copy — and records the recipe that worked, which the oracle then
reuses so patches are validated against the same build. Nothing is downloaded at run time: a missing system library is reported with
the package that provides it (the doctor's fix line).

## Study first
The build-from-path builders and how failures are classified (`grep -rnE "cannot build|\[build\]|def build" src/ | head -30`); the
recorded recipes (141); the oracle's use of recipes (151); the tool manifest (170, if present); the LLM client (132); the report model
(134); docs/ARCHITECTURE.md.

## Change
1. **Deterministic fallbacks** (each logged `[build] <component>: retry with <fallback>`), in order until one builds:
   CMake — `-DBUILD_TESTING=OFF`, docs/examples options off, `-Wno-error`, build only library and fuzzer targets; autotools — `autoreconf -fi`
   when `configure` is missing, `--disable-shared`, docs off, `-Wno-error`; Meson — tests and docs off, `-Dwerror=false`; Maven — offline,
   tests and javadoc/checkstyle/spotbugs/enforcer skipped; Gradle — offline, `-x test -x javadoc`; Cargo — default features, then
   `--no-default-features`; Go — `-mod=vendor` when a vendor dir exists, else `-mod=mod` with the module cache; Python — in-place extension build.
2. **Model-assisted repair** (site `build_repair`), only when the fallbacks fail: the failing command, the error tail, and the build files
   (CMakeLists, configure.ac/Makefile.am, meson.build, pom.xml, build.gradle, Cargo.toml, go.mod, setup.py/pyproject) → edits to BUILD
   FILES ONLY, applied in a scratch copy; an edit to any other file is rejected; at most 3 attempts; refusal → stop.
3. **Missing system libraries** (linker or configure errors naming a library) → reported with the package name from the tool manifest
   or the standard distribution package name: `[build] <component>: needs <library> (install <package>)`; no download attempted.
4. **Recipe**: the working combination (fallbacks + build-file edits as a diff) is recorded with the component and reused by fuzzing
   builds, sanitizer variants and the oracle; the report shows "built after repair: <what changed>".
5. Still failing → `cannot build <component>: <reason>` with every attempt and its error tail in the report.

## Tests (tests/test_build_repair.py) — fake build commands failing for scripted reasons, fake LLM
- `-Werror` failure → fixed by the warning fallback; test-target failure → fixed by testing-off; ladder order logged.
- fallbacks exhausted → model edit to CMakeLists applied in scratch → builds; a proposed edit to a `.c`/`.java` file rejected.
- missing library error → the needs/install line, no download; three failed attempts → `cannot build` with all attempts.
- the recipe is recorded and the oracle's build uses it (fake oracle sees the same flags and diff).

## Acceptance
```
python -m pytest -q tests/test_build_repair.py
```

## Do not touch
Source files of the target (only build files, only in a scratch copy); the OSS-CRS build; crash_dedup._get_crash_signature;
sidecar internals.
