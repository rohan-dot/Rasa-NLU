# Task 150 — reproducers: verified locally before any effort is spent, one published per signature, non-crash classes kept out of the crash path — and a real bug that will not reproduce is never silently lost

max_turns: 170

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: in a benchmark, well under half of the raw submissions were verified; one project's variants produced every
unintended crash; candidates that never reproduced in a clean room consumed LLM triage and oracle runs first. Raw counts made the
run look better than it was and cost precision. Rules, for any language: (1) a candidate reproducer is re-run locally — twice, fresh
process, the run's harness binary and sanitizer options — before any LLM work, oracle call or publication; (2) at most one published
reproducer per crash signature (the smallest); (3) timeout / OOM / leak-only signatures stay in their own finding class (hang handling)
and are never published as crash reproducers; (4) the report shows raw → reproduced → flaky → duplicate → published per harness, so a
raw count is never the headline. The other side matters as much: a crash that does not reproduce in a fresh process is often still a
real bug (state built up across inputs, timing, a setting that differed from the fuzzing run, a build that differs). Precision must not
turn into silent loss: (5) before a crash is declared non-reproducible, it is retried with the fuzzing run's exact settings; (6) it is
never discarded — it stays in the report and on disk with its input and original crash output, as an unverified finding a person can
look at; (7) a signature that drifted between builds (same crash type, same top project frame, different deeper frames) still counts
as reproduced.

## Study first
Where candidate reproducers come from (fuzzer crashes, crashing seeds, LLM-generated inputs), where they are triaged, sent to the
oracle and published (`grep -rnE "\[submit|publish|run-pov|clean-room|SUBMIT_DIR" src/`); `crash_dedup._get_crash_signature` (use, do
not change); hang/timeout classification; the report model (134); docs/ARCHITECTURE.md.

## Change
1. **Local prevalidation first**: every candidate is run twice through the local harness (single-input mode, fresh process, the run's
   sanitizer options and timeout); signature via `_get_crash_signature`. 2 of 2 → proceeds unchanged into triage/oracle/publication;
   1 of 2 → `flaky`, ranked last.
   0 of 2 → **one retry with the fuzzing run's exact settings** (the same engine options, sanitizer environment, timeout, memory limit,
   working directory, harness options/dictionary files as the run that found it): reproduces → treated as reproduced, and the setting
   that differed is logged as a verification-setup defect `[repro] <id>: reproduces only with the fuzzing run's settings (<difference>)`;
   still not → status `not_reproducible`: no LLM spend, no oracle call, not published, but KEPT — `output/findings/not_reproducible/<id>/`
   holds the input, the original crash output and every attempt's output, and the report lists it under "Unverified findings" with the
   likely reason when visible (state across inputs, timeout/memory differences, nondeterminism).
   **Signature drift**: when the signatures differ but the crash type and the top project frame match, the result is
   `reproduced (signature drift: <old> → <new>)`, not "did not reproduce" (the signature function itself is not changed).
2. **Dedup before publishing**: a signature already published → counted `duplicate`, not published (if the submission interface can
   replace an entry, a strictly smaller reproducer replaces it; otherwise skip).
3. **Non-crash classes** (timeout, OOM, leak-only) → the hang/resource finding class; never published as crash reproducers; listed in the
   report with their own counts and reproducers. A registry setting `publish_resource_findings` (default off) lets an operator whose
   benchmark scores resource-exhaustion bugs publish verified ones through the existing policy.
4. **Report**: per harness — candidates, reproduced, flaky, not reproducible, duplicates, published, non-crash; REPORT.md summary uses
   published and reproduced counts, never raw; an "Unverified findings" section lists every not-reproducible and flaky crash with its
   folder, so nothing real disappears.

## Tests (tests/test_reproducer_prevalidation.py) — fake harness runner with scripted signatures, fake LLM, fake oracle
- 56 candidates: 30 non-reproducing, 20 reproducing in 3 families, 6 timeouts → exactly 3 published (smallest per family), 6 in the
  non-crash class, 30 `not_reproducible` with zero LLM and zero oracle calls for them (assert the fakes' call counts) — each with its
  folder (input, original output, attempts) and listed under "Unverified findings".
- a candidate that crashes only with the fuzzing run's settings (fake runner keyed on a timeout or environment value) → reproduced on the
  retry, with the difference logged.
- same crash type and top project frame, different deeper frames → `reproduced (signature drift)`.
- `publish_resource_findings=on` → a verified timeout finding goes through the policy; off → never published.
- 1-of-2 → flaky, ranked after 2-of-2; duplicates counted; report counts and REPORT.md wording.
- tests/e2e passes (the fake engine reproduces deterministically).

## Acceptance
```
python -m pytest -q tests/test_reproducer_prevalidation.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals and oracle commands; the submission file format; non-LLM fuzzing budgets.
