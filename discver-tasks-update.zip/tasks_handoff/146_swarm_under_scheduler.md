# Task 146 — the bug-hunting swarm works for the run, not beside it: its jobs are scheduled, aimed at the targets that matter, routed through screening and verification, and measured by what they actually find

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
discver has a multi-agent bug-hunting swarm (MAP.md: the swarm module and its LLM call sites). Today it decides on its own what to
hunt and how much model effort to spend, outside the run's effort control. EVIDENCE.md shows the cost of unaimed LLM hunting:
generated candidates that never reproduced in a clean room consumed execution and model effort, refusals hit reproducer
construction, and generation kept producing inputs for crash families that were already found. Nothing reports what the swarm
contributed. End state: swarm work is a job type the scheduler (144) prioritizes and caps; every swarm job is assigned a concrete
target (143) with its path conditions, dictionary and the crash families to avoid; everything the swarm produces goes through seed
screening (142) and reproducer verification (150) like any other input; the swarm's yield is measured per role and per target, and
roles that produce nothing are throttled while roles that find new crash signatures get more. How a swarm agent reasons internally
is not changed — only what it is pointed at, how much it may spend, and where its output goes.

## Precondition — check before editing
Find the swarm (`grep -rnE "swarm|Swarm" src/ | head -40`). The scheduler (144) and target set (143) may or may not have landed
(`../CAMPAIGN.md`, docs/ARCHITECTURE.md). Without 144: keep the swarm's own loop but add caps, routing and yield accounting, and
apply throttling inside the swarm loop. Without 143: no target assignment (log once why) — routing, caps and accounting still apply.
State which case applied in finish().

## Study first
The swarm module: how agents/roles are created and how many, what each produces (inputs, harnesses, leads, reproducers), how it is
scheduled today (concurrency, rounds, budget), where its outputs enter the pipeline (corpus, crash handling, triage, submission),
which LLM sites it uses. The scheduler's queue (144), the target set and reach (143), seed screening (142), the LLM client's
per-site stats (132), the report model (134), the deadline helpers (135); docs/ARCHITECTURE.md. Look at how the reference CRSs in the
ref roots aim their LLM agents at targets (`grep -rniE "swarm|agent.*target|sink|direct" <refs> --include=*.py | head -40`).

## Change
1. **Swarm jobs.** Swarm work becomes `SwarmJob(role, target, harness, max_llm_calls)` entries of their own type in the scheduler's
   LLM queue (or in the swarm loop when 144 is absent). The scheduler sets how many run per round: default share 30 % of LLM jobs while
   targets are unreached, less when no role shows yield, none after the deadline check (135) says there is no time.
2. **Assignment.** Each job carries one target — unreached targets first, then reached-without-crash, in full mode the top-ranked — with
   the call-graph path and branch conditions from the harness entry, the target's dictionary tokens, and the "already found — aim
   elsewhere" block of known crash families. With no target set, the swarm keeps its current selection (logged once).
3. **Routing.** Inputs the swarm produces go through seed screening (142) — crashers become candidates there; candidate reproducers go
   through the reproducer path (task 150 adds local prevalidation for every candidate, the swarm's included); leads without a reproducer
   go to triage under the existing class and calibration rules. Nothing the swarm produces bypasses these steps.
4. **Yield accounting.** Swarm LLM sites are named `swarm_<role>` in the LLM client. Per role and per target: jobs, LLM calls, tokens,
   refusals, inputs produced, inputs kept by screening, candidates, reproduced, new signatures, published. A "Swarm" section in
   REPORT.md and a `swarm` block in health.json; one line per round:
   `[swarm] round <n>: <k> jobs (<roles>) — kept <i> inputs, <c> candidates, <s> new signatures; throttled: <roles>`.
5. **Adaptive.** A role with no kept inputs and no new signatures after N jobs (default 5, a registry setting) drops to a floor of one job
   per round; a role that produced a new signature in the last window gets a higher weight; a role whose recent refusal rate is above
   50 % gets fewer jobs (logged — requests are never reworded).
6. docs/ARCHITECTURE.md: the swarm's place in the pipeline (assignment, routing, accounting).

## Tests (tests/test_swarm_scheduling.py) — fake LLM, fake swarm roles producing scripted outputs, fake screening and reproducer path
- swarm jobs appear in the queue with their share; none once the deadline helper says no time.
- each job's prompt/assignment contains the target, its path conditions, dictionary tokens and the known-family block; unreached targets
  assigned before reached ones; no target set → current selection with the log line.
- outputs routed: inputs → screening, reproducers → reproducer path, leads → triage (assert the fakes saw them; nothing published directly).
- yield accounting per role and per target; report section and health block.
- a zero-yield role throttled to the floor after N jobs; a role with a new signature boosted; a refusal-heavy role deprioritized with the line.
- precondition branches: without the scheduler, caps and throttling run inside the swarm loop.
- the swarm's own prompts for a fixed input are byte-identical apart from the added assignment block (golden shows the exact diff).

## Acceptance
```
python -m pytest -q tests/test_swarm_scheduling.py
```

## Do not touch
How swarm agents reason (prompts beyond the assignment block); submission thresholds and format; crash_dedup._get_crash_signature;
sidecar internals.
