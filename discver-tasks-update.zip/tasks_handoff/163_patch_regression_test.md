# Task 163 — every validated patch comes with a regression test in the project's own test framework that fails before the fix and passes after it

max_turns: 180

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
A patch is far more useful — to the project's maintainers, to the people taking over discver, and as evidence — when it comes with
a test that proves it: the test fails (or crashes) on the unpatched code and passes on the patched code. For projects without tests
it is the only test there is. End state: for every validated patch, discver writes a regression test in the project's own framework,
proves fail-before / pass-after through the oracle, and ships it next to the patch; a test that does not prove it is discarded, never
shipped.

## Study first
The patch loop and its outcomes (153), persistence of patches, the oracle's build and test runs (151) and how the project's test
command is detected; the patch context (152); the submission format (what may accompany a patch); the LLM client (132);
docs/ARCHITECTURE.md.

## Change
1. **Framework detection** per component: the framework the project's tests already use (CTest with GoogleTest/Catch2/Unity/plain test
   executables; JUnit for Maven/Gradle; `go test`; Rust `#[test]`; pytest/unittest). None → a minimal standalone test program for C/C++
   added to the build only in the scratch copy, or the language's built-in test tool.
2. **Test generation** (site `regression_test`): input — the patch diff, the fixed function, the reproducer (and the values it implies at
   the fixed function), an existing test file as a style example; output — one test file or one test function added to an existing file,
   that drives the fixed function with the reproducer's input.
3. **Proof**: through the oracle, the test must FAIL or crash on the unpatched build and PASS on the patched build, and the rest of the
   suite must not newly fail. Otherwise the test is discarded with `[regression-test] <finding>: discarded — <passes before | fails after>`;
   one corrective request with the observed results, then give up. Refusal → no test.
4. **Ship**: the test is stored with the patch (`output/patches/<finding>/regression_test.*`) and listed in the patch index; included in a
   submission only if the submission format accepts additional files (the format is not changed). Report: per validated patch
   `regression test: yes (<file>) | no (<reason>)`.

## Tests (tests/test_patch_regression_test.py) — fixture C and Java projects (generic names), fake oracle, fake LLM
- framework detected per fixture; generated test fails before / passes after → shipped and indexed.
- a test that passes before the patch → discarded with the line; corrective request once; second miss → no test.
- a test that breaks another test → discarded; refusal → `no (refused)`.
- the submission format is unchanged when it cannot carry extra files.

## Acceptance
```
python -m pytest -q tests/test_patch_regression_test.py
```

## Do not touch
Patch validation rules (the test is extra evidence, never a substitute for PoV replay); the submission format; sidecar internals;
crash_dedup._get_crash_signature.
