# discver handoff campaign — one unattended run that restructures, extends, packages and documents discver

Everything is done by the agents, including the "manual" parts: configuration defaults, Docker/setup scripts, the knowledge-base
packaging, README and docs. Your part is the steps below — about 20 minutes, then it runs on its own for roughly two and a half days.

All commands from `campaign_work` (the folder with `campaign.py`, `discver/`, `results/`, `refs/`), in the same shell setup as earlier
campaigns (LITELLM_BASE_URL, LITELLM_API_KEY, AGENT_MODEL=claude-opus-5-5, AGENT_CA_BUNDLE or AGENT_TLS_VERIFY). Recommended:
`export AGENT_REASONING_EFFORT=high`.

## 0. What this box needs (no Docker, no fuzzers, no compilers)
Python 3 with pytest and discver's Python dependencies, git, and network access to the LLM gateway — the same as earlier campaigns.
Every test the agents write uses fakes (a Python fake fuzzer, a fake model server, a fake patch validator); anything that needs a real
toolchain is skipped automatically. Real builds, fuzzing and the Docker image are verified afterwards on a machine that has them
(`scripts/discver doctor` and `scripts/discver selftest`).

### Get the code: the language-agnostic branch, into `campaign_work/discver`
The kit always works on `campaign_work/discver`, so the clone goes exactly there; the current tree is kept next to it.
```
cd /exp/FY26/AIxCC/ro31337/campaign_work
git ls-remote --heads <repo-url>                      # lists the branches — copy the exact name of the language-agnostic one
mv discver discver-before-handoff
git clone --branch <branch-name> --single-branch --depth 1 <repo-url> discver
du -sh discver; du -sh discver/* | sort -h | tail -6
diff -rq discver-before-handoff/src discver/src | grep "^Only in discver-before-handoff" | head -30
```
- No git at all: download the branch as a zip from the web page (branch dropdown → the language-agnostic branch → Code → Download
  ZIP, or `<repo-url>/archive/refs/heads/<branch-name>.zip`), put it in campaign_work, then:
  `mv discver discver-before-handoff && mkdir unz && unzip -q <file>.zip -d unz && mv unz/* discver && rmdir unz && ls discver/src | head`
  — same files, no `.git`; the result then goes back as `discver-handoff.zip` instead of a pushed branch.
- You get every file committed on that branch at its latest commit — code, tests, docs, compose/YAML files, test targets. `--depth 1`
  leaves out the history (that is where large `.pack` files come from); the campaign never needs it. Anything never committed (the KB
  zip, results, refs) does not come with it.
- Private repo: when git asks for a password, use a personal access token (or clone with the SSH URL if your key is registered).
- The last command lists work that exists only in the old tree (never pushed): copy those files into `discver/`, or keep the old tree.
  Modules from the earlier 62–69 tasks need no copying — step 3 re-runs them when missing.
- If `du` shows one folder of several hundred MB of data, say which before launching: the campaign snapshots the tree before each task.
- The agents never change git state (no add/commit/checkout); after the campaign you push the result yourself (step 6).

## 1. Install (overwrites the kit; keeps your tree and history)
```
cp campaign.py campaign.py.v1 && cp microagent.py microagent.py.v1      # old MAP.md / EVIDENCE.md are moved aside by the campaign itself
unzip -o discver-handoff-campaign.zip
chmod +x stage_evidence.sh launch_campaign.sh
python3 campaign.py --version          # campaign 2.0
```

## 2. Stage the evidence (the agents read all of it; any folder layout works)
```
bash stage_evidence.sh crsbench-nov20 /path/to/the/benchmark/output/folder /path/to/the/full/RESULTS/report.md
bash stage_evidence.sh other-runs /path/to/any/other/run/folders
```
Text files (logs, reports, json, csv) are copied, everything else is listed. `results/latest/` stays as it is.

## 3. Re-run whichever earlier capability tasks (62–69) are not in this tree
Decided from the tree itself (the task's test file is present and passes), so it is right even if `discver/` was just replaced by a
fresh git checkout:
```
for f in redo/*.md; do b=$(basename "$f"); t=$(awk '/^## Acceptance/{a=1} a' "$f" | grep -oE "tests/test_[a-z0-9_]+\.py" | head -1); if [ -f "discver/$t" ] && (cd discver && python -m pytest -q "$t" >/dev/null 2>&1); then echo "skip $b ($t passes)"; else cp "$f" tasks_handoff/ && echo "redo $b"; fi; done
```

## 4. Check the tests, then launch (detached — survives closing the terminal, logging out of lair, switching off your PC)
```
(cd discver && python -m pytest -q tests 2>&1 | tail -3)      # the suite must run (failures are fine, a crash of pytest is not)
bash launch_campaign.sh                                       # verifies the gateway, then starts it in the background
```
The campaign runs on this machine in its own session with hang-ups ignored, so nothing you do on your PC stops it. Put the
`export LITELLM_…` / `AGENT_MODEL` lines at the top of `launch_campaign.sh` if you prefer not to export them by hand.

## 5. While it runs
```
bash launch_campaign.sh status        # every task: PASS / FAIL / RUNNING / pending
tail -f runs/handoff-*.out            # the live log
```
- Gateway outages are handled: the task is restored, the campaign waits for the gateway and re-runs it (no FAIL).
- Machine rebooted or the process killed: `bash launch_campaign.sh resume` (stops any orphaned agent, restores the interrupted task,
  continues). No manual restore steps.
- To stop it yourself: `bash launch_campaign.sh stop` — the running task is restored; `resume` continues later.

## 6. After
```
grep -E "^- [0-9]+_" CAMPAIGN.md | tail -45      # the summary of this run
```
- Any FAIL: re-run those once — `python3 campaign.py --work . --tasks tasks_handoff --only <n>,<n>`.
- Push the result as a branch so coworkers get it from git:
  `cd discver && git checkout -b handoff-$(date +%Y%m%d) && git add -A && git commit -m "discver handoff campaign" && git push -u origin HEAD`
- The deliverable is `discver-handoff.zip` (the whole repository: code, tests, docs, scripts, selftest projects). That is what
  coworkers and the operator get. `docs/HANDOFF.md` inside it is the page to read first.
- First real verification on a run box: `scripts/discver doctor` → `scripts/discver selftest` → a target that worked before, standalone
  → the same through OSS-CRS (operator workflow unchanged) → a benchmark slice. Compare with `docs/EVALUATION.md`.

## If you must hand off before it finishes
Stop it (`kill <pid>`), run the documentation tasks on the current state, hand off, and let the new owner continue:
```
python3 campaign.py --work . --tasks tasks_handoff --only 180,181,182,183,190
python3 campaign.py --work . --tasks tasks_handoff --from <first task number not yet done>     # later, by the new owner
```

## What changed in the kit, and why every earlier campaign came out incremental
The old agent prompt said "One behavioural change… No refactors" and "Edits only under src/ and tests/ — never docs, scripts".
That is why nothing structural or documentation-level ever happened. Kit 2.0 (tested end to end against a fake gateway):
- per-task writable paths (`## Writable` in each task: src, tests, docs, README.md, scripts, docker, selftest …) and per-task turn
  budgets (`max_turns:`); a new language-agnostic agent prompt that allows restructuring when a task asks for it and enforces
  generality (no target names in code, tests or docs), zero configuration and backward compatibility with the operator's workflow;
- an identity-based test gate (no test that passed may fail; tests may not silently disappear) instead of comparing counts;
- crash-proof state: a snapshot on disk per task, `--resume`, `--status`, orphaned-agent cleanup, stale-bytecode purge after restores;
- gateway outages wait and retry instead of failing task after task;
- named outputs for read-only tasks (EVIDENCE.md and MAP.md both reach every later task);
- `discver-handoff.zip` (full repository) at the end.

## The tasks
| # | What the handoff gets |
|---|---|
| 101 | EVIDENCE.md — every run and benchmark log/report read, failures stated as mechanisms, ranked |
| 102 | MAP.md — every module, the main flow, settings, LLM and oracle calls, docs, packaging, an extraction plan |
| 110 | an end-to-end test of the real run with a fake engine, fake LLM and fake oracle — the safety net for everything after |
| 122–129 | the earlier capability tasks that never passed (Java harness compile, hang storms, calibration, input boundaries, boundary harnesses, build from path, C/C++ service shape) |
| 131 | one configuration registry; defaults = intended behaviour; generated configuration reference |
| 132 | one LLM client: backend-correct requests, outcomes, refusals final with fallbacks, structured output, usage per site |
| 133 | the run as an explicit pipeline of phases over one context |
| 134 | one run-report model; reports rewritten after every phase; a REPORT.md a stranger can read |
| 135 | internal deadline with reserve, clean shutdown, reports always written |
| 136 | `discver run --repo <git-url or path>` — any repository, same pipeline as OSS-CRS mode |
| 137 | `discver doctor` — per-language readiness and exact fixes |
| 140–145 | harness discovery by shape; native link recipes; bounded seed screening; target reach + path dictionaries; effort scheduler; directed inputs for unreached code |
| 146 | the bug-hunting swarm under the scheduler: aimed at targets, routed through screening and verification, yield measured per role |
| 147 | knowledge-base guidance: ranking prior, playbook dictionary tokens, hints for directed inputs — with an on/off comparison in every report |
| 150–155 | reproducer prevalidation and dedup (non-reproducing crashes retried with the fuzzing run's settings, kept and reported — never silently dropped); crashes from generated harnesses translated to the project's own harness (155); oracle interface + local oracle (patching outside OSS-CRS); language-agnostic patch candidates; validation loop; "why no patch" + end-to-end patch test |
| 156 | more bug detectors: UndefinedBehaviorSanitizer and (where feasible) MemorySanitizer builds for C/C++, overflow checks for Rust, the race detector for Go, every Jazzer detector on |
| 157 | bugs that do not crash: round-trip, contract and differential property checks in generated harnesses, armed only after they hold on the whole corpus |
| 158 | nothing hidden: reproducible crashes in dependency code reported as dependency bugs; same-signature crashes that look different kept as possibly distinct |
| 159 | build repair: standard fallbacks per build system, then model edits to build files only, before a component is given up |
| 160–162 | phases moved out of the main module; dead code and duplicates removed |
| 163 | every validated patch ships with a regression test that fails before the fix and passes after |
| 170–172 | one toolchain manifest → setup script, standalone image, doctor; slim pinned knowledge base; `discver selftest` with planted-bug projects in six languages |
| 175 | JavaScript/TypeScript support: Jazzer.js fuzzing, discovery, generation, boundaries, crash parsing, patch context, toolchain, doctor, selftest |
| 180–183 | README; operator guide and troubleshooting from evidence; architecture, developer guide, AGENT.md; generated references, evaluation history, cleanup |
| 190 | final verification and docs/HANDOFF.md |
