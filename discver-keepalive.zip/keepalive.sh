#!/usr/bin/env bash
# keepalive.sh — keeps the discver campaign going until it finishes, with nobody watching.
# Every 10 minutes (from your crontab) it checks the campaign in this folder. If it is not running (machine rebooted,
# you disconnected, the process was killed) or it has written nothing for 3 hours (stuck), it resumes it with
# `campaign.py --resume`, which puts the interrupted task back and carries on. A finished run is left alone.
#
#   bash keepalive.sh          turn it on: saves your settings (asks for the LiteLLM key once), checks the gateway,
#                              adds the 10-minute check to your crontab, and resumes the campaign now if it is down
#   bash keepalive.sh status   where the campaign is, whether it is running, whether auto-restart is on
#   bash keepalive.sh off      removes the 10-minute check (a running campaign keeps running)
#   bash keepalive.sh tick     one check (what cron runs)
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$HERE" || exit 1
ENVF="$HOME/campaign.env"
LOG="$HERE/runs/keepalive.log"
TAG="discver-keepalive:$HERE"
STUCK_MIN="${KEEPALIVE_STUCK_MIN:-180}"
mkdir -p runs

say() { echo "$(date '+%F %T') $*" >> "$LOG"; }

load_env() {
    # shellcheck disable=SC1090
    [ -f "$ENVF" ] && . "$ENVF"
    PY="${DISCVER_PY:-$(command -v python3)}"
}

campaign_pid() {   # prints the pid of the live campaign for this folder (or other-host:<name>); fails if none
    local pid="" host=""
    [ -f runs/campaign.pid ] || return 1
    read -r pid host < runs/campaign.pid || true
    [ -n "$pid" ] || return 1
    if [ -n "$host" ] && [ "$host" != "$(uname -n)" ]; then echo "other-host:$host"; return 0; fi
    tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | grep -q "campaign.py" || return 1
    echo "$pid"
}

phase() {   # running | interrupted | finished | (empty: no campaign started here yet)
    "$PY" campaign.py --work . --status 2>/dev/null | sed -nE '1s/^run [^:]+: ([a-z]+).*/\1/p'
}

idle_min() {   # minutes since the campaign last wrote anything under runs/
    local newest
    newest=$(find runs -type f \( -name '*.out' -o -path 'runs/2*/*' \) -printf '%T@\n' 2>/dev/null | sort -n | tail -1)
    [ -n "$newest" ] || { echo 0; return; }
    echo $(( ($(date +%s) - ${newest%.*}) / 60 ))
}

stop_stuck() {   # $1 = pid: stop it gracefully (the campaign restores the task), forcefully if it does not stop
    local pid=$1 i
    say "campaign pid $pid has written nothing for $(idle_min) min — stopping it"
    kill -TERM "$pid" 2>/dev/null
    for i in $(seq 1 24); do kill -0 "$pid" 2>/dev/null || return 0; sleep 5; done
    kill -KILL "$pid" 2>/dev/null; sleep 5
    if kill -0 "$pid" 2>/dev/null; then say "could not stop pid $pid — leaving it"; return 1; fi
    return 0
}

resume() {
    say "resuming (phase was: $1)"
    setsid nohup "$PY" campaign.py --work . --resume >> runs/resume.out 2>&1 < /dev/null 9>&- &
}

tick() {
    load_env
    if command -v flock >/dev/null 2>&1; then exec 9> runs/keepalive.lock; flock -n 9 || exit 0; fi
    local ph pid
    ph="$(phase)"
    { [ -n "$ph" ] && [ "$ph" != "finished" ]; } || exit 0       # nothing started yet, or finished: nothing to do
    if pid="$(campaign_pid)"; then
        case "$pid" in other-host:*) exit 0 ;; esac
        [ "$(idle_min)" -ge "$STUCK_MIN" ] || exit 0             # running and active
        stop_stuck "$pid" || exit 0
        ph="$(phase)"
    fi
    resume "$ph"
}

status() {
    load_env
    "$PY" campaign.py --work . --status 2>/dev/null | awk '
        NR == 1 { print; next }
        { n[$2]++; if ($2 == "RUNNING") now = $1 }
        END { for (k in n) printf "  %-8s %d\n", k, n[k]; if (now) print "  now: " now }'
    local pid
    if pid="$(campaign_pid)"; then
        echo "campaign process: running (pid $pid), last activity $(idle_min) min ago"
    else
        echo "campaign process: NOT running"
    fi
    if crontab -l 2>/dev/null | grep -qF "$TAG"; then echo "auto-restart: on (checks every 10 minutes)"; else echo "auto-restart: off"; fi
    [ -f "$LOG" ] && tail -3 "$LOG"
}

on() {
    local key="${LITELLM_API_KEY:-}"
    if [ -z "$key" ]; then
        read -rsp "LiteLLM key (paste it, then Enter — nothing is shown): " key; echo
    fi
    key="${key%$'\r'}"
    [ -n "$key" ] || { echo "No key entered — nothing changed."; exit 1; }
    (
        umask 077
        {
            echo "export LITELLM_BASE_URL=${LITELLM_BASE_URL:-https://llai-proxy.llan.ll.mit.edu/v1}"
            printf 'export LITELLM_API_KEY=%q\n' "$key"
            echo "export AGENT_MODEL=${AGENT_MODEL:-claude-opus-5-5}"
            if [ -n "${AGENT_CA_BUNDLE:-}" ]; then echo "export AGENT_CA_BUNDLE=$AGENT_CA_BUNDLE"
            else echo "export AGENT_TLS_VERIFY=${AGENT_TLS_VERIFY:-false}"; fi
            echo "export AGENT_REASONING_EFFORT=${AGENT_REASONING_EFFORT:-high}"
            echo "export DISCVER_PY=$(command -v python3)"
            printf 'export PATH=%q\n' "$PATH"
        } > "$ENVF"
    )
    load_env
    echo "Settings saved to $ENVF (only you can read it)."
    echo "Checking the gateway ..."
    "$PY" microagent.py --verify || { echo "Gateway check failed — nothing started. Fix the key/settings, then run: bash keepalive.sh"; exit 1; }

    if { crontab -l 2>/dev/null | grep -vF "$TAG"; echo "*/10 * * * * cd $(printf '%q' "$HERE") && bash keepalive.sh tick >/dev/null 2>&1 # $TAG"; } | crontab - 2>/dev/null; then
        echo "Auto-restart: ON — checked every 10 minutes; survives reboots, disconnects and kills."
    else
        echo "Auto-restart: NOT available (crontab is not allowed for your account). If it stops again, run: bash keepalive.sh tick"
    fi

    local ph pid idle
    ph="$(phase)"
    if pid="$(campaign_pid)" && [[ "$pid" != other-host:* ]]; then
        idle=$(idle_min)
        if [ "$idle" -ge "$STUCK_MIN" ]; then
            echo "The campaign (pid $pid) has written nothing for $((idle / 60)) h — it is stuck. Stopping it and resuming."
            stop_stuck "$pid" || { echo "Could not stop pid $pid. Run: kill -9 $pid   then: bash keepalive.sh"; exit 1; }
            resume "$(phase)"
        else
            echo "The campaign is running (pid $pid, last activity $idle min ago) — leaving it alone."
        fi
    elif [ -z "$ph" ]; then
        echo "No campaign has been started in this folder yet."
    elif [ "$ph" = "finished" ]; then
        echo "The last campaign run has finished — nothing to resume."
    else
        echo "The campaign is not running (state: $ph) — resuming it now."
        resume "$ph"
    fi
    sleep 5
    echo
    status
    echo
    echo "Live log: tail -f runs/resume.out"
}

case "${1:-on}" in
    on) on ;;
    tick) tick ;;
    status) status ;;
    off)
        if { crontab -l 2>/dev/null | grep -vF "$TAG"; } | crontab - 2>/dev/null; then
            echo "Auto-restart: off (a running campaign keeps running)."
        else
            echo "Could not change your crontab."
        fi
        ;;
    *) echo "usage: bash keepalive.sh [on|status|off|tick]"; exit 2 ;;
esac
