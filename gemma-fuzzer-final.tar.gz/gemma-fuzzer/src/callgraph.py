"""
callgraph.py — Call graph for C codebases.

Handles real C patterns:
- Multiline function signatures (return type on different line from name)
- static/inline/extern qualifiers
- Pointer return types
- Macro-heavy code (libxml2, OpenSSL style)

Strategy: instead of one giant regex, we use a two-pass approach:
1. Find opening braces at column 0 or after ), trace back to find func name
2. Scan function bodies for calls to other known functions
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("gemma-fuzzer.callgraph")


@dataclass
class FunctionDef:
    name: str
    file: str
    line: int
    signature: str = ""
    called_by: list[str] = field(default_factory=list)
    calls: list[str] = field(default_factory=list)
    body: str = ""
    body_start: int = 0  # char offset in file
    body_end: int = 0


@dataclass
class CallGraph:
    functions: dict[str, FunctionDef] = field(default_factory=dict)
    files: dict[str, list[str]] = field(default_factory=dict)

    def get_callers(self, func_name: str, depth: int = 3) -> list[list[str]]:
        paths: list[list[str]] = []
        self._trace_callers(func_name, [], paths, depth)
        return paths

    def _trace_callers(self, func, current, all_paths, depth):
        if depth <= 0 or func in current:
            return
        path = current + [func]
        fdef = self.functions.get(func)
        if not fdef or not fdef.called_by:
            all_paths.append(list(reversed(path)))
            return
        for caller in fdef.called_by[:5]:
            self._trace_callers(caller, path, all_paths, depth - 1)

    def get_path_to(self, entry, target, max_depth=6):
        visited = set()
        return self._dfs(entry, target, visited, max_depth)

    def _dfs(self, cur, target, visited, depth):
        if depth <= 0 or cur in visited:
            return None
        if cur == target:
            return [cur]
        visited.add(cur)
        fdef = self.functions.get(cur)
        if not fdef:
            return None
        for callee in fdef.calls:
            p = self._dfs(callee, target, visited, depth - 1)
            if p:
                return [cur] + p
        return None

    def get_function_context(self, func_name: str, src_dir: str) -> str:
        fdef = self.functions.get(func_name)
        if not fdef:
            return ""

        context = f"// === {func_name} in {fdef.file}:{fdef.line} ===\n"

        # Get function body from file
        try:
            full_path = Path(src_dir) / fdef.file
            content = full_path.read_text(errors="replace")
            if fdef.body:
                context += fdef.body + "\n"
            elif fdef.body_start > 0:
                end = min(fdef.body_end, fdef.body_start + 3000)
                context += content[fdef.body_start:end] + "\n"
            else:
                lines = content.split("\n")
                start = max(0, fdef.line - 1)
                end = min(len(lines), start + 80)
                context += "\n".join(lines[start:end]) + "\n"
        except Exception:
            if fdef.body:
                context += fdef.body + "\n"

        # Add caller context
        for caller_name in fdef.called_by[:3]:
            caller = self.functions.get(caller_name)
            if not caller:
                continue
            context += f"\n// === Called by {caller_name} in {caller.file}:{caller.line} ===\n"
            try:
                full_path = Path(src_dir) / caller.file
                content = full_path.read_text(errors="replace")
                idx = content.find(func_name + "(")
                if idx < 0:
                    idx = content.find(func_name)
                if idx >= 0:
                    start = max(0, idx - 400)
                    end = min(len(content), idx + 400)
                    context += content[start:end] + "\n"
            except Exception:
                pass

        return context

    def to_summary(self) -> str:
        lines = [f"Call graph: {len(self.functions)} functions in {len(self.files)} files\n"]
        by_callers = sorted(
            self.functions.values(),
            key=lambda f: len(f.called_by),
            reverse=True,
        )
        lines.append("Most-called functions (likely important internal APIs):")
        for fdef in by_callers[:20]:
            if fdef.called_by:
                lines.append(
                    f"  {fdef.name} ({fdef.file}:{fdef.line}) "
                    f"← called by {len(fdef.called_by)}, calls→ {len(fdef.calls)}"
                )
        return "\n".join(lines)


def build_callgraph(src_dir: str) -> CallGraph:
    """Build call graph. Tries universal-ctags JSON first, falls back to regex."""
    graph = CallGraph()
    src_path = Path(src_dir)

    logger.info("[callgraph] Scanning %s...", src_dir)

    # Try universal-ctags first (much more accurate)
    ctags_bin = _find_uctags()
    if ctags_bin:
        logger.info("[callgraph] Using universal-ctags: %s", ctags_bin)
        _build_with_uctags(ctags_bin, src_path, graph)
    
    # Fallback to regex if ctags found nothing
    if not graph.functions:
        logger.info("[callgraph] Falling back to regex-based extraction...")
        for fpath in src_path.rglob("*.c"):
            fstr = str(fpath).lower()
            if any(s in fstr for s in [".git", "/test", "example", "python", "CMakeFiles"]):
                continue
            try:
                content = fpath.read_text(errors="replace")
                rel_path = str(fpath.relative_to(src_path))
            except Exception:
                continue

            funcs = _extract_functions(content, rel_path)
            for fdef in funcs:
                if fdef.name not in graph.functions:
                    graph.functions[fdef.name] = fdef
                    graph.files.setdefault(rel_path, []).append(fdef.name)

    logger.info("[callgraph] Found %d functions in %d files.",
                len(graph.functions), len(graph.files))

    # Phase 2: Extract call relationships
    func_names = set(graph.functions.keys())
    if len(func_names) > 5:  # sanity check
        # Build a combined regex for all function names
        # Split into chunks to avoid regex too large
        name_list = sorted(func_names, key=len, reverse=True)
        chunk_size = 200
        for i in range(0, len(name_list), chunk_size):
            chunk = name_list[i:i + chunk_size]
            pattern = re.compile(
                r'\b(' + '|'.join(re.escape(n) for n in chunk) + r')\s*\('
            )
            for fpath in src_path.rglob("*.c"):
                fstr = str(fpath).lower()
                if any(s in fstr for s in [".git", "/test", "example", "python"]):
                    continue
                try:
                    rel_path = str(fpath.relative_to(src_path))
                except Exception:
                    continue

                # For each function defined in this file, check its body for calls
                file_funcs = graph.files.get(rel_path, [])
                for fname in file_funcs:
                    fdef = graph.functions.get(fname)
                    if not fdef or not fdef.body:
                        continue
                    for m in pattern.finditer(fdef.body):
                        callee = m.group(1)
                        if callee != fname and callee in func_names:
                            if callee not in fdef.calls:
                                fdef.calls.append(callee)
                            callee_def = graph.functions.get(callee)
                            if callee_def and fname not in callee_def.called_by:
                                callee_def.called_by.append(fname)

    logger.info("[callgraph] Call relationships extracted.")
    logger.info(graph.to_summary())
    return graph


def _find_uctags() -> str | None:
    """Find universal-ctags binary."""
    for name in ["uctags", "ctags"]:
        path = shutil.which(name)
        if not path:
            continue
        try:
            result = subprocess.run(
                [path, "--version"], capture_output=True, text=True, timeout=5,
            )
            if "Universal Ctags" in result.stdout:
                return path
        except Exception:
            continue
    return None


def _build_with_uctags(ctags_bin: str, src_path: Path, graph: CallGraph) -> None:
    """Use universal-ctags JSON output for accurate function extraction."""
    try:
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as tmp:
            tags_file = tmp.name

        result = subprocess.run(
            [
                ctags_bin,
                "-R",
                "--languages=C,C++",
                "--kinds-C=f",
                "--kinds-C++=f",
                "--fields=+neS",
                "--output-format=json",
                "-f", tags_file,
                str(src_path),
            ],
            capture_output=True, text=True, timeout=60,
        )

        if result.returncode != 0:
            logger.warning("[callgraph] ctags failed: %s", result.stderr[:200])
            return

        with open(tags_file) as f:
            for line in f:
                line = line.strip()
                if not line or not line.startswith("{"):
                    continue
                try:
                    tag = json.loads(line)
                    name = tag.get("name", "")
                    path = tag.get("path", "")
                    line_no = tag.get("line", 0)
                    sig = tag.get("signature", "")
                    end_line = tag.get("end", 0)

                    if not name or not path or len(name) < 2:
                        continue

                    try:
                        rel_path = str(Path(path).relative_to(src_path))
                    except ValueError:
                        rel_path = path

                    # Skip test/example files
                    if any(s in rel_path.lower() for s in ["test", "example", "python"]):
                        continue

                    # Read function body from source
                    body = ""
                    try:
                        full_content = Path(path).read_text(errors="replace")
                        lines = full_content.split("\n")
                        start = max(0, line_no - 1)
                        end = end_line if end_line > line_no else min(len(lines), start + 100)
                        body = "\n".join(lines[start:end])
                        if len(body) > 3000:
                            body = body[:3000]
                    except Exception:
                        pass

                    fdef = FunctionDef(
                        name=name, file=rel_path, line=line_no,
                        signature=sig, body=body,
                    )
                    if name not in graph.functions:
                        graph.functions[name] = fdef
                        graph.files.setdefault(rel_path, []).append(name)
                except json.JSONDecodeError:
                    continue

        logger.info("[callgraph] ctags found %d functions.", len(graph.functions))

    except subprocess.TimeoutExpired:
        logger.warning("[callgraph] ctags timed out.")
    except Exception as exc:
        logger.error("[callgraph] ctags error: %s", exc)
    finally:
        try:
            os.unlink(tags_file)
        except Exception:
            pass


def _extract_functions(content: str, filename: str) -> list[FunctionDef]:
    """Extract function definitions from C source code.
    
    Strategy: find opening braces that start a function body, then trace
    backwards to find the function name and signature. This handles:
    - Return type on separate line from function name
    - Multi-line parameter lists
    - static/inline/extern qualifiers
    - Pointer return types with *
    """
    functions: list[FunctionDef] = []
    lines = content.split("\n")

    # C identifier pattern
    IDENT = re.compile(r'^[a-zA-Z_]\w*$')

    # Skip these — they're keywords, not function names
    SKIP = {
        "if", "else", "while", "for", "do", "switch", "case", "return",
        "sizeof", "typeof", "goto", "break", "continue", "default",
        "struct", "union", "enum", "typedef",
    }

    i = 0
    while i < len(lines):
        line = lines[i].rstrip()

        # Look for lines that contain ) followed by { (possibly with space)
        # or a standalone { on the next line after a )
        opens_func = False
        sig_end_line = -1

        if re.search(r'\)\s*\{', line):
            # ) { on same line
            opens_func = True
            sig_end_line = i
        elif line.strip() == '{' and i > 0:
            # { on its own line — check if previous line(s) end with )
            for back in range(i - 1, max(i - 4, -1), -1):
                prev = lines[back].rstrip()
                if prev.endswith(')'):
                    opens_func = True
                    sig_end_line = back
                    break
                elif prev.endswith(',') or prev.endswith('('):
                    continue  # multiline params
                else:
                    break

        if not opens_func or sig_end_line < 0:
            i += 1
            continue

        # Trace back from sig_end_line to find the opening ( of the params
        # and the function name before it
        sig_text = ""
        paren_count = 0
        found_open_paren = False
        start_line = sig_end_line

        for back in range(sig_end_line, max(sig_end_line - 10, -1), -1):
            l = lines[back].rstrip()
            sig_text = l + " " + sig_text

            for ch in l:
                if ch == ')':
                    paren_count += 1
                elif ch == '(':
                    paren_count -= 1
                    if paren_count <= 0:
                        found_open_paren = True

            if found_open_paren:
                start_line = back
                # Go back 1-2 more lines for return type
                for extra in range(1, 3):
                    if back - extra >= 0:
                        prev = lines[back - extra].rstrip()
                        # If it looks like a type/qualifier, include it
                        if prev and not prev.endswith(';') and not prev.endswith('}') and not prev.startswith('#') and not prev.startswith('//') and not prev.startswith('/*'):
                            sig_text = prev + " " + sig_text
                            start_line = back - extra
                        else:
                            break
                break

        if not found_open_paren:
            i += 1
            continue

        # Now extract the function name from sig_text
        # Pattern: [qualifiers] [return_type] func_name ( ...
        # Find the last identifier before the first (
        paren_idx = sig_text.find('(')
        if paren_idx < 0:
            i += 1
            continue

        before_paren = sig_text[:paren_idx].strip()
        # Split by whitespace and *, take the last token that's an identifier
        tokens = re.split(r'[\s\*]+', before_paren)
        func_name = None
        for t in reversed(tokens):
            t = t.strip()
            if IDENT.match(t) and t not in SKIP and len(t) >= 2:
                func_name = t
                break

        if not func_name:
            i += 1
            continue

        # Extract function body
        brace_start = content.find('{', sum(len(lines[j]) + 1 for j in range(i)))
        if line.strip() == '{':
            # The { is on line i
            char_offset = sum(len(lines[j]) + 1 for j in range(i))
            brace_start = content.find('{', char_offset)
        else:
            # The { is on sig_end_line
            char_offset = sum(len(lines[j]) + 1 for j in range(sig_end_line))
            brace_start = content.find('{', char_offset)

        if brace_start < 0:
            i += 1
            continue

        body_end = _find_matching_brace(content, brace_start)

        # Get body text (cap at 3000 chars for memory)
        sig_start_offset = sum(len(lines[j]) + 1 for j in range(start_line))
        body_text = content[sig_start_offset:min(body_end, sig_start_offset + 3000)]

        fdef = FunctionDef(
            name=func_name,
            file=filename,
            line=start_line + 1,
            signature=before_paren.strip(),
            body=body_text,
            body_start=sig_start_offset,
            body_end=body_end,
        )
        functions.append(fdef)

        # Skip past the function body
        body_end_line = content[:body_end].count('\n')
        i = body_end_line + 1
        continue

    return functions


def _find_matching_brace(content: str, open_pos: int) -> int:
    """Find the matching closing brace."""
    count = 0
    for i in range(open_pos, min(len(content), open_pos + 50000)):
        if content[i] == '{':
            count += 1
        elif content[i] == '}':
            count -= 1
            if count == 0:
                return i + 1
    return min(len(content), open_pos + 5000)
