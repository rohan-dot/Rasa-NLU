# oss-crs/asan-builder.Dockerfile
# Compiles the target project with AddressSanitizer + LibFuzzer instrumentation.

ARG target_base_image
FROM ${target_base_image}

# Install libCRS (provided by OSS-CRS as a build context)
COPY --from=libcrs . /opt/libCRS
RUN /opt/libCRS/install.sh

# Copy our compile script
COPY bin/compile_target /usr/local/bin/compile_target
RUN chmod +x /usr/local/bin/compile_target

CMD ["compile_target"]
