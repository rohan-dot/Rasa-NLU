# oss-crs/docker-compose/fuzzer.Dockerfile
# Runtime container for gemma-fuzzer.
# Runs LibFuzzer + LLM-guided crash analysis and seed generation.

ARG target_base_image
FROM ${target_base_image}

# Install libCRS
COPY --from=libcrs . /opt/libCRS
RUN /opt/libCRS/install.sh

# System deps for our Python CRS code
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3 python3-pip python3-venv \
    && rm -rf /var/lib/apt/lists/*

# Create venv and install Python deps
RUN python3 -m venv /opt/gemma-fuzzer/venv
COPY src/requirements.txt /opt/gemma-fuzzer/requirements.txt
RUN /opt/gemma-fuzzer/venv/bin/pip install --no-cache-dir \
    -r /opt/gemma-fuzzer/requirements.txt

# Copy CRS source
COPY src/ /opt/gemma-fuzzer/src/

# Copy entry script
COPY oss-crs/docker-compose/run-fuzzer.sh /opt/gemma-fuzzer/run-fuzzer.sh
RUN chmod +x /opt/gemma-fuzzer/run-fuzzer.sh

CMD ["/opt/gemma-fuzzer/run-fuzzer.sh"]
