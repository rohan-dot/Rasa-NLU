// oss-crs/build.hcl
// Builds the gemma-fuzzer base image during `oss-crs prepare`.

group "default" {
  targets = ["gemma-fuzzer-base"]
}

target "gemma-fuzzer-base" {
  dockerfile = "oss-crs/docker-compose/fuzzer.Dockerfile"
  context    = "."
  tags       = ["gemma-fuzzer-base:latest"]
}
