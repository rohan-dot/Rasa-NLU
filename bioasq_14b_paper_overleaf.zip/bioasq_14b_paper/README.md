# BioASQ Task 14b — Working Notes Paper (Overleaf bundle)

## What's in this zip

- `main.tex` — the paper, written against the CEUR-ART one-column
  document class (`\documentclass[1col]{ceurart}`). Now reflects
  Gemma 4 31B Dense for the Finalcorrected system and uses
  `\bibliography{refs}` against the bib file below.
- `refs.bib` — **all 12 references verified against primary sources**
  (DOI / arXiv / publisher pages, see "Verification log" below).
- `README.md` — this file.

## How to compile on Overleaf

1. New Project → Upload Project → upload this zip.
2. Overleaf does not ship `ceurart.cls` by default. Get the class
   from CEUR-WS (https://ceur-ws.org → "Author Templates") or
   CTAN (https://ctan.org/pkg/ceurart). Drop `ceurart.cls`,
   `ceurart.bst`, and the logo files into the project root.
3. Easier path: in the Overleaf Template Gallery, search
   "CEUR-ART" or "CLEF Working Notes", clone any recent template,
   and paste `main.tex` + `refs.bib` into it. The class will
   already be there.
4. Compiler: pdfLaTeX (or LuaLaTeX). Run twice so BibTeX picks up
   the .bib citations.

## Verification log — all references confirmed real

| Key | Source | How verified |
|-----|--------|--------------|
| `tsatsaronis2015bioasq` | BMC Bioinformatics 16:138 (2015), DOI 10.1186/s12859-015-0564-6 | DOI + PubMed + Springer Nature |
| `nentidis2026bioasq14` | Springer LNCS, DOI 10.1007/978-3-032-21321-1_42 | Springer Nature link |
| `balikas2013evaluation` | BioASQ Deliverable D4.1 (2013) | Referenced throughout the BioASQ technical documentation you uploaded in this project |
| `cormack2009rrf` | SIGIR '09, pp. 758–759, DOI 10.1145/1571941.1572114 | ACM DL + DBLP |
| `lee2020biobert` | Bioinformatics 36(4):1234–1240, DOI 10.1093/bioinformatics/btz682 | Oxford Academic + PubMed + GitHub |
| `gu2021pubmedbert` | ACM TOCH 3(1):1–23, DOI 10.1145/3458754 | ACM DL |
| `yao2023react` | ICLR 2023, arXiv:2210.03629 | Official Princeton author page + arXiv + GitHub bibtex |
| `schick2023toolformer` | NeurIPS 2023, arXiv:2302.04761 | arXiv + OpenReview |
| `kwon2023vllm` | SOSP '23, DOI 10.1145/3600006.3613165, arXiv:2309.06180 | ACM DL + arXiv |
| `gemma3report` | arXiv:2503.19786 (March 2025) | arXiv + DOI 10.48550/arXiv.2503.19786 |
| `gemma4blog` | Google blog, April 2, 2026 | Verified live at blog.google |
| `gemma4modelcard` | Hugging Face google/gemma-4-31B | Verified live at huggingface.co |

## What was removed (was hallucinated before)

- ❌ `deka2022spubmedbert` — The Deka 2022 paper (J. Data Intelligence 3(4)) is real,
  but it does NOT introduce the `pritamdeka/S-PubMedBert-MS-MARCO` model. That model
  is a community fine-tune on HuggingFace with no formal paper. The earlier draft
  cited the Deka paper for a relationship that does not exist. The paper now describes
  the embedding model in prose and cites only the underlying PubMedBERT paper.

## What was fixed

- `yao2022react` → `yao2023react`. The ReAct paper was published at ICLR 2023, not 2022
  (the arXiv preprint dates from October 2022, but the venue year is 2023).
- All references to "Gemma 3 27B" for the Finalcorrected system are now "Gemma 4 31B Dense",
  matching the actual model used (released April 2, 2026).

## Things you still need to fill in before submission

1. **ORCID** in the `\author` block (currently a placeholder).
2. **Affiliation line** — currently "MIT Lincoln Laboratory, Lexington, MA, USA".
3. **Distribution statement** in `\begin{acknowledgments}` — placeholder text;
   replace with whatever your contracts office requires.
4. **Pipeline figure & phase-gap bar chart** — both drawn natively in
   TikZ/pgfplots, no external image files needed. Recompile if you
   tweak the styling.
5. **Sanity-check the batch coverage** — paper says you submitted Phase A+ in
   batches 2-4 and Phase B in batches 1, 3, 4. Confirm against your submission log.

## License

CEUR-ART working notes are published under CC BY 4.0 — the boilerplate is already
in `main.tex`.
