# Task 00 — map the code and the evidence (read-only)

## Map
This task makes NO edits. Its finish() summary becomes MAP.md and is given to every later task, so make it precise:
file:line for everything, nothing from memory.

## Study first
Results root (grep, then read only the matching lines):
- `grep -nE "FINAL RESULTS|run health|\[(DEAD|WEAK|HEALTHY)\]|SATURATED|coverage never|peak coverage|LLM-generated seeds|patch-turn|llm-call|timed out|invalid JSON|build oracle path|build_ok|SIDECAR|test_patch|apply_edit|UNVALIDATED"` over `orchestrator.log` (root=results).
- read `patches/patch_index.json` and `health.json` in full; read `report_run_*.md` lines 1–200.
Repo (root=repo), grep then read the matching functions:
- fuzzer launch: `jazzer|-fork|max_total_time|artifact_prefix|keep_going|ignore_crashes|run_fuzzer|runs/`
- seeds: `seed|corpus|pb_seeds|DISCVER_WIRE_SEEDS`
- stats / health: `exec/s|execs|cov:|HEALTHY|WEAK|DEAD|SATURATED|peak coverage|liveness`
- patch loop: `json\.loads|parse|apply_edit|test_patch|read_source|max_iter|attempts|root_cause|static-|patch-turn|llm-call`
- oracle / sidecar (do-not-touch zone): `_get_crash_signature|apply-patch-build|run-pov|run-test|SIDECAR|ContainerPatchBuilder`
- the LLM client used by the patch loop and by seed generation (shared or separate?)
Then `run`: `python -m py_compile src/*.py && python -m pytest -q tests 2>&1 | tail -15` (baseline; do not fix anything).

## Deliverable (finish summary — this exact structure)
```
CODE MAP
fuzzer launch:      <file:line of the function that builds the fuzzer command; is it in src/ or an external script? exact flags it passes>
stats parsing:      <file:line that parses exec/cov lines; where exec rate is computed>
health checker:     <file:line that decides DEAD/WEAK/HEALTHY and emits the SATURATED verdict>
seeds:              <file:line generating LLM seeds; file:line writing them to a corpus dir; which dir the runner reads>
harness selection:  <file:line choosing primary vs background harnesses>
patch loop:         <file:line of the agent loop; prompt builder; reply parser (the json.loads/regex line); what happens on parse failure; attempts counter; max iterations; static-* handling; what fills root_cause>
LLM client:         <file:line; shared between patch loop and seeds? timeouts/max_tokens>
sidecar/oracle:     <file:line of ContainerPatchBuilder/sidecar calls and crash_dedup._get_crash_signature>  (DO NOT TOUCH)
dead/duplicate paths: <any second implementation of a stage that is NOT what the orchestrator calls>
TESTS
baseline:           <exact last lines of pytest: N passed / N failed, names of pre-existing failures>
test style:         <pytest? fixtures? how existing tests fake the LLM/fuzzer, with file:line to copy>
EVIDENCE
<one line per harness from the health block: execs, cov a→b, verdict>
<one line per patch_index entry: crash_id, attempts, test_calls, reason>
<[patch-turn] / [llm-call] lines present? yes/no with counts>
```
