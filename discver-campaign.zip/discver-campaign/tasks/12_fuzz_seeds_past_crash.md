# Task 12 — seeds that get PAST the known shallow crash and reach the primary harness (F2)

## Goal
181 LLM seeds were generated, yet the primary harness's corpus went 0→4 and every input crashes at the front door
(getCnFromDn on empty/CN-less input). Make seeds for the primary harness (a) include well-formed inputs that do not
trigger the known crash — for this target, DN strings that contain a `CN=` component plus other well-formed variants —
(b) exclude seeds that reproduce the known crash, with a logged reason, and (c) land in the directory the runner actually
reads before launch. Log the count per harness; zero is loud with the specific reason.

## Study first
- buttercup: `grep -rnE "def .*seed|corpus|write_bytes|open\(" seed-gen/` → how seeds are produced per harness and written to the corpus; file:line.
- fuzzing-brain: `grep -rnE "seed|corpus" --include=*.py -l` then grep inside the top hits for the function that writes seeds for a harness.
- repo: MAP.md "seeds" + "harness selection"; read the seed writer and the runner's corpus-dir argument; confirm they agree.

## Change (src/)
- Seed generation for the primary harness: ensure the prompt/property space yields CN-bearing DNs and other well-formed variants.
- Seed filter: before writing, run each seed through the known-crash check available in the repo (the PoV replay/crash
  reproduction helper used elsewhere — reuse it, do not duplicate it); exclude reproducers with reason
  `reproduces the known shallow crash; would not get past the front door`.
- Wiring: write to the exact corpus dir the runner reads (from MAP.md); log `harness <name>: <n> seeds wired, <m> excluded (<reasons>)`;
  when n == 0 log a WARNING with the reason (no seeds generated / all excluded / dir mismatch).

## Tests to add (tests/test_seeds_past_crash.py)
- with a fake known-crash check (empty input → crash), a set of seeds [b"", b"CN=agent1,O=DISA", b"O=x"] wires only the
  non-reproducing ones and logs the exclusion reason and counts.
- all seeds excluded → the WARNING names the reason; no silent zero.
- the seeds are written into the same directory the runner is launched with (assert path equality in a fake run).

## Acceptance
```
python -m pytest -q tests/test_seeds_past_crash.py
```

## Do not touch
crash_dedup._get_crash_signature (call it, do not change it); sidecar; anything outside src/ and tests/.
