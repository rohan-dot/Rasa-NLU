# Task 13 — probe, then a deep phase with Jazzer keep-going past the known crash (F1 — the change that decides the next run)

## Goal
The primary harness is SATURATED: every execution hits the same throw and the process restarts (~300 execs/run).
Add a two-phase launch: a short PROBE exactly as today; if the probe shows saturation, relaunch for the rest of the budget
with Jazzer keep-going so the known finding is deduplicated by stack-trace hash and fuzzing CONTINUES; record new distinct
findings as leads; at the end replay the deep-phase corpus through the NORMAL harness, one input per run, so any crashing
input becomes an ordinary crash artifact in the unchanged dedup/PoV pipeline. Decision and exact flag logged at launch. No flags for the operator.

## Study first
- jazzer (docs root): `grep -rnE "keep_going|DEDUP_TOKEN|ignore_crashes" docs/ *.md` → the exact flag spelling, env-var form (JAZZER_KEEP_GOING), and what is printed per finding.
- buttercup: `grep -rnE "keep_going|ignore_crashes|-fork|DEDUP_TOKEN|dedup" fuzzer/` ; fuzzing-brain: same pattern; atlantis: same pattern under the Java CRS. Read each hit's function; note file:line and how they re-launch.
- repo: MAP.md "fuzzer launch" (is the command built in src/ or passed to an external run script?), "stats parsing", "health checker", and the crash artifact/replay path.

## Change (src/)
- Probe: run each harness as today for PROBE_SECONDS (constant, e.g. 120). Saturation = (execs < 5000 and crashes ≥ 1) or crashes/execs ≥ 0.5.
  Log: `harness <name>: probe <execs> execs, <crashes> crash(es), cov <c> — SATURATED → deep phase (keep_going=<N>)` or `… — not saturated, continuing normally`.
- Deep phase: relaunch with `--keep_going=1000` placed BEFORE the corpus dirs (Jazzer flags are `--`, libFuzzer flags are `-`), same corpus and seed
  dirs, remaining budget. If the driver does not forward flags, use the `JAZZER_KEEP_GOING` environment form; log the exact form used.
  libFuzzer fork-mode alternative if the launch must stay in fork mode: `-fork=N -ignore_crashes=1`.
- Leads: parse `== Java Exception:` blocks + `DEDUP_TOKEN: <hex>` from the deep-phase output into distinct leads (repeats collapse); leads are UNVERIFIED until replay.
- Replay: for each input in the deep-phase corpus, run the normal harness on that single input; non-zero exit → hand the input to the EXISTING crash handler
  (same path a normal crash artifact takes). Never batch inputs (a batched replay stops at the first — known — crash).
- Health: verdict text `saturated by <sink>; continuing past it — coverage <a>→<b>`; HEALTHY only if deep-phase coverage grew; the block shows both phases.

## Tests to add (tests/test_keep_going.py) — fake runner, no Jazzer
- probe stats 299 execs / 1 crash → deep phase launched; argv contains `--keep_going=1000` before the corpus dir and the same corpus/seed dirs; the SATURATED log line is present.
- healthy probe (2M execs, 0 crashes) → no deep phase; one launch only.
- a deep-phase log with two different DEDUP_TOKENs yields two leads; the same token twice yields one.
- replay: corpus {ok, empty}; fake harness crashes on `empty` → the existing crash handler is called exactly once with that input.
- health block: flat deep-phase coverage → still WEAK with "coverage stayed"; grown coverage → HEALTHY naming the sink.

## Acceptance
```
python -m pytest -q tests/test_keep_going.py
```

## Do not touch
crash_dedup._get_crash_signature and the sidecar; the normal (probe) launch path must stay byte-for-byte what it is today; anything outside src/ and tests/.
