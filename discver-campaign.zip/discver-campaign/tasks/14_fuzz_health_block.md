# Task 14 — truthful two-phase health block and startup threshold log (F5)

## Goal
The health block must show, per harness: probe execs/crashes/cov, deep-phase execs/cov growth (if task 13 landed), leads,
replay crashes, and a verdict that names the sink being fuzzed past. HEALTHY only when coverage actually grew. All
thresholds (probe seconds, saturation limits, keep_going N, no-op budget) logged once at startup. Verdicts never more lenient than today.

## Study first
- repo: MAP.md "health checker"; `grep -nE "WARNING: \[|Overall:|SATURATED|peak coverage|liveness" src/` and read the renderer.
- results: `grep -nA3 "run health" orchestrator.log` to see today's exact format — keep it recognisable (same `[VERDICT] name` header).

## Change (src/)
- Extend the renderer with the two-phase fields when present; keep today's single-phase output for harnesses that never entered a deep phase.
- One startup INFO line: `fuzz thresholds: probe=<s>s saturated_if_execs<<n>&crash>=1 or crash_rate>=<r>; keep_going=<N>; noop_if_flat_for>=<s>s or >=<execs>`.

## Tests to add (tests/test_health_block.py)
- single-phase harness renders exactly today's shape (snapshot against a string built from the current code's output for a fake harness).
- two-phase harness renders probe + deep lines and the sink in the verdict; flat deep coverage → WEAK; grown → HEALTHY.
- startup threshold line present once.

## Acceptance
```
python -m pytest -q tests/test_health_block.py
```

## Do not touch
Oracle/sidecar; anything outside src/ and tests/.
