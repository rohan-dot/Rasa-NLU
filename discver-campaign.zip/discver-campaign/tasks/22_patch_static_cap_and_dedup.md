# Task 22 — static findings capped and emitted UNVALIDATED; one bug patched once (P7 + P8)

## Goal
Five `static-*` findings (no PoV) burned 15 iterations each and can never be validated by PoV replay. Give them a
build+tests-only path capped at 2 iterations, emitted UNVALIDATED with the label "no reproducer" — never "validated".
The same sink (X509Utils.getCnFromDn) appeared once per harness and was patched twice; the same unreproduced input was
listed twice. Dedup by sink location across harnesses before patching, and report each unreproduced input once.

## Study first
- buttercup: `grep -rnE "dedup|unique|signature|same.*(sink|crash)" patcher/ orchestrator/` → how they avoid patching one bug twice; file:line.
- repo: MAP.md "patch loop" (static-* handling, iteration cap) and the dedup summary code that lists confirmed/unreproduced crashes.

## Change (src/)
- static-* findings: MAX_STATIC_ITERS = 2; validation = build + tests only; outcome UNVALIDATED "no reproducer"; never test_calls=0 silently — reason states "no PoV; build+tests path".
- Cross-harness dedup: key = (file, line, exception) or the existing crash signature; patch once; the second harness's record points at the first's patch.
- Unreproduced inputs: dedup by hash in the final report.

## Tests to add (tests/test_static_cap_and_dedup.py)
- a static-* finding stops after 2 iterations with the UNVALIDATED label and reason.
- two findings with the same sink from two harnesses produce one patch attempt and one cross-reference.
- two identical unreproduced hashes appear once in the report.

## Acceptance
```
python -m pytest -q tests/test_static_cap_and_dedup.py
```

## Do not touch
crash_dedup._get_crash_signature (use it); sidecar; anything outside src/ and tests/.
