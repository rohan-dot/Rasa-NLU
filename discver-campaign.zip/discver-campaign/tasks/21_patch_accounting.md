# Task 21 — accounting that makes the next run self-explaining (P2)

## Goal
patch_index.json entries say only attempts=15, test_calls=0, root_cause="". Add per-finding `parse_failures`,
`read_only_turns`, `tool_histogram` (e.g. {"read_source": 9, "apply_edit": 0}), `last_parse_error`; make the reason string carry
numbers (`no validated patch: 15 iters, 12 parse failures, 0 test calls; last parse error: …`); fill `root_cause` from the RCA
step, or make the reason say why it is empty.

## Study first
- repo: MAP.md "patch loop" — where patch_index entries are built; the reliability/telemetry logger; what the RCA step returns.

## Change (src/)
- Counters incremented in the loop (hook into task 20's parse_action results if present; otherwise count at the existing parse site).
- Entry builder writes the new fields; reason string format as above; root_cause from RCA or reason explains.

## Tests to add (tests/test_patch_accounting.py)
- a scripted run with 3 parse failures and 4 read-only turns yields those counters, the histogram, and a reason string containing "3 parse failures".
- root_cause is non-empty after a fake RCA reply; when RCA returns nothing the reason says "root cause unavailable: <why>".

## Acceptance
```
python -m pytest -q tests/test_patch_accounting.py
```

## Do not touch
Oracle/sidecar; anything outside src/ and tests/.
