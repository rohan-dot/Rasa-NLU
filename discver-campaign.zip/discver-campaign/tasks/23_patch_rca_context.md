# Task 23 — root-cause context in the patch brief (P4)

## Goal
The brief the patch agent receives carries little more than the sink location. Thread in the full stack trace, a source slice
of about ±60 lines around the sink, the PoV path, and the harness name; record the RCA output as root_cause.

## Study first
- buttercup: `grep -rnE "stack|trace|snippet|slice|context|function_body|program_model" patcher/ program-model/` → how source context reaches the agent; file:line.
- atlantis (patch CRS dir): `grep -rnE "stack|trace|context|snippet|slice" --include=*.py` → same.
- repo: MAP.md "patch loop" — the brief builder (`_crash_brief` or equivalent) and the dedup record fields available (trace file path, PoV path).

## Change (src/)
- Brief builder: include trace (from the crash's .txt artifact), the source slice (read from the scratch copy, bounded), PoV path, harness; keep the whole brief under a size cap and say what was truncated.
- RCA step output stored as root_cause.

## Tests to add (tests/test_rca_context.py)
- given a fake crash record with a trace file and a source file, the brief contains the exception line, the ±60-line slice boundaries, and the PoV path; a huge trace is truncated with a note.

## Acceptance
```
python -m pytest -q tests/test_rca_context.py
```

## Do not touch
Oracle/sidecar; anything outside src/ and tests/.
