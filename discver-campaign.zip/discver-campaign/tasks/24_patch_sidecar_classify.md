# Task 24 — sidecar build observability and failure classification (P3)

## Goal
When test_patch is finally reached, a failing build must be understood from the log alone: log the exact sidecar command,
exit code and a stderr tail; classify failures (`patch_apply_failed`, `compile_error`, `harness_not_produced`, `wrong_src_layout`,
`pov_still_crashes`, `tests_failed`); fail fast on build_ok=False within 2 turns with the classification in the reason.

## Study first
- buttercup: `grep -rnE "returncode|stderr|build|compile|apply" patcher/` → how build failures are classified and fed back; file:line.
- repo: MAP.md "sidecar/oracle" — read ONLY to learn the call sites; the wiring itself is not changed. Find where its result is consumed by the patch loop.

## Change (src/)
- Around (not inside) the sidecar calls: log command/exit/stderr tail; classify from stderr patterns; surface the classification in patch_index reason and in the per-turn log; the loop stops a finding after 2 consecutive build failures.

## Tests to add (tests/test_sidecar_classify.py)
- fake sidecar results with javac error text → compile_error; "does not apply" → patch_apply_failed; missing harness binary → harness_not_produced; PoV exit non-zero after build → pov_still_crashes.
- two consecutive build failures → the finding stops with the classification in its reason.

## Acceptance
```
python -m pytest -q tests/test_sidecar_classify.py
```

## Do not touch
The sidecar invocation itself (apply-patch-build / run-pov / run-test) and crash_dedup._get_crash_signature; anything outside src/ and tests/.
