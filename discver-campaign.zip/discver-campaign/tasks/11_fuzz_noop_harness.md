# Task 11 — detect and stop no-op harnesses (F3)

## Goal
GenFuzzer0 ran ~27M executions with coverage 10→10. A harness whose coverage never moves from its FIRST stats line after
a fixed budget is a no-op or uninstrumented target: flag it "no-op or uninstrumented", stop spending executions on it,
and say so in the health block with the reason. Budget: module-level constants (e.g. 5 minutes or 1M execs), logged at startup. No flags.

## Study first
- fuzzing-brain: `grep -rnE "plateau|stall|no.?progress|cov(erage)?.*(flat|unchanged|same)" --include=*.py --include=*.go --include=*.rs` → read the matching function; note file:line.
- buttercup: `grep -rnE "plateau|stall|coverage" fuzzer/` → same.
- repo: MAP.md "stats parsing" and "health checker"; read the loop that consumes stats lines for a running harness.

## Change (src/)
- In the stats-consuming loop: remember the first `cov:` value per harness; if `cov` is unchanged after NOOP_BUDGET_SECONDS
  or NOOP_BUDGET_EXECS, mark the harness no-op, terminate its fuzzer process (the existing stop path), log
  `harness <name>: coverage flat at <cov> after <execs> execs / <s>s — no-op or uninstrumented; stopped, budget released`.
- Health block: verdict `DEAD — no-op or uninstrumented (coverage flat at <cov>)`. Never softer than today.

## Tests to add (tests/test_noop_harness.py)
- fake stats history: flat cov past the budget → flagged, stop requested, log line present.
- growing cov (2063→3417) → not flagged. Flat cov within budget → not flagged yet.
- a harness flagged no-op renders DEAD with the reason in the health block.

## Acceptance
```
python -m pytest -q tests/test_noop_harness.py
```

## Do not touch
Oracle/sidecar code; the SATURATED verdict logic (task 13 handles it); anything outside src/ and tests/.
