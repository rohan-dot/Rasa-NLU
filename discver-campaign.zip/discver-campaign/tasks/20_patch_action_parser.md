# Task 20 — an action protocol that survives any model (P1)

## Goal
Seven findings failed identically with attempts=15, test_calls=0: the loop never turns a model reply into an action.
Make reply parsing lenient and the loop self-correcting: strip code fences and `<think>…</think>`; take the first balanced
JSON object that contains the action key; tolerate trailing prose; accept case/alias variants of tool names. On a parse
failure send a repair message quoting the exact error, the raw reply (first 300 chars) and the schema example. After 2
consecutive parse failures on a finding, switch it to a one-line minimal protocol. After 4 consecutive read-only turns
(read_source/read_definition/find_references) demand an apply_edit or a stated reason. After an apply_edit followed by
read-only turns, force test_patch (check whether an existing auto-validation already does this; extend rather than duplicate).

## Study first
- buttercup: `grep -rnE "json\.loads|fence|\`\`\`|repair|retry|malformed|parse" patcher/` → how they recover from non-JSON/malformed output; file:line.
- atlantis (Java/patch CRS dirs): `grep -rnE "json\.loads|repair|retry|malformed|parse_action|tool_call" --include=*.py` → same.
- repo: MAP.md "patch loop" — the parser line, the parse-failure branch, the attempts counter, the auto-validation added recently.

## Change (src/patch_generator.py or wherever MAP.md says)
- `parse_action(text) -> (action|None, error)` with the leniency above; the loop logs `[patch-turn] … tool=<name>` or `tool=unparseable err=<e> raw[:300]=…` every turn.
- Repair message and minimal-protocol fallback as described; read-only-turn nudge; post-edit forced test_patch if not already present.

## Tests to add (tests/test_action_parser.py) — fake LLM client returning scripted replies, no network
- fenced JSON parses; JSON followed by prose parses; `<think>…</think>` prefix then JSON parses; `{"Tool": "Apply_Edit"}` aliases to apply_edit.
- garbage reply → repair message is sent (contains "parse", the raw snippet, and the schema example) and the next valid reply proceeds.
- five read_source replies → the sixth prompt contains the apply_edit demand.
- an apply_edit followed by two read-only replies → test_patch is invoked automatically.

## Acceptance
```
python -m pytest -q tests/test_action_parser.py
```

## Do not touch
The validation oracle itself, crash_dedup._get_crash_signature, sidecar wiring; anything outside src/ and tests/.
