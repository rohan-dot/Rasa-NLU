# discver campaign kit — one agent, concrete tasks, tests as the judge

What's different from everything before: there is no manager, no specialists, no "figure out what to do".
Each task file already says what to change, where to look in the reference CRSs, and which test proves it.
`microagent.py` runs ONE task with Opus 4.8; `campaign.py` runs the tasks in order and verifies each one with
tests it runs itself (py_compile → the task's acceptance test → full suite vs. the baseline). A task that fails
verification gets one repair pass; if it still fails, its edits are reverted and the next task starts from a green tree.

## Files
- `microagent.py`   the agent (stdlib only; LiteLLM chat/completions with tools; reasoning_effort optional, auto-dropped if rejected)
- `campaign.py`     the runner (baseline → tasks → verify → repair → restore → CAMPAIGN.md, patch.diff, discver-fix.zip)
- `setup.sh`        builds the work folder: copies your repo + results, clones/links the reference repos
- `tasks/`          00 map (read-only, produces MAP.md) · 10–14 fuzzing · 20–24 patching — edit, reorder, or add your own
- `EVIDENCE.md`     short evidence summary injected into every task (update it after each real run)

## Run it (5 commands)
```bash
export LITELLM_BASE_URL=https://llai-proxy.llan.ll.mit.edu/v1 LITELLM_API_KEY=<key> AGENT_MODEL=claude-opus-4-8 AGENT_TLS_VERIFY=false
bash setup.sh /exp/FY26/AIxCC/ro31337/discver-v3 /path/to/discver-repo /path/to/latest-run-output /exp/FY26/AIxCC/ro31337/chatgpt
#            ^ NEW work folder                  ^ dir that contains src/       ^ has orchestrator.log, patches/   ^ optional: existing atlantis/ buttercup/ clones to link
python3 /exp/FY26/AIxCC/ro31337/discver-v3/microagent.py --verify
nohup python3 /exp/FY26/AIxCC/ro31337/discver-v3/campaign.py --work /exp/FY26/AIxCC/ro31337/discver-v3 > /exp/FY26/AIxCC/ro31337/discver-v3/campaign.log 2>&1 &
tail -f /exp/FY26/AIxCC/ro31337/discver-v3/campaign.log
```
If your suite is not `python -m pytest -q tests`, add `--test-cmd "<your command>"` to campaign.py.
Run a subset: `--only 00,13` · resume: `--from 20` · one task by hand: `python3 microagent.py --repo discver --task-file tasks/13_fuzz_keep_going.md --results results --ref buttercup=refs/buttercup --context MAP.md`.

## What you will see
- `[campaign] baseline suite: exit 0 {passed: N, failed: M}` — pre-existing failures are recorded, never blamed on a task.
- `[agent] 7: str_replace(path='src/...')` lines — the agent working; `NO-OP`/`REFUSED`/`REJECTED` lines are the guard rails doing their job.
- `[campaign] 13_fuzz_keep_going.md: PASS (2 file(s) kept)` or `FAIL — repo restored`.
- At the end: `CAMPAIGN.md` (per task: verdict, verification output, agent summary), `patch.diff`, `changed_files.txt`,
  `discver-fix.zip` (changed src/ + tests/ files + diff + CAMPAIGN.md) — that zip is what goes to the container.

## Tuning
- Task 13 (keep-going) is the one that changes the next run; give it `--max-turns 90` if it fails on turns.
- Add a task: copy a file in `tasks/`, keep the sections (Goal / Study first / Change / Tests to add / Acceptance / Do not touch).
  The runner executes the command in the Acceptance block; keep it to the task's own test file.
- `AGENT_REASONING_EFFORT=high` is optional; if the gateway rejects it the agent drops it automatically and says so.
