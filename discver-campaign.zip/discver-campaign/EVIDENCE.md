As of the last run analysed (report_run_20260915-203913; verify against the results root — it outranks this text):
- Primary harness X509Fuzzer WEAK: ~300 executions, coverage flat 2043→2043, corpus 0→4, health verdict
  "SATURATED by a shallow crash (throws on ~every input; each fork restart dominates runtime)". SinkFuzzer0 the same.
- GenFuzzer0: ~27M executions, coverage 10→10 — a no-op/uninstrumented harness burning budget.
- Every harness prints an execution rate of 0.0/s next to millions of executions — the rate calculation is wrong.
- GenFuzzer1 / SinkFuzzer1 HEALTHY (2063→3417): the fuzzer goes deep once the front door is open.
- 181 LLM-generated seeds, yet corpus 0→4 on the primary harness.
- Patching: failed=7; every patch_index.json entry: status=failed, attempts=15, test_calls=0, root_cause="" —
  on two PoV-backed crashes and five static-* findings. The loop never turns a reply into apply_edit/test_patch.
- Confirmed crash: index-out-of-bounds in mil.disa.common.util.agentmanager.X509Utils.getCnFromDn (X509Utils.java:81).
  Its PoV file name is the SHA-1 of the empty string: the target crashes on EMPTY input. Fix = one-line guard.
- Builder sidecar works ("build oracle path: SIDECAR", libCRS apply-patch-build / run-pov / run-test).
- Nine real runs, zero validated patches. Every failure so far was plumbing or protocol, never the model.
