#!/usr/bin/env python3
"""
repo_tools.py — read-only, sandboxed tools over a project directory, plus a
deterministic (no-LLM) inventory pre-pass.

Everything the model can call lives on `RepoTools` and returns a string sized for a
context window. Paths are confined to the project root (plus explicitly allowed extra
files such as a .pptx that lives elsewhere). Weight files are never read.
"""
from __future__ import annotations

import csv
import fnmatch
import io
import json
import os
import re
from pathlib import Path
from typing import Any

try:  # optional: slide extraction
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    HAVE_PPTX = True
except ImportError:  # pragma: no cover
    HAVE_PPTX = False

try:  # optional: pdf text extraction
    from pypdf import PdfReader

    HAVE_PYPDF = True
except ImportError:  # pragma: no cover
    HAVE_PYPDF = False


try:  # share the exception type with the agent runtime when it is importable
    from agent_core import ToolError
except ImportError:  # pragma: no cover

    class ToolError(Exception):  # type: ignore[no-redef]
        pass


MAX_TOOL_CHARS = 14_000
BIG_TEXT_BYTES = 8_000_000  # above this, files are only read by line range
SKIP_DIRS = {
    ".git", "__pycache__", ".venv", "venv", ".env", "env", "node_modules", ".mypy_cache",
    ".pytest_cache", ".ipynb_checkpoints", ".idea", ".vscode", ".tox", "site-packages",
    ".ruff_cache", ".cache", "dist", "build", "egg-info",
}
WEIGHT_EXT = {
    ".safetensors", ".bin", ".pt", ".pth", ".ckpt", ".h5", ".gguf", ".npy", ".npz", ".pkl",
    ".pickle", ".onnx", ".msgpack", ".index", ".faiss", ".zip", ".tar", ".gz", ".7z",
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".mp4", ".wav", ".pyc", ".so", ".dylib", ".dll",
}
CODE_EXT = {
    ".py", ".sh", ".bash", ".zsh", ".slurm", ".sbatch", ".r", ".jl", ".js", ".ts", ".sql", ".cu", ".c",
    ".cpp", ".h", ".hpp", ".java", ".scala", ".go", ".rs", ".lua", ".ps1", ".bat",
}
CONFIG_EXT = {".yaml", ".yml", ".toml", ".cfg", ".ini", ".env", ".conf"}
DATA_EXT = {".jsonl", ".csv", ".tsv", ".parquet", ".arrow", ".feather", ".xlsx"}
DOC_EXT = {".md", ".rst", ".txt", ".tex", ".bib", ".html", ".xml"}
CONFIG_NAMES = {
    "adapter_config.json", "config.json", "generation_config.json", "tokenizer_config.json",
    "special_tokens_map.json", "training_args.json", "deepspeed_config.json", "accelerate_config.yaml",
    "Dockerfile", "Makefile", "requirements.txt", "environment.yml", "pyproject.toml", "setup.py", "setup.cfg",
}
RESULT_NAME_RE = re.compile(r"(result|metric|eval|score|pred|leaderboard|summary|bench|report|accuracy|f1|rouge|bleu)", re.I)
DATA_NAME_RE = re.compile(r"(train|test|dev|valid|corpus|dataset|data|split|sample)", re.I)

FRAMEWORK_PATTERNS = {
    "peft/LoRA": r"\bpeft\b|LoraConfig|get_peft_model|PeftModel",
    "trl": r"\btrl\b|SFTTrainer|SFTConfig|DPOTrainer|ORPOTrainer|GRPOTrainer",
    "transformers.Trainer": r"\bTrainer\(|TrainingArguments|Seq2SeqTrainer",
    "unsloth": r"\bunsloth\b|FastLanguageModel",
    "axolotl": r"\baxolotl\b",
    "llama-factory": r"llamafactory|LLaMA-Factory",
    "bitsandbytes/QLoRA": r"bitsandbytes|BitsAndBytesConfig|load_in_4bit|load_in_8bit",
    "deepspeed": r"\bdeepspeed\b",
    "accelerate": r"\baccelerate\b",
    "vllm": r"\bvllm\b",
    "openai client": r"\bopenai\b",
    "langchain": r"\blangchain",
    "langgraph": r"\blanggraph\b|StateGraph",
    "llamaindex": r"llama_index",
    "dspy": r"\bdspy\b",
    "faiss": r"\bfaiss\b",
    "chromadb/qdrant/milvus/pgvector": r"chromadb|qdrant|pymilvus|pgvector|weaviate",
    "sentence-transformers": r"sentence_transformers|SentenceTransformer",
    "bm25/rank_bm25": r"rank_bm25|BM25",
    "cross-encoder rerank": r"CrossEncoder|rerank",
    "wandb": r"\bwandb\b",
    "mlflow": r"\bmlflow\b",
    "tensorboard": r"tensorboard|SummaryWriter",
    "ragas": r"\bragas\b",
    "evaluate/sklearn metrics": r"\bevaluate\.load\b|sklearn\.metrics|rouge_score|sacrebleu",
    "datasets (HF)": r"load_dataset|from datasets import",
    "pandas": r"\bpandas\b|\bpd\.",
    "lm-eval-harness": r"lm_eval|lm-evaluation-harness",
}


# --------------------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------------------


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f}{unit}" if unit == "B" else f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def _truncate(s: str, limit: int = MAX_TOOL_CHARS, hint: str = "narrow the request") -> str:
    if len(s) <= limit:
        return s
    return s[:limit] + f"\n...[truncated {len(s) - limit} chars — {hint}]"


def _is_binary_sample(b: bytes) -> bool:
    return b"\x00" in b


def classify(rel: str) -> str:
    p = Path(rel)
    name = p.name
    lname = name.lower()
    ext = p.suffix.lower()
    if ext in WEIGHT_EXT:
        return "weights"
    if ext == ".ipynb":
        return "notebook"
    if ext in {".pptx", ".ppt", ".key", ".odp"}:
        return "slides"
    if ext == ".pdf":
        return "pdf"
    if ext in {".epub", ".mobi", ".docx", ".doc", ".odt"}:
        return "doc-binary"
    if lname == "trainer_state.json":
        return "results"
    if name in CONFIG_NAMES or ext in CONFIG_EXT:
        return "config"
    if ext in {".log", ".out", ".err"} or (ext == ".txt" and "log" in lname):
        return "log"
    if ext in {".json", ".jsonl", ".csv", ".tsv", ".txt", ".md"} and RESULT_NAME_RE.search(lname) and not DATA_NAME_RE.search(lname):
        return "results"
    if ext in DATA_EXT or (ext == ".json" and DATA_NAME_RE.search(lname)):
        return "data"
    if ext in {".json", ".jsonl", ".csv", ".tsv"} and RESULT_NAME_RE.search(lname):
        return "results"
    if ext in CODE_EXT:
        return "code"
    if ext == ".json":
        return "config"
    if ext in DOC_EXT:
        return "doc"
    return "other"


def _glob_match(rel: str, pattern: str) -> bool:
    if not pattern or pattern == "*":
        return True
    return fnmatch.fnmatch(rel, pattern) or fnmatch.fnmatch(Path(rel).name, pattern) or fnmatch.fnmatch(rel, f"*/{pattern}")


def summarize_trainer_state(d: dict) -> dict:
    lh = d.get("log_history") or []
    train = [(e.get("step"), e["loss"]) for e in lh if isinstance(e, dict) and "loss" in e and "eval_loss" not in e]
    evals = [e for e in lh if isinstance(e, dict) and any(str(k).startswith("eval_") for k in e)]
    out: dict[str, Any] = {
        k: d.get(k)
        for k in ("global_step", "epoch", "max_steps", "num_train_epochs", "best_metric", "best_model_checkpoint", "train_batch_size", "total_flos")
        if d.get(k) is not None
    }
    if train:
        vals = [v for _, v in train]
        out["train_loss"] = {"first": vals[0], "last": vals[-1], "min": min(vals), "n_logged": len(vals)}
        n = len(train)
        picks = sorted(set(int(i * (n - 1) / 11) for i in range(12))) if n > 12 else range(n)
        out["train_loss_curve"] = [{"step": train[i][0], "loss": round(float(train[i][1]), 4)} for i in picks]
    lrs = [e.get("learning_rate") for e in lh if isinstance(e, dict) and e.get("learning_rate") is not None]
    if lrs:
        out["learning_rate"] = {"first": lrs[0], "last": lrs[-1], "max": max(lrs)}
    if evals:
        el = [(e.get("step"), e["eval_loss"]) for e in evals if "eval_loss" in e]
        if el:
            best = min(el, key=lambda x: x[1])
            out["eval_loss"] = {"first": el[0][1], "last": el[-1][1], "min": best[1], "min_step": best[0], "n_evals": len(el)}
        out["last_eval"] = {k: v for k, v in evals[-1].items() if str(k).startswith("eval_")}
    runtime = [e for e in lh if isinstance(e, dict) and "train_runtime" in e]
    if runtime:
        out["train_runtime"] = {k: runtime[-1].get(k) for k in ("train_runtime", "train_samples_per_second", "train_steps_per_second", "train_loss")}
    return out


# --------------------------------------------------------------------------------------
# PPTX / PDF / notebook extraction (pure functions)
# --------------------------------------------------------------------------------------


def extract_pptx(path: Path) -> dict:
    if not HAVE_PPTX:
        raise ToolError("python-pptx is not installed (pip install python-pptx)")
    prs = Presentation(str(path))
    slides = []
    for idx, slide in enumerate(prs.slides, 1):
        title = ""
        try:
            if slide.shapes.title is not None:
                title = slide.shapes.title.text_frame.text.strip()
        except Exception:  # noqa: BLE001
            pass
        texts: list[str] = []
        tables: list[list[list[str]]] = []
        charts: list[dict] = []
        n_images = 0

        def walk(shapes):
            nonlocal n_images
            for sh in shapes:
                try:
                    st = sh.shape_type
                except Exception:  # noqa: BLE001
                    st = None
                try:
                    if st == MSO_SHAPE_TYPE.GROUP:
                        walk(sh.shapes)
                        continue
                    if st == MSO_SHAPE_TYPE.PICTURE:
                        n_images += 1
                    if getattr(sh, "has_text_frame", False) and sh.has_text_frame:
                        t = sh.text_frame.text.strip()
                        if t and t != title:
                            texts.append(t)
                    if getattr(sh, "has_table", False) and sh.has_table:
                        tables.append([[c.text.strip() for c in row.cells] for row in sh.table.rows])
                    if getattr(sh, "has_chart", False) and sh.has_chart:
                        charts.append(_extract_chart(sh.chart))
                except Exception as e:  # noqa: BLE001
                    texts.append(f"[unreadable shape: {type(e).__name__}]")

        walk(slide.shapes)
        notes = ""
        try:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame is not None:
                notes = slide.notes_slide.notes_text_frame.text.strip()
        except Exception:  # noqa: BLE001
            pass
        slides.append({"n": idx, "title": title, "text": texts, "tables": tables, "charts": charts, "images": n_images, "notes": notes})
    return {"path": str(path), "n_slides": len(slides), "slides": slides}


def _extract_chart(chart) -> dict:
    out: dict[str, Any] = {}
    try:
        out["type"] = str(chart.chart_type).split(".")[-1].split(" ")[0]
    except Exception:  # noqa: BLE001
        out["type"] = "unknown"
    try:
        if chart.has_title:
            out["title"] = chart.chart_title.text_frame.text.strip()
    except Exception:  # noqa: BLE001
        pass
    series_out = []
    for plot in chart.plots:
        cats = None
        try:
            cats = [str(c) for c in plot.categories]
        except Exception:  # noqa: BLE001
            pass
        for s in plot.series:
            entry: dict[str, Any] = {"name": getattr(s, "name", "")}
            try:
                entry["values"] = [None if v is None else round(float(v), 6) for v in s.values]
            except Exception:  # noqa: BLE001
                entry["values"] = "?"
            if cats:
                entry["categories"] = cats
            series_out.append(entry)
    out["series"] = series_out
    return out


def render_pptx_md(outline: dict, max_chars: int = 40_000) -> str:
    lines = [f"# Slides: {outline['path']} ({outline['n_slides']} slides)"]
    for s in outline["slides"]:
        lines.append(f"\n## Slide {s['n']}: {s['title'] or '(no title)'}")
        for t in s["text"]:
            for ln in t.splitlines():
                ln = ln.strip()
                if ln:
                    lines.append(f"- {ln}")
        for tb in s["tables"]:
            lines.append("Table:")
            for row in tb:
                lines.append("| " + " | ".join(row) + " |")
        for ch in s["charts"]:
            lines.append(f"Chart ({ch.get('type')}) {ch.get('title', '')!r}:")
            for se in ch.get("series", []):
                cats = se.get("categories")
                vals = se.get("values")
                if cats and isinstance(vals, list) and len(cats) == len(vals):
                    lines.append(f"  - {se.get('name')}: " + ", ".join(f"{c}={v}" for c, v in zip(cats, vals)))
                else:
                    lines.append(f"  - {se.get('name')}: {vals}")
        if s["images"]:
            lines.append(f"[{s['images']} image(s) — not extracted]")
        if s["notes"]:
            lines.append(f"Notes: {s['notes']}")
    return _truncate("\n".join(lines), max_chars, "read the slides in ranges")


def extract_pdf_text(path: Path, first_page: int = 1, max_pages: int = 15) -> str:
    if not HAVE_PYPDF:
        raise ToolError("pypdf is not installed (pip install pypdf)")
    reader = PdfReader(str(path))
    n = len(reader.pages)
    out = [f"# PDF: {path.name} ({n} pages) — showing pages {first_page}..{min(n, first_page + max_pages - 1)}"]
    for i in range(first_page - 1, min(n, first_page - 1 + max_pages)):
        try:
            txt = reader.pages[i].extract_text() or ""
        except Exception as e:  # noqa: BLE001
            txt = f"[extract error: {e}]"
        out.append(f"\n--- page {i + 1} ---\n{txt.strip()}")
    return "\n".join(out)


def extract_notebook(path: Path, max_output_chars: int = 800, max_source_chars: int = 4000) -> str:
    nb = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    cells = nb.get("cells", [])
    out = [f"# Notebook: {path.name} ({len(cells)} cells)"]
    for i, cell in enumerate(cells):
        src = cell.get("source", "")
        src = "".join(src) if isinstance(src, list) else str(src)
        kind = cell.get("cell_type", "?")
        out.append(f"\n--- cell {i} [{kind}] ---")
        out.append(src if len(src) <= max_source_chars else src[:max_source_chars] + f"\n...[+{len(src) - max_source_chars} chars]")
        texts = []
        for o in cell.get("outputs", []) or []:
            ot = o.get("output_type")
            if ot == "stream":
                t = o.get("text", "")
                texts.append("".join(t) if isinstance(t, list) else str(t))
            elif ot in ("execute_result", "display_data"):
                t = (o.get("data") or {}).get("text/plain", "")
                texts.append("".join(t) if isinstance(t, list) else str(t))
            elif ot == "error":
                texts.append(f"{o.get('ename')}: {o.get('evalue')}")
        if texts:
            joined = "\n".join(t for t in texts if t)
            if len(joined) > max_output_chars:
                joined = joined[:max_output_chars] + f"\n...[+{len(joined) - max_output_chars} output chars]"
            out.append(f">>> output:\n{joined}")
    return "\n".join(out)


# --------------------------------------------------------------------------------------
# Sandboxed tools
# --------------------------------------------------------------------------------------


def parse_roots(specs: list[str]) -> dict[str, Path]:
    """Turn CLI values like ['quanta=/exp/.../run', '/other/dir'] into {label: path}.
    One unlabeled root -> label '' (paths unchanged). Several roots -> every root gets a label
    (given, or the directory's basename) and tool paths are prefixed with it: 'quanta/train_sft.sh'."""
    roots: dict[str, Path] = {}
    for spec in specs:
        label, sep, path = spec.partition("=")
        if not sep or "/" in label or label.strip() == "":
            label, path = "", spec
        p = Path(path).expanduser().resolve()
        if not p.is_dir():
            raise ToolError(f"root is not a directory: {path}")
        label = label.strip()
        if len(specs) > 1 and not label:
            label = p.name or "root"
        base, n = label, 2
        while label in roots:
            label = f"{base}{n}"
            n += 1
        roots[label] = p
    return roots


class RepoTools:
    def __init__(self, root: str | Path | None = None, extra_files: list[str | Path] | None = None, roots: dict[str, Path] | None = None):
        if roots:
            self.roots = {label: Path(p).resolve() for label, p in roots.items()}
        elif root is not None:
            self.roots = {"": Path(root).resolve()}
        else:
            raise ToolError("RepoTools needs a root or roots")
        for label, p in self.roots.items():
            if not p.is_dir():
                raise ToolError(f"root is not a directory: {p}")
        self.multi = any(label for label in self.roots)
        self.root = next(iter(self.roots.values()))  # primary root (backward compatibility)
        self.extras: dict[str, Path] = {}
        for f in extra_files or []:
            p = Path(f).resolve()
            if not p.is_file():
                raise ToolError(f"extra file not found: {f}")
            if self._root_of(p) is None:
                self.extras[p.name] = p  # outside every root -> reachable as extra/<name>

    # -- path handling ------------------------------------------------------------------
    def _root_of(self, p: Path) -> tuple[str, Path] | None:
        for label, root in self.roots.items():
            try:
                p.relative_to(root)
                return label, root
            except ValueError:
                continue
        return None

    def _resolve(self, path: str) -> Path:
        if not path or not isinstance(path, str):
            raise ToolError("path is required")
        path = path.strip()
        if path.startswith("extra/"):
            name = path[len("extra/"):]
            if name in self.extras:
                return self.extras[name]
            raise ToolError(f"unknown extra file '{name}'. Known: {list(self.extras)}")
        if path in self.extras:
            return self.extras[path]
        p = Path(path)
        if p.is_absolute():
            cand = p.resolve()
            if cand in self.extras.values():
                return cand
            if self._root_of(cand) is None:
                raise ToolError(f"path escapes the project root(s): {path}")
        elif self.multi:
            label, _, rest = path.partition("/")
            if label not in self.roots:
                raise ToolError(f"unknown root label '{label}'. Paths must start with one of: {', '.join(self.roots)}/ (or extra/)")
            cand = (self.roots[label] / rest).resolve()
            if self._root_of(cand) is None:
                raise ToolError(f"path escapes the project root(s): {path}")
        else:
            cand = (self.root / p).resolve()
            if self._root_of(cand) is None:
                raise ToolError(f"path escapes the project root: {path}")
        if not cand.exists():
            raise ToolError(f"no such file: {path} (use list_files to find the right path)")
        return cand

    def _rel(self, p: Path) -> str:
        hit = self._root_of(p)
        if hit is None:
            return f"extra/{p.name}"
        label, root = hit
        rel = p.relative_to(root).as_posix()
        return f"{label}/{rel}" if label else rel

    def _iter_files(self):
        for label, root in self.roots.items():
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS and not d.endswith(".egg-info"))
                for fn in sorted(filenames):
                    full = Path(dirpath) / fn
                    try:
                        size = full.stat().st_size
                    except OSError:
                        continue
                    rel = full.relative_to(root).as_posix()
                    yield (f"{label}/{rel}" if label else rel), full, size
        for name, full in sorted(self.extras.items()):
            yield f"extra/{name}", full, full.stat().st_size

    # -- tools --------------------------------------------------------------------------
    def list_files(self, subdir: str = "", pattern: str = "*", max_results: int = 200) -> str:
        subdir = (subdir or "").strip("/")
        rows = []
        total = 0
        for rel, full, size in self._iter_files():
            if subdir and not (rel == subdir or rel.startswith(subdir + "/")):
                continue
            if not _glob_match(rel, pattern):
                continue
            total += 1
            if len(rows) < max_results:
                rows.append(f"{rel}  ({classify(rel)}, {_fmt_size(size)})")
        head = f"{total} file(s) matched" + (f" under '{subdir}'" if subdir else "") + (f" with pattern '{pattern}'" if pattern and pattern != "*" else "")
        if total > len(rows):
            head += f"; showing first {len(rows)} — narrow with subdir/pattern"
        return head + "\n" + "\n".join(rows)

    def read_file(self, path: str, start_line: int = 1, max_lines: int = 300) -> str:
        p = self._resolve(path)
        if p.is_dir():
            return self.list_files(self._rel(p))
        ext = p.suffix.lower()
        if ext in WEIGHT_EXT:
            return f"{self._rel(p)} is a binary/weight file ({_fmt_size(p.stat().st_size)}); not readable. Look for trainer_state.json / adapter_config.json next to it."
        if ext == ".ipynb":
            return self.read_notebook(path)
        if ext in {".pptx"}:
            return self.read_pptx(path)
        if ext == ".pdf":
            return self.read_pdf(path)
        if ext in {".ppt", ".key", ".odp"}:
            return f"{self._rel(p)}: legacy/other presentation format. Convert to .pptx first (e.g. `soffice --headless --convert-to pptx file.ppt`)."
        if ext in {".epub", ".mobi", ".docx", ".doc", ".odt"}:
            return f"{self._rel(p)} is a packaged document ({ext}, {_fmt_size(p.stat().st_size)}); not extracted here. Look for the pipeline's own text extraction / chunk files instead."
        size = p.stat().st_size
        start_line = max(1, int(start_line or 1))
        max_lines = max(1, min(int(max_lines or 300), 2000))
        with open(p, "rb") as fb:
            sample = fb.read(4096)
        if _is_binary_sample(sample):
            return f"{self._rel(p)} looks binary ({_fmt_size(size)}); not readable as text."
        lines_out = []
        n_total = 0
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f, 1):
                n_total = i
                if start_line <= i < start_line + max_lines:
                    lines_out.append(f"{i:5d}| {line.rstrip()}")
                elif i >= start_line + max_lines and size > BIG_TEXT_BYTES:
                    n_total = f">{i}"
                    break
        end = start_line + len(lines_out) - 1
        head = f"# {self._rel(p)} ({_fmt_size(size)}, {n_total} lines) — lines {start_line}-{end}"
        if isinstance(n_total, int) and end < n_total:
            head += f"; {n_total - end} more lines: call again with start_line={end + 1}"
        return _truncate(head + "\n" + "\n".join(lines_out), hint=f"use start_line={start_line} with a smaller max_lines")

    def grep(self, pattern: str, glob: str = "*", max_results: int = 80, ignore_case: bool = True, context: int = 0) -> str:
        try:
            rx = re.compile(pattern, re.I if ignore_case else 0)
        except re.error as e:
            raise ToolError(f"bad regex: {e}") from e
        context = max(0, min(int(context or 0), 3))
        hits: list[str] = []
        n_files = 0
        for rel, full, size in self._iter_files():
            if not _glob_match(rel, glob) or classify(rel) in {"weights", "slides", "pdf", "doc-binary"} or size > 2_000_000:
                continue
            try:
                with open(full, "rb") as fb:
                    if _is_binary_sample(fb.read(2048)):
                        continue
                with open(full, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
            except OSError:
                continue
            file_hit = False
            for i, line in enumerate(lines):
                if rx.search(line):
                    file_hit = True
                    if context:
                        lo, hi = max(0, i - context), min(len(lines), i + context + 1)
                        block = "".join(f"{rel}:{j + 1}{'>' if j == i else ' '} {lines[j].rstrip()[:200]}\n" for j in range(lo, hi))
                        hits.append(block.rstrip())
                    else:
                        hits.append(f"{rel}:{i + 1}: {line.rstrip()[:200]}")
                    if len(hits) >= max_results:
                        break
            n_files += file_hit
            if len(hits) >= max_results:
                hits.append(f"...[stopped at {max_results} matches — narrow the pattern or glob]")
                break
        if not hits:
            return f"no matches for /{pattern}/ in files matching '{glob}'"
        return f"{len(hits)} match line(s) in {n_files} file(s):\n" + "\n".join(hits)

    def read_notebook(self, path: str, max_output_chars: int = 800) -> str:
        p = self._resolve(path)
        return _truncate(extract_notebook(p, max_output_chars=max_output_chars), hint="read specific cells via read_file ranges on the exported .py if available")

    def read_pptx(self, path: str) -> str:
        p = self._resolve(path)
        if p.suffix.lower() != ".pptx":
            raise ToolError("read_pptx only handles .pptx files")
        outline = extract_pptx(p)
        outline["path"] = self._rel(p)
        return render_pptx_md(outline)

    def read_pdf(self, path: str, first_page: int = 1, max_pages: int = 15) -> str:
        p = self._resolve(path)
        return _truncate(extract_pdf_text(p, int(first_page or 1), int(max_pages or 15)), hint="read fewer pages at a time")

    def read_json(self, path: str, max_chars: int = 10_000, max_records: int = 5) -> str:
        p = self._resolve(path)
        size = p.stat().st_size
        ext = p.suffix.lower()
        if ext == ".jsonl" or (ext == ".json" and size > 20_000_000):
            recs, keys = [], {}
            n = 0
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    n += 1
                    if n <= max(1, int(max_records)):
                        recs.append(line[:1500] + ("...[truncated record]" if len(line) > 1500 else ""))
                    if n <= 500:
                        try:
                            obj = json.loads(line)
                            if isinstance(obj, dict):
                                for k in obj:
                                    keys[k] = keys.get(k, 0) + 1
                        except json.JSONDecodeError:
                            pass
                    if n >= 2_000_000:
                        break
            head = f"# {self._rel(p)} ({_fmt_size(size)}, {n} records{'+' if n >= 2_000_000 else ''})\nkeys seen in first 500 records: {json.dumps(keys)}"
            return _truncate(head + "\nfirst records:\n" + "\n".join(recs), int(max_chars))
        if p.name == "trainer_state.json":
            d = json.loads(p.read_text(encoding="utf-8", errors="replace"))
            return _truncate(f"# {self._rel(p)} (summary)\n" + json.dumps(summarize_trainer_state(d), indent=1), int(max_chars))
        try:
            obj = json.loads(p.read_text(encoding="utf-8", errors="replace"))
        except json.JSONDecodeError as e:
            return f"{self._rel(p)} is not valid JSON ({e}); showing raw head:\n" + self.read_file(path, 1, 60)
        shape = f"top-level {type(obj).__name__}"
        if isinstance(obj, dict):
            shape += f" with {len(obj)} keys: {list(obj)[:40]}"
        elif isinstance(obj, list):
            shape += f" with {len(obj)} items"
        return _truncate(f"# {self._rel(p)} ({_fmt_size(size)}) — {shape}\n" + json.dumps(obj, indent=1, ensure_ascii=False), int(max_chars), "read fewer keys or use grep")

    def read_table(self, path: str, max_rows: int = 25) -> str:
        p = self._resolve(path)
        ext = p.suffix.lower()
        size = p.stat().st_size
        if ext in {".parquet", ".arrow", ".feather", ".xlsx"}:
            try:
                import pandas as pd  # optional

                df = pd.read_parquet(p) if ext == ".parquet" else (pd.read_feather(p) if ext in {".arrow", ".feather"} else pd.read_excel(p))
                buf = io.StringIO()
                df.head(int(max_rows)).to_string(buf)
                desc = df.describe(include="all").transpose().head(40).to_string()
                return _truncate(f"# {self._rel(p)} shape={df.shape} columns={list(df.columns)[:50]}\n{buf.getvalue()}\n\ndescribe():\n{desc}")
            except ImportError:
                return f"{self._rel(p)}: pandas/pyarrow not installed; cannot read {ext}."
        if ext not in {".csv", ".tsv", ".txt"}:
            return self.read_file(path, 1, int(max_rows) + 1)
        with open(p, "r", encoding="utf-8", errors="replace", newline="") as f:
            sample = f.read(16384)
        if not sample.strip():
            return f"{self._rel(p)} is empty"
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
            delim = dialect.delimiter
        except csv.Error:
            delim = "\t" if ext == ".tsv" else ","
        rows: list[list[str]] = []
        header: list[str] = []
        n_rows = 0
        numeric: dict[int, list[float]] = {}
        with open(p, "r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f, delimiter=delim)
            for i, row in enumerate(reader):
                if i == 0:
                    header = row
                    continue
                n_rows += 1
                if n_rows <= int(max_rows):
                    rows.append(row)
                if n_rows <= 20_000:
                    for j, cell in enumerate(row):
                        try:
                            numeric.setdefault(j, []).append(float(cell))
                        except ValueError:
                            numeric.setdefault(j, [])
                if n_rows >= 5_000_000:
                    break
        lines = [f"# {self._rel(p)} ({_fmt_size(size)}, delimiter={delim!r}, {n_rows} data rows, {len(header)} columns)"]
        lines.append("| " + " | ".join(h[:40] for h in header) + " |")
        for r in rows:
            lines.append("| " + " | ".join(c[:60] for c in r) + " |")
        stats = []
        for j, vals in numeric.items():
            if j < len(header) and vals and len(vals) >= 0.9 * min(n_rows, 20_000):
                stats.append(f"{header[j]}: min={min(vals):.4g} max={max(vals):.4g} mean={sum(vals) / len(vals):.4g} (n={len(vals)})")
        if stats:
            lines.append("numeric columns (first ≤20k rows): " + "; ".join(stats))
        return _truncate("\n".join(lines))

    # -- schemas for the LLM ------------------------------------------------------------
    def tool_specs(self) -> list[dict]:
        S = lambda **props: {"type": "object", "properties": props}  # noqa: E731
        def req(schema: dict, *names: str) -> dict:
            schema["required"] = list(names)
            return schema

        return [
            {
                "name": "list_files",
                "description": "List files under the project root (recursive), with kind and size. Use pattern like '*.py', 'trainer_state.json', 'results*'.",
                "parameters": S(
                    subdir={"type": "string", "description": "relative directory to restrict to ('' = whole project)"},
                    pattern={"type": "string", "description": "glob on basename or relative path, default '*'"},
                    max_results={"type": "integer"},
                ),
                "fn": self.list_files,
            },
            {
                "name": "read_file",
                "description": "Read a text file by line range (code, configs, logs, markdown). Notebooks/.pptx/.pdf are auto-routed to their readers. Page with start_line/max_lines for long files.",
                "parameters": req(S(path={"type": "string"}, start_line={"type": "integer"}, max_lines={"type": "integer", "description": "default 300, max 2000"}), "path"),
                "fn": self.read_file,
            },
            {
                "name": "grep",
                "description": "Regex search across text files; returns path:line: text. Use glob to restrict (e.g. '*.py'). Great for finding LoraConfig, learning_rate, metric names, dataset paths.",
                "parameters": req(S(pattern={"type": "string"}, glob={"type": "string"}, max_results={"type": "integer"}, ignore_case={"type": "boolean"}, context={"type": "integer", "description": "lines of context (0-3)"}), "pattern"),
                "fn": self.grep,
            },
            {
                "name": "read_notebook",
                "description": "Read a Jupyter notebook: code/markdown cells plus truncated outputs.",
                "parameters": req(S(path={"type": "string"}, max_output_chars={"type": "integer"}), "path"),
                "fn": self.read_notebook,
            },
            {
                "name": "read_pptx",
                "description": "Extract a .pptx deck: per-slide titles, bullet text, tables, chart data (series values) and speaker notes.",
                "parameters": req(S(path={"type": "string"}), "path"),
                "fn": self.read_pptx,
            },
            {
                "name": "read_pdf",
                "description": "Extract text from a PDF by page range (e.g. an exported presentation or a paper).",
                "parameters": req(S(path={"type": "string"}, first_page={"type": "integer"}, max_pages={"type": "integer"}), "path"),
                "fn": self.read_pdf,
            },
            {
                "name": "read_json",
                "description": "Read JSON (pretty, with shape) or JSONL (first records + key histogram). trainer_state.json is summarized into loss/eval curves.",
                "parameters": req(S(path={"type": "string"}, max_chars={"type": "integer"}, max_records={"type": "integer"}), "path"),
                "fn": self.read_json,
            },
            {
                "name": "read_table",
                "description": "Read CSV/TSV (or parquet/xlsx if pandas is installed): header, first rows, row count and numeric column stats. Use for results tables and dataset files.",
                "parameters": req(S(path={"type": "string"}, max_rows={"type": "integer"}), "path"),
                "fn": self.read_table,
            },
        ]

    # -- inventory pre-pass (no LLM) ----------------------------------------------------
    def build_inventory(self, max_listed: int = 700) -> dict:
        files = []
        total_size = 0
        by_kind: dict[str, int] = {}
        for rel, full, size in self._iter_files():
            kind = classify(rel)
            files.append({"path": rel, "size": size, "kind": kind})
            total_size += size
            by_kind[kind] = by_kind.get(kind, 0) + 1
        by_ext: dict[str, dict[str, int]] = {}
        for f in files:
            ext = Path(f["path"]).suffix.lower() or "(none)"
            e = by_ext.setdefault(ext, {"n": 0, "bytes": 0})
            e["n"] += 1
            e["bytes"] += f["size"]
        inv: dict[str, Any] = {
            "root": str(self.root),
            "roots": {label or "(root)": str(p) for label, p in self.roots.items()},
            "n_files": len(files),
            "total_size": total_size,
            "by_kind": by_kind,
            "by_ext": dict(sorted(by_ext.items(), key=lambda kv: -kv[1]["bytes"])[:30]),
            "files": files[:max_listed],
            "files_truncated": max(0, len(files) - max_listed),
            "adapter_configs": [],
            "trainer_states": [],
            "results_files": [],
            "datasets": [],
            "slides": [],
            "pdfs": [],
            "notebooks": [],
            "entry_points": [],
            "framework_hints": {},
            "readme": None,
            "weights": [],
        }
        for f in files:
            rel, size, kind = f["path"], f["size"], f["kind"]
            full = self._resolve(rel)
            name = Path(rel).name
            if name == "adapter_config.json" and size < 200_000:
                try:
                    inv["adapter_configs"].append({"path": rel, "config": json.loads(full.read_text(encoding="utf-8", errors="replace"))})
                except Exception as e:  # noqa: BLE001
                    inv["adapter_configs"].append({"path": rel, "error": str(e)})
            elif name == "trainer_state.json" and size < 50_000_000:
                try:
                    inv["trainer_states"].append({"path": rel, "summary": summarize_trainer_state(json.loads(full.read_text(encoding="utf-8", errors="replace")))})
                except Exception as e:  # noqa: BLE001
                    inv["trainer_states"].append({"path": rel, "error": str(e)})
            elif kind == "results":
                entry: dict[str, Any] = {"path": rel, "size": size}
                if name.endswith(".json") and size < 100_000:
                    try:
                        obj = json.loads(full.read_text(encoding="utf-8", errors="replace"))
                        entry["keys"] = list(obj)[:30] if isinstance(obj, dict) else f"list[{len(obj)}]"
                        entry["preview"] = json.dumps(obj)[:600]
                    except Exception:  # noqa: BLE001
                        pass
                inv["results_files"].append(entry)
            elif kind == "data":
                entry = {"path": rel, "size": size}
                if size < 300_000_000 and Path(rel).suffix.lower() in {".jsonl", ".csv", ".tsv", ".txt"}:
                    try:
                        with open(full, "rb") as fb:
                            entry["lines"] = sum(1 for _ in fb)
                    except OSError:
                        pass
                inv["datasets"].append(entry)
            elif kind == "slides":
                entry = {"path": rel}
                if rel.endswith(".pptx") and HAVE_PPTX:
                    try:
                        entry["n_slides"] = len(Presentation(str(full)).slides)
                    except Exception as e:  # noqa: BLE001
                        entry["error"] = str(e)
                inv["slides"].append(entry)
            elif kind == "pdf":
                inv["pdfs"].append({"path": rel, "size": size})
            elif kind == "notebook":
                inv["notebooks"].append({"path": rel, "size": size})
            elif kind == "weights":
                inv["weights"].append({"path": rel, "size": size})
            if kind == "code" and size < 1_500_000:
                try:
                    text = full.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue
                for label, pat in FRAMEWORK_PATTERNS.items():
                    if re.search(pat, text):
                        inv["framework_hints"].setdefault(label, []).append(rel)
                depth = rel.count("/")
                if depth <= 2 and (re.search(r'__name__\s*==\s*["\']__main__["\']', text) or "argparse" in text or rel.endswith((".sh", ".slurm", ".sbatch"))):
                    inv["entry_points"].append(rel)
            if inv["readme"] is None and name.lower().startswith("readme") and rel.count("/") == 0:
                try:
                    inv["readme"] = {"path": rel, "head": full.read_text(encoding="utf-8", errors="replace")[:4000]}
                except OSError:
                    pass
        for label in inv["framework_hints"]:
            inv["framework_hints"][label] = inv["framework_hints"][label][:12]
        return inv


def render_inventory_md(inv: dict, max_chars: int = 30_000) -> str:
    L: list[str] = []
    roots = inv.get("roots") or {"(root)": inv["root"]}
    if len(roots) == 1:
        L.append(f"# Project inventory: {next(iter(roots.values()))}")
    else:
        L.append("# Project inventory (several roots; tool paths start with the label)")
        L += [f"- `{label}/` -> {p}" for label, p in roots.items()]
    kinds = ", ".join(f"{k} {v}" for k, v in sorted(inv["by_kind"].items(), key=lambda kv: -kv[1]))
    L.append(f"- {inv['n_files']} files, {_fmt_size(inv['total_size'])} total; by kind: {kinds}")
    if inv.get("by_ext"):
        L.append("- by extension (count, bytes): " + ", ".join(f"{ext} {e['n']}/{_fmt_size(e['bytes'])}" for ext, e in list(inv["by_ext"].items())[:15]))
    if inv["framework_hints"]:
        L.append("\n## Framework / library hints (from code)")
        for label, paths in inv["framework_hints"].items():
            L.append(f"- {label}: {', '.join(paths[:6])}{' ...' if len(paths) > 6 else ''}")
    if inv["entry_points"]:
        L.append("\n## Likely entry points")
        L += [f"- {p}" for p in inv["entry_points"][:25]]
    if inv["adapter_configs"]:
        L.append("\n## LoRA adapter configs (adapter_config.json)")
        for a in inv["adapter_configs"]:
            c = a.get("config") or {}
            if c:
                keys = ("base_model_name_or_path", "peft_type", "task_type", "r", "lora_alpha", "lora_dropout", "target_modules", "bias", "use_rslora", "use_dora", "modules_to_save")
                L.append(f"- {a['path']}: " + ", ".join(f"{k}={json.dumps(c[k])}" for k in keys if k in c))
            else:
                L.append(f"- {a['path']}: error {a.get('error')}")
    if inv["trainer_states"]:
        L.append("\n## Trainer states (trainer_state.json)")
        for t in inv["trainer_states"]:
            L.append(f"- {t['path']}: {json.dumps(t.get('summary') or t.get('error'))[:900]}")
    if inv["results_files"]:
        L.append("\n## Results-like files")
        for r in inv["results_files"][:40]:
            extra = f" keys={r['keys']}" if "keys" in r else ""
            L.append(f"- {r['path']} ({_fmt_size(r['size'])}){extra}")
    if inv["datasets"]:
        L.append("\n## Dataset-like files")
        for d in inv["datasets"][:40]:
            ln = f", {d['lines']} lines" if "lines" in d else ""
            L.append(f"- {d['path']} ({_fmt_size(d['size'])}{ln})")
    if inv["slides"] or inv["pdfs"]:
        L.append("\n## Presentations / PDFs")
        for s in inv["slides"]:
            L.append(f"- {s['path']}" + (f" ({s['n_slides']} slides)" if "n_slides" in s else "") + (f" [error: {s['error']}]" if "error" in s else ""))
        for s in inv["pdfs"]:
            L.append(f"- {s['path']} ({_fmt_size(s['size'])})")
    if inv["notebooks"]:
        L.append("\n## Notebooks")
        L += [f"- {n['path']} ({_fmt_size(n['size'])})" for n in inv["notebooks"][:30]]
    if inv["weights"]:
        L.append(f"\n## Weight/binary files (not readable): {len(inv['weights'])}")
        L += [f"- {w['path']} ({_fmt_size(w['size'])})" for w in inv["weights"][:15]]
    if inv["readme"]:
        L.append(f"\n## {inv['readme']['path']} (head)")
        L.append(inv["readme"]["head"])
    L.append("\n## File tree (path, kind, size)")
    for f in inv["files"]:
        if f["kind"] == "weights":
            continue
        L.append(f"- {f['path']} [{f['kind']}, {_fmt_size(f['size'])}]")
    if inv["files_truncated"]:
        L.append(f"- ... {inv['files_truncated']} more files (use list_files)")
    return _truncate("\n".join(L), max_chars, "use list_files for the rest")
