#!/usr/bin/env python3
"""
run_pipeline.py — run Agent 1 (audit report) then Agent 2 (architecture + scaffold).

  python run_pipeline.py --root /path/to/lora_project [--ppt deck.pptx] --out-dir agent_outputs \
      --model google/gemma-3-27b-it --base-url http://localhost:8000/v1

Outputs in --out-dir: inventory.md/json, slides_outline.md, report_notes.md, report.md,
arch_notes.md, ARCHITECTURE.md, architecture.mmd, scaffold/, trace_*.jsonl, *_run.json
"""
from __future__ import annotations

import argparse
import sys

from agent_core import add_llm_args, llm_from_args
from architecture_agent import run_architecture_agent
from report_agent import run_report_agent


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="LoRA project audit -> agentic architecture, end to end")
    p.add_argument("--root", action="append", required=True, help="project directory; repeatable, optionally labelled: --root quanta=/exp/.../run --root lora=/exp/.../timellama --root rag=/path/to/rag")
    p.add_argument("--ppt", action="append", default=[], help="path to a .pptx outside --root (repeatable)")
    p.add_argument("--out-dir", default="agent_outputs")
    p.add_argument("--hint", default="", help="one line of context passed to both agents")
    p.add_argument("--skip-report", action="store_true", help="reuse <out-dir>/report.md and run only Agent 2")
    p.add_argument("--no-scaffold", action="store_true")
    p.add_argument("--max-scaffold-files", type=int, default=12)
    p.add_argument("--report-max-turns", type=int, default=60)
    p.add_argument("--arch-max-turns", type=int, default=15)
    add_llm_args(p)
    p.add_argument("--context-chars", type=int, default=240_000, help="rough context budget in characters (~4 chars/token); lower it for 32k-context models")
    p.add_argument("--quiet", action="store_true")
    args = p.parse_args(argv)
    llm = llm_from_args(args)
    verbose = not args.quiet

    if args.skip_report:
        from pathlib import Path

        report_path = Path(args.out_dir) / "report.md"
        if not report_path.exists():
            raise SystemExit(f"--skip-report given but {report_path} does not exist")
    else:
        report_path = run_report_agent(
            args.root,
            args.out_dir,
            llm,
            ppt=args.ppt,
            hint=args.hint,
            max_turns=args.report_max_turns,
            context_chars=args.context_chars,
            synthesis_max_tokens=args.synthesis_max_tokens,
            verbose=verbose,
        )
    arch_path = run_architecture_agent(
        report_path,
        args.out_dir,
        llm,
        root=args.root,
        hint=args.hint,
        max_turns=args.arch_max_turns,
        context_chars=args.context_chars,
        synthesis_max_tokens=args.synthesis_max_tokens,
        scaffold=not args.no_scaffold,
        max_scaffold_files=args.max_scaffold_files,
        verbose=verbose,
    )
    print(f"report:       {report_path}")
    print(f"architecture: {arch_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
