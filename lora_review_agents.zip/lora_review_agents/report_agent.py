#!/usr/bin/env python3
"""
report_agent.py — Agent 1: audit a LoRA fine-tuning project directory (code, configs,
results, logs, notebooks) plus its supporting .pptx deck, and write a grounded report.

How it works
  1. Inventory pre-pass (no LLM): classifies every file, parses adapter_config.json and
     trainer_state.json, counts dataset rows, extracts the slide deck.
  2. Exploration (agentic): the model reads what it needs with sandboxed tools and saves
     notes with file citations. Old tool outputs are evicted from context; notes are not.
  3. Synthesis (one long call): notes + inventory + slide outline -> report.md

Usage
  python report_agent.py --root /path/to/lora_project [--ppt slides.pptx] --out-dir agent_outputs \
      --model google/gemma-3-27b-it --base-url http://localhost:8000/v1
  python report_agent.py --root ... --inventory-only        # no LLM calls, just the pre-pass
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from agent_core import Agent, LLMClient, ToolRegistry, add_agent_args, add_llm_args, llm_from_args
from repo_tools import RepoTools, extract_pptx, render_inventory_md, render_pptx_md

EXPLORE_SYSTEM = """You are a meticulous ML engineer auditing a LoRA fine-tuning project. You have READ-ONLY tools over the project directory (code, configs, results, logs, notebooks, slides). In this phase you EXPLORE and take NOTES; a later step turns your notes into the final report, so the notes must carry every fact the report needs.

Ground rules
- Evidence only. Every note cites file paths (and line numbers when useful). Never guess a number; if something is missing, write "NOT FOUND" and say where you looked.
- Label each fact as OBSERVED (code/results/logs), CLAIMED (slides/README/comments) or INFERRED (your reasoning), and flag conflicts between them explicitly.
- Be economical: start from the inventory, use grep/list_files to locate things, then read only what matters; page long files with start_line/max_lines instead of dumping them. Do not re-read files you already noted.
- Save a note (save_note) as soon as you learn something that belongs in the report. Older tool outputs are evicted from your context; notes are permanent.
- When the checklist is covered (or you are told you hit the step limit), stop calling tools and reply with a short plain-text summary of coverage and open questions.

Checklist — find and note each item
1. TASK & DATA: what the model is trained to do; dataset names/paths/sizes/splits; record schema; prompt / chat template actually used in training; preprocessing and filtering; label/answer format; whether retrieved context is in the prompt (and where it comes from); leakage risks (train/test overlap, eval on train, gold context used at eval time).
2. BASE MODEL & LoRA: base model id; r, lora_alpha, lora_dropout, target_modules, bias, rslora/dora; quantization (4/8-bit, QLoRA); trainable parameter count if logged; max sequence length; adapter saved vs merged; which checkpoint is "final".
3. TRAINING RECIPE: framework (HF Trainer / TRL SFTTrainer / Unsloth / axolotl / custom); learning rate, scheduler, warmup, epochs or max_steps, per-device batch x grad accumulation, precision, loss masking (completion-only?), packing; hardware and wall-clock time; loss curve (trainer_state.json, logs, wandb) — first/last/min train loss, eval loss trend, signs of over/underfitting.
4. EVALUATION PROTOCOL: metrics and the exact code computing them; eval sets and sizes; decoding parameters; baselines (base model, prompt-only, other configs); any LLM-judge or human scoring; retrieval evaluated separately or not.
5. RESULTS: the actual numbers from results files/logs (not slides); per-config / per-split tables; seeds and variance; anything inconsistent between files.
6. SLIDES vs CODE: what the deck claims (method, numbers, conclusions) and whether code/results back each claim; list every discrepancy with both numbers.
7. CODE QUALITY & REPRODUCIBILITY: entry points and how to run; config duplication (yaml vs hardcoded); hardcoded paths/secrets; seeds; requirements/env; dead or duplicated code; notebook-vs-script drift.
8. WEAKNESSES & BOTTLENECK HYPOTHESES: small or contaminated eval sets, metric mismatch with the real task, overfitting signals, prompt/template mismatch between train and eval, retrieval quality unknown, missing ablations, unverified claims. State which bottleneck (data / retrieval / generation / eval / recipe) each piece of evidence points to.
"""

EXPLORE_USER = """Audit the project below. The inventory was computed deterministically and is reliable for file paths and sizes; everything else must be verified by reading files.

{inventory}

{extra}

Work through the checklist in order. Save notes continuously. Finish with a plain-text coverage summary."""

SYNTHESIS_SYSTEM = """You write precise, evidence-grounded technical audit reports in Markdown. You never invent numbers. When something was not found, you say NOT FOUND. You cite file paths for claims. You keep prose tight and prefer tables for configs and results."""

SYNTHESIS_USER = """Write the final audit report for this LoRA fine-tuning project. Use ONLY the material below (deterministic inventory, extracted slides, the exploration notes and summary). Where notes conflict with the inventory, prefer the inventory for file facts and the notes for code semantics.

Required structure (Markdown, use these exact headings):
# <Project name> — LoRA fine-tuning audit
## 1. Executive summary
5–8 bullets: what was built, headline result (with the number and its source file), the single biggest weakness, and what to do next.
## 2. Task and data
Task definition; dataset table (path, split, rows, schema); prompt/template used in training; preprocessing; retrieval context (if any); leakage risks.
## 3. Base model and LoRA configuration
Table of base model, r, alpha, dropout, target_modules, quantization, seq len, trainable params, adapter/merge status (cite adapter_config.json and the training code).
## 4. Training recipe
Table of hyperparameters (lr, scheduler, warmup, epochs/steps, batch x accumulation, precision, loss masking, packing), hardware, wall time; loss-curve summary and what it suggests.
## 5. Evaluation protocol
Metrics with the code that computes them, eval sets and sizes, decoding, baselines, judge/human scoring, whether retrieval is measured.
## 6. Results
Results tables from files (not slides); seeds/variance; inconsistencies.
## 7. Slides vs. code
Claim-by-claim table: claim (slide #) | what code/results show | status (confirmed / contradicted / unverified).
## 8. Code quality and reproducibility
Entry points and run commands; config drift; hardcoded paths/secrets; seeds; environment; dead/duplicated code.
## 9. Weaknesses, risks and bottleneck hypotheses
Each item: evidence (file) -> bottleneck it points to (data / retrieval / generation / eval / recipe) -> confidence.
## 10. Open questions
Things that could not be verified from the repository.
## Appendix A. File index
One line per important file: path — role.
## Appendix B. Key configs (verbatim, short)

=== INVENTORY ===
{inventory}

=== EXTRACTED SLIDES ===
{slides}

=== EXPLORATION NOTES ===
{notes}

=== EXPLORATION SUMMARY ===
{summary}
"""


def discover_ppts(repo: RepoTools, inventory: dict) -> list[str]:
    return [s["path"] for s in inventory.get("slides", []) if s["path"].lower().endswith(".pptx")]


def extract_all_slides(repo: RepoTools, ppt_paths: list[str], max_chars_each: int = 30_000) -> str:
    parts = []
    for rel in ppt_paths:
        try:
            outline = extract_pptx(repo._resolve(rel))
            outline["path"] = rel
            parts.append(render_pptx_md(outline, max_chars=max_chars_each))
        except Exception as e:  # noqa: BLE001
            parts.append(f"# Slides: {rel}\n[could not extract: {type(e).__name__}: {e}]")
    return "\n\n".join(parts) if parts else "(no .pptx found — pass --ppt if the deck lives outside the project)"


def run_report_agent(
    root: str | Path,
    out_dir: str | Path,
    llm: LLMClient | None,
    *,
    ppt: list[str] | None = None,
    hint: str = "",
    max_turns: int = 60,
    context_chars: int = 240_000,
    synthesis_max_tokens: int = 8192,
    inventory_only: bool = False,
    verbose: bool = True,
) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    repo = RepoTools(root, extra_files=ppt or [])
    t0 = time.time()

    # 1) deterministic pre-pass (sized so inventory + slides use at most ~1/4 of the context budget)
    cap = max(8_000, min(30_000, context_chars // 8))
    inventory = repo.build_inventory()
    inventory_md = render_inventory_md(inventory, max_chars=cap)
    (out_dir / "inventory.json").write_text(json.dumps(inventory, indent=1), encoding="utf-8")
    (out_dir / "inventory.md").write_text(render_inventory_md(inventory, max_chars=200_000), encoding="utf-8")
    ppt_paths = discover_ppts(repo, inventory)
    slides_md = extract_all_slides(repo, ppt_paths, max_chars_each=cap)
    (out_dir / "slides_outline.md").write_text(slides_md, encoding="utf-8")
    if verbose:
        print(f"[report] inventory: {inventory['n_files']} files, {len(ppt_paths)} deck(s) -> {out_dir/'inventory.md'}", file=sys.stderr)
    if inventory_only or llm is None:
        return out_dir / "inventory.md"

    # 2) agentic exploration
    registry = ToolRegistry()
    registry.register_specs(repo.tool_specs())
    agent = Agent(
        llm,
        registry,
        EXPLORE_SYSTEM,
        name="report-agent",
        max_turns=max_turns,
        context_char_budget=context_chars,
        trace_path=out_dir / "trace_report.jsonl",
        verbose=verbose,
    )
    extra = ""
    if ppt_paths:
        extra += "Slide decks found (already extracted in the inventory step; read_pptx gives the full text): " + ", ".join(ppt_paths) + "\n"
    if hint:
        extra += f"Additional context from the user: {hint}\n"
    result = agent.run(EXPLORE_USER.format(inventory=inventory_md, extra=extra))
    (out_dir / "report_notes.md").write_text("# Exploration notes\n" + agent.notes_markdown() + "\n\n# Coverage summary\n" + result.final_text, encoding="utf-8")

    # 3) synthesis
    report = agent.generate_long(
        SYNTHESIS_SYSTEM,
        SYNTHESIS_USER.format(inventory=inventory_md, slides=slides_md, notes=agent.notes_markdown(), summary=result.final_text or "(none)"),
        max_tokens=synthesis_max_tokens,
    )
    report_path = out_dir / "report.md"
    report_path.write_text(report + "\n", encoding="utf-8")
    meta = {
        "root": str(Path(root).resolve()),
        "ppt": ppt_paths,
        "turns": result.turns,
        "tool_calls": result.tool_calls,
        "notes": len(result.notes),
        "usage": agent.llm.usage,
        "seconds": round(time.time() - t0, 1),
        "model": llm.cfg.model,
        "tool_transport": llm.transport_used,
    }
    (out_dir / "report_run.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    if verbose:
        print(f"[report] done: {report_path} ({len(report)} chars, {result.turns} turns, {result.tool_calls} tool calls, {meta['seconds']}s)", file=sys.stderr)
    return report_path


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Agent 1: audit a LoRA project + slides and write report.md")
    p.add_argument("--root", required=True, help="project directory (code, results, data, slides)")
    p.add_argument("--ppt", action="append", default=[], help="path to a .pptx outside --root (repeatable)")
    p.add_argument("--out-dir", default="agent_outputs")
    p.add_argument("--hint", default="", help="one line of context for the agent, e.g. 'the goal is BioASQ yes/no accuracy'")
    p.add_argument("--inventory-only", action="store_true", help="run the deterministic pre-pass only (no LLM)")
    add_llm_args(p)
    add_agent_args(p, default_max_turns=60)
    args = p.parse_args(argv)
    llm = None if args.inventory_only else llm_from_args(args)
    path = run_report_agent(
        args.root,
        args.out_dir,
        llm,
        ppt=args.ppt,
        hint=args.hint,
        max_turns=args.max_turns,
        context_chars=args.context_chars,
        synthesis_max_tokens=args.synthesis_max_tokens,
        inventory_only=args.inventory_only,
        verbose=not args.quiet,
    )
    print(path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
