#!/usr/bin/env python3
"""Build a small but realistic mock LoRA fine-tuning project (code + results + slides)
so the agents can be exercised offline. Usage: python tests/make_fixture.py <dir>"""
from __future__ import annotations

import json
import sys
from pathlib import Path

TRAIN_PY = '''"""Fine-tune a LoRA adapter for biomedical yes/no QA with retrieved context."""
import argparse, json
from datasets import load_dataset
from peft import LoraConfig, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTTrainer, SFTConfig

PROMPT = "Context:\\n{context}\\n\\nQuestion: {question}\\nAnswer (yes/no):"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="google/gemma-3-4b-it")
    ap.add_argument("--train", default="data/train.jsonl")
    ap.add_argument("--out", default="outputs/adapter")
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--epochs", type=int, default=3)
    args = ap.parse_args()
    tok = AutoTokenizer.from_pretrained(args.base)
    model = AutoModelForCausalLM.from_pretrained(args.base, quantization_config=BitsAndBytesConfig(load_in_4bit=True))
    model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05,
                                             target_modules=["q_proj", "v_proj"], task_type="CAUSAL_LM"))
    ds = load_dataset("json", data_files=args.train)["train"]
    ds = ds.map(lambda ex: {"text": PROMPT.format(**ex) + " " + ex["answer"]})
    cfg = SFTConfig(output_dir=args.out, learning_rate=args.lr, num_train_epochs=args.epochs,
                    per_device_train_batch_size=4, gradient_accumulation_steps=4, max_seq_length=1024,
                    logging_steps=10, save_steps=100, bf16=True, report_to="none")
    SFTTrainer(model=model, args=cfg, train_dataset=ds, tokenizer=tok).train()
    model.save_pretrained(args.out)

if __name__ == "__main__":
    main()
'''

EVAL_PY = '''"""Evaluate base vs LoRA on the test split (exact match on yes/no)."""
import argparse, csv, json
from vllm import LLM, SamplingParams

def exact_match(pred, gold):
    return pred.strip().lower().startswith(gold.strip().lower())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test", default="data/test.jsonl")
    ap.add_argument("--adapter", default="outputs/adapter")
    args = ap.parse_args()
    rows = [json.loads(l) for l in open(args.test)]
    llm = LLM("google/gemma-3-4b-it", enable_lora=True)
    sp = SamplingParams(temperature=0.0, max_tokens=8)
    # NOTE: context is NOT retrieved at eval time; the gold context from the file is used.
    outs = llm.generate([f"Context:\\n{r['context']}\\n\\nQuestion: {r['question']}\\nAnswer (yes/no):" for r in rows], sp)
    acc = sum(exact_match(o.outputs[0].text, r["answer"]) for o, r in zip(outs, rows)) / len(rows)
    print({"accuracy": acc, "n": len(rows)})

if __name__ == "__main__":
    main()
'''

README = """# BioQA LoRA

Fine-tunes Gemma-3-4b-it with a LoRA adapter for yes/no biomedical questions.

```
python train.py --train data/train.jsonl --out outputs/adapter
python eval.py --test data/test.jsonl --adapter outputs/adapter
```
Results: see results/metrics.json and slides/project_update.pptx.
"""


def build(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    (root / "README.md").write_text(README)
    (root / "train.py").write_text(TRAIN_PY)
    (root / "eval.py").write_text(EVAL_PY)
    (root / "requirements.txt").write_text("transformers\npeft\ntrl\nvllm\ndatasets\n")
    (root / "configs").mkdir(exist_ok=True)
    (root / "configs" / "train.yaml").write_text("base: google/gemma-3-4b-it\nlr: 2.0e-4\nepochs: 3\nr: 16\nalpha: 32\n")
    (root / "data").mkdir(exist_ok=True)
    with open(root / "data" / "train.jsonl", "w") as f:
        for i in range(40):
            f.write(json.dumps({"id": i, "question": f"Does drug {i} inhibit kinase X?", "context": f"Study {i} reports drug {i} inhibits kinase X in vitro.", "answer": "yes" if i % 3 else "no"}) + "\n")
    with open(root / "data" / "test.jsonl", "w") as f:
        for i in range(10):
            f.write(json.dumps({"id": 100 + i, "question": f"Is gene {i} associated with disease Y?", "context": f"GWAS {i} found gene {i} associated with disease Y.", "answer": "yes" if i % 2 else "no"}) + "\n")
    (root / "outputs" / "adapter").mkdir(parents=True, exist_ok=True)
    (root / "outputs" / "adapter" / "adapter_config.json").write_text(json.dumps({
        "base_model_name_or_path": "google/gemma-3-4b-it", "peft_type": "LORA", "task_type": "CAUSAL_LM",
        "r": 16, "lora_alpha": 32, "lora_dropout": 0.05, "target_modules": ["q_proj", "v_proj"], "bias": "none",
    }, indent=2))
    (root / "outputs" / "adapter" / "adapter_model.safetensors").write_bytes(b"\x00" * 2048)
    ck = root / "outputs" / "checkpoint-300"
    ck.mkdir(parents=True, exist_ok=True)
    (ck / "training_args.bin").write_bytes(b"\x80\x04" + b"\x00" * 64)
    log_history = []
    for step in range(10, 301, 10):
        log_history.append({"step": step, "epoch": step / 100, "loss": round(2.1 * (0.985 ** (step / 10)) + 0.05, 4), "learning_rate": 2e-4 * (1 - step / 300)})
        if step % 100 == 0:
            log_history.append({"step": step, "epoch": step / 100, "eval_loss": round(1.3 - 0.1 * (step / 100) + (0.15 if step == 300 else 0), 4), "eval_accuracy": round(0.6 + 0.1 * (step / 100), 3)})
    log_history.append({"step": 300, "train_runtime": 1830.5, "train_samples_per_second": 4.2, "train_loss": 0.42})
    (ck / "trainer_state.json").write_text(json.dumps({"global_step": 300, "epoch": 3.0, "max_steps": 300, "num_train_epochs": 3, "log_history": log_history}, indent=1))
    (root / "results").mkdir(exist_ok=True)
    (root / "results" / "metrics.json").write_text(json.dumps({"base_accuracy": 0.61, "lora_accuracy": 0.74, "n_test": 10, "seed": 42}, indent=2))
    with open(root / "results" / "eval_results.csv", "w") as f:
        f.write("model,split,accuracy,n\nbase,test,0.61,10\nlora,test,0.74,10\nlora,train,0.98,40\n")
    (root / "logs").mkdir(exist_ok=True)
    (root / "logs" / "train.log").write_text("\n".join(f"step {s} loss {2.1 * (0.985 ** (s / 10)) + 0.05:.4f}" for s in range(10, 301, 10)))
    (root / "notebooks").mkdir(exist_ok=True)
    nb = {
        "cells": [
            {"cell_type": "markdown", "source": ["# Error analysis\n", "Looking at the 3 wrong answers."], "metadata": {}},
            {"cell_type": "code", "source": ["import pandas as pd\n", "df = pd.read_csv('../results/eval_results.csv')\n", "df"], "metadata": {}, "execution_count": 1,
             "outputs": [{"output_type": "execute_result", "data": {"text/plain": ["  model split  accuracy   n\n0  base  test      0.61  10\n1  lora  test      0.74  10"]}, "metadata": {}, "execution_count": 1}]},
        ],
        "metadata": {}, "nbformat": 4, "nbformat_minor": 5,
    }
    (root / "notebooks" / "error_analysis.ipynb").write_text(json.dumps(nb))
    (root / "slides").mkdir(exist_ok=True)
    try:
        make_pptx(root / "slides" / "project_update.pptx")
    except ImportError:
        pass
    return root


def make_pptx(path: Path) -> None:
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    from pptx.util import Inches

    prs = Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[0])
    s.shapes.title.text = "BioQA LoRA — project update"
    s.placeholders[1].text = "Gemma-3-4b-it + LoRA on biomedical yes/no QA"
    s.notes_slide.notes_text_frame.text = "We claim +13 points over base. Only 10 test questions."

    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = "Method"
    tf = s.placeholders[1].text_frame
    tf.text = "LoRA r=16, alpha=32 on q_proj/v_proj"
    tf.add_paragraph().text = "3 epochs, lr 2e-4, 4-bit base"
    tf.add_paragraph().text = "Retrieval-augmented prompts (BM25 top-3)"

    s = prs.slides.add_slide(prs.slide_layouts[5])
    s.shapes.title.text = "Results"
    rows, cols = 3, 3
    tbl = s.shapes.add_table(rows, cols, Inches(0.5), Inches(1.5), Inches(6), Inches(1.5)).table
    for j, h in enumerate(["Model", "Accuracy", "n"]):
        tbl.cell(0, j).text = h
    for i, r in enumerate([["base", "0.61", "10"], ["LoRA", "0.80", "10"]], start=1):
        for j, v in enumerate(r):
            tbl.cell(i, j).text = v
    cd = CategoryChartData()
    cd.categories = ["base", "LoRA"]
    cd.add_series("Accuracy", (0.61, 0.80))
    s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.5), Inches(3.3), Inches(6), Inches(3), cd)
    prs.save(str(path))


if __name__ == "__main__":
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "mock_lora_project")
    build(out)
    print(f"fixture written to {out.resolve()}")
