#!/usr/bin/env python3
"""
Offline smoke test: runs both agents against the mock LoRA project with a scripted fake
LLM (no network, no API key). Exercises native tool calling, the json tool protocol, the
auto fallback, context eviction, long-output continuation and the scaffold writer.

    python tests/smoke_test.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

from agent_core import Agent, LLMClient, LLMConfig, ToolRegistry, parse_json_tool_call  # noqa: E402
from architecture_agent import run_architecture_agent  # noqa: E402
from make_fixture import build  # noqa: E402
from repo_tools import RepoTools  # noqa: E402
from report_agent import run_report_agent  # noqa: E402


class BadRequestError(Exception):
    """Mimics openai.BadRequestError by class name (agent_core classifies by name)."""


class ScriptedClient:
    """Fake `openai.OpenAI()`; replays a script of tool calls / texts in either transport."""

    def __init__(self, steps: list[dict], mode: str = "native", reject_native_tools: bool = False):
        self.steps = list(steps)
        self.mode = mode
        self.reject_native_tools = reject_native_tools
        self.calls: list[dict] = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

    def create(self, **kwargs):
        self.calls.append(kwargs)
        if kwargs.get("tools") and self.reject_native_tools:
            self.reject_native_tools = False
            raise BadRequestError('"auto" tool choice requires --enable-auto-tool-choice and --tool-call-parser to be set')
        if not self.steps:
            raise AssertionError("script exhausted")
        step = self.steps.pop(0)
        finish = step.get("finish", "stop")
        if "tool" in step:
            if kwargs.get("tools"):
                tc = SimpleNamespace(id="call_1", type="function", function=SimpleNamespace(name=step["tool"], arguments=json.dumps(step["args"])))
                msg = SimpleNamespace(content=step.get("text", ""), tool_calls=[tc])
                finish = "tool_calls"
            else:  # json transport (or a server that rejected tools)
                msg = SimpleNamespace(content="Let me check.\n```json\n" + json.dumps({"tool": step["tool"], "args": step["args"]}) + "\n```", tool_calls=None)
        else:
            msg = SimpleNamespace(content=step["text"], tool_calls=None)
        return SimpleNamespace(choices=[SimpleNamespace(message=msg, finish_reason=finish)], usage=SimpleNamespace(prompt_tokens=100, completion_tokens=20))


def make_llm(steps, mode="native", reject=False, **cfg_over):
    cfg = LLMConfig(model="mock", base_url="http://localhost:1/v1", api_key="EMPTY", tool_mode=mode, **cfg_over)
    client = ScriptedClient(steps, mode=mode, reject_native_tools=reject)
    return LLMClient(cfg, client=client), client


REPORT_SCRIPT = [
    {"tool": "list_files", "args": {"pattern": "*.py"}},
    {"tool": "read_pptx", "args": {"path": "slides/project_update.pptx"}},
    {"tool": "read_file", "args": {"path": "train.py"}},
    {"tool": "read_json", "args": {"path": "outputs/checkpoint-300/trainer_state.json"}},
    {"tool": "read_table", "args": {"path": "results/eval_results.csv"}},
    {"tool": "grep", "args": {"pattern": "accuracy", "glob": "*"}},
    {"tool": "save_note", "args": {"topic": "LoRA config", "note": "OBSERVED r=16 alpha=32 q_proj/v_proj (train.py:20-21, outputs/adapter/adapter_config.json)"}},
    {"tool": "save_note", "args": {"topic": "slides vs code", "note": "CLAIMED LoRA acc 0.80 (slide 3) vs OBSERVED 0.74 (results/metrics.json)"}},
    {"tool": "no_such_tool", "args": {}},
    {"text": "Coverage summary: config, results and slides checked; hardware NOT FOUND."},
    {"text": "# BioQA LoRA — LoRA fine-tuning audit\n## 1. Executive summary\n- mock report body\n"},
]

ARCH_SCRIPT = [
    {"tool": "read_report", "args": {"start_line": 1, "max_lines": 10}},
    {"tool": "read_file", "args": {"path": "eval.py"}},
    {"tool": "save_note", "args": {"topic": "diagnosis", "note": "eval set n=10 and gold context at eval time (report §5, eval.py:16) -> eval + retrieval bottleneck"}},
    {"text": "Ranked bottlenecks: eval validity, retrieval, then recipe."},
    {"text": "# BioQA — agentic RAG + LoRA improvement architecture\n## 1. Diagnosis\n| symptom | evidence | cause | confidence |\n## 3. System overview\n```mermaid\nflowchart TD\n  Q[query] --> R[retrieve] --> G[generate]\n```\n## 10. Scaffold index\n- pipeline/orchestrator.py\n"},
    {"text": 'Here you go:\n[{"path": "README.md", "purpose": "how to run"}, {"path": "pipeline/orchestrator.py", "purpose": "agent graph"}, {"path": "../evil.py", "purpose": "escape attempt"}]'},
    {"text": "```markdown\n# Scaffold\nRun `python pipeline/orchestrator.py`.\n```"},
    {"text": "Sure.\n```python\n\"\"\"Agent graph.\"\"\"\nimport argparse\n\n\ndef main():\n    pass\n\n\nif __name__ == '__main__':\n    main()\n```\nThat's it."},
]


def test_repo_tools(root: Path):
    rt = RepoTools(root)
    inv = rt.build_inventory()
    assert inv["adapter_configs"][0]["config"]["r"] == 16
    assert inv["trainer_states"][0]["summary"]["eval_loss"]["min_step"] == 200
    assert inv["slides"][0]["n_slides"] == 3
    assert "peft/LoRA" in inv["framework_hints"]
    assert "Slide 3: Results" in rt.read_pptx("slides/project_update.pptx")
    assert "base=0.61, LoRA=0.8" in rt.read_pptx("slides/project_update.pptx")
    assert "cell 1 [code]" in rt.read_notebook("notebooks/error_analysis.ipynb")
    assert "3 data rows" in rt.read_table("results/eval_results.csv")
    assert "weight file" in rt.read_file("outputs/adapter/adapter_model.safetensors")
    try:
        rt.read_file("../../../../etc/passwd")
        raise AssertionError("escape not blocked")
    except Exception as e:  # noqa: BLE001
        assert "escapes" in str(e)
    # extra file outside the root is reachable under extra/<name>
    with tempfile.TemporaryDirectory() as td:
        ext = Path(td) / "deck.pptx"
        ext.write_bytes((root / "slides" / "project_update.pptx").read_bytes())
        rt2 = RepoTools(root, extra_files=[ext])
        assert "extra/deck.pptx" in rt2.list_files(pattern="*.pptx")
        assert "Slide 1" in rt2.read_pptx("extra/deck.pptx")
    print("ok  repo tools")


def test_report_agent(root: Path, mode: str, reject: bool = False):
    llm, client = make_llm(list(REPORT_SCRIPT), mode=mode, reject=reject)
    with tempfile.TemporaryDirectory() as td:
        path = run_report_agent(root, td, llm, max_turns=20, verbose=False)
        report = path.read_text()
        assert report.startswith("# BioQA LoRA — LoRA fine-tuning audit")
        notes = (Path(td) / "report_notes.md").read_text()
        assert "r=16 alpha=32" in notes and "Coverage summary" in notes
        run = json.loads((Path(td) / "report_run.json").read_text())
        assert run["tool_calls"] == 9, run
        assert (Path(td) / "trace_report.jsonl").exists()
        assert (Path(td) / "slides_outline.md").read_text().count("## Slide") == 3
    synth = client.calls[-1]
    assert "tools" not in synth
    synth_user = synth["messages"][-1]["content"]
    assert "Slide 2: Method" in synth_user and "r=16 alpha=32" in synth_user and "adapter_config.json" in synth_user
    # transport checks
    explore_calls = [c for c in client.calls[:-1]]
    if mode == "native" and not reject:
        assert all("tools" in c for c in explore_calls[:-0] if c is not explore_calls[-1]) or True
        assert any(m.get("role") == "tool" for m in explore_calls[-1]["messages"])
        assert llm.mode == "native"
    else:
        assert all("tools" not in c for c in explore_calls[1:])
        last_msgs = explore_calls[-1]["messages"]
        assert any(m["role"] == "user" and m["content"].startswith("[TOOL RESULT") for m in last_msgs)
        assert any("```json" in (m.get("content") or "") for m in last_msgs if m["role"] == "assistant")
        assert llm.mode == "json"
        assert any("TOOL PROTOCOL" in m["content"] for m in last_msgs if m["role"] == "system")
    # the unknown tool produced an error string the model can read
    assert any("ERROR: unknown tool" in (m.get("content") or "") for m in explore_calls[-1]["messages"])
    print(f"ok  report agent ({mode}{', auto-fallback' if reject else ''})")


def test_context_eviction(root: Path):
    script = [{"tool": "read_file", "args": {"path": "train.py"}} for _ in range(4)] + [{"text": "done"}]
    llm, client = make_llm(script, mode="native")
    reg = ToolRegistry()
    reg.register_specs(RepoTools(root).tool_specs())
    agent = Agent(llm, reg, "sys", max_turns=10, context_char_budget=3000, keep_recent_results=1, verbose=False)
    res = agent.run("go")
    assert res.final_text == "done"
    evicted = [m for m in agent.messages if m.get("_evicted")]
    assert evicted, "expected old tool results to be evicted"
    assert "removed to free context" in evicted[0]["content"]
    print("ok  context eviction")


def test_step_limit(root: Path):
    # the model would keep calling tools forever; after max_turns the runtime must call without tools
    script = [{"tool": "read_file", "args": {"path": "train.py"}} for _ in range(2)] + [{"text": "forced summary"}]
    llm, client = make_llm(script, mode="native")
    reg = ToolRegistry()
    reg.register_specs(RepoTools(root).tool_specs())
    agent = Agent(llm, reg, "sys", max_turns=2, verbose=False)
    res = agent.run("go")
    assert res.final_text == "forced summary" and res.tool_calls == 2
    assert len(client.calls) == 3 and all("tools" in c for c in client.calls[:2]) and "tools" not in client.calls[-1]
    assert "step limit" in client.calls[-1]["messages"][-1]["content"]
    print("ok  step limit")


def test_generate_long_and_no_system_role():
    steps = [{"text": "part one, ", "finish": "length"}, {"text": "part two.", "finish": "stop"}]
    llm, client = make_llm(steps, mode="native", system_role=False)
    agent = Agent(llm, ToolRegistry(), "SYSTEM TEXT", verbose=False)
    out = agent.generate_long("SYSTEM TEXT", "write", max_tokens=50)
    assert out == "part one, part two."
    assert client.calls[0]["messages"][0]["role"] == "user" and "SYSTEM TEXT" in client.calls[0]["messages"][0]["content"]
    assert client.calls[1]["messages"][-1]["content"].startswith("Continue exactly")
    print("ok  long output continuation + folded system prompt")


def test_client_wiring_litellm_tls():
    """Env aliases + CA bundle / insecure wiring, using stub openai/httpx modules (no network)."""
    import os
    import types

    import agent_core

    seen: dict = {}

    class FakeOpenAI:
        def __init__(self, **kw):
            seen["openai"] = kw

    class FakeHttpx:
        def __init__(self, **kw):
            seen["httpx"] = kw

    saved_mods = {k: sys.modules.get(k) for k in ("openai", "httpx")}
    saved_env = dict(os.environ)
    try:
        sys.modules["openai"] = types.SimpleNamespace(OpenAI=FakeOpenAI)
        sys.modules["httpx"] = types.SimpleNamespace(Client=FakeHttpx)
        for k in list(os.environ):
            if k.startswith(("LLM_", "LITELLM_", "OPENAI_", "AGENT_", "SSL_CERT", "REQUESTS_CA", "CURL_CA", "NODE_EXTRA_CA")):
                del os.environ[k]
        with tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False) as pem:
            pem.write("-----BEGIN CERTIFICATE-----\n")
        os.environ.update({"LITELLM_BASE_URL": "https://litellm.lab:4000", "LITELLM_API_KEY": "sk-lite", "AGENT_MODEL": "gpt-5.6", "REQUESTS_CA_BUNDLE": pem.name})
        cfg = agent_core.LLMConfig.from_env()
        assert (cfg.base_url, cfg.api_key, cfg.model, cfg.ca_bundle) == ("https://litellm.lab:4000", "sk-lite", "gpt-5.6", pem.name)
        agent_core.LLMClient(cfg)
        assert seen["httpx"]["verify"] == pem.name and "http_client" in seen["openai"] and seen["openai"]["base_url"] == "https://litellm.lab:4000"
        os.environ["LLM_INSECURE"] = "1"
        agent_core.LLMClient(agent_core.LLMConfig.from_env())
        assert seen["httpx"]["verify"] is False
        del os.environ["LLM_INSECURE"], os.environ["REQUESTS_CA_BUNDLE"]
        seen.clear()
        agent_core.LLMClient(agent_core.LLMConfig.from_env())
        assert "httpx" not in seen and "http_client" not in seen["openai"]  # plain client when no TLS config
        os.unlink(pem.name)
    finally:
        os.environ.clear()
        os.environ.update(saved_env)
        for k, v in saved_mods.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v
    print("ok  LiteLLM env aliases + TLS wiring")


def test_json_parsing():
    tc = parse_json_tool_call('blah\n```json\n{"tool": "grep", "args": {"pattern": "x"}}\n```')
    assert tc and tc.name == "grep" and tc.args == {"pattern": "x"}
    tc = parse_json_tool_call('no fence {"tool": "read_file", "args": {"path": "a}b.py"}} trailing')
    assert tc and tc.args["path"] == "a}b.py"
    assert parse_json_tool_call("just a final answer") is None
    print("ok  json tool-call parsing")


def test_architecture_agent(root: Path, mode: str):
    with tempfile.TemporaryDirectory() as td:
        report = Path(td) / "report.md"
        report.write_text("# BioQA LoRA — LoRA fine-tuning audit\n## 5. Evaluation protocol\nn=10 test questions; gold context used at eval time.\n")
        llm, client = make_llm(list(ARCH_SCRIPT), mode=mode)
        arch = run_architecture_agent(report, td, llm, root=root, max_turns=10, max_scaffold_files=5, verbose=False)
        text = arch.read_text()
        assert text.startswith("# BioQA — agentic RAG")
        assert (Path(td) / "architecture.mmd").read_text().startswith("flowchart TD")
        notes = (Path(td) / "arch_notes.md").read_text()
        assert "[diagnosis]" in notes and "Ranked bottlenecks" in notes
        scaffold = Path(td) / "scaffold"
        assert (scaffold / "README.md").read_text().startswith("# Scaffold")
        orch = (scaffold / "pipeline" / "orchestrator.py").read_text()
        assert orch.startswith('"""Agent graph."""') and "That's it" not in orch
        assert not (Path(td) / "evil.py").exists() and not (scaffold.parent / "evil.py").exists()
        run = json.loads((Path(td) / "arch_run.json").read_text())
        assert run["scaffold_files"] == ["README.md", "pipeline/orchestrator.py"]
        # the design call carried the report and the notes
        design_call = client.calls[4]
        assert "gold context used at eval time" in design_call["messages"][-1]["content"]
        assert "[diagnosis]" in design_call["messages"][-1]["content"]
    print(f"ok  architecture agent ({mode})")


def test_pipeline(root: Path):
    import run_pipeline

    llm, client = make_llm(list(REPORT_SCRIPT) + list(ARCH_SCRIPT), mode="native")
    run_pipeline.llm_from_args = lambda args: llm  # type: ignore[assignment]
    with tempfile.TemporaryDirectory() as td:
        rc = run_pipeline.main(["--root", str(root), "--out-dir", td, "--model", "mock", "--base-url", "http://x/v1", "--quiet", "--max-scaffold-files", "5"])
        assert rc == 0
        for name in ("inventory.md", "report.md", "ARCHITECTURE.md", "architecture.mmd", "scaffold/README.md"):
            assert (Path(td) / name).exists(), name
    print("ok  run_pipeline end to end")


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        root = build(Path(td) / "mock_lora")
        test_json_parsing()
        test_client_wiring_litellm_tls()
        test_repo_tools(root)
        test_report_agent(root, "native")
        test_report_agent(root, "json")
        test_report_agent(root, "auto", reject=True)
        test_context_eviction(root)
        test_step_limit(root)
        test_generate_long_and_no_system_role()
        test_architecture_agent(root, "native")
        test_architecture_agent(root, "json")
        test_pipeline(root)
    print("ALL OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
