#!/usr/bin/env python3
"""Plain RAG vs agentic RAG, each with the fine-tuned and the base model as the answering model.

    python rag_plain_vs_agentic.py --lora-root DIR --corpus DIR --out-dir rag_outputs [any rag_compare.py flag]
    python rag_plain_vs_agentic.py --out-dir rag_outputs --table-only      # both runs are finished: just the table

It runs rag_compare.py twice on the same questions with the same rag_config.json:

    agentic RAG  ->  <out-dir>          the runner searches, reads the hits, rewrites the query, picks the passages
    plain RAG    ->  <out-dir>_plain    one search with the question as written; the top hits go to the model

and then joins the two into one table (plain_vs_agentic.md in <out-dir>): what agentic retrieval adds for each
model, and what fine-tuning adds under each kind of retrieval, with paired 95% intervals over the same questions.

Each run is the unchanged rag_compare.py in its own process, so every stage resumes exactly as it does there, and
an answer that is word-for-word the same in both runs is judged once and gets the same score in both.

Add --plus for a third run, improved agentic RAG -> <out-dir>_plus (rag_compare.py --retrieval agentic_plus): spare
passage slots filled, the fine-tuned model's from-memory draft guiding the search, answers checked against the
passages and retried once. It becomes a third column in the same report.

Flags of this script: --out-dir (agentic run), --plain-dir (default <out-dir>_plain), --plus, --plus-dir, --table-only.
Every other flag is passed on to rag_compare.py (see `python rag_compare.py --help`), e.g. --limit 5, --stages generate.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).resolve().parent
MODELS = [("base", "Base model"), ("lora", "Fine-tuned (LoRA)")]
METRICS = [("judge", "Judge accuracy"), ("f1", "Token F1")]
MODE_OF = {"agentic": "agentic", "plain": "single", "improved agentic": "agentic_plus"}  # this script's word -> rag_compare.py's --retrieval value


def log(msg: str) -> None:
    print(f"[plain-vs-agentic] {msg}", file=sys.stderr, flush=True)


# --------------------------------------------------------------------------------------
# the table: read two finished runs, join them per question
# --------------------------------------------------------------------------------------


def _num(row: dict, key: str) -> float | None:
    v = row.get(key)
    if v is None or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def load_run(folder: Path, name: str) -> dict:
    """One finished rag_compare.py run. `name` is 'agentic' or 'plain'."""
    folder = Path(folder)
    per, comp = folder / "per_example.csv", folder / "comparison.json"
    if not per.exists() or not comp.exists():
        raise SystemExit(
            f"the {name} run in {folder} has no finished report yet ({per.name} / {comp.name} not found).\n"
            "  -> run the same command again without --table-only and without --stages; it continues where it stopped.\n"
            f"     If it says this again, open {folder / 'comparison.md'}: it names what is missing."
        )
    info = json.loads(comp.read_text(encoding="utf-8"))
    mode = (info.get("retrieval") or {}).get("mode")
    if mode is None:
        raise SystemExit(f"the {name} run in {folder} has no retrieval-based answers (it only has no-retrieval arms), so there is nothing to compare.")
    if mode != MODE_OF[name]:
        raise SystemExit(f"{folder} was produced with --retrieval {mode}, but it was given as the {name} run (which needs --retrieval {MODE_OF[name]}). Check --out-dir / --plain-dir.")
    csv.field_size_limit(2**31 - 1)
    with open(per, "r", encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    state_path = folder / "run_state.json"
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
    return {"name": name, "dir": folder, "order": [r["id"] for r in rows], "rows": {r["id"]: r for r in rows}, "setup": info.get("setup", {}), "retrieval": info.get("retrieval") or {}, "state": state}


def _eval_path(setup: dict) -> str:
    return str(setup.get("Evaluation set", "")).split(" — ")[0]


def build_table(ag: dict, pl: dict) -> dict:
    """All numbers of the report as plain data."""
    import numpy as np

    from rag_eval import RECALL_SPLIT, paired_stats

    common = [i for i in ag["order"] if i in pl["rows"] and pl["rows"][i].get("question") == ag["rows"][i].get("question")]
    if not common:
        raise SystemExit(
            f"the two runs have no question in common ({ag['dir']}: {len(ag['order'])} questions, {pl['dir']}: {len(pl['order'])}).\n"
            "  -> both must use the same rag_config.json, --limit and --seed; run_plain_vs_agentic.sh takes care of that."
        )
    cols_ag, cols_pl = set(ag["rows"][common[0]]), set(pl["rows"][common[0]])
    models = [m for m, _ in MODELS if f"pred_{m}_rag" in cols_ag and f"pred_{m}_rag" in cols_pl]
    if not models:
        raise SystemExit("the two runs have no answering model in common (need lora_rag and/or base_rag in both).")

    warnings = []
    for key in ("Base model", "Adapter", "Generation", "Prompts"):
        if ag["setup"].get(key) != pl["setup"].get(key):
            warnings.append(f"{key} differs between the runs — agentic: {ag['setup'].get(key)} / plain: {pl['setup'].get(key)}")
    if _eval_path(ag["setup"]) != _eval_path(pl["setup"]):
        warnings.append(f"the question file differs between the runs — agentic: {_eval_path(ag['setup'])} / plain: {_eval_path(pl['setup'])}")
    if ag["state"].get("ctx_k") != pl["state"].get("ctx_k"):
        warnings.append(f"the passage limit differs between the runs (--ctx-k {ag['state'].get('ctx_k')} vs {pl['state'].get('ctx_k')})")

    runs = {"plain": pl, "agentic": ag}

    def val(run: str, metric: str, arm: str, i: str) -> float | None:
        return _num(runs[run]["rows"][i], f"{metric}_{arm}")

    def metric_table(metric: str) -> dict | None:
        ids = [i for i in common if all(val(r, metric, f"{m}_rag", i) is not None for r in runs for m in models)]
        if not ids:
            return None
        cell = {(m, r): np.array([val(r, metric, f"{m}_rag", i) for i in ids], dtype=float) for m in models for r in runs}
        t: dict[str, Any] = {"n": len(ids), "ids": ids, "mean": {f"{m}|{r}": float(v.mean()) for (m, r), v in cell.items()}}
        t["by_model"] = {m: paired_stats(cell[(m, "agentic")], cell[(m, "plain")]) for m in models}  # agentic - plain
        t["by_mode"], t["interaction"], t["closed"] = {}, None, None
        if len(models) == 2:
            t["by_mode"] = {r: paired_stats(cell[("lora", r)], cell[("base", r)]) for r in runs}  # fine-tuned - base
            t["interaction"] = paired_stats(cell[("lora", "agentic")] - cell[("base", "agentic")], cell[("lora", "plain")] - cell[("base", "plain")])
            # answers without retrieval do not depend on the retrieval mode: take them from whichever run has them
            for r in ("agentic", "plain"):
                sub = [i for i in ids if val(r, metric, "lora_closed", i) is not None and val(r, metric, "base_closed", i) is not None]
                if sub:
                    t["closed"] = paired_stats([val(r, metric, "lora_closed", i) for i in sub], [val(r, metric, "base_closed", i) for i in sub])
                    break
        return t

    tables = {k: metric_table(k) for k, _ in METRICS}
    judged = tables["judge"]["n"] if tables["judge"] else 0
    primary = "judge" if judged >= 0.5 * len(common) else "f1"
    if tables[primary] is None:
        raise SystemExit("the two runs share questions but no scored answers yet — finish both runs first.")

    rec = [(_num(ag["rows"][i], "evidence_recall"), _num(pl["rows"][i], "evidence_recall")) for i in common]
    rec = [(a, b) for a, b in rec if a is not None and b is not None]
    recall = None
    if rec:
        a, b = np.array([x for x, _ in rec]), np.array([y for _, y in rec])
        recall = {"stats": paired_stats(a, b), "hit_agentic": float((a >= RECALL_SPLIT).mean()), "hit_plain": float((b >= RECALL_SPLIT).mean()), "split": RECALL_SPLIT}
    searches = [x for x in (_num(ag["rows"][i], "n_searches") for i in common) if x is not None]

    # questions where the two runs differ most on the primary metric, summed over the answering models
    gain = {i: sum(val("agentic", primary, f"{m}_rag", i) - val("plain", primary, f"{m}_rag", i) for m in models) for i in tables[primary]["ids"]}
    helped = [i for i in sorted(gain, key=lambda i: -gain[i]) if gain[i] > 1e-9][:3]
    hurt = [i for i in sorted(gain, key=lambda i: gain[i]) if gain[i] < -1e-9][:3]

    same = {m: sum(1 for i in common if ag["rows"][i].get(f"pred_{m}_rag", "") == pl["rows"][i].get(f"pred_{m}_rag", "")) for m in models}
    rescored = sum(
        1 for m in models for i in common
        if ag["rows"][i].get(f"pred_{m}_rag", "") == pl["rows"][i].get(f"pred_{m}_rag", "")
        and None not in (val("agentic", "judge", f"{m}_rag", i), val("plain", "judge", f"{m}_rag", i))
        and val("agentic", "judge", f"{m}_rag", i) != val("plain", "judge", f"{m}_rag", i)
    )

    return {
        "same_answer": same, "rescored": rescored,
        "n_common": len(common), "n_agentic": len(ag["order"]), "n_plain": len(pl["order"]), "ids": common, "models": models, "primary": primary,
        "tables": tables, "recall": recall, "searches_mean": float(np.mean(searches)) if searches else None,
        "ctx_mean": {"agentic": ag["retrieval"].get("ctx_mean"), "plain": pl["retrieval"].get("ctx_mean")},
        "fallbacks": int(ag["retrieval"].get("fallbacks") or 0),
        "helped": helped, "hurt": hurt, "warnings": warnings,
    }


def _f(x: float | None, signed: bool = False, nd: int = 3) -> str:
    if x is None:
        return "–"
    return f"{x:+.{nd}f}" if signed else f"{x:.{nd}f}"


def _clip(s: Any, n: int) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"


def render(t: dict, ag: dict, pl: dict) -> tuple[str, list[str]]:
    """(markdown report, the headline lines for the terminal)."""
    from rag_eval import MIN_N_FOR_VERDICT, verdict

    labels = dict(MODELS)
    mlabels = dict(METRICS)
    runner = ag["state"].get("runner_model") or "the runner model"
    L: list[str] = ["# Plain RAG vs agentic RAG", ""]
    n_note = "" if t["n_common"] == t["n_agentic"] == t["n_plain"] else f" (the agentic run has {t['n_agentic']}, the plain run {t['n_plain']})"
    L.append(f"{t['n_common']} questions answered in both runs{n_note}, by the same models with the same prompts. The only difference is how the passages were chosen:")
    L.append("")
    L.append("| | How the passages are chosen | Passages per question |")
    L.append("|---|---|---|")
    L.append(f"| **Plain RAG** | one search with the question as written; the top hits go to the answering model | {_f(t['ctx_mean']['plain'], nd=1)} |")
    searches = f" ({t['searches_mean']:.1f} searches per question on average)" if t["searches_mean"] is not None else ""
    L.append(f"| **Agentic RAG** | {runner} searches, reads the hits, rewrites the query and searches again{searches}, then picks the passages | {_f(t['ctx_mean']['agentic'], nd=1)} |")
    L.append("")
    for w in t["warnings"]:
        L.append(f"> **Warning:** {w}. The comparison below is then not only about retrieval.")
        L.append("")
    if t["fallbacks"]:
        L.append(f"> **Note:** in {t['fallbacks']} of the agentic run's questions the agent did not choose the passages itself (a runner error, or it ran out of steps), so the top search hits were used. Those questions behave more like plain RAG. Running the command again retries the ones that failed with an error.")
        L.append("")

    prim = t["tables"][t["primary"]]
    head = [f"Result ({mlabels[t['primary']].lower()}, n = {prim['n']})"]
    L.append(f"**{head[0]}**")
    L.append("")
    for m in t["models"]:
        st = prim["by_model"][m]
        body = f"plain RAG {_f(st['b'])} → agentic RAG {_f(st['a'])}, change {_f(st['delta'], True)} (95% CI {_f(st['lo'], True)} to {_f(st['hi'], True)})"
        reading = verdict(st, "agentic RAG", "plain RAG")
        L.append(f"- **{labels[m]}:** {body}: **{reading}**")
        head.append(f"{labels[m]}: {body.replace('→', '->')}: {reading}")
    L.append("")
    if t["primary"] == "f1":
        L.append("_Too few judge scores exist in both runs, so token F1 is the headline. F1 also rewards matching the reference's wording, so read the fine-tuned-vs-base rows with care; the judge stage gives the fairer number._")
        L.append("")
    if prim["n"] < MIN_N_FOR_VERDICT:
        L.append(f"_With {prim['n']} questions this only shows that both runs work. Naming a winner needs at least {MIN_N_FOR_VERDICT} questions; the default run uses 200._")
        L.append("")

    for key, title in METRICS:
        tb = t["tables"][key]
        if tb is None:
            continue
        L.append(f"## {title} (n = {tb['n']})")
        L.append("")
        L.append("What agentic retrieval adds — same answering model, plain vs agentic:")
        L.append("")
        L.append("| Answering model | Plain RAG | Agentic RAG | Agentic − plain | 95% CI | Agentic better / same / worse | Reading |")
        L.append("|---|---|---|---|---|---|---|")
        for m in t["models"]:
            st = tb["by_model"][m]
            L.append(f"| {labels[m]} | {_f(st['b'])} | {_f(st['a'])} | {_f(st['delta'], True)} | {_f(st['lo'], True)} to {_f(st['hi'], True)} | {st['wins']} / {st['ties']} / {st['losses']} | {verdict(st, 'agentic RAG', 'plain RAG')} |")
        L.append("")
        if tb["by_mode"]:
            L.append("What fine-tuning adds — same passages, base vs fine-tuned model:")
            L.append("")
            L.append("| Retrieval | Base model | Fine-tuned (LoRA) | Fine-tuned − base | 95% CI | Fine-tuned better / same / worse | Reading |")
            L.append("|---|---|---|---|---|---|---|")
            rows = [("Plain RAG", tb["by_mode"]["plain"]), ("Agentic RAG", tb["by_mode"]["agentic"])]
            if tb["closed"]:
                rows.insert(0, ("No retrieval" + ("" if tb["closed"]["n"] == tb["n"] else f" (n = {tb['closed']['n']})"), tb["closed"]))
            for name, st in rows:
                L.append(f"| {name} | {_f(st['b'])} | {_f(st['a'])} | {_f(st['delta'], True)} | {_f(st['lo'], True)} to {_f(st['hi'], True)} | {st['wins']} / {st['ties']} / {st['losses']} | {verdict(st, 'the fine-tuned model', 'the base model')} |")
            L.append("")
            it = tb["interaction"]
            if it["n"] < MIN_N_FOR_VERDICT:
                reading = f"too few questions to call (n = {it['n']})"
            elif it["lo"] > 0:
                reading = "fine-tuning helps more when retrieval is agentic"
            elif it["hi"] < 0:
                reading = "agentic retrieval narrows the gap between the fine-tuned and the base model"
            else:
                reading = "no reliable change — the two effects simply add up, as far as this sample can tell"
            L.append(f"Fine-tuning's lead over the base model is {_f(it['b'], True)} with plain RAG and {_f(it['a'], True)} with agentic RAG (change {_f(it['delta'], True)}, 95% CI {_f(it['lo'], True)} to {_f(it['hi'], True)}): {reading}.")
            L.append("")

    if t["recall"]:
        r, st = t["recall"], t["recall"]["stats"]
        L.append("## Did the agent find better passages?")
        L.append("")
        L.append(f"Measured without any model answer: the share of the reference answer's content words that appear in the passages (n = {st['n']}).")
        L.append("")
        L.append("| | Plain RAG | Agentic RAG | Agentic − plain | 95% CI |")
        L.append("|---|---|---|---|---|")
        L.append(f"| Evidence recall | {_f(st['b'], nd=2)} | {_f(st['a'], nd=2)} | {_f(st['delta'], True, 2)} | {_f(st['lo'], True, 2)} to {_f(st['hi'], True, 2)} |")
        L.append(f"| Questions whose passages contain the answer (recall ≥ {r['split']}) | {r['hit_plain']:.0%} | {r['hit_agentic']:.0%} | | |")
        L.append("")
        L.append("Better passages without better answers means the answering model is the bottleneck. No better passages means the agent's extra searches found nothing the first search had missed.")
        L.append("")

    def example(i: str) -> list[str]:
        ra, rp = ag["rows"][i], pl["rows"][i]
        out = [f"- **Q:** {_clip(ra.get('question', ''), 300)}", f"  - reference: {_clip(ra.get('reference', ''), 300)}"]
        for m in t["models"]:
            sp, sa = _num(rp, f"{t['primary']}_{m}_rag"), _num(ra, f"{t['primary']}_{m}_rag")
            out.append(f"  - {labels[m]}, plain RAG ({_f(sp, nd=2)}): {_clip(rp.get(f'pred_{m}_rag', ''), 240) or '(empty)'}")
            out.append(f"  - {labels[m]}, agentic RAG ({_f(sa, nd=2)}): {_clip(ra.get(f'pred_{m}_rag', ''), 240) or '(empty)'}")
        return out

    if t["helped"] or t["hurt"]:
        L.append("## Questions where the two runs differ most")
        L.append("")
        L.append(f"The number in brackets is the {mlabels[t['primary']].lower()} of that answer.")
        L.append("")
        for title, ids in (("Agentic retrieval helped", t["helped"]), ("Plain RAG was better", t["hurt"])):
            if ids:
                L.append(f"**{title}**")
                L.append("")
                for i in ids:
                    L.extend(example(i))
                L.append("")

    L.append("## Setup")
    L.append("")
    L.append("| | |")
    L.append("|---|---|")
    for k in ("Base model", "Adapter", "Evaluation set", "Generation", "Prompts", "Judge"):
        if ag["setup"].get(k):
            L.append(f"| {k} | {str(ag['setup'][k]).replace('|', '/')} |")
    L.append(f"| Agentic run | `{ag['dir']}` — {str(ag['setup'].get('Retrieval', '')).replace('|', '/')} |")
    L.append(f"| Plain run | `{pl['dir']}` — {str(pl['setup'].get('Retrieval', '')).replace('|', '/')} |")
    L.append("")
    short = {"base": "base model", "lora": "fine-tuned model"}
    same = "; ".join(f"{short[m]} {t['same_answer'][m]} of {t['n_common']}" for m in t["models"])
    L.append(f"_Intervals are paired-bootstrap 95% intervals over the same questions. An interval that includes zero means this sample does not establish a difference. Answers that are word-for-word the same in both runs: {same}._")
    if t["rescored"]:
        L.append("")
        L.append(f"_{t['rescored']} identical answers were judged separately in the two runs and got different scores (the judge is not perfectly repeatable). Running both through `rag_plain_vs_agentic.py` judges an identical answer once._")
    else:
        L.append("")
        L.append("_An answer that is identical in both runs has the same judge score in both._")
    return "\n".join(L) + "\n", head


def write_plus(agentic_dir: Path, plain_dir: Path, plus_dir: Path) -> None:
    """Third column: the improved agentic run against the other two, appended to plain_vs_agentic.md."""
    import numpy as np

    from rag_eval import paired_stats, verdict

    runs = {"plain": load_run(plain_dir, "plain"), "agentic": load_run(agentic_dir, "agentic"), "improved": load_run(plus_dir, "improved agentic")}
    ag = runs["agentic"]
    common = [i for i in ag["order"] if all(i in r["rows"] and r["rows"][i].get("question") == ag["rows"][i].get("question") for r in runs.values())]
    if not common:
        raise SystemExit("the three runs have no question in common — they must share rag_config.json, --limit and --seed")
    models = [m for m, _ in MODELS if all(f"pred_{m}_rag" in r["rows"][common[0]] for r in runs.values())]
    labels = dict(MODELS)
    out: dict[str, Any] = {"n_common": len(common), "metrics": {}}
    L = ["", "## Improved agentic RAG (third column)", ""]
    L.append("Agentic RAG plus three changes: spare passage slots are filled with the next-best hits; the fine-tuned model's from-memory draft gives the runner search vocabulary; the runner checks the answers against the passages and sends unsupported ones back with new passages for one more try.")
    L.append("")
    pr = runs["improved"]["retrieval"]
    if pr.get("checked") is not None:
        L.append(f"In this run: {pr.get('drafts', 0)} of {pr.get('n', len(common))} searches used a draft; {pr.get('checked', 0)} questions were checked; {pr.get('revised', 0)} were answered a second time with new passages; {_f(pr.get('ctx_mean'), nd=1)} passages per question.")
        L.append("")
    head: list[str] = []
    for key, title in METRICS:
        ids = [i for i in common if all(_num(r["rows"][i], f"{key}_{m}_rag") is not None for r in runs.values() for m in models)]
        if not ids or (key == "judge" and len(ids) < 0.5 * len(common)):
            continue
        L.append(f"**{title} (n = {len(ids)})**")
        L.append("")
        L.append("| Answering model | Plain RAG | Agentic RAG | Improved agentic | Improved − agentic | 95% CI | Reading | Improved − plain | 95% CI | Reading |")
        L.append("|---|---|---|---|---|---|---|---|---|---|")
        out["metrics"][key] = {"n": len(ids)}
        for m in models:
            v = {name: np.array([_num(r["rows"][i], f"{key}_{m}_rag") for i in ids], dtype=float) for name, r in runs.items()}
            sa, sp = paired_stats(v["improved"], v["agentic"]), paired_stats(v["improved"], v["plain"])
            ra, rp = verdict(sa, "improved agentic", "agentic RAG"), verdict(sp, "improved agentic", "plain RAG")
            L.append(f"| {labels[m]} | {_f(float(v['plain'].mean()))} | {_f(float(v['agentic'].mean()))} | {_f(float(v['improved'].mean()))} | {_f(sa['delta'], True)} | {_f(sa['lo'], True)} to {_f(sa['hi'], True)} | {ra} | {_f(sp['delta'], True)} | {_f(sp['lo'], True)} to {_f(sp['hi'], True)} | {rp} |")
            out["metrics"][key][m] = {"plain": float(v["plain"].mean()), "agentic": float(v["agentic"].mean()), "improved": float(v["improved"].mean()), "vs_agentic": sa, "vs_plain": sp}
            if not head or head[0].startswith(title):
                if not head:
                    head.append(f"{title} (n = {len(ids)}), three ways")
                head.append(f"{labels[m]}: plain {_f(float(v['plain'].mean()))} | agentic {_f(float(v['agentic'].mean()))} | improved agentic {_f(float(v['improved'].mean()))}  (improved - agentic {_f(sa['delta'], True)}, 95% CI {_f(sa['lo'], True)} to {_f(sa['hi'], True)}: {ra})")
        L.append("")
    rec = {name: [_num(r["rows"][i], "evidence_recall") for i in common] for name, r in runs.items()}
    keep = [k for k in range(len(common)) if all(rec[name][k] is not None for name in rec)]
    if keep:
        means = {name: float(np.mean([rec[name][k] for k in keep])) for name in rec}
        out["recall"] = means
        L.append(f"Evidence recall (n = {len(keep)}): plain {_f(means['plain'], nd=2)}, agentic {_f(means['agentic'], nd=2)}, improved agentic {_f(means['improved'], nd=2)}.")
        L.append("")
    with open(Path(agentic_dir) / "plain_vs_agentic.md", "a", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    (Path(agentic_dir) / "three_way.json").write_text(json.dumps(out, indent=1, default=str), encoding="utf-8")
    for k, line in enumerate(head):
        print(("  " if k else "") + line)


def write_table(agentic_dir: Path, plain_dir: Path) -> Path:
    ag, pl = load_run(agentic_dir, "agentic"), load_run(plain_dir, "plain")
    t = build_table(ag, pl)
    text, head = render(t, ag, pl)
    out = Path(agentic_dir) / "plain_vs_agentic.md"
    out.write_text(text, encoding="utf-8")
    (Path(agentic_dir) / "plain_vs_agentic.json").write_text(json.dumps({k: v for k, v in t.items() if k != "ids"}, indent=1, default=str), encoding="utf-8")

    # one row per question with both runs side by side
    cols = ["id", "question", "reference", "evidence_recall_plain", "evidence_recall_agentic", "n_searches_agentic"]
    for m in t["models"]:
        for r in ("plain", "agentic"):
            cols += [f"pred_{m}_{r}", f"judge_{m}_{r}", f"f1_{m}_{r}"]
    with open(Path(agentic_dir) / "plain_vs_agentic.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for i in t["ids"]:
            ra, rp = ag["rows"][i], pl["rows"][i]
            row = {"id": i, "question": ra.get("question", ""), "reference": ra.get("reference", ""), "evidence_recall_plain": rp.get("evidence_recall", ""), "evidence_recall_agentic": ra.get("evidence_recall", ""), "n_searches_agentic": ra.get("n_searches", "")}
            for m in t["models"]:
                for r, src in (("plain", rp), ("agentic", ra)):
                    row[f"pred_{m}_{r}"] = src.get(f"pred_{m}_rag", "")
                    row[f"judge_{m}_{r}"] = src.get(f"judge_{m}_rag", "")
                    row[f"f1_{m}_{r}"] = src.get(f"f1_{m}_rag", "")
            w.writerow(row)

    print(f"\nplain vs agentic: {out}")
    for line in head:
        print(("  " if line is not head[0] else "") + line)
    for wn in t["warnings"]:
        print(f"  WARNING: {wn}")
    return out


# --------------------------------------------------------------------------------------
# the two runs
# --------------------------------------------------------------------------------------


def share_judgments(src: Path, dst: Path) -> int:
    """Give dst the judge scores src has that dst lacks. A score belongs to (question, reference, answer text),
    so an answer that is identical in the two runs is judged once and scored the same in both."""
    from rag_eval import JsonlAppender, read_jsonl

    s, d = Path(src) / "judgments.jsonl", Path(dst) / "judgments.jsonl"
    if not s.exists():
        return 0
    have = {r.get("key") for r in read_jsonl(d)}
    new: dict[str, dict] = {}
    for r in read_jsonl(s):
        if r.get("key") and r.get("score") is not None and r["key"] not in have:
            new.setdefault(r["key"], r)
    if new:
        Path(dst).mkdir(parents=True, exist_ok=True)
        writer = JsonlAppender(d)
        for r in new.values():
            writer.add(r)
    return len(new)


def run_compare(args: list[str]) -> int:
    """One rag_compare.py run in its own process (a fresh process also means a clean GPU for each run)."""
    return subprocess.run([sys.executable, str(HERE / "rag_compare.py"), *args]).returncode


def parse(argv: list[str]) -> tuple[argparse.Namespace, list[str]]:
    p = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    p.add_argument("--out-dir", default="rag_outputs")
    p.add_argument("--plain-dir", default=None)
    p.add_argument("--table-only", action="store_true")
    p.add_argument("--plus", action="store_true")
    p.add_argument("--plus-dir", default=None)
    p.add_argument("--config", default=None)
    p.add_argument("--retrieval", default=None)  # set by this script for each run
    p.add_argument("--stages", default=None)
    p.add_argument("--redo", default="")
    p.add_argument("--with-closed-book", action="store_true")
    p.add_argument("--check", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    return p.parse_known_args(argv)


def main(argv: list[str] | None = None, run: Callable[[list[str]], int] | None = None) -> int:
    own, rest = parse(list(sys.argv[1:] if argv is None else argv))
    if own.help:
        print(__doc__)
        return 0
    run = run or run_compare
    a_dir = Path(own.out_dir)
    b_dir = Path(own.plain_dir) if own.plain_dir else (a_dir.parent / (a_dir.name + "_plain") if a_dir.name else a_dir.resolve().parent / (a_dir.resolve().name + "_plain"))
    if own.retrieval:
        log(f"--retrieval {own.retrieval} ignored: this command runs both kinds")
    if own.check:
        return run(rest + ["--out-dir", str(a_dir), "--check"] + (["--config", own.config] if own.config else []))
    c_dir = Path(own.plus_dir) if own.plus_dir else Path(str(b_dir)[: -len("_plain")] + "_plus" if str(b_dir).endswith("_plain") else str(b_dir) + "_plus")
    if own.table_only:
        write_table(a_dir, b_dir)
        if own.plus:
            write_plus(a_dir, b_dir, c_dir)
        return 0

    stages = [s.strip() for s in own.stages.split(",") if s.strip()] if own.stages else None
    redo = [s.strip() for s in own.redo.split(",") if s.strip()]
    cfg_path = Path(own.config) if own.config else a_dir / "rag_config.json"
    stage_args = ["--stages", ",".join(stages)] if stages else []

    def redo_args(items: list[str]) -> list[str]:
        return ["--redo", ",".join(items)] if items else []

    try:
        # ---- 1. agentic ---------------------------------------------------------------
        if "judge" not in redo:
            share_judgments(b_dir, a_dir)
        log(f"1/3  agentic RAG  ->  {a_dir}")
        rc_a = run(rest + ["--out-dir", str(a_dir), "--retrieval", "agentic"] + (["--config", own.config] if own.config else []) + (["--with-closed-book"] if own.with_closed_book else []) + stage_args + redo_args(redo))
        if not cfg_path.exists():
            log(f"the agentic run stopped before its setup was written ({cfg_path} does not exist), so the plain run was not started.\n"
                "  -> fix what the message above says, then run this same command again.")
            return rc_a or 1

        # ---- 2. plain: same config, same questions; only the retrieval differs ----------
        if "judge" in redo and (b_dir / "judgments.jsonl").exists():
            (b_dir / "judgments.jsonl").unlink()
        share_judgments(a_dir, b_dir)
        log(f"2/3  plain RAG (same adapter, base model, questions and prompts)  ->  {b_dir}   [answers identical to the agentic run keep its judge score]")
        # setup is never redone here (the config is the agentic run's); judge scores were handled above
        rc_b = run(rest + ["--out-dir", str(b_dir), "--retrieval", "single", "--config", str(cfg_path)] + stage_args + redo_args([s for s in redo if s not in ("setup", "judge")]))
        # ---- optional third run: improved agentic (draft-guided search, filled slots, answer check + retry) ----
        rc_c = 0
        if own.plus:
            if "judge" in redo and (c_dir / "judgments.jsonl").exists():
                (c_dir / "judgments.jsonl").unlink()
            share_judgments(a_dir, c_dir)
            share_judgments(b_dir, c_dir)
            log(f"plus  improved agentic RAG (same adapter, base model, questions and prompts)  ->  {c_dir}")
            rc_c = run(rest + ["--out-dir", str(c_dir), "--retrieval", "agentic_plus", "--config", str(cfg_path)] + stage_args + redo_args([s for s in redo if s not in ("setup", "judge")]))
    except KeyboardInterrupt:
        log("interrupted — run the same command again to continue; finished work is kept")
        return 130
    if rc_c and not (rc_a or rc_b):
        log(f"not finished yet: the improved agentic run ({c_dir}) stopped — see its message above. Fix that and run this same command again; finished work is kept.")
        return 1

    if rc_a or rc_b:
        log(
            "not finished yet:\n"
            f"    agentic run ({a_dir}): " + ("ok" if not rc_a else "stopped — see its message above") + "\n"
            f"    plain run   ({b_dir}): " + ("ok" if not rc_b else "stopped — see its message above") + "\n"
            "  -> do what the message says, then run this same command again; finished work is kept.\n"
            "     If it is about torch / transformers / peft: add  --stages generate  to this same command in the training\n"
            "     environment, then run this same command (without --stages) here again."
        )
        return 1
    if stages is not None and "report" not in stages:
        log(f"stages [{', '.join(stages)}] done for both runs. Run this same command without --stages (in the runner's environment) to finish and build the table.")
        return 0

    # ---- 3. the table -------------------------------------------------------------------
    log("3/3  joining the runs")
    write_table(a_dir, b_dir)
    if own.plus:
        write_plus(a_dir, b_dir, c_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
