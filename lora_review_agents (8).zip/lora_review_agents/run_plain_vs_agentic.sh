#!/usr/bin/env bash
# Plain RAG vs agentic RAG, each with the fine-tuned (LoRA) and the base model — with your paths filled in.
#
#   bash lora_review_agents/run_plain_vs_agentic.sh --check       preflight (same as run_rag.sh --check)
#   bash lora_review_agents/run_plain_vs_agentic.sh --limit 5     five questions through both runs (plumbing test)
#   bash lora_review_agents/run_plain_vs_agentic.sh               the real run: 200 sampled questions
#
# It does three things, and re-running it continues where it stopped:
#   1. agentic RAG -> rag_outputs/         (what run_rag.sh does; a finished run there is reused, not repeated)
#   2. plain RAG   -> rag_outputs_plain/   (same adapter, base model, questions and prompts; one plain search)
#   3. one table   -> rag_outputs/plain_vs_agentic.md
#
# Any rag_compare.py flag can be appended (--limit 0, --with-closed-book, --stages generate, ...).
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

LORA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/timellama   # LoRA code (train.sh -> train_sft.py) and its adapter
QUANTA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/quanta/run       # sibling project, readable so shared data (eval_dataset.json) can be used
CORPUS=/exp/FY26/AIA_FEW/da31742/da31742/data/af_epubs                 # the documents to retrieve from
DATA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/data               # readable so question files next to the corpus can be used
QA_ROOT=/exp/FY26/AIA_FEW/da31742/da31742/qa_finetuning        # the EPUB question files (qa_combined_*.csv)
OUT_DIR="${OUT_DIR:-rag_outputs}"

# your own judge instructions: put them in lora_review_agents/prompt.txt and they are used automatically
JUDGE=()
if [ -f "$HERE/prompt.txt" ]; then JUDGE=(--judge-prompt "$HERE/prompt.txt"); echo "using judge prompt: $HERE/prompt.txt" >&2; fi

if [ -f "$HERE/env.sh" ]; then source "$HERE/env.sh"; fi
exec python "$HERE/rag_plain_vs_agentic.py" \
  --lora-root "$LORA_ROOT" \
  --root "quanta=$QUANTA_ROOT" \
  --root "data=$DATA_ROOT" \
  --root "qa=$QA_ROOT" \
  --corpus "$CORPUS" \
  --out-dir "$OUT_DIR" \
  ${JUDGE[@]+"${JUDGE[@]}"} \
  "$@"
