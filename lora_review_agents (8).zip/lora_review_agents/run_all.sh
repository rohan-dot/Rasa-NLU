#!/usr/bin/env bash
# Everything in one run, on the full EPUB test set (a seeded sample of it), with your paths filled in:
#
#   base model and LoRA fine-tuned model  x  alone | plain RAG | agentic RAG | improved agentic RAG
#   + the QuanTA model's saved answers (alone), graded by the same judge on the same questions
#
#   bash lora_review_agents/run_all.sh --limit 5      five questions through everything (plumbing test, ~15 min)
#   bash lora_review_agents/run_all.sh                the real run: 1000 questions (many hours; resumes if interrupted)
#
# Result: rag_all/plain_vs_agentic.md (the headline numbers are also printed at the end).
# Re-running the same command continues where it stopped. A different --limit reuses what is already answered.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE=/exp/FY26/AIA_FEW/da31742/da31742

LORA_ROOT=$BASE/quanta/timellama                               # LoRA code and adapters
QUANTA_ROOT=$BASE/quanta/run                                   # QuanTA code and outputs
CORPUS=$BASE/data/af_epubs                                     # the documents to retrieve from
DATA_ROOT=$BASE/data
QA_ROOT=$BASE/qa_finetuning
ADAPTER=$LORA_ROOT/epubs_Mistral-7B-Instruct-v0.3_genlen_130_epochs_14_r_16/adapter      # the LoRA with a real effect (r=16, alpha=8)
EVAL_FILE=$BASE/quanta/qa_combined_output_deduped_test.csv     # the test set (columns: question, answer, ...)
QUANTA_PREDS=$QUANTA_ROOT/epubs_Mistral-7B-Instruct-v0.3_genlen_130_epochs_14/test_predictions.csv   # QuanTA's saved answers
OUT_DIR="${OUT_DIR:-rag_all}"
LIMIT="${LIMIT:-1000}"

EXTRA=()
if [ -f "$QUANTA_PREDS" ]; then EXTRA=(--extra-predictions "QuanTA=$QUANTA_PREDS"); else echo "note: $QUANTA_PREDS not found - running without the QuanTA answers" >&2; fi

# your own judge instructions: put them in lora_review_agents/prompt.txt and they are used automatically
JUDGE=()
if [ -f "$HERE/prompt.txt" ]; then JUDGE=(--judge-prompt "$HERE/prompt.txt"); echo "using judge prompt: $HERE/prompt.txt" >&2; fi

if [ -f "$HERE/env.sh" ]; then source "$HERE/env.sh"; fi
exec python "$HERE/rag_plain_vs_agentic.py" \
  --lora-root "$LORA_ROOT" \
  --root "quanta=$QUANTA_ROOT" \
  --root "data=$DATA_ROOT" \
  --root "qa=$QA_ROOT" \
  --corpus "$CORPUS" \
  --out-dir "$OUT_DIR" \
  --plus --with-closed-book \
  --adapter "$ADAPTER" \
  --eval-file "$EVAL_FILE" --question-field question --answer-field answer \
  --max-new-tokens 400 \
  --limit "$LIMIT" \
  ${EXTRA[@]+"${EXTRA[@]}"} \
  ${JUDGE[@]+"${JUDGE[@]}"} \
  "$@"
