#!/usr/bin/env python3
"""
Offline tests for the RAG comparison (rag_index / rag_eval / rag_generate / rag_agents / rag_compare).

No network, no GPU, no model downloads: the runner model is a scripted stand-in that behaves like
an OpenAI-compatible endpoint (including gpt-5-style parameter rejections), and torch /
transformers / peft are replaced by the test doubles in fake_hf.py.

    python tests/test_rag.py
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sys
import tempfile
import threading
import time
import types
import zipfile
from pathlib import Path
from types import SimpleNamespace as N

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import numpy as np  # noqa: E402

import fake_hf  # noqa: E402
import rag_fixture  # noqa: E402
from rag_fixture import FACTS, MEMORISED  # noqa: E402

fake_hf.install()
fake_hf.reset()

import agent_core  # noqa: E402
import rag_agents as ra  # noqa: E402
import rag_compare  # noqa: E402
import rag_eval as ev  # noqa: E402
import rag_generate as rg  # noqa: E402
import rag_index as ri  # noqa: E402

NQ = len(FACTS)
QUIET = lambda m: None  # noqa: E731


# --------------------------------------------------------------------------------------
# a stand-in for the runner model
# --------------------------------------------------------------------------------------


class BadRequestError(Exception):
    """Same class name as openai.BadRequestError (agent_core classifies errors by name)."""


class FakeRunner:
    """Behaves like `openai.OpenAI()` for the roles the runner plays. Stateless per conversation
    (decisions come from the message history), so it is safe to call from many threads."""

    def __init__(self, gpt5_quirks: bool = True, setup_mistake: bool = True, fail_retrieval: bool = False):
        self.quirks = gpt5_quirks
        self.setup_mistake = setup_mistake
        self.fail_retrieval = fail_retrieval
        self.calls: list[dict] = []
        self.rejected: list[str] = []
        self._lock = threading.Lock()
        self._n = 0
        self.chat = N(completions=N(create=self.create))

    # -- plumbing ------------------------------------------------------------------------
    def _reply(self, text: str = "", tool: tuple[str, dict] | None = None, finish: str = "stop"):
        with self._lock:
            self._n += 1
            n = self._n
        calls = None
        if tool:
            calls = [N(id=f"call_{n}", type="function", function=N(name=tool[0], arguments=json.dumps(tool[1])))]
            finish = "tool_calls"
        return N(choices=[N(message=N(content=text, tool_calls=calls), finish_reason=finish)], usage=N(prompt_tokens=50, completion_tokens=10))

    def create(self, **kw):
        if self.quirks:  # what gpt-5-class models reject through an OpenAI-compatible proxy
            if "temperature" in kw:
                self.rejected.append("temperature")
                raise BadRequestError("Unsupported value: 'temperature' does not support 0.2 with this model.")
            if "max_tokens" in kw:
                self.rejected.append("max_tokens")
                raise BadRequestError("Unsupported parameter: 'max_tokens'. Use 'max_completion_tokens' instead.")
        with self._lock:
            self.calls.append(kw)
        msgs = kw["messages"]
        system = msgs[0]["content"] if msgs[0]["role"] == "system" else ""
        if "setup agent" in system:
            return self._setup(msgs)
        if "retrieval controller" in system:
            return self._retrieval(msgs)
        if "You grade an answer" in system:
            return self._judge(msgs)
        if "answer checker" in system:
            return self._verify(msgs)
        if "applied ML scientist" in system:
            return self._reply("1. The fine-tuned model is ahead on judged accuracy.\n2. The gap comes from questions where retrieval missed.\n3. Next: add dense retrieval; train with retrieved context.")
        return self._reply("ready")

    # -- roles ---------------------------------------------------------------------------
    def _setup(self, msgs):
        step = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
        good = dict(
            adapter_path="lora/outputs/epubs_lora",
            base_model=self.base_model,
            eval_path="lora/data/eval_dataset.json",
            question_field="question",
            answer_field="answer",
            prompt_style="raw",
            raw_wrapper="<s>[INST] {user} [/INST]",
            closed_book_template="You are an Air Force publications assistant. Answer the question.\n\nQuestion: {question}",
            rag_template="You are an Air Force publications assistant. Answer the question. Use the excerpts below and answer in your usual style.\n\n{context}\n\nQuestion: {question}",
            max_new_tokens=64,
            stop=["[INST]"],
            env_hint="source activate epubs_ft",
            rationale="train.sh passes --model and --out outputs/epubs_lora; train_sft.py:8 builds the [INST] string by hand; predict.py uses MAX_NEW_TOKENS = 64.",
        )
        plan = [
            ("read_file", {"path": "lora/train_sft.py"}),
            ("read_file", {"path": "lora/train.sh"}),
            ("inspect_eval_file", {"path": "lora/data/eval_dataset.json"}),
        ]
        if self.setup_mistake:  # first proposal is wrong in two ways; the validator must send it back
            plan.append(("propose_config", {**good, "adapter_path": "lora/outputs", "rag_template": "Question: {question}"}))
        plan.append(("propose_config", good))
        if step < len(plan):
            return self._reply(tool=plan[step])
        return self._reply("done")

    def _retrieval(self, msgs):
        question = next(m["content"] for m in msgs if m["role"] == "user").split("Question:\n", 1)[1].strip()
        if self.fail_retrieval:
            raise RuntimeError("simulated runner failure")
        fact = next((f for f in FACTS if f[2] == question), None)
        results = [m["content"] for m in msgs if m["role"] == "tool"]
        n_search = sum(1 for m in msgs if m["role"] == "assistant" for tc in (m.get("tool_calls") or []) if tc["function"]["name"] == "search")
        if n_search == 0:
            return self._reply(tool=("search", {"query": question}))
        if n_search == 1 and fact and fact[4]:
            return self._reply(tool=("search", {"query": fact[4], "k": 5}))
        blocks = re.split(r"\n\n(?=\[c\d+\])", results[-1]) if results else []
        hits = [(int(re.match(r"\[c(\d+)\]", b).group(1)), b) for b in blocks if re.match(r"\[c\d+\]", b)]
        good = [cid for cid, b in hits if fact and fact[1] in b]
        if good:
            return self._reply(tool=("submit_evidence", {"chunk_ids": good, "sufficient": True, "note": "states the answer"}))
        return self._reply(tool=("submit_evidence", {"chunk_ids": [cid for cid, _ in hits[:2]], "sufficient": False, "note": "not found"}))

    def _verify(self, msgs):
        """Sends a question back when an answer says it lacks the information and another wording finds the passage."""
        user = next(m["content"] for m in msgs if m["role"] == "user")
        question = user.split("Question:\n", 1)[1].split("\n\nCurrent passages:", 1)[0].strip()
        fact = next((f for f in FACTS if f[2] == question), None)
        answers = user.split("Candidate answer 1:", 1)[1].lower()
        results = [m["content"] for m in msgs if m["role"] == "tool"]
        unsure = "not sure" in answers or "enough information" in answers
        if not (unsure and fact and fact[4]):
            return self._reply(tool=("finish", {"supported": True}))
        if not results:
            return self._reply(tool=("search", {"query": fact[4], "k": 5}))
        good = [int(x) for x, body in re.findall(r"\[c(\d+)\][^\n]*\n([^\n]*)", results[-1]) if fact[1] in body]
        current = [int(x) for x in re.findall(r"\[c(\d+)\]", user)]
        return self._reply(tool=("finish", {"supported": False, "chunk_ids": good + current[:1], "note": "the passages did not state it"}))

    def _judge(self, msgs):
        user = msgs[-1]["content"]
        ref = user.split("Reference answer:\n", 1)[1].split("\n\nCandidate answer:\n", 1)[0]
        cand = user.split("Candidate answer:\n", 1)[1]
        score = 1 if ev.normalize_answer(ref) in ev.normalize_answer(cand) else 0
        body = json.dumps({"score": score, "reason": "matches" if score else "does not match"})
        return self._reply(f"```json\n{body}\n```" if len(cand) % 2 else body)


def patch_runner(fake: FakeRunner, base_model: str):
    """Make rag_compare build its LLMClient around the stand-in."""
    fake.base_model = base_model

    def llm_from_args(args):
        cfg = agent_core.LLMConfig(model=args.model or "gpt-5.6", base_url="https://litellm.test", api_key="k", temperature=0.2, max_tokens=2048)
        return agent_core.LLMClient(cfg, client=fake)

    rag_compare.llm_from_args = llm_from_args


# --------------------------------------------------------------------------------------
# rag_index
# --------------------------------------------------------------------------------------


def test_index():
    import random

    assert ri.chunk_text("", 200, 40) == []
    w = lambda n: " ".join(f"w{i}" for i in range(n))  # noqa: E731
    for n, exp in [(190, 1), (200, 1), (201, 2), (210, 2), (230, 2), (360, 2), (361, 3), (5, 1)]:
        ch = ri.chunk_text(w(n), 200, 40)
        assert len(ch) == exp, (n, len(ch))
        assert {x for c in ch for x in c.split()} == set(w(n).split())
    random.seed(1)
    words = [f"term{i}" for i in range(400)] + ["torque", "waiver", "commander", "afi", "36", "2903", "inspection", "the", "of", "and"]
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "corpus"
        (root / "catA" / "txt").mkdir(parents=True)
        (root / "catB" / "txt").mkdir(parents=True)
        for d in range(40):
            text = " ".join(random.choice(words) for _ in range(random.randint(50, 900)))
            if d % 7 == 0:
                text += "\n\nSection 4.2. The MAJCOM commander approves waiver requests for AFI 36-2903 within 30 days."
            (root / ("catA" if d % 2 else "catB") / "txt" / f"doc{d:02d}.txt").write_text(text)
        (root / "catA" / "metadata.csv").write_text("file,title\ndoc01.txt,Something\n")
        for stem in ("doc00", "book"):
            with zipfile.ZipFile(root / "catB" / f"{stem}.epub", "w") as z:
                z.writestr("OEBPS/ch2.xhtml", "<html><head><title>x</title><style>p{}</style></head><body><p>Second chapter about hydraulic fluid.</p></body></html>")
                z.writestr("OEBPS/ch10.xhtml", "<html><body><p>Tenth chapter &amp; appendix zebra.</p><script>var a=1;</script></body></html>")
        files = ri.list_corpus_files([root])
        names = [n for n, _ in files]
        assert "catB/book.epub" in names and "catB/doc00.epub" not in names and not any(n.endswith(".csv") for n in names) and len(files) == 41
        book = ri.read_epub(root / "catB" / "book.epub")
        assert book.index("Second chapter") < book.index("Tenth chapter") and "var a" not in book and "p{}" not in book
        logs: list[str] = []
        r = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("building" in x for x in logs) and r.meta["n_docs"] == 41 and r.n_chunks > 100
        for name, path in files[:5]:  # chunks reassemble to the original text
            cids = [i for i in range(r.n_chunks) if r.chunk_doc[i] == r.docs.index(name)]
            rebuilt = r.text(cids[0]).split()
            for c in cids[1:]:
                rebuilt += r.text(c).split()[10:]
            assert rebuilt == ri.read_document(path).split(), name
        toks = [ri.tokenize(r.text(i)) for i in range(r.n_chunks)]
        avgdl = sum(len(t) for t in toks) / len(toks)

        def brute(q):  # textbook BM25, independent of the index code
            sc = np.zeros(len(toks))
            for t in set(ri.tokenize(q)):
                df = sum(1 for tk in toks if t in tk)
                if df:
                    idf = math.log(1 + (len(toks) - df + 0.5) / (df + 0.5))
                    for i, tk in enumerate(toks):
                        tf = tk.count(t)
                        if tf:
                            sc[i] += idf * tf * 2.5 / (tf + 1.5 * (0.25 + 0.75 * len(tk) / avgdl))
            return sc

        for q in ["Who approves waiver requests for AFI 36-2903?", "torque inspection term17 term250", "hydraulic fluid zebra", "term5", "term1 term2 term3 commander 2903"]:
            ref = brute(q)
            hits = r.search(q, k=7)
            want = sorted(ref[ref > 0], reverse=True)[:7]
            assert len(hits) == len(want)
            for h, wv in zip(hits, want):
                assert abs(h["score"] - wv) < 2e-3 and abs(h["score"] - ref[h["id"]]) < 2e-3, (q, h["score"], wv)
        assert r.search("zzzz qqqq") == [] and r.search("the of and") == []
        assert "MAJCOM commander approves waiver" in r.search("Who approves waiver requests for AFI 36-2903?", k=3)[0]["text"]
        f = r.search("waiver commander", k=20, doc_filter="doc07")
        assert f and all("doc07" in h["doc"] for h in f) and r.search("waiver commander", 5, doc_filter="nope") == []
        first = [i for i in range(r.n_chunks) if r.chunk_pos[i] == 0][3]
        assert [n["pos"] for n in r.neighbors(first)] == [1]
        logs.clear()
        ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("cached" in x for x in logs)
        time.sleep(1.1)
        (root / "catA" / "txt" / "new.txt").write_text("brand new document about quokka maintenance")
        logs.clear()
        r3 = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, log=logs.append)
        assert any("building" in x for x in logs) and r3.search("quokka")[0]["doc"] == "catA/txt/new.txt"
        qs = ["waiver commander", "torque inspection", "term3 term4 term5", "hydraulic zebra"] * 20
        seq = [[h["id"] for h in r3.search(q, 5)] for q in qs]
        res: list = [None] * len(qs)
        th = [threading.Thread(target=lambda i=i: res.__setitem__(i, [h["id"] for h in r3.search(qs[i], 5)])) for i in range(len(qs))]
        [t.start() for t in th]
        [t.join() for t in th]
        assert res == seq

        class FakeST:  # sentence-transformers stand-in: hashed bag of words
            def __init__(self, path, device="cpu"):
                pass

            def encode(self, texts, batch_size=32, normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False):
                out = np.zeros((len(texts), 64), dtype=np.float32)
                for i, t in enumerate(texts):
                    for tok in ri.tokenize(t):
                        out[i, int(hashlib.md5(tok.encode()).hexdigest(), 16) % 64] += 1
                    out[i] /= np.linalg.norm(out[i]) or 1
                return out

        sys.modules["sentence_transformers"] = types.SimpleNamespace(SentenceTransformer=FakeST)
        try:
            r4 = ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, embed_model="/m/fake", log=logs.append)
            assert r4.emb.shape == (r4.n_chunks, 64) and "dense" in r4.describe() and r4.search("quokka maintenance", 3)[0]["doc"] == "catA/txt/new.txt"
            logs.clear()
            ri.Retriever.build_or_load([root], Path(td) / "idx", chunk_words=60, chunk_overlap=10, embed_model="/m/fake", log=logs.append)
            assert any("cached embeddings" in x for x in logs)
        finally:
            sys.modules.pop("sentence_transformers", None)
    print("ok  index: chunking, BM25 == textbook BM25, epub, filters, cache, threads, dense wiring")


# --------------------------------------------------------------------------------------
# rag_eval
# --------------------------------------------------------------------------------------


def test_eval_data():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        qa = [{"question": f"What is rule {i}?", "answer": f"Rule {i} says stop.", "id": i} for i in range(12)]
        (td / "list.json").write_text(json.dumps(qa))
        (td / "wrapped.json").write_text(json.dumps({"meta": {"v": 1}, "data": qa}))
        (td / "columnar.json").write_text(json.dumps({"question": [r["question"] for r in qa], "answer": [r["answer"] for r in qa]}))
        (td / "lines.jsonl").write_text("\n".join(json.dumps(r) for r in qa) + "\n\n")
        (td / "lines_as.json").write_text("\n".join(json.dumps(r) for r in qa))
        (td / "t.csv").write_text("﻿Question,Answer,predict\n" + "\n".join(f'"What, is rule {i}?","Rule {i} says ""stop"".",x' for i in range(5)))
        (td / "t.tsv").write_text("prompt\tlabel\tpredict\n" + "\n".join(f"Q{i}\tA{i}\tP{i}" for i in range(4)))
        (td / "alpaca_const.json").write_text(json.dumps([{"instruction": "Answer the question about Air Force policy.", "input": f"Who signs form {i}?", "output": f"The commander signs form {i}."} for i in range(8)]))
        (td / "alpaca_var.json").write_text(json.dumps([{"instruction": f"Summarize section {i}", "input": f"text {i}" if i % 2 == 0 else "", "output": f"sum {i}"} for i in range(8)]))
        (td / "chat.jsonl").write_text("\n".join(json.dumps({"messages": [{"role": "system", "content": "s"}, {"role": "user", "content": f"q{i}"}, {"role": "assistant", "content": f"a{i}"}]}) for i in range(6)))
        (td / "sharegpt.json").write_text(json.dumps([{"conversations": [{"from": "human", "value": f"q{i}"}, {"from": "gpt", "value": f"a{i}"}]} for i in range(6)]))
        (td / "metrics.json").write_text(json.dumps({"eval_loss": 1.2}))
        (td / "nested.json").write_text(json.dumps([{"q": {"text": f"deep {i}"}, "answers": {"text": [f"ans {i}", "alt"]}} for i in range(5)]))
        for name in ("list.json", "wrapped.json", "columnar.json", "lines.jsonl", "lines_as.json"):
            recs = ev.load_records(td / name)
            sc = ev.detect_schema(recs)
            assert len(recs) == 12 and (sc["question_field"], sc["answer_field"]) == ("question", "answer"), name
            assert len(ev.build_examples(recs, sc)[0]) == 12
        sc = ev.detect_schema(ev.load_records(td / "list.json"))
        assert sc["id_field"] == "id" and ev.build_examples(ev.load_records(td / "list.json"), sc)[0][3].id == "3"
        recs = ev.load_records(td / "t.csv")
        sc = ev.detect_schema(recs)
        exs, _ = ev.build_examples(recs, sc)
        assert (sc["question_field"], sc["answer_field"]) == ("Question", "Answer") and exs[1].question == "What, is rule 1?" and exs[1].answer == 'Rule 1 says "stop".'
        sc = ev.detect_schema(ev.load_records(td / "t.tsv"))
        assert (sc["question_field"], sc["answer_field"]) == ("prompt", "label")
        sc = ev.detect_schema(ev.load_records(td / "alpaca_const.json"))
        assert sc["question_field"] == "input" and sc["constant_instruction"].startswith("Answer the question") and sc["input_field"] is None
        recs = ev.load_records(td / "alpaca_var.json")
        sc = ev.detect_schema(recs)
        exs, _ = ev.build_examples(recs, sc)
        assert sc["input_field"] == "input" and exs[0].query == "Summarize section 0\ntext 0" and exs[1].query == "Summarize section 1"
        for name in ("chat.jsonl", "sharegpt.json"):
            recs = ev.load_records(td / name)
            sc = ev.detect_schema(recs)
            assert sc["format"] == "messages" and [(e.question, e.answer) for e in ev.build_examples(recs, sc)[0][:2]] == [("q0", "a0"), ("q1", "a1")]
        assert ev.load_records(td / "metrics.json") == [] and ev.detect_schema([]) is None
        exs, _ = ev.build_examples(ev.load_records(td / "nested.json"), {"format": "fields", "question_field": "q.text", "answer_field": "answers.text.0"})
        assert exs[2].question == "deep 2" and exs[2].answer == "ans 2"
        exs, sk = ev.build_examples([{"question": "a", "answer": "b", "id": 1}, {"question": "", "answer": "b", "id": 2}, {"question": "c", "answer": "d", "id": 1}], {"question_field": "question", "answer_field": "answer", "id_field": "id"})
        assert sk == 1 and [e.id for e in exs] == ["1", "1#2"]
        exs, _ = ev.build_examples(ev.load_records(td / "list.json"), {"question_field": "question", "answer_field": "answer"})
        s5, s9 = ev.select_examples(exs, 5, 0), ev.select_examples(exs, 9, 0)
        assert [e.id for e in s9[:5]] == [e.id for e in s5] and len(ev.select_examples(exs, 0, 0)) == 12 and [e.id for e in ev.select_examples(exs, 5, 1)] != [e.id for e in s5]
        # appending after a half-written line (interrupted run) does not lose the next record
        f = td / "a.jsonl"
        f.write_text('{"id": 1}\n{"id": 2, "x"')
        ev.JsonlAppender(f).add({"id": 3})
        assert [r["id"] for r in ev.read_jsonl(f)] == [1, 3]
    print("ok  eval data: loaders, schema detection, seeded subsets, interrupted-write recovery")


def test_metrics_and_stats():
    assert abs(ev.token_f1("The cat sat", "cat sat down") - 0.8) < 1e-9
    assert ev.exact_match("The Commander.", "commander") == 1.0 and ev.exact_match("commander general", "commander") == 0.0
    assert ev.token_f1("", "x") == 0.0 and ev.token_f1("", "") == 1.0
    assert abs(ev.rouge_l("a b c d".split(), "a c d e f".split()) - 2 * 0.75 * 0.6 / 1.35) < 1e-9
    assert abs(ev.rouge_n("a b c d".split(), "a b x d".split(), 1) - 0.75) < 1e-9 and abs(ev.rouge_n("a b c d".split(), "a b x d".split(), 2) - 1 / 3) < 1e-9
    st = ev.bleu_stats("the quick brown fox jumps".split(), "the quick brown fox jumped over".split())
    assert st == [4, 5, 3, 4, 2, 3, 1, 2, 5, 6]
    assert abs(float(ev.bleu_from_stats(st)[0]) - math.exp(1 - 6 / 5) * (0.8 * 0.75 * (2 / 3) * 0.5) ** 0.25) < 1e-9
    assert abs(float(ev.bleu_from_stats(ev.bleu_stats("a b c d e".split(), "a b c d e".split()))[0]) - 1.0) < 1e-12
    assert float(ev.bleu_from_stats(ev.bleu_stats([], ["a"]))[0]) == 0.0
    assert abs(ev.evidence_recall("The MAJCOM commander approves the waiver within 30 days", "waiver requests are approved by the majcom commander; 30 days") - 5 / 6) < 1e-9
    rng = np.random.default_rng(3)
    b = rng.random(300)
    a = b + 0.05 + rng.normal(0, 0.05, 300)
    s = ev.paired_stats(a, b)
    se = (a - b).std(ddof=1) / math.sqrt(300)
    assert s["lo"] > 0 and abs(s["delta"] - (a - b).mean()) < 1e-12 and s["wins"] + s["ties"] + s["losses"] == 300
    assert abs((s["hi"] - s["lo"]) / 2 - 1.96 * se) < 0.25 * 1.96 * se
    s0 = ev.paired_stats(b, b)
    assert s0["delta"] == 0 and s0["lo"] == 0 == s0["hi"] and "no reliable" in ev.verdict(s0, "A", "B")
    assert ev.verdict(s, "A", "B") == "A is better" and ev.verdict(ev.paired_stats(b, a), "A", "B") == "B is better" and ev.paired_stats([], []) is None
    miss = 0
    for seed in range(200):  # with no true difference the 95% CI should rarely exclude zero
        r = np.random.default_rng(1000 + seed)
        c = ev.paired_stats(r.normal(0, 1, 60), r.normal(0, 1, 60), iters=400, seed=seed)
        miss += (c["lo"] > 0) or (c["hi"] < 0)
    assert 0.01 <= miss / 200 <= 0.12, miss / 200
    print("ok  metrics (hand-computed values) and paired bootstrap (CI width, false-positive rate)")


# --------------------------------------------------------------------------------------
# rag_generate
# --------------------------------------------------------------------------------------


def _world(td):
    paths = rag_fixture.build(Path(td))
    exs, _ = ev.build_examples(ev.load_records(paths["eval"]), {"question_field": "question", "answer_field": "answer"})
    r = ri.Retriever.build_or_load([paths["corpus"]], Path(td) / "idx", log=QUIET)
    evidence = {e.id: {"id": e.id, "chunks": r.search(e.query, 3)} for e in exs}
    cfg = ra.merge_config(ra.default_config(), {
        "base_model": str(paths["base"]), "adapter_path": str(paths["adapter"]),
        "prompt": {"style": "raw", "raw_wrapper": "<s>[INST] {user} [/INST]",
                   "closed_book": "You are an Air Force publications assistant. Answer the question.\n\nQuestion: {question}",
                   "rag": "You are an Air Force publications assistant. Answer the question using the excerpts.\n\n{context}\n\nQuestion: {question}"},
        "gen": {"max_new_tokens": 32},
    })
    return paths, exs, r, evidence, cfg


def test_generate_hf():
    logs: list[str] = []
    with tempfile.TemporaryDirectory() as td:
        paths, exs, _, evidence, cfg = _world(td)
        out = Path(td) / "out"
        tk = {str(paths["adapter"]): {"n_tokens": 32001, "has_template": False}}
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        meta: dict = {}
        done = rg.run_generation(arms=list(rg.ARMS), examples=exs, evidence=evidence, cfg=cfg, out_dir=out, batch_size=5, meta=meta, log=logs.append)
        assert done == {a: NQ for a in rg.ARMS}, done
        assert meta["styles"] == {"lora_rag": "raw", "base_rag": "chat", "lora_closed": "raw", "base_closed": "chat"}
        # one base load (dtype + device_map); the adapter is attached once, after every base arm has finished
        assert len(S["model_loads"]) == 1 and S["model_loads"][0]["torch_dtype"] == "torch.bfloat16" and S["model_loads"][0]["device_map"] == "auto"
        assert S["peft_loads"] == [str(paths["adapter"])] and S["tok_loads"] == [str(paths["base"]), str(paths["adapter"])]
        adapters = [c["adapter"] for c in S["generate_calls"]]
        first = next(i for i, a in enumerate(adapters) if a)
        assert all(a is None for a in adapters[:first]) and all(adapters[first:])
        assert all(p["n_bos"] == 1 for c in S["generate_calls"] for p in c["prompts"])  # never a double BOS
        assert max(c["batch"] for c in S["generate_calls"]) == 5 and all(c["do_sample"] is False and "temperature" not in c["extra"] for c in S["generate_calls"])
        preds = {a: rg.load_predictions(out, a) for a in rg.ARMS}
        for i, e in enumerate(exs):
            in_ctx = FACTS[i][1].lower() in " ".join(c["text"] for c in evidence[e.id]["chunks"]).lower()
            lr, br, lc, bc = (preds[a][e.id]["prediction"] for a in rg.ARMS)
            if in_ctx:
                assert lr == e.answer and br == f"Based on the excerpts, the answer is {e.answer}.", (i, lr, br)
            assert lc == (e.answer if i in MEMORISED else "I am not sure.") and bc == "I do not have enough information to answer."
        rec = preds["lora_rag"][exs[0].id]
        assert rec["n_ctx"] == len(evidence[exs[0].id]["chunks"]) >= 1 and rec["hit_cap"] is False and rec["ehash"] and preds["lora_closed"][exs[0].id]["ehash"] == ""
        sp = (out / "sample_prompts.md").read_text()
        lora_block, base_block = sp.split("## lora_rag")[1].split("## base_rag")[0], sp.split("## base_rag")[1].split("## lora_closed")[0]
        assert "wrapper: raw" in lora_block and "<s>[INST] You are an Air Force publications assistant. Answer the question using the excerpts." in lora_block and "[1] " in lora_block
        assert "wrapper: chat" in base_block and "<s>[INST] You are an Air Force publications assistant." in base_block

        # resume: nothing missing -> the model is not even loaded
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=out, log=logs.append) == {"lora_rag": 0, "base_rag": 0}
        assert S["model_loads"] == [] and S["generate_calls"] == []
        lines = (out / "predictions_lora_rag.jsonl").read_text().splitlines()
        (out / "predictions_lora_rag.jsonl").write_text("\n".join(lines[:7]) + "\n" + lines[7][:25])  # interrupted mid-line
        done = rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=out, log=logs.append)
        assert done == {"lora_rag": NQ - 7, "base_rag": 0} and all(c["adapter"] for c in S["generate_calls"]) and len(rg.load_predictions(out, "lora_rag")) == NQ
        # changed passages for one question -> exactly that question is regenerated in both RAG arms
        ev2 = dict(evidence)
        ev2[exs[1].id] = {"id": exs[1].id, "chunks": []}
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=ev2, cfg=cfg, out_dir=out, log=logs.append) == {"lora_rag": 1, "base_rag": 1}
        assert len(ev.read_jsonl(out / "predictions_lora_rag.jsonl")) == NQ and rg.load_predictions(out, "lora_rag")[exs[1].id]["n_ctx"] == 0
        cfg2 = json.loads(json.dumps(cfg))
        cfg2["gen"]["max_new_tokens"] = 3
        assert rg.run_generation(arms=["base_rag"], examples=exs[:4], evidence=evidence, cfg=cfg2, out_dir=out, log=logs.append) == {"base_rag": 4}
        p = rg.load_predictions(out, "base_rag")
        assert p[exs[0].id]["prediction"] == "Based on the" and p[exs[0].id]["hit_cap"] is True and len(p) == NQ and p[exs[8].id]["hit_cap"] is False

        # failure handling and fallbacks
        S = fake_hf.reset(answer_fn=lambda p, a: "the answer ### Question: something else", oom_above=2)
        cfg3 = json.loads(json.dumps(cfg))
        cfg3["gen"].update(stop=["### Question:"], temperature=0.7)
        assert rg.run_generation(arms=["base_closed"], examples=exs[:12], evidence={}, cfg=cfg3, out_dir=Path(td) / "o2", batch_size=8, load_in_4bit=True, log=logs.append) == {"base_closed": 12}
        assert [c["batch"] for c in S["generate_calls"]] == [2] * 6 and any("out of memory -> batch size 4" in x for x in logs)
        assert all(c["do_sample"] is True and c["extra"]["temperature"] == 0.7 for c in S["generate_calls"]) and S["model_loads"][0]["quantization_config"].kw["load_in_4bit"] is True
        assert all(r["prediction"] == "the answer" and "### Question" in r["raw"] for r in rg.load_predictions(Path(td) / "o2", "base_closed").values())
        for state, kwargs, needle in [
            (dict(oom_above=0), {}, "batch size 1"),
            (dict(cuda=False), {}, "no CUDA GPU"),
        ]:
            fake_hf.reset(**state)
            try:
                rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o3", log=logs.append, **kwargs)
                raise AssertionError(needle)
            except SystemExit as e:
                assert needle in str(e), e
        S = fake_hf.reset(need_accelerate=True, new_dtype_kwarg=True)
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o4", log=logs.append)
        assert S["model_loads"][0].get("dtype") == "torch.bfloat16" and "device_map" not in S["model_loads"][0] and S["moved_to"] == ["cuda"]
        cfg4 = json.loads(json.dumps(cfg))
        cfg4["base_model"] = "mistralai/Mistral-7B-Instruct-v0.3"
        S = fake_hf.reset(hub_cache={"mistralai/Mistral-7B-Instruct-v0.3"})
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg4, out_dir=Path(td) / "o5", log=logs.append)
        assert S["model_loads"][0]["local_files_only"] is True
        fake_hf.reset()
        for bad_cfg, arms, evd, needle in [
            (cfg4, ["base_closed"], {}, "--base-model /local/path"),
            (cfg, ["base_rag"], {exs[0].id: evidence[exs[0].id]}, f"{NQ - 1} selected questions have no retrieved evidence"),
            ({**cfg, "adapter_path": str(paths["project"])}, ["lora_closed"], {}, "could not attach the adapter"),
        ]:
            try:
                rg.run_generation(arms=arms, examples=exs, evidence=evd, cfg=bad_cfg, out_dir=Path(td) / "o6", log=logs.append)
                raise AssertionError(needle)
            except SystemExit as e:
                assert needle in str(e), e
        fake_hf.reset(cuda=False)
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "o7", allow_cpu=True, log=logs.append)
        assert fake_hf.STATE["model_loads"][0]["torch_dtype"] == "torch.float32"
    print("ok  generation (transformers/peft doubles): arm order, single BOS, resume, cache invalidation, OOM backoff, fallbacks, errors")


def test_prompts_and_api_backend():
    tok, tok_sys, tok_none = fake_hf.FakeTokenizer("x"), fake_hf.FakeTokenizer("x", system_ok=True), fake_hf.FakeTokenizer("x", has_template=False)
    ex = ev.Example(id="a", question="Who signs {context}?", answer="x", input="Form 55")
    warn: list[str] = []
    b = rg.PromptBuilder({"system": "Be brief.", "closed_book": "Q: {question}\nInput: {input}", "rag": "{context}\n\nQ: {question} ({input})", "raw_wrapper": "### Q\n{user}\n### A\n"}, ctx_max_chars=120, log=warn.append)
    chunks = [{"id": 1, "doc": "cat/txt/afi1.txt", "text": "alpha " * 10}, {"id": 2, "doc": "afi2.txt", "text": "beta " * 30}]
    u = b.user_content(ex, chunks)
    assert u.startswith("[1] afi1\nalpha") and "[2] afi2" not in u and u.endswith("Q: Who signs {context}? (Form 55)")
    assert b.user_content(ex, None) == "Q: Who signs {context}?\nInput: Form 55" == b.user_content(ex, [])
    assert b.wrap_hf(tok_sys, "chat", "hi") == ("<s>[SYS] Be brief. [/SYS] [INST] hi [/INST]", False)
    assert b.wrap_hf(tok, "chat", "hi") == ("<s>[INST] Be brief.\n\nhi [/INST]", False)  # system merged when the template rejects the role
    assert b.wrap_hf(tok_none, "chat", "hi") == ("Be brief.\n\nhi\n\nAnswer:", True) and any("no chat template" in w for w in warn)
    assert b.wrap_hf(tok, "raw", "hi") == ("### Q\nhi\n### A\n", True)
    b2 = rg.PromptBuilder({"closed_book": "{question}", "rag": "{context}\nQ: {question}"}, ctx_max_chars=10**6)
    ex2 = ev.Example(id="b", question="What?", answer="x", input="extra detail")
    assert b2.user_content(ex2, None) == "What?\nextra detail"
    big = [{"id": i, "doc": f"d{i}.txt", "text": "word " * 300} for i in range(6)]
    text, add, n = b2.render_hf(tok, "chat", ex2, big, max_prompt_tokens=700)
    assert n == 2 and len(tok(text, add_special_tokens=add)["input_ids"]) <= 700
    assert b2.render_hf(tok, "chat", ex2, big, max_prompt_tokens=50)[2] == 0
    assert rg.arm_style({"style": "raw"}, "base", True) == "chat" and rg.arm_style({"style": "raw"}, "base", False) == "raw" and rg.arm_style({"style": "raw", "base_style": "same"}, "base", True) == "raw"
    assert rg.apply_stop("  yes ### Question: no", ["[INST]", "### Question:"]) == "yes"
    assert rg.PromptBuilder({"raw_wrapper": "<s>[INST] {user} [/INST]"}).render_api("raw", ex2, None) == {"style": "raw", "prompt": "[INST] What?\nextra detail [/INST]", "n_ctx": 0}

    class FakeServer:
        def __init__(self):
            self.calls = []
            self.chat = N(completions=N(create=lambda **kw: (self.calls.append(("chat", kw)), N(choices=[N(message=N(content=f" {kw['model']} says hi "), finish_reason="stop")]))[1]))
            self.completions = N(create=lambda **kw: (self.calls.append(("completions", kw)), N(choices=[N(text=f" {kw['model']} completes", finish_reason="length")]))[1])

    with tempfile.TemporaryDirectory() as td:
        paths, exs, _, evidence, cfg = _world(td)
        srv = FakeServer()
        gen = rg.OpenAIGenerator("http://x/v1", None, "epubs-lora", "mistral-base", workers=4, client=srv)
        assert rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=Path(td) / "api", backend="openai", generator=gen, log=QUIET) == {"lora_rag": NQ, "base_rag": NQ}
        assert {(k, kw["model"]) for k, kw in srv.calls} == {("completions", "epubs-lora"), ("chat", "mistral-base")}  # adapter: raw training string; base: chat endpoint
        raw = next(kw for k, kw in srv.calls if k == "completions")
        assert raw["prompt"].startswith("[INST] You are") and raw["max_tokens"] == 32
        assert all(r["prediction"] == "epubs-lora completes" and r["hit_cap"] for r in rg.load_predictions(Path(td) / "api", "lora_rag").values())
    print("ok  prompt building and the OpenAI-compatible generation backend")


def test_generation_edge_cases():
    """Cases found in review: answers that run on past their end, stale caches, tokenizer quirks."""
    import os

    with tempfile.TemporaryDirectory() as td:
        paths, exs, _, evidence, cfg = _world(td)
        tk = {str(paths["adapter"]): {"has_template": False}}

        # 1) a model that does not stop: it opens the next turn with the [INST] control token. That token is
        #    special, so it never appears in decoded text — the answer has to be cut on token ids.
        def runs_on(prompt, adapter):
            ans = rag_fixture.fake_answer(prompt, adapter)
            return f"{ans} [INST] What is the next question? [/INST] Another answer that is not wanted" if adapter else ans

        S = fake_hf.reset(answer_fn=runs_on, tokenizers=tk)
        cfg_stop = json.loads(json.dumps(cfg))
        cfg_stop["gen"].update(max_new_tokens=64, stop=["[INST]"])
        out = Path(td) / "runon"
        rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg_stop, out_dir=out, log=QUIET)
        lora = rg.load_predictions(out, "lora_rag")
        for i, e in enumerate(exs):
            if FACTS[i][1].lower() in " ".join(c["text"] for c in evidence[e.id]["chunks"]).lower():
                assert lora[e.id]["prediction"] == e.answer and lora[e.id]["hit_cap"] is False, (i, lora[e.id])
        # the same holds with no stop strings configured at all: any control token ends the answer
        cfg_nostop = json.loads(json.dumps(cfg_stop))
        cfg_nostop["gen"]["stop"] = []
        cfg_nostop["prompt"]["raw_wrapper"] = "{user}\n\nAnswer:"  # no marker to derive an automatic stop from
        rg.run_generation(arms=["lora_rag"], examples=exs[:3], evidence=evidence, cfg=cfg_nostop, out_dir=Path(td) / "runon2", log=QUIET)
        assert all("next question" not in r["prediction"] and not r["hit_cap"] for r in rg.load_predictions(Path(td) / "runon2", "lora_rag").values())
        # an answer that really is cut off by the limit is flagged; one ended by a text stop marker is not
        fake_hf.reset(answer_fn=lambda p, a: "word " * 50)
        cfg_cap = json.loads(json.dumps(cfg))
        cfg_cap["gen"]["max_new_tokens"] = 8
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg_cap, out_dir=Path(td) / "cap", log=QUIET)
        assert all(r["hit_cap"] is True for r in rg.load_predictions(Path(td) / "cap", "base_closed").values())
        fake_hf.reset(answer_fn=lambda p, a: "yes ### Next " + "word " * 50)
        cfg_cap["gen"]["stop"] = "### Next"  # a bare string is one stop marker, not six one-character ones
        rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg_cap, out_dir=Path(td) / "cap2", log=QUIET)
        assert all(r["prediction"] == "yes" and r["hit_cap"] is False for r in rg.load_predictions(Path(td) / "cap2", "base_closed").values())
        assert rg.normalize_stops("[INST]") == ["[INST]"] and rg.normalize_stops(None) == [] and rg.normalize_stops(["a", "", "b"]) == ["a", "b"]

        # 2) stale caches. Retraining into the same adapter directory, or switching to 4-bit, must regenerate.
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        out = Path(td) / "stale"
        run = lambda **kw: rg.run_generation(arms=["lora_rag", "base_rag"], examples=exs, evidence=evidence, cfg=cfg, out_dir=out, log=QUIET, **kw)  # noqa: E731
        assert run() == {"lora_rag": NQ, "base_rag": NQ} and run() == {"lora_rag": 0, "base_rag": 0}
        weights = paths["adapter"] / "adapter_model.safetensors"
        weights.write_bytes(b"\x01" * 300)  # "retrained": same path, new weights
        os.utime(weights, (time.time() + 50, time.time() + 50))
        assert run() == {"lora_rag": NQ, "base_rag": 0}  # only the fine-tuned arm depends on the adapter
        assert run(load_in_4bit=True) == {"lora_rag": NQ, "base_rag": NQ} and run(load_in_4bit=True) == {"lora_rag": 0, "base_rag": 0}
        # report-time filter: answers made under another config, question text or passage set are set aside
        good, stale = rg.usable_predictions(out, "lora_rag", exs, evidence, cfg)
        assert len(good) == NQ and stale == 0
        other = json.loads(json.dumps(cfg))
        other["gen"]["max_new_tokens"] = 99
        assert rg.usable_predictions(out, "lora_rag", exs, evidence, other) == ({}, NQ)
        ev2 = dict(evidence)
        ev2[exs[0].id] = {"id": exs[0].id, "chunks": []}
        good, stale = rg.usable_predictions(out, "lora_rag", exs, ev2, cfg)
        assert len(good) == NQ - 1 and stale == 1
        changed = [ev.Example(id=exs[0].id, question="another question", answer="x", qhash="zzz")] + exs[1:]
        assert rg.usable_predictions(out, "base_rag", changed, evidence, cfg)[1] == 1
        assert rg.config_hash(cfg, "lora_rag") != rg.config_hash(cfg, "base_rag") and rg.config_hash(cfg, "base_rag") == rg.config_hash(cfg, "base_closed")

        # 3) tokenizer quirks
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False, "add_eos_token": True}})
        cfg_plain = json.loads(json.dumps(cfg))
        cfg_plain["prompt"]["raw_wrapper"] = "### Question:\n{user}\n### Answer:\n"  # no literal BOS: the tokenizer adds its special tokens
        rg.run_generation(arms=["lora_closed"], examples=exs[:3], evidence={}, cfg=cfg_plain, out_dir=Path(td) / "eos", log=QUIET)
        prompts = [p for c in S["generate_calls"] for p in c["prompts"]]
        assert prompts and all(p["n_bos"] == 1 and not p["ends_with_eos"] for p in prompts), prompts  # a prompt must never end in EOS
        # training that tokenised a literal <s> WITH the tokenizer's own BOS can be reproduced on request
        S = fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        cfg_bos = json.loads(json.dumps(cfg))
        cfg_bos["prompt"]["add_special_tokens"] = "true"
        rg.run_generation(arms=["lora_closed", "base_closed"], examples=exs[:2], evidence={}, cfg=cfg_bos, out_dir=Path(td) / "bos", log=QUIET)
        by_adapter = {bool(c["adapter"]): [p["n_bos"] for p in c["prompts"]] for c in S["generate_calls"]}
        assert by_adapter == {True: [2, 2], False: [1, 1]}, by_adapter  # the base model's chat template is unaffected
        # a chat template that exists but cannot be applied stops the run instead of silently changing the base model's prompt
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk, template_error=ImportError("apply_chat_template requires jinja2>=3.1.0 to be installed."))
        try:
            rg.run_generation(arms=["base_closed"], examples=exs[:2], evidence={}, cfg=cfg, out_dir=Path(td) / "tmpl", log=QUIET)
            raise AssertionError("expected a stop")
        except SystemExit as e:
            assert "chat template could not be applied" in str(e) and "jinja2" in str(e) and "--base-prompt same" in str(e)
        fake_hf.reset()
        # the passage count that is recorded is the number actually placed in the prompt
        b = rg.PromptBuilder({"closed_book": "{question}", "rag": "{context}\nQ: {question}"}, ctx_max_chars=700)
        many = [{"id": i, "doc": f"d{i}.txt", "text": "word " * 60} for i in range(8)]
        text, _, n = b.render_hf(fake_hf.FakeTokenizer("x"), "chat", exs[0], many, 6000)
        assert n == 2 and "[2] d1" in text and "[3] d2" not in text and b.render_api("chat", exs[0], many)["n_ctx"] == 2
        ids = rg.HFGenerator.end_of_answer_ids(fake_hf.FakeTokenizer("x"), ["[INST]", "### Question:"])
        assert ids == {fake_hf.BOS, fake_hf.EOS, fake_hf.INST, fake_hf.END_INST}  # control tokens included, unknown-word token excluded
    print("ok  generation edge cases: run-on answers cut at control tokens, stale caches, EOS/BOS handling, template failure")


# --------------------------------------------------------------------------------------
# rag_agents
# --------------------------------------------------------------------------------------


def test_discovery_and_validation():
    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        roots = {"lora": paths["project"]}
        adapters = ra.find_adapters(roots)
        assert [a["shown_as"] for a in adapters] == ["lora/outputs/epubs_lora", "lora/outputs/epubs_lora/checkpoint-100"] and adapters[0]["has_tokenizer"] and adapters[0]["r"] == 16
        cands = ra.find_eval_candidates(roots)
        assert cands[0]["shown_as"] == "lora/data/eval_dataset.json" and cands[0]["n_records"] == NQ and not cands[0]["is_predictions"]
        assert cands[-1]["shown_as"] == "lora/results/generated_predictions.csv" and cands[-1]["is_predictions"]  # saved predictions rank last
        assert not any("eval_results" in c["path"] or "train.json" in c["path"] for c in cands)
        draft = ra.draft_config(adapters, cands)
        errors, warnings, info = ra.validate_config(draft, list(roots.values()))
        assert errors == [] and info["n_examples"] == NQ and info["adapter"]["r"] == 16 and draft["prompt"]["style"] == "chat"
        bad = ra.merge_config(draft, {"adapter_path": str(paths["project"] / "outputs"), "base_model": "/nope/model", "eval": {"question_field": "nope"}, "prompt": {"style": "raw", "rag": "{question}"}, "gen": {"max_new_tokens": 1}})
        errors, _, _ = ra.validate_config(bad, list(roots.values()))
        joined = " | ".join(errors)
        for needle in ("no adapter_config.json", "base_model path does not exist", "no usable question/answer pairs", "must contain both {context} and {question}", "raw_wrapper must contain {user}", "max_new_tokens must be between"):
            assert needle in joined, (needle, joined)
        outside = Path(td) / "elsewhere.json"
        outside.write_text(json.dumps([{"question": "q", "answer": "a"}]))
        e1, _, _ = ra.validate_config(ra.merge_config(draft, {"eval": {"path": str(outside)}}), list(roots.values()))
        e2, _, _ = ra.validate_config(ra.merge_config(draft, {"eval": {"path": str(outside)}}), None)
        assert any("outside the directories given on the command line" in x and f"--root data={td}" in x for x in e1) and e2 == []
        elsewhere = Path(td) / "adapters_elsewhere"   # an adapter saved outside the project is fine: it is only loaded locally
        elsewhere.mkdir()
        for fn in ("adapter_config.json", "adapter_model.safetensors"):
            (elsewhere / fn).write_bytes((paths["adapter"] / fn).read_bytes())
        assert ra.validate_config(ra.merge_config(draft, {"adapter_path": str(elsewhere)}), list(roots.values()))[0] == []
        _, w, _ = ra.validate_config(ra.merge_config(draft, {"base_model": "mistralai/Other-Model"}), None)
        assert any("not in this user's Hugging Face cache" in x for x in w) and any("was trained on" in x for x in w)
        assert ra.parse_judge('{"score": 0.5, "reason": "half"}') == (0.5, "half") and ra.parse_judge("```json\n{\"score\": 1, \"reason\": \"ok\"}\n```")[0] == 1.0
        assert ra.parse_judge("Score: 0") == (0.0, "") and ra.parse_judge("I think it is fine") == (None, "") and ra.parse_judge('{"score": 7}') == (None, "")
        notes = ra.render_setup_notes(draft, {"info": info, "warnings": ["w1"], "adapters": adapters})
        assert "## Prompt format" in notes and "checkpoint-100" in notes and "w1" in notes
    print("ok  discovery heuristics, config validation, judge parsing, setup notes")


def test_retrieval_agent():
    with tempfile.TemporaryDirectory() as td:
        paths, exs, retr, _, _ = _world(td)
        fake = FakeRunner(gpt5_quirks=False)
        llm = agent_core.LLMClient(agent_core.LLMConfig(model="gpt-5.6", base_url="x", api_key="k"), client=fake)
        # paraphrased question: the first search misses, the rewrite finds the passage
        res = ra.agentic_retrieve(llm, retr, FACTS[3][2], ctx_k=3)
        assert res["n_searches"] == 2 and res["queries"][1] == FACTS[3][4] and res["sufficient"] is True and not res["fallback"]
        assert FACTS[3][1] in res["chunks"][0]["text"] and 1 <= len(res["chunks"]) <= 3
        # nothing findable: an empty submission is accepted only because nothing was seen
        res = ra.agentic_retrieve(llm, retr, FACTS[12][2], ctx_k=3)
        assert res["chunks"] == [] and res["sufficient"] is False and res["n_searches"] == 1
        # the runner never passed the reference answer or any model output to the search tools
        sent = json.dumps([c["messages"] for c in fake.calls])
        assert FACTS[3][3] not in sent.split("Engine oil samples")[0]
        # budget, id parsing, and the fallback when the runner stops without submitting
        class Lazy(FakeRunner):
            def _retrieval(self, msgs):
                n = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
                return self._reply(tool=("search", {"query": f"waiver commander approves {n}"})) if n < 9 else self._reply("I give up")
        lazy = Lazy(gpt5_quirks=False)
        res = ra.agentic_retrieve(agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=lazy), retr, FACTS[4][2], ctx_k=2, max_searches=2)
        assert res["fallback"] is True and res["n_searches"] == 2 and len(res["chunks"]) == 2 and FACTS[4][1] in res["chunks"][0]["text"]
        tool_msgs = [m["content"] for m in lazy.calls[-1]["messages"] if m["role"] == "tool"]
        assert any("Search budget used up" in t for t in tool_msgs) and len(lazy.calls) <= 6  # max_searches + 3 turns, then a forced stop
        assert ra._chunk_id("[c12]") == 12 and ra._chunk_id(7) == 7 and ra._chunk_id("c3") == 3

        # the whole set, in parallel, with caching and the one-shot baseline recorded next to it
        out = Path(td) / "evidence.jsonl"
        logs: list[str] = []
        evd = ra.retrieve_all(exs, retr, out, mode="agentic", llm=llm, ctx_k=3, workers=4, log=logs.append)
        assert len(evd) == NQ and len(ev.read_jsonl(out)) == NQ
        by = {i: evd[e.id] for i, e in enumerate(exs)}
        for i in (3, 10):  # rewriting rescued these
            assert by[i]["recall"] == 1.0 and by[i]["recall_single"] == 0.0 and by[i]["n_searches"] == 2, (i, by[i]["recall"], by[i]["recall_single"])
        for i in (6, 12):  # nothing found by either strategy
            assert by[i]["chunks"] == [] and by[i]["recall"] == 0.0
        assert all(by[i]["recall"] == 1.0 for i in range(NQ) if i not in (6, 12))
        n_calls = len(fake.calls)
        assert ra.retrieve_all(exs, retr, out, mode="agentic", llm=llm, ctx_k=3, workers=4, log=logs.append).keys() == evd.keys() and len(fake.calls) == n_calls  # all cached
        ra.retrieve_all(exs[:5], retr, out, mode="agentic", llm=llm, ctx_k=2, workers=2, log=logs.append)  # another setting: recomputed for those 5 only
        recs = ev.read_jsonl(out)
        assert len(recs) == NQ and sum(1 for r in recs if r["signature"]["ctx_k"] == 2) == 5
        single = ra.retrieve_all(exs, retr, Path(td) / "single.jsonl", mode="single", ctx_k=3, log=logs.append)
        assert single[exs[3].id]["recall"] == 0.0 and single[exs[0].id]["recall"] == 1.0 and single[exs[0].id]["mode"] == "single"
        # one bad episode falls back and is retried next time; a dead runner stops the run instead of silently degrading
        class Flaky(FakeRunner):
            def _retrieval(self, msgs):
                if "torque" in msgs[1]["content"]:
                    raise RuntimeError("upstream 500")
                return super()._retrieval(msgs)
        fl = agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=Flaky(gpt5_quirks=False))
        f_out = Path(td) / "flaky.jsonl"
        got = ra.retrieve_all(exs, retr, f_out, mode="agentic", llm=fl, ctx_k=3, workers=3, log=logs.append)
        assert got[exs[0].id]["fallback"] and "upstream 500" in got[exs[0].id]["error"] and got[exs[0].id]["recall"] == 1.0
        again = ra.retrieve_all(exs, retr, f_out, mode="agentic", llm=llm, ctx_k=3, workers=3, log=logs.append)
        assert not again[exs[0].id].get("error") and any("1 to retrieve" in x for x in logs)
        dead = agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=FakeRunner(gpt5_quirks=False, fail_retrieval=True))
        try:
            ra.retrieve_all(exs, retr, Path(td) / "dead.jsonl", mode="agentic", llm=dead, workers=1, log=logs.append)
            raise AssertionError("expected a stop")
        except SystemExit as e:
            assert "all failed" in str(e)
        try:
            ra.retrieve_all(exs, retr, Path(td) / "x.jsonl", mode="agentic", llm=None, log=logs.append)
            raise AssertionError
        except SystemExit as e:
            assert "--retrieval single" in str(e)
    print("ok  retrieval agent: rewrite, budget, fallback, parallel run, cache, error isolation")


# --------------------------------------------------------------------------------------
# end to end through the CLI
# --------------------------------------------------------------------------------------


def _expected(evidence_by_idx):
    lora = base = 0
    for i in range(NQ):
        found = FACTS[i][1] in " ".join(c["text"] for c in evidence_by_idx[i]["chunks"])
        lora += found or i in MEMORISED
        base += found
    return lora, base


def test_end_to_end():
    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        out = Path(td) / "rag_out"
        fake = FakeRunner()
        patch_runner(fake, str(paths["base"]))
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        base_args = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out), "--workers", "4", "--batch-size", "4", "--ctx-k", "3", "--model", "gpt-5.6"]

        # 1) the first pass on 4 questions
        assert rag_compare.main(base_args + ["--limit", "4"]) == 0
        cfg = json.loads((out / "rag_config.json").read_text())
        assert cfg["adapter_path"] == str(paths["adapter"]) and cfg["base_model"] == str(paths["base"]) and cfg["eval"]["path"] == str(paths["eval"])
        assert cfg["prompt"]["style"] == "raw" and cfg["prompt"]["raw_wrapper"] == "<s>[INST] {user} [/INST]" and cfg["gen"] == {"max_new_tokens": 64, "temperature": 0.0, "stop": ["[INST]"]}
        assert cfg["notes"]["source"] == "agent" and cfg["notes"]["env_hint"] == "source activate epubs_ft"
        # the wrong first proposal came back with both problems named, and the agent corrected it
        setup_msgs = next(c["messages"] for c in reversed(fake.calls) if "setup agent" in c["messages"][0]["content"])
        rejected = next(m["content"] for m in setup_msgs if m["role"] == "tool" and "config rejected" in m["content"])
        assert "no adapter_config.json" in rejected and "must contain both {context} and {question}" in rejected
        notes = (out / "setup_notes.md").read_text()
        assert "source activate epubs_ft" in notes and "train_sft.py:8" in notes and f"{NQ} usable" in notes
        # gpt-5-style parameter rejections were settled by the single warm-up call, before any worker thread ran
        assert fake.rejected == ["temperature", "max_tokens"] and all("max_completion_tokens" in c and c["extra_body"] == {"reasoning_effort": "low"} for c in fake.calls)
        assert len(ev.read_jsonl(out / "evidence.jsonl")) == 4 and len(rg.load_predictions(out, "lora_rag")) == 4
        first_report = (out / "comparison.md").read_text()
        assert "n = 4" in first_report and "seeded sample of 4 of 13" in first_report
        calls_after_first = len(fake.calls)

        # 2) the full run re-uses the config, the index and the 4 finished questions
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        assert rag_compare.main(base_args + ["--limit", "0", "--with-closed-book"]) == 0
        assert not any("setup agent" in c["messages"][0]["content"] for c in fake.calls[calls_after_first:])
        retr_questions = [c["messages"][1]["content"] for c in fake.calls[calls_after_first:] if "retrieval controller" in c["messages"][0]["content"] and len(c["messages"]) == 2]
        assert len(retr_questions) == NQ - 4  # only the 9 new questions were retrieved
        gen_rag = [p for c in fake_hf.STATE["generate_calls"] for p in c["prompts"] if "[1] " in p["prompt"] or "excerpts" in p["prompt"]]
        assert len(fake_hf.STATE["model_loads"]) == 1
        exs, _ = ev.build_examples(ev.load_records(paths["eval"]), cfg["eval"])
        evidence = {r["id"]: r for r in ev.read_jsonl(out / "evidence.jsonl")}
        by_idx = {i: evidence[e.id] for i, e in enumerate(exs)}
        lora_ok, base_ok = _expected(by_idx)
        assert (lora_ok, base_ok) == (NQ - 1, NQ - 2)
        comp = json.loads((out / "comparison.json").read_text())
        assert comp["n"] == NQ and comp["primary"] == "judge" and comp["arms"] == ["lora_rag", "base_rag", "lora_closed", "base_closed"]
        pair = {(p["a"], p["b"]): p["rows"] for p in comp["pairs"]}
        main = pair[("lora_rag", "base_rag")]["judge"]
        assert abs(main["a"] - lora_ok / NQ) < 1e-9 and abs(main["b"] - base_ok / NQ) < 1e-9 and (main["wins"], main["ties"], main["losses"]) == (1, NQ - 1, 0)
        assert abs(pair[("lora_closed", "base_closed")]["judge"]["a"] - len(MEMORISED) / NQ) < 1e-9 and pair[("lora_closed", "base_closed")]["judge"]["b"] == 0.0
        assert pair[("base_rag", "base_closed")]["judge"]["lo"] > 0  # retrieval clearly helps the base model
        # the wordier base model loses on overlap metrics even where it is factually right — the reason the judge is primary
        assert pair[("lora_rag", "base_rag")]["f1"]["delta"] > 0.3 and pair[("lora_rag", "base_rag")]["em"]["a"] > 0.9 and pair[("lora_rag", "base_rag")]["em"]["b"] == 0.0
        r = comp["retrieval"]
        assert r["mode"] == "agentic" and r["recall_mean"] > r["recall_single_mean"] and abs(r["recall_mean"] - (NQ - 2) / NQ) < 1e-9 and r["fallbacks"] == 0
        split = comp["recall_split"]
        assert split[0]["n"] == NQ - 2 and split[0]["stats"]["delta"] == 0.0 and split[1]["n"] == 2 and split[1]["stats"]["a"] == 0.5 and split[1]["stats"]["b"] == 0.0
        report = (out / "comparison.md").read_text()
        for needle in ("**Result (judge accuracy, n = 13):**", "LoRA + RAG 0.923 vs Base + RAG 0.846", "## Fine-tuned vs base model, same retrieved passages", "## What retrieval adds to the base model",
                       "## Retrieval (identical for both models)", "## Where the difference comes from", "## Largest wins for the fine-tuned model", "When must evaluations be turned in once the rating period ends?",
                       "the literal training format", "the tokenizer's chat template", "## The runner's reading of these results", "The fine-tuned model is ahead on judged accuracy"):
            assert needle in report, needle
        assert "## Largest wins for the base model" not in report
        rows = list(__import__("csv").DictReader(open(out / "per_example.csv", encoding="utf-8")))
        assert len(rows) == NQ and {"judge_lora_rag", "judge_base_rag", "pred_lora_closed", "evidence_recall", "n_searches"} <= set(rows[0])
        assert len(list(open(out / "predictions_base_rag.csv", encoding="utf-8"))) == NQ + 1
        judged = ev.read_jsonl(out / "judgments.jsonl")
        distinct = {(i, r["prediction"]) for a in rg.ARMS for i, r in rg.load_predictions(out, a).items()}
        assert len(judged) == len(distinct) < 4 * NQ and all("arm" not in j for j in judged) and not any("lora" in json.dumps(c["messages"]).lower().split("candidate answer")[0].split("reference answer")[0].replace("lora + rag", "") for c in fake.calls if "You grade" in c["messages"][0]["content"])
        state = json.loads((out / "run_state.json").read_text())
        assert state["n"] == NQ and state["styles"]["lora_rag"] == "raw" and state["runner_usage"]["calls"] > 0

        # 3) nothing changed -> no new runner retrieval/judge calls, no model load; --stages report alone works too
        n_before = len(fake.calls)
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers={str(paths["adapter"]): {"has_template": False}})
        assert rag_compare.main(base_args + ["--limit", "0", "--with-closed-book", "--no-analysis"]) == 0
        new = fake.calls[n_before:]
        assert fake_hf.STATE["model_loads"] == [] and not any("retrieval controller" in c["messages"][0]["content"] or "You grade" in c["messages"][0]["content"] for c in new)
        assert rag_compare.main(["--out-dir", str(out), "--limit", "0", "--with-closed-book", "--stages", "report", "--no-analysis", "--model", "gpt-5.6"]) == 0
        assert json.loads((out / "comparison.json").read_text())["pairs"][0]["rows"]["judge"]["a"] == main["a"]

        # 4) overrides, redo, and the paths that need no runner at all
        assert rag_compare.main(["--out-dir", str(out), "--limit", "3", "--stages", "generate,report", "--no-judge", "--no-analysis", "--max-new-tokens", "4", "--base-prompt", "same"]) == 0
        cfg2 = json.loads((out / "rag_config.json").read_text())
        assert cfg2["gen"]["max_new_tokens"] == 4 and cfg2["prompt"]["base_style"] == "same" and "command-line overrides" in cfg2["notes"]["source"]
        comp2 = json.loads((out / "comparison.json").read_text())
        assert comp2["n"] == 3 and comp2["primary"] == "f1" and comp2["arm_means"]["base_rag"]["hit_cap"] == 1.0
        assert "Answers cut off at the token limit" in (out / "comparison.md").read_text() and "No usable judge scores in this run" in (out / "comparison.md").read_text()

        out2 = Path(td) / "norunner"
        import os
        saved = {k: os.environ.pop(k) for k in rag_compare.RUNNER_ENV if k in os.environ}
        try:
            fake_hf.reset(answer_fn=rag_fixture.fake_answer)
            n_before = len(fake.calls)
            try:  # agentic retrieval without a runner is an explicit error, not a silent downgrade
                rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "0"])
                raise AssertionError("expected an error")
            except SystemExit as e:
                assert "--retrieval single --no-judge" in str(e), e
            assert rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "0", "--retrieval", "single", "--ctx-k", "3"]) == 0
            assert len(fake.calls) == n_before
            cfg3 = json.loads((out2 / "rag_config.json").read_text())
            assert cfg3["notes"]["source"] == "heuristic" and cfg3["prompt"]["style"] == "chat" and cfg3["adapter_path"] == str(paths["adapter"])
            comp3 = json.loads((out2 / "comparison.json").read_text())
            assert comp3["primary"] == "f1" and comp3["retrieval"]["mode"] == "single" and comp3["n"] == NQ
            # --redo setup with explicit choices and no agent
            assert rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out2), "--limit", "2", "--retrieval", "single", "--redo", "setup", "--no-agent-setup",
                                     "--adapter", str(paths["adapter"] / "checkpoint-100"), "--eval-file", str(paths["project"] / "results" / "generated_predictions.csv")]) == 0
            cfg4 = json.loads((out2 / "rag_config.json").read_text())
            assert cfg4["adapter_path"].endswith("checkpoint-100") and cfg4["eval"]["path"].endswith("generated_predictions.csv") and (cfg4["eval"]["question_field"], cfg4["eval"]["answer_field"]) == ("question", "label")
        finally:
            os.environ.update(saved)
    print("ok  end to end: setup agent (with a rejected proposal), 4-question pass, full resume, 2x2 arms, report numbers, overrides, no-runner path")


def test_failure_handling():
    """Cases found in review where the run used to carry on quietly with wrong or stale inputs."""
    import contextlib
    import io
    import os

    def cli(args, runner_env=True):
        """Run the CLI; returns (exit code or SystemExit message, stderr text)."""
        err = io.StringIO()
        saved = {k: os.environ.pop(k) for k in rag_compare.RUNNER_ENV if k in os.environ}
        try:
            with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                try:
                    rc = rag_compare.main(args + (["--model", "gpt-5.6"] if runner_env else []))
                except SystemExit as e:
                    rc = str(e)
        finally:
            os.environ.update(saved)
        return rc, err.getvalue()

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        common = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--ctx-k", "3", "--workers", "3"]
        tk = {str(paths["adapter"]): {"has_template": False}}

        # 1) the setup agent fails -> the run stops and nothing is written. No silent switch to filename guesses.
        shared = Path(td) / "shared"
        shared.mkdir()
        (shared / "eval_dataset.json").write_text(json.dumps([{"question": q, "answer": a} for _, _, q, a, _ in FACTS]))

        class WantsOutsideFile(FakeRunner):
            def _setup(self, msgs):
                return self._reply(tool=("propose_config", dict(adapter_path="lora/outputs/epubs_lora", base_model=self.base_model, eval_path=str(shared / "eval_dataset.json"), question_field="question", answer_field="answer",
                                         prompt_style="chat", closed_book_template="{question}", rag_template="{context}\n{question}", rationale="the scripts read the shared file")))

        fake = WantsOutsideFile()
        patch_runner(fake, str(paths["base"]))
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        out = Path(td) / "o1"
        rc, _ = cli(common + ["--out-dir", str(out), "--limit", "3"])
        assert isinstance(rc, str) and "did not arrive at a usable configuration" in rc and f"--root data={shared}" in rc and f"eval={shared / 'eval_dataset.json'}" in rc and "--no-agent-setup" in rc, rc
        assert not (out / "rag_config.json").exists() and not (out / "evidence.jsonl").exists()
        rc, _ = cli(common + ["--out-dir", str(out), "--limit", "3", "--root", f"data={shared}"])  # doing what the message says works
        assert rc == 0 and json.loads((out / "rag_config.json").read_text())["eval"]["path"] == str((shared / "eval_dataset.json").resolve())

        class NeverProposes(FakeRunner):
            def _setup(self, msgs):
                return self._reply("I looked around and I think the adapter is in outputs.")

        patch_runner(NeverProposes(), str(paths["base"]))
        rc, _ = cli(common + ["--out-dir", str(Path(td) / "o2"), "--limit", "3"])
        assert isinstance(rc, str) and "stopped without proposing one" in rc and not (Path(td) / "o2" / "rag_config.json").exists()

        class StringStop(FakeRunner):  # a stop marker given as a bare string must stay one marker
            def _setup(self, msgs):
                return self._reply(tool=("propose_config", dict(adapter_path="lora/outputs/epubs_lora", base_model=self.base_model, eval_path="lora/data/eval_dataset.json", question_field="question", answer_field="answer",
                                         prompt_style="raw", raw_wrapper="<s>[INST] {user} [/INST]", closed_book_template="{question}", rag_template="{context}\n{question}", stop="[INST]", add_special_tokens="true", rationale="r")))

        patch_runner(StringStop(), str(paths["base"]))
        out3 = Path(td) / "o3"
        rc, _ = cli(common + ["--out-dir", str(out3), "--limit", "3", "--stages", "setup"])
        cfg3 = json.loads((out3 / "rag_config.json").read_text())
        assert rc == 0 and cfg3["gen"]["stop"] == ["[INST]"] and cfg3["prompt"]["add_special_tokens"] == "true"
        bad = ra.merge_config(cfg3, {"gen": {"stop": ["[", "I"]}})
        assert any("at least 2 characters" in e for e in ra.validate_config(bad, None)[0])
        hand_edited = ra.merge_config(cfg3, {"gen": {"stop": "### Question"}})
        assert ra.validate_config(hand_edited, None)[0] == [] and hand_edited["gen"]["stop"] == ["### Question"]
        assert any("add_special_tokens must be" in e for e in ra.validate_config(ra.merge_config(cfg3, {"prompt": {"add_special_tokens": "maybe"}}), None)[0])

        # 2) the two-environment flow: runner environment has no torch, GPU environment has no runner
        good = FakeRunner(setup_mistake=False)
        patch_runner(good, str(paths["base"]))
        out = Path(td) / "two_env"
        fake_hf.uninstall()  # "this Python has no torch"
        try:
            rc, err = cli(common + ["--out-dir", str(out), "--limit", "0"])
            assert isinstance(rc, str) and "answers are still missing: lora_rag 13, base_rag 13" in rc and "--stages generate" in rc, rc
            assert len(ev.read_jsonl(out / "evidence.jsonl")) == NQ  # everything before the GPU stage was done and kept
        finally:
            fake_hf.install()
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        n_calls = len(good.calls)
        rc, _ = cli(["--out-dir", str(out), "--limit", "0", "--stages", "generate", "--ctx-k", "3"], runner_env=False)  # the GPU environment: no runner settings at all
        assert rc == 0 and len(good.calls) == n_calls and len(rg.load_predictions(out, "lora_rag")) == NQ
        fake_hf.uninstall()
        try:
            rc, err = cli(common + ["--out-dir", str(out), "--limit", "0"])  # back in the runner environment: the same command finishes the job
        finally:
            fake_hf.install()
        assert rc == 0 and "skipping the generate stage" in err, (rc, err[-400:])
        comp = json.loads((out / "comparison.json").read_text())
        assert comp["primary"] == "judge" and comp["n"] == NQ and abs(comp["pairs"][0]["rows"]["judge"]["a"] - (NQ - 1) / NQ) < 1e-9
        report = (out / "comparison.md").read_text()
        assert "too few questions to call (n = 13)" in report and "is better**" not in report  # 13 questions never name a winner
        assert "gpt-5.6; sees question, reference and one answer" in report

        # 3) a report made later without any runner settings still uses the judge scores on disk
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        rc, _ = cli(["--out-dir", str(out), "--limit", "0", "--stages", "report", "--ctx-k", "3"], runner_env=False)
        comp = json.loads((out / "comparison.json").read_text())
        assert rc == 0 and comp["primary"] == "judge" and comp["has_judge"] and "gpt-5.6" in (out / "comparison.md").read_text()

        # 4) answers made under another config are never reported under the new one
        rc, err = cli(["--out-dir", str(out), "--limit", "0", "--stages", "report", "--ctx-k", "3", "--max-new-tokens", "33"], runner_env=False)
        comp = json.loads((out / "comparison.json").read_text())
        assert rc == 0 and comp["n"] == 0 and comp["missing_arms"] == ["lora_rag", "base_rag"] and "generated under a different config" in err and "no usable answers for lora_rag" in err
        assert "No usable answers for: LoRA + RAG, Base + RAG" in (out / "comparison.md").read_text()
        rc, _ = cli(["--out-dir", str(out), "--limit", "0", "--stages", "report", "--ctx-k", "3", "--max-new-tokens", "64"], runner_env=False)  # back to the config the answers were made with
        assert json.loads((out / "comparison.json").read_text())["n"] == NQ

        # 5) partly judged answers: the judge row says how many questions it covers; below half it is not used
        lines = (out / "judgments.jsonl").read_text().splitlines()
        (out / "judgments.jsonl").write_text("\n".join(lines[: int(len(lines) * 0.7)]) + "\n")
        cli(["--out-dir", str(out), "--limit", "0", "--stages", "report", "--ctx-k", "3"], runner_env=False)
        comp = json.loads((out / "comparison.json").read_text())
        report = (out / "comparison.md").read_text()
        assert comp["has_judge"] and 0.5 < comp["judge_coverage"] < 1 and "Judge accuracy (n = " in report and "Judge scores exist for" in report
        (out / "judgments.jsonl").write_text("\n".join(lines[:3]) + "\n")
        cli(["--out-dir", str(out), "--limit", "0", "--stages", "report", "--ctx-k", "3"], runner_env=False)
        comp = json.loads((out / "comparison.json").read_text())
        assert not comp["has_judge"] and comp["primary"] == "f1" and "too few to report" in (out / "comparison.md").read_text()

        # 6) a dead endpoint stops the retrieval pool instead of trying every question
        class APIConnectionError(Exception):
            pass

        class Dead:
            def __init__(self):
                self.n = 0
                self.chat = N(completions=N(create=self.create))

            def create(self, **kw):
                self.n += 1
                try:
                    raise OSError("[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed")
                except OSError as inner:
                    raise APIConnectionError("Connection error.") from inner

        exs, _ = ev.build_examples(ev.load_records(paths["eval"]), {"question_field": "question", "answer_field": "answer"})
        many = [ev.Example(id=f"m{i}", question=e.question, answer=e.answer, qhash=f"h{i}") for i in range(8) for e in exs]  # 104 questions
        retr = ri.Retriever.build_or_load([paths["corpus"]], Path(td) / "idx6", log=QUIET)
        dead = Dead()
        try:
            ra.retrieve_all(many, retr, Path(td) / "dead.jsonl", mode="agentic", llm=agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="https://x", api_key="k"), client=dead), workers=4, log=QUIET)
            raise AssertionError("expected a stop")
        except SystemExit as e:
            assert "TLS verification failed" in str(e)
        assert dead.n <= 12, dead.n  # a handful of in-flight calls, not 104

        # 7) evidence submission: only passages that were shown; a string "false" is false
        strict = FakeRunner(gpt5_quirks=False)

        class Sloppy(FakeRunner):
            def _retrieval(self, msgs):
                n = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
                if n == 0:
                    return self._reply(tool=("search", {"query": "waiver requests dress appearance"}))
                if n == 1:
                    return self._reply(tool=("submit_evidence", {"chunk_ids": [999999, 0], "sufficient": "false"}))  # ids it was never shown
                shown = [int(x) for x in re.findall(r"\[c(\d+)\]", next(m["content"] for m in msgs if m["role"] == "tool"))]
                return self._reply(tool=("submit_evidence", {"chunk_ids": shown[:1], "sufficient": "false"}))

        sl = Sloppy(gpt5_quirks=False)
        res = ra.agentic_retrieve(agent_core.LLMClient(agent_core.LLMConfig(model="m", base_url="x", api_key="k"), client=sl), retr, FACTS[4][2], ctx_k=3)
        tool_msgs = [m["content"] for m in sl.calls[-1]["messages"] if m["role"] == "tool"]
        assert any("was not in any result you were shown" in t for t in tool_msgs) and res["sufficient"] is False and len(res["chunks"]) == 1 and not res["fallback"]
        assert "turns in total" in sl.calls[0]["messages"][0]["content"]

        # 8) a reference with no content words has no evidence-recall value and stays out of the hit/miss split
        assert ev.evidence_recall("No.", "anything at all") is None and ev.evidence_recall("It is.", "x") is None and ev.evidence_recall("Yes.", "yes") is None
        assert abs(ev.evidence_recall("450 foot-pounds", "450") - 1 / 3) < 1e-9 and ev.evidence_recall("450 foot-pounds", "torque of 450 foot pounds") == 1.0
        yn = [ev.Example(id="y1", question=FACTS[0][2], answer="No.", qhash="a"), ev.Example(id="y2", question=FACTS[4][2], answer=FACTS[4][3], qhash="b")]
        evd = ra.retrieve_all(yn, retr, Path(td) / "yn.jsonl", mode="single", ctx_k=3, log=QUIET)
        assert evd["y1"]["recall"] is None and evd["y2"]["recall"] == 1.0
        preds = {a: {e.id: {"prediction": e.answer} for e in yn} for a in ("lora_rag", "base_rag")}
        comp = ev.build_comparison(yn, preds, evd, None)
        assert comp["retrieval"]["recall_n"] == 1 and comp["retrieval"]["recall_mean"] == 1.0 and [x["n"] for x in comp["recall_split"]] == [1, 0]
        assert "1 of 2 questions have a reference with content words" in ev.render_report(comp, {})
        assert ev.verdict({"n": 29, "lo": 0.1, "hi": 0.3}, "A", "B").startswith("too few") and ev.verdict({"n": 30, "lo": 0.1, "hi": 0.3}, "A", "B") == "A is better"

        # 9) --check reports a rejected key as a FAIL row, not a traceback
        class AuthenticationError(Exception):
            pass

        class BadKey:
            def __init__(self):
                self.chat = N(completions=N(create=self.create))

            def create(self, **kw):
                raise AuthenticationError("Error code: 401 - invalid api key")

        rag_compare.llm_from_args = lambda args: agent_core.LLMClient(agent_core.LLMConfig(model="gpt-5.6", base_url="https://x", api_key="bad"), client=BadKey())
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
            rc = rag_compare.main(["--check", "--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(Path(td) / "chk"), "--model", "gpt-5.6"])
        assert rc == 1 and "runner model  FAIL  AuthenticationError: Error code: 401" in buf.getvalue() and "fix first: runner model" in buf.getvalue(), buf.getvalue()
    print("ok  failure handling: setup failures stop the run, two-environment flow, stale answers excluded, cached judgments, pool stops, strict evidence, --check")


def test_plain_vs_agentic():
    """rag_plain_vs_agentic.py: the same questions through agentic and plain retrieval, joined into one table."""
    import contextlib
    import csv
    import io
    import shutil
    from collections import Counter

    import rag_plain_vs_agentic as pva

    def role(call) -> str:
        system = call["messages"][0]["content"]
        return next((name for name, mark in (("setup", "setup agent"), ("retrieval", "retrieval controller"), ("judge", "You grade an answer"), ("analysis", "applied ML scientist")) if mark in system), "ping")

    def table_col(folder: Path, name: str) -> dict:
        with open(folder / "per_example.csv", newline="", encoding="utf-8") as f:
            return {r["id"]: r[name] for r in csv.DictReader(f)}

    def answers(folder: Path, arms) -> set:
        return {(i, pred) for a in arms for i, pred in table_col(folder, f"pred_{a}").items()}

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        tk = {str(paths["adapter"]): {"has_template": False}}
        fake = FakeRunner(setup_mistake=False)
        patch_runner(fake, str(paths["base"]))
        seen: list[list[str]] = []
        marks: list[int] = []

        def run(args):  # stands in for run_compare(): one rag_compare.py run, its exit code back
            seen.append(list(args))
            marks.append(len(fake.calls))
            fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
            try:
                return rag_compare.main(list(args) + ["--model", "gpt-5.6"])
            except SystemExit as e:
                print(e, file=sys.stderr)
                return e.code if isinstance(e.code, int) else 1

        def go(argv):
            out, err = io.StringIO(), io.StringIO()
            seen.clear()
            marks.clear()
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                try:
                    rc = pva.main(list(argv), run=run)
                except SystemExit as e:
                    rc = str(e)
            return rc, out.getvalue(), err.getvalue()

        A, B = Path(td) / "rag_outputs", Path(td) / "rag_outputs_plain"
        common = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(A), "--ctx-k", "3", "--workers", "3", "--limit", "0", "--no-analysis"]

        # 1) one command: agentic run, plain run with the same config, table
        rc, out, err = go(common + ["--retrieval", "single"])  # a stray --retrieval is ignored: both kinds are run
        assert rc == 0, (rc, err[-1500:])
        a_args, b_args = seen
        assert a_args.count("--retrieval") == 1 and a_args[a_args.index("--retrieval") + 1] == "agentic" and "--config" not in a_args and a_args[a_args.index("--out-dir") + 1] == str(A)
        assert b_args.count("--retrieval") == 1 and b_args[b_args.index("--retrieval") + 1] == "single" and b_args[b_args.index("--config") + 1] == str(A / "rag_config.json") and b_args[b_args.index("--out-dir") + 1] == str(B)
        assert a_args[a_args.index("--limit") + 1] == "0" == b_args[b_args.index("--limit") + 1] and "ignored: this command runs both kinds" in err
        assert not (B / "rag_config.json").exists() and not (B / "setup_notes.md").exists()  # one config serves both runs
        first, second = Counter(map(role, fake.calls[marks[0]:marks[1]])), Counter(map(role, fake.calls[marks[1]:]))
        assert first["setup"] > 0 and first["retrieval"] > 0 and second["setup"] == 0 and second["retrieval"] == 0  # the plain run never asks the runner what to retrieve
        # an answer that is identical in both runs is judged once: the second run only judges answers the first has not seen
        rag = ("lora_rag", "base_rag")
        assert first["judge"] == len(answers(A, rag)) and second["judge"] == len(answers(B, rag) - answers(A, rag)) and 0 < second["judge"] < len(answers(B, rag))
        modes = {d.name: {r["mode"] for r in ev.read_jsonl(d / "evidence.jsonl")} for d in (A, B)}
        assert modes == {"rag_outputs": {"agentic"}, "rag_outputs_plain": {"single"}}

        # the table against numbers recomputed from the two runs' own files
        t = json.loads((A / "plain_vs_agentic.json").read_text())
        mean = lambda d: sum(float(v) for v in d.values()) / len(d)  # noqa: E731
        for m in ("base", "lora"):
            for r, folder in (("plain", B), ("agentic", A)):
                for metric in ("judge", "f1"):
                    assert abs(t["tables"][metric]["mean"][f"{m}|{r}"] - mean(table_col(folder, f"{metric}_{m}_rag"))) < 1e-9
        j = t["tables"]["judge"]
        # by construction of the fixture: two questions need a rewritten query; the adapter has memorised two answers the corpus search misses
        assert t["primary"] == "judge" and j["n"] == NQ == t["n_common"] and t["models"] == ["base", "lora"]
        assert [round(j["mean"][k] * NQ) for k in ("base|plain", "base|agentic", "lora|plain", "lora|agentic")] == [9, 11, 11, 12]
        bm, lm = j["by_model"]["base"], j["by_model"]["lora"]
        assert (bm["wins"], bm["ties"], bm["losses"]) == (2, 11, 0) and abs(bm["delta"] - 2 / NQ) < 1e-9 and bm["lo"] <= bm["delta"] <= bm["hi"]
        assert (lm["wins"], lm["ties"], lm["losses"]) == (1, 12, 0) and abs(lm["delta"] - 1 / NQ) < 1e-9
        assert abs(j["by_mode"]["plain"]["delta"] - 2 / NQ) < 1e-9 and abs(j["by_mode"]["agentic"]["delta"] - 1 / NQ) < 1e-9
        assert abs(j["interaction"]["delta"] - (-1 / NQ)) < 1e-9 and abs(j["interaction"]["a"] - 1 / NQ) < 1e-9 and abs(j["interaction"]["b"] - 2 / NQ) < 1e-9
        rec_a, rec_p = table_col(A, "evidence_recall"), table_col(B, "evidence_recall")
        assert abs(t["recall"]["stats"]["a"] - mean(rec_a)) < 1e-9 and abs(t["recall"]["stats"]["b"] - mean(rec_p)) < 1e-9 and t["recall"]["stats"]["delta"] > 0
        assert t["same_answer"] == {m: sum(1 for i, v in table_col(A, f"pred_{m}_rag").items() if table_col(B, f"pred_{m}_rag")[i] == v) for m in ("base", "lora")} and t["rescored"] == 0
        md = (A / "plain_vs_agentic.md").read_text()
        assert "| Base model | 0.692 | 0.846 | +0.154 |" in md and "| Fine-tuned (LoRA) | 0.846 | 0.923 | +0.077 |" in md and "| Plain RAG | 0.692 | 0.846 | +0.154 |" in md
        assert "too few questions to call (n = 13)" in md and "is better" not in md and "Naming a winner needs at least 30 questions" in md
        assert "Agentic retrieval helped" in md and "Plain RAG was better" not in md and "Did the agent find better passages?" in md and "No retrieval" not in md
        assert "An answer that is identical in both runs has the same judge score in both." in md and "Warning" not in md
        assert "Result (judge accuracy, n = 13)" in out and "Base model: plain RAG 0.692 -> agentic RAG 0.846, change +0.154" in out
        with open(A / "plain_vs_agentic.csv", newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == NQ and {"pred_base_plain", "pred_lora_agentic", "judge_base_agentic", "f1_lora_plain", "evidence_recall_plain", "n_searches_agentic"} <= set(rows[0])

        # 2) the same command again: nothing is recomputed, the table is rebuilt
        rc, out, err = go(common)
        again = Counter(map(role, fake.calls[marks[0]:]))
        assert rc == 0 and again["setup"] == again["retrieval"] == again["judge"] == 0 and json.loads((A / "plain_vs_agentic.json").read_text())["tables"] == t["tables"]

        # 3) flags that must not reach the plain run as they are: --redo setup/judge, --with-closed-book
        rc, out, err = go(common + ["--with-closed-book", "--redo", "setup,judge"])
        assert rc == 0, err[-1500:]
        a_args, b_args = seen
        assert "--with-closed-book" in a_args and a_args[a_args.index("--redo") + 1] == "setup,judge" and "--with-closed-book" not in b_args and "--redo" not in b_args
        first, second = Counter(map(role, fake.calls[marks[0]:marks[1]])), Counter(map(role, fake.calls[marks[1]:]))
        four = ("lora_rag", "base_rag", "lora_closed", "base_closed")
        assert first["setup"] > 0 and second["setup"] == 0  # the runner re-read the project once; the plain run used that config
        assert first["judge"] == len(answers(A, four)) and second["judge"] == len(answers(B, rag) - answers(A, four))  # re-judged once, shared again
        t3 = json.loads((A / "plain_vs_agentic.json").read_text())
        assert t3["tables"]["judge"]["mean"] == j["mean"] and t3["rescored"] == 0
        closed = t3["tables"]["judge"]["closed"]
        assert abs(closed["a"] - mean(table_col(A, "judge_lora_closed"))) < 1e-9 and abs(closed["b"] - mean(table_col(A, "judge_base_closed"))) < 1e-9
        assert "| No retrieval |" in (A / "plain_vs_agentic.md").read_text()
        # the models alone against each retrieval setup, on the same questions
        alone = json.loads((A / "alone_vs_retrieval.json").read_text())["metrics"]["judge"]
        md3 = (A / "plain_vs_agentic.md").read_text()
        assert "## The models on their own vs with retrieval" in md3 and "| Fine-tuned (LoRA) | Alone (no retrieval) |" in md3 and "alone vs with retrieval" in out
        for m in ("base", "lora"):
            assert abs(alone[m]["alone"] - mean(table_col(A, f"judge_{m}_closed"))) < 1e-9
            assert abs(alone[m]["Agentic RAG"]["vs_alone"]["delta"] - (mean(table_col(A, f"judge_{m}_rag")) - mean(table_col(A, f"judge_{m}_closed")))) < 1e-9
            assert abs(alone[m]["Plain RAG"]["score"] - mean(table_col(B, f"judge_{m}_rag"))) < 1e-9
        assert round(alone["lora"]["alone"] * NQ) == 6 and round(alone["base"]["alone"] * NQ) == 0 and "Improved agentic" not in alone["lora"]
        rc, out, err = go(common + ["--redo", "retrieve"])
        assert rc == 0 and seen[0][seen[0].index("--redo") + 1] == "retrieve" == seen[1][seen[1].index("--redo") + 1]

        # 4) the GPU libraries live in another environment: three passes of the same command
        A2, B2 = Path(td) / "two_env", Path(td) / "two_env_plain"
        c2 = [str(A2) if x == str(A) else x for x in common]
        fake_hf.uninstall()
        try:
            rc, out, err = go(c2)
        finally:
            fake_hf.install()
        assert rc == 1 and "not finished yet" in err and "--stages generate" in err and len(seen) == 2
        assert len(ev.read_jsonl(A2 / "evidence.jsonl")) == NQ == len(ev.read_jsonl(B2 / "evidence.jsonl"))  # both runs got as far as they can without a GPU
        rc, out, err = go(c2 + ["--stages", "generate"])  # "the training environment"
        assert rc == 0 and "Run this same command without --stages" in err and not (A2 / "plain_vs_agentic.md").exists()
        assert all(a[a.index("--stages") + 1] == "generate" for a in seen) and len(rg.load_predictions(B2, "base_rag")) == NQ
        fake_hf.uninstall()
        try:
            rc, out, err = go(c2)  # back in the runner's environment
        finally:
            fake_hf.install()
        assert rc == 0 and json.loads((A2 / "plain_vs_agentic.json").read_text())["tables"]["judge"]["mean"] == j["mean"]

        # 5) the agentic run cannot be configured: the plain run is not started
        class NeverProposes(FakeRunner):
            def _setup(self, msgs):
                return self._reply("I could not decide.")

        patch_runner(NeverProposes(), str(paths["base"]))
        rc, out, err = go([str(Path(td) / "stuck") if x == str(A) else x for x in common])
        assert rc == 1 and len(seen) == 1 and "the plain run was not started" in err and not (Path(td) / "stuck_plain").exists()
        patch_runner(fake, str(paths["base"]))

        # 6) --table-only and its error messages; --check is passed on once
        rc, out, err = go(["--out-dir", str(A), "--table-only"])
        assert rc == 0 and not seen and "Result (judge accuracy, n = 13)" in out
        rc, _, _ = go(["--out-dir", str(Path(td) / "nothing"), "--table-only"])
        assert isinstance(rc, str) and "no finished report yet" in rc
        rc, _, _ = go(["--out-dir", str(B), "--plain-dir", str(A), "--table-only"])
        assert isinstance(rc, str) and "was produced with --retrieval single" in rc and "agentic run" in rc
        go(common + ["--check"])
        assert len(seen) == 1 and "--check" in seen[0] and "--retrieval" not in seen[0]
        rc, out, _ = go(["--help"])
        assert rc == 0 and "--table-only" in out and not seen

        # 7) judge scores are shared once, never duplicated; unscored records are not shared
        n_lines = len((B / "judgments.jsonl").read_text().splitlines())
        assert pva.share_judgments(A, B) == 0 and pva.share_judgments(B, A) == 0 and len((B / "judgments.jsonl").read_text().splitlines()) == n_lines
        C = Path(td) / "c"
        C.mkdir()
        (C / "judgments.jsonl").write_text(json.dumps({"key": "k1", "id": "x", "score": 1, "reason": "", "model": "m"}) + "\n" + json.dumps({"key": "k2", "id": "y", "score": None}) + "\n" + json.dumps({"key": "k1", "id": "x", "score": 0}) + "\n")
        D = Path(td) / "d"
        assert pva.share_judgments(C, D) == 1 and [r["key"] for r in ev.read_jsonl(D / "judgments.jsonl")] == ["k1"] and pva.share_judgments(C, D) == 0
        assert pva.share_judgments(Path(td) / "missing", D) == 0

        # 8) two runs made by hand that do not line up: fewer shared questions, a different adapter, an answer scored twice
        A4, B4 = Path(td) / "a4", Path(td) / "b4"
        shutil.copytree(A, A4)
        shutil.copytree(B, B4)
        with open(B4 / "per_example.csv", newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        pa = table_col(A4, "pred_lora_rag")
        same_row = next(r for r in rows if pa[r["id"]] == r["pred_lora_rag"])
        same_row["judge_lora_rag"] = str(1.0 - float(same_row["judge_lora_rag"]))
        kept = [r for r in rows if r is same_row or r["id"] in sorted(pa)[:9]]
        with open(B4 / "per_example.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(kept)
        info = json.loads((B4 / "comparison.json").read_text())
        info["setup"]["Adapter"] = "/some/other/adapter"
        (B4 / "comparison.json").write_text(json.dumps(info))
        info = json.loads((A4 / "comparison.json").read_text())
        info["retrieval"]["fallbacks"] = 3
        (A4 / "comparison.json").write_text(json.dumps(info))
        rc, out, err = go(["--out-dir", str(A4), "--plain-dir", str(B4), "--table-only"])
        md = (A4 / "plain_vs_agentic.md").read_text()
        t4 = json.loads((A4 / "plain_vs_agentic.json").read_text())
        assert rc == 0 and t4["n_common"] == len(kept) < NQ and t4["rescored"] == 1 and f"(the agentic run has {NQ}, the plain run {len(kept)})" in md
        assert "**Warning:** Adapter differs between the runs" in md and "WARNING: Adapter differs" in out and "1 identical answers were judged separately" in md
        assert "in 3 of the agentic run's questions the agent did not choose the passages itself" in md and "did not choose the passages itself" not in (A / "plain_vs_agentic.md").read_text()
        # with no judge scores in one run the headline falls back to token F1, and says so
        for r in kept:
            r["judge_lora_rag"] = r["judge_base_rag"] = ""
        with open(B4 / "per_example.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(kept)
        rc, out, err = go(["--out-dir", str(A4), "--plain-dir", str(B4), "--table-only"])
        assert rc == 0 and json.loads((A4 / "plain_vs_agentic.json").read_text())["primary"] == "f1" and "Result (token f1, n = " in out and "token F1 is the headline" in (A4 / "plain_vs_agentic.md").read_text()
    print("ok  plain vs agentic: one config for both runs, shared judge scores, table == recomputed numbers, flag handling, two-environment flow, mismatched runs")


def test_agentic_plus():
    """--retrieval agentic_plus: filled passage slots, the fine-tuned model's draft in the search, answers checked and retried."""
    import contextlib
    import io
    from collections import Counter

    import rag_plain_vs_agentic as pva

    def role(call) -> str:
        system = call["messages"][0]["content"]
        return next((name for name, mark in (("setup", "setup agent"), ("retrieval", "retrieval controller"), ("judge", "You grade an answer"), ("verify", "answer checker")) if mark in system), "other")

    class NoRewrite(FakeRunner):  # a retrieval agent that never rewords its query: two questions miss in the first round
        def _retrieval(self, msgs):
            user = next(m["content"] for m in msgs if m["role"] == "user")
            question = user.split("Question:\n", 1)[1].strip()
            fact = next((f for f in FACTS if f[2] == question), None)
            results = [m["content"] for m in msgs if m["role"] == "tool"]
            if not results:
                return self._reply(tool=("search", {"query": question}))
            hits = [(int(x), body) for x, body in re.findall(r"\[c(\d+)\][^\n]*\n([^\n]*)", results[-1])]
            good = [cid for cid, body in hits if fact and fact[1] in body]
            return self._reply(tool=("submit_evidence", {"chunk_ids": good or [cid for cid, _ in hits[:1]], "sufficient": bool(good)}))

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        tk = {str(paths["adapter"]): {"has_template": False}}
        llm_cfg = agent_core.LLMConfig(model="m", base_url="x", api_key="k")
        exs, _ = ev.build_examples(ev.load_records(paths["eval"]), {"question_field": "question", "answer_field": "answer"})
        retr = ri.Retriever.build_or_load([paths["corpus"]], Path(td) / "idx", log=QUIET)

        # 1) the pieces: the draft reaches the runner as vocabulary, the runner's picks stay first and spare slots are filled
        fake = FakeRunner(gpt5_quirks=False)
        llm = agent_core.LLMClient(llm_cfg, client=fake)
        plain = ra.agentic_retrieve(llm, retr, FACTS[1][2], ctx_k=3)
        res = ra.agentic_retrieve(llm, retr, FACTS[1][2], ctx_k=3, draft="AF Form 4392 goes to the wing commander", fill=True)
        first_user = next(m["content"] for m in fake.calls[-1]["messages"] if m["role"] == "user")
        assert "AF Form 4392 goes to the wing commander" in first_user and "never treat it as evidence" in first_user and first_user.rstrip().endswith(FACTS[1][2])
        assert [c["id"] for c in res["chunks"]][: len(plain["chunks"])] == [c["id"] for c in plain["chunks"]] and res["n_picked"] == len(plain["chunks"])
        assert len(res["chunks"]) == 2 > len(plain["chunks"]) and len({c["id"] for c in res["chunks"]}) == 2  # the small test corpus has two hits for this question
        assert "Draft answer" not in next(m["content"] for m in fake.calls[0]["messages"] if m["role"] == "user")

        # the checker: supported answers change nothing; an "I am not sure" answer is sent back with the passage that states it
        i3 = 3
        miss = retr.search(FACTS[i3][2], 3)
        ok = ra.verify_one(llm, retr, FACTS[1][2], plain["chunks"], [FACTS[1][3], f"Based on the excerpts, the answer is {FACTS[1][3]}."], ctx_k=3)
        assert ok["supported"] and ok["decided"] and ok["chunks"] == plain["chunks"] and ok["queries"] == []
        back = ra.verify_one(llm, retr, FACTS[i3][2], miss, ["I am not sure.", "I do not have enough information to answer."], ctx_k=3)
        assert not back["supported"] and FACTS[i3][1] in back["chunks"][0]["text"] and len(back["chunks"]) <= 3 and back["queries"] == [FACTS[i3][4]]
        shown = next(m["content"] for m in fake.calls[-1]["messages"] if m["role"] == "user")
        assert "Candidate answer 2:" in shown and FACTS[i3][3] not in shown  # the checker never sees the reference answer

        class BadIds(FakeRunner):
            def _verify(self, msgs):
                n = sum(1 for m in msgs if m["role"] == "assistant" and m.get("tool_calls"))
                return self._reply(tool=("finish", {"supported": False, "chunk_ids": [987654]})) if n == 0 else self._reply(tool=("finish", {"supported": "true"}))

        bad = BadIds(gpt5_quirks=False)
        r = ra.verify_one(agent_core.LLMClient(llm_cfg, client=bad), retr, FACTS[1][2], plain["chunks"], ["x"], ctx_k=3)
        assert r["supported"] and any("neither a current passage" in m["content"] for m in bad.calls[-1]["messages"] if m["role"] == "tool")

        # 2) the whole mode through the command line
        lazy = NoRewrite(setup_mistake=False)
        patch_runner(lazy, str(paths["base"]))
        P = Path(td) / "plus"
        common = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--ctx-k", "3", "--workers", "3", "--limit", "0", "--no-analysis", "--model", "gpt-5.6"]

        def cli(args):
            fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
            err = io.StringIO()
            with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                try:
                    rc = rag_compare.main(args)
                except SystemExit as e:
                    rc = str(e)
            return rc, err.getvalue()

        rc, err = cli(common + ["--out-dir", str(P), "--retrieval", "agentic_plus"])
        assert rc == 0, (rc, err[-1500:])
        evd = {r["id"]: r for r in ev.read_jsonl(P / "evidence.jsonl")}
        by = [evd[e.id] for e in exs]
        assert len(rg.load_predictions(P, "lora_closed")) == NQ and all(r["draft_used"] and r["verified"] and r["mode"] == "agentic_plus" for r in by)
        assert any(len(r["chunks"]) > r["n_picked"] for r in by if not r["revised"])  # spare slots were filled
        assert [i for i, r in enumerate(by) if r["revised"]] == [3, 10] and all(by[i]["round1_recall"] == 0.0 and by[i]["recall"] == 1.0 for i in (3, 10))
        retr_users = [next(m["content"] for m in c["messages"] if m["role"] == "user") for c in lazy.calls if role(c) == "retrieval"]
        assert retr_users and all("Draft answer, written from memory" in u for u in retr_users) and any(FACTS[0][3] in u for u in retr_users)  # fact 0 is one the adapter memorised
        comp = json.loads((P / "comparison.json").read_text())
        assert comp["retrieval"]["mode"] == "agentic_plus" and comp["retrieval"]["checked"] == NQ and comp["retrieval"]["revised"] == 2 and comp["retrieval"]["drafts"] == NQ
        row = comp["pairs"][0]["rows"]["judge"]
        assert round(row["a"] * NQ) == 12 and round(row["b"] * NQ) == 11  # the retry recovered both missed questions for both models
        assert "sent back with new passages" in err and "[retry]" in err and "Improved agentic mode" in (P / "comparison.md").read_text() and "checked the answers against the passages" in (P / "comparison.md").read_text()
        final = rg.usable_predictions(P, "base_rag", exs, evd, json.loads((P / "rag_config.json").read_text()))
        assert len(final[0]) == NQ and final[1] == 0 and FACTS[3][3] in final[0][exs[3].id]["prediction"]
        # without the check the same lazy retrieval leaves those two questions unanswered
        n_before = len(lazy.calls)
        rc, err = cli(common + ["--out-dir", str(P), "--retrieval", "agentic_plus"])
        again = Counter(map(role, lazy.calls[n_before:]))
        assert rc == 0 and again["retrieval"] == again["verify"] == again["judge"] == 0 and "generated: lora_rag 0, base_rag 0" in err  # everything resumes
        Q = Path(td) / "noplus"
        rc, err = cli(common + ["--out-dir", str(Q), "--retrieval", "agentic", "--config", str(P / "rag_config.json")])
        row = json.loads((Q / "comparison.json").read_text())["pairs"][0]["rows"]["judge"]
        assert rc == 0 and round(row["b"] * NQ) == 9 and not (Q / "predictions_lora_closed.jsonl").exists()
        # the mode needs the models where the runner is
        fake_hf.uninstall()
        try:
            rc, _ = cli(common + ["--out-dir", str(Path(td) / "nogpu"), "--retrieval", "agentic_plus", "--config", str(P / "rag_config.json")])
        finally:
            fake_hf.install()
        assert isinstance(rc, str) and "needs the models and the runner in the same Python" in rc

        # 3) three columns from one command
        fake3 = FakeRunner(setup_mistake=False)
        patch_runner(fake3, str(paths["base"]))
        seen = []

        def run(args):
            seen.append(list(args))
            fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
            try:
                return rag_compare.main(list(args) + ["--model", "gpt-5.6"])
            except SystemExit as e:
                print(e, file=sys.stderr)
                return 1

        A = Path(td) / "rag_outputs"
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc = pva.main([a for a in common if a not in ("--model", "gpt-5.6")] + ["--out-dir", str(A), "--plus"], run=run)
        assert rc == 0 and len(seen) == 3, err.getvalue()[-1500:]
        c_args = seen[2]
        assert c_args[c_args.index("--retrieval") + 1] == "agentic_plus" and c_args[c_args.index("--out-dir") + 1] == str(Path(td) / "rag_outputs_plus") and c_args[c_args.index("--config") + 1] == str(A / "rag_config.json")
        md = (A / "plain_vs_agentic.md").read_text()
        three = json.loads((A / "three_way.json").read_text())
        b = three["metrics"]["judge"]["base"]
        assert "## Improved agentic RAG (third column)" in md and "| Base model | 0.692 | 0.846 | 0.846 |" in md and "three ways" in out.getvalue()
        assert [round(b[k] * NQ) for k in ("plain", "agentic", "improved")] == [9, 11, 11] and abs(b["vs_plain"]["delta"] - 2 / NQ) < 1e-9 and b["vs_agentic"]["delta"] == 0
        assert three["recall"]["improved"] >= three["recall"]["agentic"] > three["recall"]["plain"]
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            assert pva.main(["--out-dir", str(A), "--table-only", "--plus"], run=run) == 0 and len(seen) == 3
        assert (A / "plain_vs_agentic.md").read_text().count("## Improved agentic RAG") == 1
    print("ok  improved agentic mode: draft-guided search, filled slots, answer check + retry, resume, third column")


def test_external_predictions():
    """--extra-predictions: answers another model saved earlier, graded on the same questions and put next to every setup."""
    import contextlib
    import csv
    import io

    import rag_plain_vs_agentic as pva

    # the saved-output format seen in practice: prompt echoed, an '### Answer:' header, a ruler line and run-on after the answer
    raw = "Answer the question.\n\n### Question:\nQ: What is it?\n\n\n\n### Answer:\n\n The defect is reported to the Safety Office.\n\n" + "-" * 60 + "\n### Question: next"
    assert ev.clean_saved_answer(raw) == "The defect is reported to the Safety Office."
    assert ev.clean_saved_answer("PROMPT TEXT here the answer", "PROMPT TEXT here") == "the answer" and ev.clean_saved_answer("plain answer") == "plain answer"
    assert ev.norm_question("Q:  What should\n be done? ") == "what should be done?" == ev.norm_question("what should be done?")

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        tk = {str(paths["adapter"]): {"has_template": False}}
        # a "QuanTA" run that kept only its answers: right on facts 0-7, missing the last two questions entirely
        saved = Path(td) / "test_predictions.csv"
        with open(saved, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["prompt", "predicted_output", "gold_output"])
            for i, (_, _, q, a, _) in enumerate(FACTS[: NQ - 2]):
                prompt = f"Answer the question with a response that appropriately completes the request.\n\n### Question:\nQ: {q}\n\n\n"
                w.writerow([prompt, prompt + f"### Answer:\n\n {a if i < 8 else 'I am not sure.'}\n\n" + "-" * 40, a])
        got, info = ev.load_external_predictions(saved)
        assert info["question_column"] == "prompt" and info["prediction_column"] == "predicted_output" and len(got) == NQ - 2 and got[ev.norm_question(FACTS[0][2])] == FACTS[0][3]

        fake = FakeRunner(setup_mistake=False)
        patch_runner(fake, str(paths["base"]))

        def run(args):
            fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
            try:
                return rag_compare.main(list(args) + ["--model", "gpt-5.6"])
            except SystemExit as e:
                print(e, file=sys.stderr)
                return 1

        A = Path(td) / "rag_outputs"
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            rc = pva.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(A), "--ctx-k", "3", "--workers", "3", "--limit", "0", "--no-analysis",
                           "--plus", "--with-closed-book", "--extra-predictions", f"QuanTA={saved}"], run=run)
        assert rc == 0, err.getvalue()[-2000:]
        n = NQ - 2
        assert f"{n} of {NQ} questions in the evaluation file also have those saved answers" in err.getvalue()  # fewer than 30 matches: the whole file is used
        for d in (A, Path(td) / "rag_outputs_plain", Path(td) / "rag_outputs_plus"):
            with open(d / "external_QuanTA.csv", newline="", encoding="utf-8") as f:
                rows = list(csv.DictReader(f))
            assert len(rows) == n and sum(float(r["judge"]) for r in rows) == 8 and rows[0]["prediction"] in {a for _, _, _, a, _ in FACTS}
        res = json.loads((A / "external_vs_setups.json").read_text())["QuanTA"]
        j = res["metrics"]["judge"]
        assert res["n_common"] == n and j["n"] == n and abs(j["score"] - 8 / n) < 1e-9
        assert set(j["setups"]) == {f"{m}{s}" for m in ("Base model", "Fine-tuned (LoRA)") for s in (", alone", " + Plain RAG", " + Agentic RAG", " + Improved agentic")}
        with open(A / "per_example.csv", newline="", encoding="utf-8") as f:
            per = {r["id"]: r for r in csv.DictReader(f)}
        ids = [r["id"] for r in rows]
        lora_ag = sum(float(per[i]["judge_lora_rag"]) for i in ids) / n
        assert abs(j["setups"]["Fine-tuned (LoRA) + Agentic RAG"]["score"] - lora_ag) < 1e-9 and abs(j["setups"]["Fine-tuned (LoRA) + Agentic RAG"]["vs_external"]["delta"] - (lora_ag - 8 / n)) < 1e-9
        md = (A / "plain_vs_agentic.md").read_text()
        assert "## QuanTA: its saved answers vs every setup here" in md and "| Fine-tuned (LoRA) + Improved agentic |" in md and "QuanTA, alone: judge accuracy" in out.getvalue()
        # with enough matches the sample is drawn only from questions the saved answers cover
        many = Path(td) / "many.csv"
        with open(many, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["question", "answer"])
            for k in range(4):
                for _, _, q, a, _ in FACTS:
                    w.writerow([f"{q} (v{k})" if k else q, a])
        big = Path(td) / "big_preds.csv"
        with open(big, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["question", "prediction"])
            for k in range(3):
                for _, _, q, a, _ in FACTS:
                    w.writerow([f"Q: {q} (v{k})" if k else f"Q: {q}", a])
        e2 = io.StringIO()
        fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(e2):
            rc = rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(Path(td) / "o2"), "--config", str(A / "rag_config.json"), "--eval-file", str(many),
                                   "--retrieval", "single", "--limit", "0", "--no-analysis", "--no-judge", "--stages", "setup,index,retrieve", "--extra-predictions", f"Q={big}", "--model", "gpt-5.6"])
        assert rc == 0 and f"{3 * NQ} of {4 * NQ} questions" in e2.getvalue() and len(ev.read_jsonl(Path(td) / "o2" / "evidence.jsonl")) == 3 * NQ
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                rag_compare.main(["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(Path(td) / "o3"), "--config", str(A / "rag_config.json"), "--extra-predictions", "Q=/nope.csv", "--model", "gpt-5.6"])
            raise AssertionError
        except SystemExit as e:
            assert "no such file" in str(e)
    print("ok  saved answers of another model: cleaned, matched by question, judged, compared with every setup")


def test_custom_judge_prompt():
    """--judge-prompt FILE: the user's own grading instructions replace the built-in judge."""
    import contextlib
    import io

    class RubricJudge(FakeRunner):  # answers in a rubric's own format (1-5), then the final line it was asked to add
        def create(self, **kw):
            msgs = kw["messages"]
            text = msgs[0]["content"] + "\n" + msgs[-1]["content"]
            if "MY RUBRIC" in text:
                self.calls.append(kw)
                user = msgs[-1]["content"]
                blob = msgs[0]["content"] + "\n" + user
                ref = re.search(r"(?:Reference answer:|GOLD=)\s*(.+)", blob).group(1).strip()
                cand = re.search(r"(?:Answer to evaluate:|PRED=)\s*(.+)", blob).group(1).strip()
                good = ev.normalize_answer(ref) in ev.normalize_answer(cand)
                return self._reply(f"Correctness: {5 if good else 2}/5\nJustification: compared with the reference.\nFINAL_SCORE: {1.0 if good else 0.25}")
            return super().create(**kw)

    try:
        ra.set_judge_prompt("MY RUBRIC: rate correctness from 1 to 5 and justify.")
        system, user = ra.custom_judge_messages("Q?", "REF", "PRED")
        assert system.startswith("MY RUBRIC") and "FINAL_SCORE: <number from 0 to 1>" in system and user == "Question:\nQ?\n\nReference answer:\nREF\n\nAnswer to evaluate:\nPRED"
        k_custom = ra.judge_key({"id": "a", "reference": "r", "prediction": "p"})
        ra.set_judge_prompt("MY RUBRIC\nQ: {question}\nGOLD= {gold_answer}\nPRED= {{ answer }}\nKeep {this} as is.")
        system, user = ra.custom_judge_messages("Q?", "REF", "PRED")
        assert "Q: Q?" in user and "GOLD= REF" in user and "PRED= PRED" in user and "{this}" in user and "Reference answer:" not in user and user.rstrip().endswith("convert it proportionally.")
        ra.set_judge_prompt("MY RUBRIC for {question} only")
        _, user = ra.custom_judge_messages("Q?", "REF", "PRED")
        assert "for Q? only" in user and "Reference answer:\nREF" in user and "Answer to evaluate:\nPRED" in user
        assert ra.parse_custom_judge("Score 4/5\nFINAL_SCORE: 0.75") == (0.75, "Score 4/5") and ra.parse_custom_judge("FINAL SCORE = **1**")[0] == 1.0
        assert ra.parse_custom_judge("FINAL_SCORE: 0.2 ... later\nFINAL_SCORE: 0.9")[0] == 0.9 and ra.parse_custom_judge("FINAL_SCORE: 4")[0] is None and ra.parse_custom_judge("no score here")[0] is None
        ra.set_judge_prompt(None)
        k_default = ra.judge_key({"id": "a", "reference": "r", "prediction": "p"})
        assert k_default != k_custom and k_default == ev.sha("a", "r", "p")

        with tempfile.TemporaryDirectory() as td:
            paths = rag_fixture.build(Path(td))
            tk = {str(paths["adapter"]): {"has_template": False}}
            fake = RubricJudge(setup_mistake=False)
            patch_runner(fake, str(paths["base"]))
            prompt = Path(td) / "prompt.txt"
            prompt.write_text("MY RUBRIC: rate correctness from 1 to 5 and justify.\n")
            out = Path(td) / "o"
            common = ["--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(out), "--ctx-k", "3", "--workers", "3", "--limit", "0", "--no-analysis", "--model", "gpt-5.6"]

            def cli(args):
                fake_hf.reset(answer_fn=rag_fixture.fake_answer, tokenizers=tk)
                err = io.StringIO()
                n0 = len(fake.calls)
                with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                    try:
                        rc = rag_compare.main(args)
                    except SystemExit as e:
                        rc = str(e)
                kinds = [("rubric" if "MY RUBRIC" in c["messages"][0]["content"] else "builtin" if "You grade an answer" in c["messages"][0]["content"] else "") for c in fake.calls[n0:]]
                return rc, err.getvalue(), kinds.count("rubric"), kinds.count("builtin")

            rc, err, n_rubric, n_builtin = cli(common)  # first with the built-in judge
            assert rc == 0 and n_builtin > 0 and n_rubric == 0
            base_default = json.loads((out / "comparison.json").read_text())["pairs"][0]["rows"]["judge"]["b"]
            rc, err, n_rubric, n_builtin = cli(common + ["--judge-prompt", str(prompt)])  # same answers, now graded with the user's prompt
            comp = json.loads((out / "comparison.json").read_text())
            row = comp["pairs"][0]["rows"]["judge"]
            assert rc == 0 and n_rubric > 0 and n_builtin == 0 and "using the prompt in" in err and "generated: lora_rag 0, base_rag 0" in err
            assert abs(base_default - 11 / NQ) < 1e-9 and abs(row["b"] - (11 + 2 * 0.25) / NQ) < 1e-9  # wrong answers get the rubric's 0.25, not 0
            assert "graded with your own judge prompt (prompt.txt" in (out / "comparison.md").read_text() and comp["has_judge"]
            rc, err, n_rubric, n_builtin = cli(common + ["--judge-prompt", str(prompt)])
            assert rc == 0 and n_rubric == 0 and n_builtin == 0  # cached under that prompt
            prompt.write_text("MY RUBRIC v2: stricter.\n")
            rc, err, n_rubric, n_builtin = cli(common + ["--judge-prompt", str(prompt)])
            assert rc == 0 and n_rubric > 0  # an edited prompt grades again
            rc, err, n_rubric, n_builtin = cli(common)
            assert rc == 0 and n_rubric == n_builtin == 0 and abs(json.loads((out / "comparison.json").read_text())["pairs"][0]["rows"]["judge"]["b"] - 11 / NQ) < 1e-9  # the built-in scores are still there
            rc, _, _, _ = cli(common + ["--judge-prompt", str(Path(td) / "nope.txt")])
            assert isinstance(rc, str) and "no such file" in rc
    finally:
        ra.set_judge_prompt(None)
    print("ok  your own judge prompt: placeholders, final score line, separate cache, report note")


def test_check():
    import contextlib
    import io
    import os

    with tempfile.TemporaryDirectory() as td:
        paths = rag_fixture.build(Path(td))
        fake = FakeRunner()
        patch_runner(fake, str(paths["base"]))
        fake_hf.reset()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = rag_compare.main(["--check", "--lora-root", str(paths["project"]), "--corpus", str(paths["corpus"]), "--out-dir", str(Path(td) / "o"), "--model", "gpt-5.6"])
        text = buf.getvalue()
        assert rc == 0, text
        for needle in ("runner model  OK", "gpt-5.6", "torch         OK", "Fake A100 80GB", "peft          OK", "adapters      OK", "epubs_lora", "eval files    OK", "corpus        OK", "all good"):
            assert needle in text, (needle, text)
        fake_hf.reset(cuda=False)
        saved = {k: os.environ.pop(k) for k in rag_compare.RUNNER_ENV if k in os.environ}
        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                rc = rag_compare.main(["--check", "--corpus", str(Path(td) / "models"), "--out-dir", str(Path(td) / "o")])
        finally:
            os.environ.update(saved)
        text = buf.getvalue()
        assert rc == 1 and "runner model  WARN" in text and "no CUDA GPU visible" in text and "corpus        FAIL" in text and "fix first: torch, corpus" in text, text
    print("ok  --check")


def main() -> int:
    test_index()
    test_eval_data()
    test_metrics_and_stats()
    test_generate_hf()
    test_generation_edge_cases()
    test_prompts_and_api_backend()
    test_discovery_and_validation()
    test_retrieval_agent()
    test_end_to_end()
    test_failure_handling()
    test_plain_vs_agentic()
    test_agentic_plus()
    test_external_predictions()
    test_custom_judge_prompt()
    test_check()
    print("ALL OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
