#!/usr/bin/env python3
"""
rag_generate.py — prompts and answer generation for each arm of the comparison.

Arms
  lora_rag / base_rag        retrieved passages + question   (the comparison you asked for)
  lora_closed / base_closed  question only                   (optional: what retrieval itself adds)

"lora" is the base model with the LoRA adapter attached; "base" is the same weights without it.
Both arms get the same passages and the same user content. Each is wrapped in its own native
prompt format: the adapter in the format it was trained on, the base model in its chat template
(`prompt.base_style` in the config changes this).

Backends
  hf      transformers + peft in this process. Base arms run first on the untouched model, then
          the adapter is attached and the LoRA arms run — one load, identical decoding.
  openai  any OpenAI-compatible server, e.g. vLLM:
          vllm serve <base> --enable-lora --lora-modules lora=<adapter_dir>
"""
from __future__ import annotations

import gc
import json
import os
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

from rag_eval import Example, JsonlAppender, read_jsonl, sha, write_jsonl

ARMS = ("lora_rag", "base_rag", "lora_closed", "base_closed")
DEFAULT_RAG_TEMPLATE = (
    "Use the excerpts below from the reference documents to answer the question. "
    "If the excerpts do not contain the answer, answer as well as you can from what you know.\n\n"
    "{context}\n\nQuestion: {question}"
)
_PLACEHOLDER = re.compile(r"\{(question|input|context|user|system)\}")


def parse_arm(arm: str) -> tuple[str, str]:
    if arm not in ARMS:
        raise SystemExit(f"unknown arm '{arm}'. Choose from: {', '.join(ARMS)}")
    model, mode = arm.split("_", 1)
    return model, mode


def fill(template: str, **vals: str) -> str:
    """Single-pass placeholder substitution (inserted text is never re-scanned; other braces are left alone)."""
    return _PLACEHOLDER.sub(lambda m: vals[m.group(1)] if m.group(1) in vals else m.group(0), template)


def normalize_stops(x: Any) -> list[str]:
    """Stop strings as a list. A bare string is ONE stop string, never a list of characters."""
    if x is None:
        return []
    if isinstance(x, str):
        return [x] if x else []
    return [str(s) for s in x if str(s)]


def adapter_fingerprint(adapter_path: str | None) -> str:
    """Path plus size and mtime of the adapter files, so retraining into the same directory is noticed."""
    parts = [str(adapter_path or "")]
    for fn in ("adapter_config.json", "adapter_model.safetensors", "adapter_model.bin"):
        try:
            st = (Path(adapter_path or "") / fn).stat()
            parts.append(f"{fn}:{st.st_size}:{int(st.st_mtime)}")
        except OSError:
            pass
    return "|".join(parts)


def config_hash(cfg: dict, arm: str) -> str:
    """Everything in the config that determines an arm's answers (model identity, prompt, decoding).
    Stored with every prediction; a prediction whose hash no longer matches is never reported."""
    model_key, _ = parse_arm(arm)
    g = cfg.get("gen") or {}
    payload = {
        "base": cfg.get("base_model"),
        "adapter": adapter_fingerprint(cfg.get("adapter_path")) if model_key == "lora" else "",
        "prompt": cfg.get("prompt") or {},
        "gen": {"max_new_tokens": int(g.get("max_new_tokens", 256)), "temperature": float(g.get("temperature", 0.0) or 0.0), "stop": normalize_stops(g.get("stop"))},
    }
    return sha(json.dumps(payload, sort_keys=True, default=str))


def apply_stop(text: str, stops: list[str] | None) -> str:
    cut = len(text)
    for s in stops or []:
        if s:
            i = text.find(s)
            if i != -1:
                cut = min(cut, i)
    return text[:cut].strip()


def auto_stops(raw_wrapper: str) -> list[str]:
    """A raw training format usually opens each turn with a marker ('### Question:', '[INST]').
    A model that keeps writing past its answer starts the next turn with it, so cut there."""
    head = (raw_wrapper or "").split("{user}")[0].replace("{system}", "").replace("{input}", "")
    for special in ("<s>", "</s>", "<|begin_of_text|>"):
        head = head.replace(special, "")
    lines = [ln.strip() for ln in head.splitlines() if ln.strip()]
    marker = lines[-1] if lines else ""
    return [marker] if len(marker) >= 3 and not marker[0].isalnum() else []


def context_limit(base_model: str, max_new_tokens: int, requested: int) -> int:
    """Prompt-token budget: the requested one, capped by the model's own window when config.json says what it is."""
    try:
        import json

        cfg = json.loads((Path(base_model) / "config.json").read_text(encoding="utf-8"))
        window = int(cfg.get("max_position_embeddings") or cfg.get("n_positions") or 0)
    except (OSError, ValueError, TypeError):
        window = 0
    return max(256, min(requested, window - max_new_tokens - 16)) if window > 0 else requested


def arm_style(pcfg: dict, model: str, has_chat_template: bool) -> str:
    """Prompt wrapper for an arm: 'chat' (the tokenizer's chat template) or 'raw' (literal string)."""
    style = pcfg.get("style") or "chat"
    if model == "lora":
        return style
    base_style = pcfg.get("base_style") or "auto"
    if base_style == "same":
        return style
    if base_style in ("chat", "raw"):
        return base_style
    return "chat" if has_chat_template else style


class PromptBuilder:
    def __init__(self, pcfg: dict, ctx_max_chars: int = 24_000, log: Callable[[str], None] | None = None):
        self.system = (pcfg.get("system") or "").strip()
        self.closed = pcfg.get("closed_book") or "{question}"
        self.rag = pcfg.get("rag") or DEFAULT_RAG_TEMPLATE
        self.raw_wrapper = pcfg.get("raw_wrapper") or ""
        # raw prompts: should the tokenizer add its own special tokens (BOS)? "auto" = only when the string does not already start with BOS
        flag = str(pcfg.get("add_special_tokens", "auto")).strip().lower()
        self.add_special: bool | None = True if flag == "true" else False if flag == "false" else None
        self.ctx_max_chars = ctx_max_chars
        self.log = log or (lambda m: None)
        self._warned: set[str] = set()

    def _warn_once(self, msg: str) -> None:
        if msg not in self._warned:
            self._warned.add(msg)
            self.log(f"WARNING: {msg}")

    def context(self, chunks: list[dict]) -> tuple[str, int]:
        """The passage block and how many passages fit into the character budget."""
        parts: list[str] = []
        used = 0
        for n, ch in enumerate(chunks, 1):
            block = f"[{n}] {Path(ch.get('doc', '')).stem}\n{ch['text']}"
            if parts and used + len(block) > self.ctx_max_chars:
                break
            if not parts and len(block) > self.ctx_max_chars:
                block = block[: self.ctx_max_chars]
            parts.append(block)
            used += len(block) + 2
        return "\n\n".join(parts), len(parts)

    def user_content_n(self, ex: Example, chunks: list[dict] | None, style: str = "chat") -> tuple[str, int]:
        template = self.rag if chunks else self.closed
        # a per-example input appears exactly once: where the template or the raw wrapper puts it, else after the question
        placed = "{input}" in template or (style == "raw" and "{input}" in self.raw_wrapper)
        context, n = self.context(chunks) if chunks else ("", 0)
        return fill(template, question=ex.question if placed else ex.query, input=ex.input, context=context), n

    def user_content(self, ex: Example, chunks: list[dict] | None, style: str = "chat") -> str:
        return self.user_content_n(ex, chunks, style)[0]

    def _raw(self, user: str, ex: Example | None = None) -> str:
        if self.raw_wrapper:
            return fill(self.raw_wrapper, user=user, system=self.system, input=ex.input if ex else "")
        return (self.system + "\n\n" if self.system else "") + user + "\n\nAnswer:"

    # -- in-process (transformers) --------------------------------------------------------
    def wrap_hf(self, tok: Any, style: str, user: str, ex: Example | None = None) -> tuple[str, bool]:
        """Final prompt string and whether the tokenizer should still add its special tokens (BOS)."""
        if style == "chat":
            if getattr(tok, "chat_template", None):
                msgs = ([{"role": "system", "content": self.system}] if self.system else []) + [{"role": "user", "content": user}]
                try:
                    return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True), False
                except Exception as first:  # noqa: BLE001 — e.g. templates that reject a system role
                    if self.system:
                        try:
                            merged = [{"role": "user", "content": f"{self.system}\n\n{user}"}]
                            return tok.apply_chat_template(merged, tokenize=False, add_generation_prompt=True), False
                        except Exception:  # noqa: BLE001
                            pass
                    # a model prompted outside its chat format would be compared unfairly — stop instead of improvising
                    raise SystemExit(
                        f"the tokenizer's chat template could not be applied: {type(first).__name__}: {first}\n"
                        "  -> often an old jinja2 (pip install -U 'jinja2>=3.1'). To prompt the base model in the adapter's own format instead, pass --base-prompt same."
                    ) from first
            self._warn_once("the tokenizer has no chat template; using a plain 'Answer:' prompt instead")
            text = (self.system + "\n\n" if self.system else "") + user + "\n\nAnswer:"
        else:
            text = self._raw(user, ex)
        if self.add_special is not None:
            return text, self.add_special
        bos = getattr(tok, "bos_token", None)
        return text, not (bos and text.startswith(bos))

    def render_hf(self, tok: Any, style: str, ex: Example, chunks: list[dict] | None, max_prompt_tokens: int | None) -> tuple[str, bool, int]:
        """Prompt for one example; passages are dropped from the end until it fits max_prompt_tokens."""
        n = len(chunks) if chunks else 0
        while True:
            user, used = self.user_content_n(ex, chunks[:n] if chunks and n > 0 else None, style)
            text, add_special = self.wrap_hf(tok, style, user, ex)
            if n == 0 or not max_prompt_tokens or len(text) <= 2 * max_prompt_tokens:
                return text, add_special, used
            if len(tok(text, add_special_tokens=add_special)["input_ids"]) <= max_prompt_tokens:
                return text, add_special, used
            n = used - 1  # drop the last passage that was actually included

    # -- OpenAI-compatible server ----------------------------------------------------------
    def render_api(self, style: str, ex: Example, chunks: list[dict] | None) -> dict:
        user, used = self.user_content_n(ex, chunks, style)
        if style == "chat":
            msgs = ([{"role": "system", "content": self.system}] if self.system else []) + [{"role": "user", "content": user}]
            return {"style": "chat", "messages": msgs, "n_ctx": used}
        text = self._raw(user, ex)
        return {"style": "raw", "prompt": text[3:] if text.startswith("<s>") else text, "n_ctx": used}  # the server adds BOS itself


# --------------------------------------------------------------------------------------
# transformers + peft backend
# --------------------------------------------------------------------------------------


class HFGenerator:
    def __init__(self, base_model: str, adapter_path: str, *, load_in_4bit: bool = False, allow_cpu: bool = False, trust_remote_code: bool = False, log: Callable[[str], None] | None = None):
        self.base_model = base_model
        self.adapter_path = adapter_path
        self.load_in_4bit = load_in_4bit
        self.allow_cpu = allow_cpu
        self.trust_remote_code = trust_remote_code
        self.log = log or (lambda m: print(f"[generate] {m}", file=sys.stderr, flush=True))
        self.model = None
        self.base_tok = None
        self.lora_tok = None
        self.adapter_loaded = False
        try:
            import torch
            import transformers
        except ImportError as e:
            raise SystemExit(
                f"the generate stage needs torch + transformers + peft in this Python ({sys.executable}): {e}\n"
                "  -> run this stage in the environment the adapter was trained in:  python rag_compare.py ... --stages generate\n"
                "     (the other stages only need `openai` and numpy), or point --gen-backend openai at a vLLM server."
            ) from e
        self.torch = torch
        self.transformers = transformers

    # -- loading ---------------------------------------------------------------------------
    def _from_pretrained(self, cls: Any, src: str, dtype: Any = None, **kw: Any) -> Any:
        attempts = [{}] if os.path.isdir(src) else [{"local_files_only": True}, {}]  # hub ids: try the local cache first
        last: Exception | None = None
        for extra in attempts:
            try:
                if dtype is None:
                    return cls.from_pretrained(src, **kw, **extra)
                try:
                    return cls.from_pretrained(src, torch_dtype=dtype, **kw, **extra)
                except TypeError as e:
                    if "torch_dtype" not in str(e):
                        raise
                    return cls.from_pretrained(src, dtype=dtype, **kw, **extra)
            except OSError as e:  # not in the local cache -> the next attempt may reach the hub
                last = e
            except Exception as e:  # noqa: BLE001 — anything else will not be fixed by retrying
                last = e
                break
        raise SystemExit(
            f"could not load {cls.__name__} from {src!r}: {type(last).__name__}: {last}\n"
            "  -> if this is a hub id on an offline node, pass --base-model /local/path/to/the/model (the directory with config.json)."
        )

    def _tokenizer(self, src: str) -> Any:
        tok = self._from_pretrained(self.transformers.AutoTokenizer, src, **({"trust_remote_code": True} if self.trust_remote_code else {}))
        tok.padding_side = "left"  # decoder-only models must be left-padded for batched generation
        if getattr(tok, "add_eos_token", False):  # some training scripts save the tokenizer with this on; a prompt must not end in EOS
            try:
                tok.add_eos_token = False
            except Exception:  # noqa: BLE001
                self.log("WARNING: the tokenizer appends EOS to its input and that could not be switched off")
        if tok.pad_token_id is None:
            fallback = tok.unk_token or tok.eos_token
            if fallback is None:
                raise SystemExit(f"the tokenizer at {src} has no pad, unk or eos token")
            tok.pad_token = fallback
        return tok

    def load_tokenizers(self) -> None:
        self.base_tok = self._tokenizer(self.base_model)
        has_own = any((Path(self.adapter_path) / f).exists() for f in ("tokenizer_config.json", "tokenizer.json", "tokenizer.model"))
        if has_own:
            self.lora_tok = self._tokenizer(self.adapter_path)
            if not getattr(self.lora_tok, "chat_template", None) and getattr(self.base_tok, "chat_template", None):
                self.lora_tok.chat_template = self.base_tok.chat_template
        else:
            self.lora_tok = self.base_tok

    def load_base(self) -> None:
        torch = self.torch
        cuda = torch.cuda.is_available()
        if not cuda and not self.allow_cpu:
            raise SystemExit("no CUDA GPU is visible to this process — run the generate stage on a GPU node (or pass --allow-cpu to run very slowly on CPU)")
        if cuda:
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        else:
            dtype = torch.float32
        kw: dict[str, Any] = {}
        if self.trust_remote_code:
            kw["trust_remote_code"] = True
        if self.load_in_4bit:
            kw["quantization_config"] = self.transformers.BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=dtype)
        t0 = time.time()
        self.log(f"loading base model {self.base_model} ({'4-bit' if self.load_in_4bit else str(dtype).replace('torch.', '')}) ...")
        if cuda:
            try:
                self.model = self._from_pretrained(self.transformers.AutoModelForCausalLM, self.base_model, dtype=dtype, device_map="auto", **kw)
            except SystemExit as e:
                if "accelerate" not in str(e).lower():
                    raise
                self.log("`accelerate` is not installed; loading without device_map and moving the model to cuda:0")
                self.model = self._from_pretrained(self.transformers.AutoModelForCausalLM, self.base_model, dtype=dtype, **kw)
                if not self.load_in_4bit:
                    self.model.to("cuda")
        else:
            self.model = self._from_pretrained(self.transformers.AutoModelForCausalLM, self.base_model, dtype=dtype, **kw)
        self.model.eval()
        self.log(f"base model loaded in {time.time() - t0:.0f}s")

    def load_adapter(self) -> None:
        try:
            from peft import PeftModel
        except ImportError as e:
            raise SystemExit(f"the LoRA arms need the `peft` package in this Python ({sys.executable}): {e}") from e
        if self.lora_tok is not self.base_tok:
            n_tok, n_emb = len(self.lora_tok), self.model.get_input_embeddings().weight.shape[0]
            if n_tok > n_emb:
                self.log(f"the adapter's tokenizer has {n_tok} tokens vs {n_emb} embedding rows; resizing embeddings before attaching the adapter")
                self.model.resize_token_embeddings(n_tok)
        t0 = time.time()
        try:
            self.model = PeftModel.from_pretrained(self.model, self.adapter_path)
        except Exception as e:  # noqa: BLE001
            raise SystemExit(
                f"could not attach the adapter at {self.adapter_path}: {type(e).__name__}: {e}\n"
                "  -> it must be a PEFT adapter directory (adapter_config.json + adapter_model.safetensors) trained on this base model."
            ) from e
        self.model.eval()
        self.adapter_loaded = True
        self.log(f"adapter attached in {time.time() - t0:.0f}s: {self.adapter_path}")

    def close(self) -> None:
        self.model = None
        gc.collect()
        try:
            if self.torch.cuda.is_available():
                self.torch.cuda.empty_cache()
        except Exception:  # noqa: BLE001
            pass

    # -- generation ------------------------------------------------------------------------
    def _input_device(self) -> Any:
        try:
            return self.model.get_input_embeddings().weight.device
        except Exception:  # noqa: BLE001
            return next(self.model.parameters()).device

    @staticmethod
    def end_of_answer_ids(tok: Any, stops: list[str] | None = None) -> set[int]:
        """Token ids that end an answer: EOS and every other special/control token (a model that runs on
        opens its next turn with one, e.g. Mistral's [INST]), plus stop strings that are single tokens.
        Decoding with skip_special_tokens removes such tokens from the text, so the cut has to happen on ids."""
        ids: set[int] = set()
        for i in getattr(tok, "all_special_ids", None) or []:
            ids.add(int(i))
        try:
            for i, t in tok.added_tokens_decoder.items():
                if getattr(t, "special", False):
                    ids.add(int(i))
        except Exception:  # noqa: BLE001 — older tokenizers without added_tokens_decoder
            pass
        unk = getattr(tok, "unk_token_id", None)
        for st in stops or []:
            try:
                i = tok.convert_tokens_to_ids(st)
            except Exception:  # noqa: BLE001
                i = None
            if isinstance(i, int) and i >= 0 and i != unk:
                ids.add(i)
        if tok.eos_token_id is not None:
            ids.add(int(tok.eos_token_id))
        if unk is not None and unk != tok.eos_token_id:
            ids.discard(int(unk))  # an unknown-word token inside an answer is not the end of it
        return ids

    def _batch(self, tok: Any, texts: list[str], add_special: bool, max_new_tokens: int, temperature: float, end_ids: set[int]) -> tuple[list[str], list[bool]]:
        torch = self.torch
        enc = tok(texts, return_tensors="pt", padding=True, add_special_tokens=add_special)
        dev = self._input_device()
        ids, mask = enc["input_ids"].to(dev), enc["attention_mask"].to(dev)
        kw: dict[str, Any] = {"max_new_tokens": max_new_tokens, "do_sample": temperature > 0, "pad_token_id": tok.pad_token_id}
        if temperature > 0:
            kw["temperature"] = temperature
        with torch.inference_mode():
            out = self.model.generate(input_ids=ids, attention_mask=mask, **kw)
        rows = out[:, ids.shape[1] :].tolist()  # only the newly generated tokens
        decoded: list[str] = []
        hit: list[bool] = []
        for row in rows:
            cut = next((k for k, t in enumerate(row) if t in end_ids), None)
            decoded.append(tok.decode(row if cut is None else row[:cut], skip_special_tokens=True))
            hit.append(cut is None and len(row) >= max_new_tokens)  # never reached an end-of-answer token: stopped by the limit
        return decoded, hit

    def generate(self, tok: Any, texts: list[str], add_special: bool, *, max_new_tokens: int, temperature: float, batch_size: int, on_batch: Callable[[list[int], list[str], list[bool]], None], stops: list[str] | None = None) -> None:
        """Longest prompts first (an out-of-memory error shows up immediately, not an hour in);
        on OOM the batch size is halved and the batch retried."""
        order = sorted(range(len(texts)), key=lambda i: -len(texts[i]))
        end_ids = self.end_of_answer_ids(tok, stops)
        bs = max(1, batch_size)
        i = 0
        while i < len(order):
            idx = order[i : i + bs]
            try:
                outs, hit = self._batch(tok, [texts[j] for j in idx], add_special, max_new_tokens, temperature, end_ids)
            except RuntimeError as e:
                if "out of memory" not in str(e).lower():
                    raise
                self.torch.cuda.empty_cache()
                if bs == 1:
                    raise SystemExit("GPU out of memory even with batch size 1 — use --load-in-4bit, a smaller --ctx-k, or a GPU with more memory") from e
                bs = max(1, bs // 2)
                self.log(f"GPU out of memory -> batch size {bs}")
                continue
            on_batch(idx, outs, hit)
            i += len(idx)


# --------------------------------------------------------------------------------------
# OpenAI-compatible backend (vLLM etc.)
# --------------------------------------------------------------------------------------


class OpenAIGenerator:
    def __init__(self, base_url: str, api_key: str | None, lora_model: str, base_model: str, *, workers: int = 8, timeout: float = 300.0, client: Any = None):
        self.names = {"lora": lora_model, "base": base_model}
        self.workers = max(1, workers)
        if client is None:
            try:
                from openai import OpenAI
            except ImportError as e:
                raise SystemExit("--gen-backend openai needs the `openai` package") from e
            client = OpenAI(base_url=base_url, api_key=api_key or "EMPTY", timeout=timeout, max_retries=2)
        self.client = client

    def _one(self, name: str, item: dict, max_new_tokens: int, temperature: float, stop: list[str] | None) -> tuple[str, bool]:
        kw: dict[str, Any] = {"model": name, "max_tokens": max_new_tokens, "temperature": temperature}
        if stop:
            kw["stop"] = stop[:4]
        last: Exception | None = None
        for attempt in range(3):
            try:
                if item["style"] == "chat":
                    r = self.client.chat.completions.create(messages=item["messages"], **kw)
                    return (r.choices[0].message.content or ""), r.choices[0].finish_reason == "length"
                r = self.client.completions.create(prompt=item["prompt"], **kw)
                return (r.choices[0].text or ""), r.choices[0].finish_reason == "length"
            except Exception as e:  # noqa: BLE001
                last = e
                if type(e).__name__ in ("BadRequestError", "NotFoundError", "AuthenticationError", "PermissionDeniedError"):
                    break
                time.sleep(2 * (attempt + 1))
        raise SystemExit(f"generation request to the model server failed for model '{name}': {type(last).__name__}: {last}")

    def generate(self, model_key: str, items: list[dict], *, max_new_tokens: int, temperature: float, stop: list[str] | None, on_item: Callable[[int, str, bool], None]) -> None:
        name = self.names[model_key]
        pool = ThreadPoolExecutor(max_workers=self.workers)
        try:
            futures = [pool.submit(self._one, name, it, max_new_tokens, temperature, stop) for it in items]
            for i, fut in enumerate(futures):
                text, hit = fut.result()
                on_item(i, text, hit)
        except BaseException:  # a dead server or Ctrl-C: drop everything that has not started instead of trying each question
            pool.shutdown(wait=False, cancel_futures=True)
            raise
        pool.shutdown(wait=True)


# --------------------------------------------------------------------------------------
# the generate stage
# --------------------------------------------------------------------------------------


def predictions_path(out_dir: Path, arm: str) -> Path:
    return Path(out_dir) / f"predictions_{arm}.jsonl"


def evidence_hash(ev: dict | None) -> str:
    return sha(*[c["id"] for c in (ev or {}).get("chunks", [])]) if ev else ""


def load_predictions(out_dir: Path, arm: str) -> dict[str, dict]:
    """Latest prediction per example id."""
    return {r["id"]: r for r in read_jsonl(predictions_path(out_dir, arm)) if "id" in r}


def usable_predictions(out_dir: Path, arm: str, examples: list[Example], evidence: dict[str, dict], cfg: dict) -> tuple[dict[str, dict], int]:
    """Predictions that belong to the current questions, config and retrieved passages, plus the number
    set aside as stale. Needs no tokenizer, so it also works where torch is not installed."""
    want = config_hash(cfg, arm)
    rag = parse_arm(arm)[1] == "rag"
    by_id = {e.id: e for e in examples}
    good: dict[str, dict] = {}
    stale = 0
    for i, r in load_predictions(out_dir, arm).items():
        e = by_id.get(i)
        if e is None:
            continue
        if r.get("qhash") != e.qhash or r.get("chash") != want or (rag and r.get("ehash") != evidence_hash(evidence.get(i))):
            stale += 1
            continue
        good[i] = r
    return good, stale


def run_generation(
    *,
    arms: list[str],
    examples: list[Example],
    evidence: dict[str, dict],
    cfg: dict,
    out_dir: Path,
    backend: str = "hf",
    batch_size: int = 8,
    max_prompt_tokens: int = 6000,
    ctx_max_chars: int = 24_000,
    load_in_4bit: bool = False,
    allow_cpu: bool = False,
    trust_remote_code: bool = False,
    api: dict | None = None,
    generator: Any = None,
    meta: dict | None = None,
    log: Callable[[str], None] | None = None,
) -> dict[str, int]:
    """Generate missing predictions for every arm. Returns {arm: number generated in this call};
    `meta`, when given, receives {"styles": {arm: prompt wrapper used}}."""
    log = log or (lambda m: print(f"[generate] {m}", file=sys.stderr, flush=True))
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    gcfg = cfg.get("gen", {})
    max_new = int(gcfg.get("max_new_tokens", 256))
    temperature = float(gcfg.get("temperature", 0.0) or 0.0)
    stops = normalize_stops(gcfg.get("stop"))
    raw_stops = stops or auto_stops((cfg.get("prompt") or {}).get("raw_wrapper", ""))  # only for arms prompted in the raw format
    builder = PromptBuilder(cfg.get("prompt", {}), ctx_max_chars, log)
    for arm in arms:
        parse_arm(arm)
    rag_arms = [a for a in arms if a.endswith("_rag")]
    missing_ev = [e.id for e in examples if e.id not in evidence] if rag_arms else []
    if missing_ev:
        raise SystemExit(f"{len(missing_ev)} selected questions have no retrieved evidence — run the `retrieve` stage first (same --limit/--seed).")

    gen = generator
    if gen is None:
        if backend == "hf":
            gen = HFGenerator(cfg["base_model"], cfg["adapter_path"], load_in_4bit=load_in_4bit, allow_cpu=allow_cpu, trust_remote_code=trust_remote_code, log=log)
        elif backend == "openai":
            api = api or {}
            if not api.get("base_url") or not api.get("lora_model") or not api.get("base_model"):
                raise SystemExit("--gen-backend openai needs --gen-base-url, --gen-lora-model and --gen-base-model (the names the server serves)")
            gen = OpenAIGenerator(api["base_url"], api.get("api_key"), api["lora_model"], api["base_model"], workers=api.get("workers", 8))
        else:
            raise SystemExit(f"unknown --gen-backend '{backend}' (hf or openai)")
    is_hf = isinstance(gen, HFGenerator) or hasattr(gen, "load_adapter")
    if is_hf:
        gen.load_tokenizers()
        max_prompt_tokens = context_limit(str(cfg.get("base_model", "")), max_new, max_prompt_tokens)

    # 1) render every prompt and find what is still missing (cached predictions are keyed by a prompt hash)
    plan: dict[str, dict] = {}
    samples: list[str] = []
    for arm in arms:
        model_key, mode = parse_arm(arm)
        tok = (gen.lora_tok if model_key == "lora" else gen.base_tok) if is_hf else None
        style = arm_style(cfg.get("prompt", {}), model_key, bool(getattr(tok, "chat_template", None)) if is_hf else True)
        arm_stops = raw_stops if style == "raw" else stops
        chash = config_hash(cfg, arm)
        served = getattr(gen, "names", {}).get(model_key, "")  # OpenAI-compatible backend: the served model name
        identity = (chash, backend, bool(load_in_4bit) if is_hf else served, "|".join(arm_stops))
        items = []
        for ex in examples:
            ev = evidence.get(ex.id) if mode == "rag" else None
            chunks = ev["chunks"] if ev else None
            if is_hf:
                text, add_special, n_ctx = builder.render_hf(tok, style, ex, chunks, max_prompt_tokens)
                payload: Any = text
            else:
                payload = builder.render_api(style, ex, chunks)
                text, add_special, n_ctx = (payload.get("prompt") or "\n".join(f"<{m['role']}> {m['content']}" for m in payload["messages"])), True, payload["n_ctx"]
            items.append({"ex": ex, "text": text, "payload": payload, "add_special": add_special, "n_ctx": n_ctx, "phash": sha(*identity, text), "ehash": evidence_hash(ev), "chash": chash})
        path = predictions_path(out_dir, arm)
        current = {it["ex"].id: it["phash"] for it in items}
        existing = read_jsonl(path)
        valid = {r["id"]: r for r in existing if current.get(r.get("id")) == r.get("phash")}
        keep = [r for r in existing if r.get("id") not in current] + list(valid.values())  # other subsets stay cached
        if len(keep) != len(existing):
            write_jsonl(path, keep)
        pending = [it for it in items if it["ex"].id not in valid]
        plan[arm] = {"model": model_key, "tok": tok, "style": style, "items": items, "pending": pending, "stops": arm_stops}
        if items:
            samples.append(f"## {arm}  (prompt wrapper: {style})\n\n```\n{items[0]['text']}\n```\n")
        log(f"{arm}: {len(items) - len(pending)} cached, {len(pending)} to generate (prompt wrapper: {style})")
    (out_dir / "sample_prompts.md").write_text("# First prompt of each arm, exactly as sent to the model\n\n" + "\n".join(samples), encoding="utf-8")
    if meta is not None:
        meta["styles"] = {a: plan[a]["style"] for a in arms}

    # 2) generate: base arms on the untouched model first, then attach the adapter
    done: dict[str, int] = {a: 0 for a in arms}
    order = [a for a in arms if plan[a]["model"] == "base"] + [a for a in arms if plan[a]["model"] == "lora"]
    todo = [a for a in order if plan[a]["pending"]]
    if not todo:
        return done
    if is_hf:
        gen.load_base()
    for arm in todo:
        info = plan[arm]
        pending = info["pending"]
        if is_hf and info["model"] == "lora" and not gen.adapter_loaded:
            gen.load_adapter()
        writer = JsonlAppender(predictions_path(out_dir, arm))
        t0 = time.time()
        last_log = [t0]

        def record(it: dict, raw: str, hit: bool) -> None:
            pred = apply_stop(raw, info["stops"])
            trimmed = raw.strip() != pred  # a stop marker ended the answer, so it was not cut off by the token limit
            rec = {"id": it["ex"].id, "qhash": it["ex"].qhash, "arm": arm, "phash": it["phash"], "chash": it["chash"], "ehash": it["ehash"], "n_ctx": it["n_ctx"], "prediction": pred, "hit_cap": bool(hit) and not trimmed}
            if trimmed:
                rec["raw"] = raw
            writer.add(rec)
            done[arm] += 1

        def progress() -> None:
            now = time.time()
            if done[arm] == len(pending) or now - last_log[0] >= 10:
                last_log[0] = now
                log(f"{arm}: {done[arm]}/{len(pending)} ({done[arm] / max(now - t0, 1e-6):.1f} answers/s)")

        if is_hf:
            def on_batch(idx: list[int], outs: list[str], hits: list[bool]) -> None:
                for j, o, h in zip(idx, outs, hits):
                    record(pending[j], o, h)
                progress()

            gen.generate(info["tok"], [it["text"] for it in pending], pending[0]["add_special"], max_new_tokens=max_new, temperature=temperature, batch_size=batch_size, on_batch=on_batch, stops=info["stops"])
        else:
            def on_item(i: int, text: str, hit: bool) -> None:
                record(pending[i], text, hit)
                progress()

            gen.generate(info["model"], [it["payload"] for it in pending], max_new_tokens=max_new, temperature=temperature, stop=info["stops"], on_item=on_item)
    if is_hf and generator is None:
        gen.close()
    return done
