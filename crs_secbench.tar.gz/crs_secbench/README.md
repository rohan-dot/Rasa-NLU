# CRS — SEC-bench Edition

LLM-powered Cyber Reasoning System adapted for SEC-bench and local testing.
Uses vLLM directly (OpenAI-compatible API). **No LiteLLM dependency.**

## Quick Start (No Docker, No LLM)

Test with the two built-in ASAN samples using known-good PoCs:

```bash
# Prerequisites
sudo apt-get install -y build-essential g++ python3 python3-pip
pip3 install openai

# Run
cd crs_secbench
PYTHONPATH=. python3 -m crs.main --samples-dir ./samples --no-llm
```

Expected output: both samples trigger ASAN (heap-buffer-overflow and
heap-use-after-free).

## Quick Start (No Docker, With LLM via vLLM)

```bash
PYTHONPATH=. python3 -m crs.main --samples-dir ./samples \
    --model gemma-3-27b-it \
    --base-url http://g52lambda02.llan.ll.mit.edu:8000/v1 \
    --api-key EMPTY
```

## Quick Start (Docker)

```bash
cd crs_secbench
docker build -t crs-secbench .
docker run --rm crs-secbench
```

With LLM access (your vLLM server must be reachable):

```bash
docker run --rm --network=host \
    -e OPENAI_BASE_URL=http://g52lambda02.llan.ll.mit.edu:8000/v1 \
    -e LLM_MODEL=gemma-3-27b-it \
    crs-secbench \
    python3 -m crs.main --samples-dir ./samples \
        --base-url http://g52lambda02.llan.ll.mit.edu:8000/v1
```

## Built-in Samples

### Sample 1: heap_overflow
- **Bug**: `parse_packet()` uses a user-controlled length field in memcpy
  without checking it against the actual input size
- **Trigger**: Send a packet with magic=0xDEADBEEF and payload_len=256
  but only 4 bytes of actual payload
- **ASAN output**: `heap-buffer-overflow on address ... READ of size 256`

### Sample 2: use_after_free
- **Bug**: `handle_delete()` frees a cache entry but doesn't NULL the
  pointer. A subsequent `handle_get()` dereferences freed memory.
- **Trigger**: ADD to slot 0, DELETE slot 0, GET slot 0
- **ASAN output**: `heap-use-after-free on address ... READ of size N`

## Running on SEC-bench Tasks

### Option A: Manual (no Docker)

1. Download a task from the SEC-bench HuggingFace dataset
2. Clone the vulnerable repo at the specified commit
3. Create a sample directory with description.txt + harness + source
4. Run: `python3 -m crs.main --sample ./my_secbench_task`

### Option B: Inside SEC-bench Docker

```bash
# Pull a SEC-bench Docker image for a specific task
# (image names follow SEC-bench conventions)

# Mount the CRS inside and run
docker run --rm --network=host \
    -v $(pwd)/crs:/opt/crs/crs \
    <secbench-image> \
    python3 -m crs.main --sample /repo \
        --base-url http://your-vllm-host:8000/v1
```

## Architecture

```
crs/
├── config.py           — Configuration (vLLM endpoint, timeouts)
├── llm_router.py       — Direct openai client to vLLM (no LiteLLM)
├── secbench_adapter.py — Load SEC-bench or local sample tasks
├── builder.py          — Compile fuzz targets with ASAN
├── byte_gen.py         — LLM-guided + pattern PoC generation
├── runner.py           — Feed PoCs to fuzz target, detect crashes
└── main.py             — Pipeline orchestrator

samples/
├── heap_overflow/      — Heap-buffer-overflow sample
│   ├── source.c        — Vulnerable parser code
│   ├── harness.c       — LLVMFuzzerTestOneInput wrapper
│   ├── description.txt — Vulnerability description
│   └── poc_known_good.py — Known-good PoC generator
└── use_after_free/     — Use-after-free sample
    ├── source.c        — Vulnerable cache code
    ├── harness.c       — LLVMFuzzerTestOneInput wrapper
    ├── description.txt — Vulnerability description
    └── poc_known_good.py — Known-good PoC generator
```

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `OPENAI_BASE_URL` | `http://g52lambda02...` | vLLM endpoint |
| `OPENAI_API_KEY` | `EMPTY` | API key for vLLM |
| `LLM_MODEL` | `gemma-3-27b-it` | Model name |
| `CRS_WORK_DIR` | `/tmp/crs_workdir` | Working directory |
