"""
crs/secbench_adapter.py — Load SEC-bench tasks or local sample tasks.

SEC-bench dataset lives on HuggingFace at SEC-bench/SEC-bench.
Each instance has:
  - instance_id: e.g. "kloetzl__libdna-CVE-2020-35460"
  - repo:        e.g. "kloetzl/libdna"
  - base_commit: git commit hash of the vulnerable version
  - bug_description: CVE description (what the bug is)
  - harness:     build/test commands
  - patch:       the gold fix (we don't use this for PoC generation)

For local testing we also support a simple directory layout:
    samples/<task_name>/
        source.c          — vulnerable source code
        harness.c         — fuzz harness (LLVMFuzzerTestOneInput)
        description.txt   — vulnerability description
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class SecBenchTask:
    """Unified task representation for both SEC-bench and local samples."""
    task_id: str
    project_name: str
    project_language: str
    vulnerability_description: str
    repo_path: Path                  # path to the source code
    harness_path: Optional[Path]     # path to harness file, if provided
    source_files: List[Path]         # list of all C/C++ source files
    sanitizer: str = "asan"          # asan | msan | ubsan
    build_cmd: Optional[str] = None  # custom build command
    extra_cflags: str = ""


# ── Local sample loader ───────────────────────────────────────────────────

_SOURCE_EXTS = {".c", ".cpp", ".cc", ".cxx", ".h", ".hpp"}


def load_local_sample(sample_dir: str | Path) -> SecBenchTask:
    """
    Load a self-contained sample from a local directory.

    Expected layout:
        <sample_dir>/
            source.c            — the vulnerable code
            harness.c           — the fuzz harness
            description.txt     — vulnerability description
            [Makefile]          — optional custom build
    """
    d = Path(sample_dir).resolve()
    if not d.is_dir():
        raise FileNotFoundError(f"Sample directory not found: {d}")

    desc_file = d / "description.txt"
    if not desc_file.exists():
        raise FileNotFoundError(f"description.txt not found in {d}")

    description = desc_file.read_text(encoding="utf-8", errors="replace").strip()

    # Find source files
    source_files = sorted(
        f for f in d.rglob("*") if f.is_file() and f.suffix.lower() in _SOURCE_EXTS
    )
    if not source_files:
        raise FileNotFoundError(f"No C/C++ source files found in {d}")

    # Find harness
    harness_path = None
    for name in ["harness.c", "harness.cpp", "fuzz_target.c", "fuzz_target.cpp"]:
        if (d / name).exists():
            harness_path = d / name
            break

    # Detect sanitizer from description
    desc_lower = description.lower()
    if "msan" in desc_lower or "memory sanitizer" in desc_lower:
        sanitizer = "msan"
    elif "ubsan" in desc_lower or "undefined" in desc_lower:
        sanitizer = "ubsan"
    else:
        sanitizer = "asan"

    return SecBenchTask(
        task_id=d.name,
        project_name=d.name,
        project_language="c",
        vulnerability_description=description,
        repo_path=d,
        harness_path=harness_path,
        source_files=source_files,
        sanitizer=sanitizer,
    )


def load_all_local_samples(samples_dir: str | Path) -> List[SecBenchTask]:
    """Load all sample tasks from subdirectories of samples_dir."""
    root = Path(samples_dir)
    tasks = []
    for sub in sorted(root.iterdir()):
        if sub.is_dir() and (sub / "description.txt").exists():
            try:
                tasks.append(load_local_sample(sub))
            except Exception as e:
                print(f"[adapter] Skipping {sub.name}: {e}")
    return tasks


# ── SEC-bench HuggingFace loader ──────────────────────────────────────────

def load_secbench_from_hf(
    instance_ids: Optional[List[str]] = None,
    max_tasks: int = 5,
) -> List[SecBenchTask]:
    """
    Load SEC-bench tasks from HuggingFace.
    Requires: pip install datasets

    Each task provides a Docker image with the project already set up.
    This loader downloads the metadata; you still need the Docker image
    to actually run the task.
    """
    try:
        from datasets import load_dataset
    except ImportError:
        raise ImportError("pip install datasets to use load_secbench_from_hf")

    ds = load_dataset("SEC-bench/SEC-bench", split="test")

    tasks = []
    for row in ds:
        if instance_ids and row["instance_id"] not in instance_ids:
            continue

        task_id = row["instance_id"]
        repo_name = row.get("repo", task_id.split("-")[0])
        bug_desc = row.get("bug_description", row.get("problem_statement", ""))

        # Inside the SEC-bench Docker container, the repo is at /repo
        repo_path = Path("/repo")

        # Find source files if we're inside the container
        source_files = []
        if repo_path.exists():
            source_files = sorted(
                f for f in repo_path.rglob("*")
                if f.is_file() and f.suffix.lower() in _SOURCE_EXTS
            )

        tasks.append(SecBenchTask(
            task_id=task_id,
            project_name=repo_name,
            project_language="c",
            vulnerability_description=bug_desc,
            repo_path=repo_path,
            harness_path=None,
            source_files=source_files,
            sanitizer="asan",
        ))

        if len(tasks) >= max_tasks:
            break

    return tasks
