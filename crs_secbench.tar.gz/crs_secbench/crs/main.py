#!/usr/bin/env python3
"""
crs/main.py — CRS Entry Point (SEC-bench edition)

Usage:
    # Run on local samples (no LLM needed for known-good PoCs):
    python -m crs.main --samples-dir ./samples --no-llm

    # Run on local samples WITH LLM-generated PoCs:
    python -m crs.main --samples-dir ./samples \
        --model gemma-3-27b-it \
        --base-url http://g52lambda02.llan.ll.mit.edu:8000/v1

    # Run on a specific sample:
    python -m crs.main --sample ./samples/heap_overflow

    # Run inside a SEC-bench Docker container:
    python -m crs.main --secbench --instance-id "kloetzl__libdna-CVE-..."
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Optional

from crs.builder import BuildResult, build_local_sample
from crs.byte_gen import PoCCandidate, generate_all_pocs
from crs.config import cfg
from crs.llm_router import LLMRouter
from crs.runner import RunResult, run_all_pocs
from crs.secbench_adapter import (
    SecBenchTask,
    load_all_local_samples,
    load_local_sample,
)


# ── Result tracking ───────────────────────────────────────────────────────

@dataclass
class TaskResult:
    task_id: str
    project_name: str
    triggered: bool
    crash_type: str
    strategy: str
    poc_size: int
    elapsed: float
    build_ok: bool
    notes: str


def run_task(
    task: SecBenchTask,
    router: Optional[LLMRouter],
    use_known_poc: bool = True,
) -> TaskResult:
    """Run the full CRS pipeline on a single task."""
    banner = f"  TASK: {task.task_id}"
    print(f"\n{'='*60}\n{banner}\n{'='*60}")
    print(f"  Description: {task.vulnerability_description[:100]}...")
    t0 = time.time()

    # Step 1: Build fuzz target
    print(f"\n  Step 1: Building fuzz target...")
    build = build_local_sample(task)
    if not build.success:
        elapsed = time.time() - t0
        print(f"  BUILD FAILED ({elapsed:.1f}s)")
        return TaskResult(
            task.task_id, task.project_name, False, "build_fail",
            "none", 0, elapsed, False, "Build failed",
        )
    print(f"  Built: {build.binary_path}")

    # Step 2: Generate PoC candidates
    print(f"\n  Step 2: Generating PoC candidates...")
    pocs: list[PoCCandidate] = []

    # Try known-good PoC first (for local samples)
    if use_known_poc:
        known_poc = _load_known_poc(task)
        if known_poc:
            pocs.insert(0, known_poc)

    # Generate via LLM + patterns
    generated = generate_all_pocs(task, router)
    pocs.extend(generated)

    if not pocs:
        elapsed = time.time() - t0
        return TaskResult(
            task.task_id, task.project_name, False, "no_pocs",
            "none", 0, elapsed, True, "No PoCs generated",
        )

    # Step 3: Test PoCs
    print(f"\n  Step 3: Testing {len(pocs)} candidate(s)...")
    results = run_all_pocs(build.binary_path, pocs, stop_on_trigger=True)

    triggered = [r for r in results if r.triggered]
    elapsed = time.time() - t0

    if triggered:
        best = triggered[0]
        print(f"\n  \033[92mSUCCESS\033[0m — {best.crash_type} via {best.poc.name} ({elapsed:.1f}s)")

        # Print sanitizer output excerpt
        print(f"\n  --- Sanitizer Output ---")
        for line in best.sanitizer_output.split("\n"):
            line_s = line.strip()
            if any(kw in line_s for kw in [
                "ERROR:", "SUMMARY:", "READ", "WRITE",
                "freed by", "allocated by", "#0 ", "#1 ", "#2 ",
            ]):
                print(f"  {line_s}")
        print(f"  --- End ---\n")

        return TaskResult(
            task.task_id, task.project_name, True, best.crash_type,
            best.poc.name, len(best.poc.data), elapsed, True,
            f"Triggered {best.crash_type} with {len(best.poc.data)} bytes",
        )
    else:
        print(f"\n  \033[91mNO TRIGGER\033[0m — tested {len(results)} PoC(s) ({elapsed:.1f}s)")
        return TaskResult(
            task.task_id, task.project_name, False, "no_trigger",
            "none", 0, elapsed, True,
            f"Tested {len(results)} PoCs, none triggered",
        )


def _load_known_poc(task: SecBenchTask) -> Optional[PoCCandidate]:
    """Load the known-good PoC script from the sample directory."""
    poc_script = task.repo_path / "poc_known_good.py"
    if not poc_script.exists():
        return None

    print(f"  [gen] Running known-good PoC script: {poc_script.name}")
    try:
        r = subprocess.run(
            ["python3", str(poc_script)],
            capture_output=True, timeout=10,
        )
        if r.returncode != 0:
            print(f"  [gen] Known-good PoC script failed: {r.stderr.decode()[:200]}")
            return None

        data = r.stdout
        if not data:
            return None

        path = cfg.task_work_dir(task.task_id) / "poc_known_good.bin"
        path.write_bytes(data)

        print(f"  [gen] Known-good PoC: {len(data)} bytes")
        return PoCCandidate(
            "known_good", data, path, 0.99,
            f"Known-good PoC: {len(data)} bytes",
        )
    except Exception as e:
        print(f"  [gen] Error loading known-good PoC: {e}")
        return None


# ── CLI ────────────────────────────────────────────────────────────────────

def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="CRS — Cyber Reasoning System (SEC-bench edition)",
    )
    p.add_argument("--samples-dir", default=None,
                    help="Directory containing sample task subdirectories")
    p.add_argument("--sample", default=None,
                    help="Path to a single sample directory")
    p.add_argument("--output-dir", default="./crs_results",
                    help="Output directory for results")

    # LLM options
    p.add_argument("--model", default=cfg.LLM_MODEL)
    p.add_argument("--base-url", default=cfg.LLM_BASE_URL)
    p.add_argument("--api-key", default=cfg.LLM_API_KEY)
    p.add_argument("--no-llm", action="store_true",
                    help="Skip LLM-based PoC generation (use patterns + known-good only)")

    # SEC-bench options
    p.add_argument("--secbench", action="store_true",
                    help="Load tasks from SEC-bench HuggingFace dataset")
    p.add_argument("--instance-id", nargs="*", default=None,
                    help="Specific SEC-bench instance IDs to run")

    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    print("\033[96m")
    print("  " + "=" * 55)
    print("  CRS — Cyber Reasoning System (SEC-bench edition)")
    print("  " + "=" * 55)
    print("\033[0m")
    print(f"  Model  : {args.model}")
    print(f"  URL    : {args.base_url}")
    print(f"  LLM    : {'disabled' if args.no_llm else 'enabled'}")
    print(f"  Output : {args.output_dir}")

    # Set up LLM router
    router: Optional[LLMRouter] = None
    if not args.no_llm:
        try:
            router = LLMRouter(args.model, args.base_url, args.api_key)
            print(f"  Router : connected to {args.base_url}")
        except Exception as e:
            print(f"  Router : FAILED ({e}) — falling back to no-LLM mode")

    # Load tasks
    tasks: list[SecBenchTask] = []

    if args.sample:
        tasks = [load_local_sample(args.sample)]
    elif args.samples_dir:
        tasks = load_all_local_samples(args.samples_dir)
    elif args.secbench:
        from crs.secbench_adapter import load_secbench_from_hf
        tasks = load_secbench_from_hf(instance_ids=args.instance_id)
    else:
        # Default: look for ./samples directory
        samples_dir = Path(__file__).parent.parent / "samples"
        if samples_dir.exists():
            tasks = load_all_local_samples(samples_dir)
        else:
            print("  ERROR: No tasks specified. Use --samples-dir, --sample, or --secbench")
            sys.exit(1)

    print(f"  Tasks  : {len(tasks)}\n")

    # Run pipeline
    all_results: list[TaskResult] = []
    for i, task in enumerate(tasks, 1):
        print(f"\n  [{i}/{len(tasks)}]")
        result = run_task(task, router, use_known_poc=True)
        all_results.append(result)

    # Save results
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    json_path = out_dir / "results.json"
    json_path.write_text(json.dumps(
        [asdict(r) for r in all_results], indent=2, default=str,
    ))
    print(f"\n  Results saved to {json_path}")

    # Print summary
    print(f"\n  {'='*70}")
    print(f"  CRS SUMMARY")
    print(f"  {'='*70}")
    for r in all_results:
        status = "\033[92mTRIGGERED\033[0m" if r.triggered else (
            "\033[93mBUILD FAIL\033[0m" if not r.build_ok else "\033[91mMISS\033[0m"
        )
        print(f"  {r.task_id:<20s} {status:<12s} {r.crash_type:<25s} "
              f"strategy={r.strategy:<15s} {r.elapsed:.1f}s")

    triggered = sum(r.triggered for r in all_results)
    print(f"  {'='*70}")
    print(f"  Triggered: {triggered}/{len(all_results)}  "
          f"Total time: {sum(r.elapsed for r in all_results):.1f}s")

    if router:
        router.log_stats()

    return 0 if triggered > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
