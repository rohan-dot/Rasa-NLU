"""
crs/runner.py — Run PoC bytes against a fuzz target and detect crashes.
"""
from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

from crs.byte_gen import PoCCandidate
from crs.config import cfg


@dataclass
class RunResult:
    poc: PoCCandidate
    triggered: bool
    crash_type: str
    sanitizer_output: str
    return_code: int


def detect_crash(return_code: int, output: str) -> Tuple[bool, str]:
    """Check if sanitizer output indicates a vulnerability trigger."""
    # ASAN
    for pat in [
        r"ERROR: AddressSanitizer",
        r"heap-buffer-overflow",
        r"stack-buffer-overflow",
        r"heap-use-after-free",
        r"SUMMARY: AddressSanitizer",
        r"AddressSanitizer",
    ]:
        if re.search(pat, output, re.IGNORECASE):
            m = re.search(r"ERROR: AddressSanitizer: (\S+)", output)
            return True, m.group(1) if m else "asan"

    # UBSAN
    for pat in [r"runtime error:", r"UndefinedBehaviorSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "ubsan"

    # MSAN
    for pat in [r"MemorySanitizer", r"use-of-uninitialized-value"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "msan"

    # Generic crashes
    for pat in [r"Segmentation fault", r"Aborted", r"double free"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "crash"

    # Signal-based crash
    if return_code not in (0, 1) and return_code < 0:
        return True, f"signal_{abs(return_code)}"

    return False, ""


def run_poc(poc: PoCCandidate, binary: Path) -> RunResult:
    """Feed a single PoC to the fuzz target binary."""
    print(f"  [run] {poc.name}: {len(poc.data)} bytes -> {binary.name}")
    try:
        r = subprocess.run(
            [str(binary)],
            input=poc.data,
            capture_output=True,
            timeout=cfg.RUN_TIMEOUT,
            cwd=str(binary.parent),
        )
        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        triggered, crash_type = detect_crash(r.returncode, output)

        status = f"\033[92mTRIGGERED ({crash_type})\033[0m" if triggered else "no trigger"
        print(f"  [run]   -> {status}  rc={r.returncode}")

        if triggered:
            # Print relevant sanitizer lines
            for line in output.split("\n"):
                line_s = line.strip()
                if any(kw in line_s for kw in ["ERROR:", "SUMMARY:", "runtime error"]):
                    print(f"  [run]   {line_s}")

        return RunResult(
            poc=poc, triggered=triggered, crash_type=crash_type,
            sanitizer_output=output[:8000], return_code=r.returncode,
        )

    except subprocess.TimeoutExpired:
        return RunResult(poc=poc, triggered=False, crash_type="timeout",
                         sanitizer_output="", return_code=-1)
    except Exception as e:
        return RunResult(poc=poc, triggered=False, crash_type="error",
                         sanitizer_output=str(e), return_code=-1)


def run_all_pocs(
    binary: Path, pocs: List[PoCCandidate], stop_on_trigger: bool = True,
) -> List[RunResult]:
    """Run all PoC candidates against the binary."""
    results: list[RunResult] = []
    print(f"\n  [pipeline] Testing {len(pocs)} candidate(s) against {binary.name}")

    for idx, poc in enumerate(pocs):
        print(f"\n  [{idx+1}/{len(pocs)}] {poc.name}")
        result = run_poc(poc, binary)
        results.append(result)

        if result.triggered and stop_on_trigger:
            print(f"\n  *** PoC {idx} TRIGGERED: {result.crash_type} ***")
            break

    return results
