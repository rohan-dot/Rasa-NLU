"""
crs/llm_router.py — LLM interface via vLLM (OpenAI-compatible).

Uses the openai client directly. No LiteLLM dependency.
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Optional

try:
    import openai
except ImportError:
    openai = None  # type: ignore

from crs.config import cfg

logger = logging.getLogger(__name__)


class LLMRouter:
    """Thin wrapper around openai.OpenAI with retry logic."""

    def __init__(
        self,
        model: str = cfg.LLM_MODEL,
        base_url: str = cfg.LLM_BASE_URL,
        api_key: str = cfg.LLM_API_KEY,
    ) -> None:
        if openai is None:
            raise ImportError("pip install openai to use LLMRouter")

        self.model = model
        self._calls = 0
        self._failures = 0
        self._prompt_tokens = 0
        self._completion_tokens = 0

        self._client = openai.OpenAI(
            base_url=base_url,
            api_key=api_key,
            timeout=300.0,
        )

    def chat(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = cfg.MAX_TOKENS,
        temperature: float = 0.2,
    ) -> str:
        """Send a chat completion request. Returns the response text."""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        last_error: Optional[Exception] = None
        for attempt in range(1, cfg.MAX_RETRIES + 1):
            try:
                response = self._client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
                self._calls += 1
                usage = response.usage
                if usage:
                    self._prompt_tokens += usage.prompt_tokens or 0
                    self._completion_tokens += usage.completion_tokens or 0
                return response.choices[0].message.content or ""

            except (openai.APITimeoutError, openai.APIConnectionError) as e:
                last_error = e
                wait = 2 ** (attempt - 1)
                print(f"  [LLM] Retryable error (attempt {attempt}): {type(e).__name__} — wait {wait}s")
                time.sleep(wait)

            except openai.RateLimitError as e:
                last_error = e
                wait = 2 ** attempt
                print(f"  [LLM] Rate limited (attempt {attempt}) — wait {wait}s")
                time.sleep(wait)

            except openai.APIStatusError as e:
                self._failures += 1
                raise RuntimeError(f"LLM non-retryable error: {e.status_code} - {e.body}")

            except Exception as e:
                last_error = e
                wait = 2 ** (attempt - 1)
                print(f"  [LLM] Error (attempt {attempt}): {type(e).__name__} — wait {wait}s")
                time.sleep(wait)

        self._failures += 1
        raise RuntimeError(f"LLM: all retries exhausted. Last error: {last_error}")

    def extract_code_block(self, response: str, language: str = "c") -> Optional[str]:
        pattern = rf"```{language}\s*\n(.*?)```"
        m = re.search(pattern, response, re.DOTALL | re.IGNORECASE)
        if m:
            return m.group(1).strip()
        m = re.search(r"```[a-z+]*\s*\n(.*?)```", response, re.DOTALL)
        if m:
            return m.group(1).strip()
        return None

    def log_stats(self) -> None:
        total = self._prompt_tokens + self._completion_tokens
        print(
            f"[LLMRouter] calls={self._calls} failed={self._failures} "
            f"prompt_tok={self._prompt_tokens} "
            f"completion_tok={self._completion_tokens} "
            f"total_tok={total}"
        )
