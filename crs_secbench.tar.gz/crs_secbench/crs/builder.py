"""
crs/builder.py — Build fuzz targets with sanitizers.

Handles two scenarios:
  1. Local samples: compile source.c + harness.c directly
  2. SEC-bench Docker: project is at /repo, may need autotools/cmake/make
"""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from crs.config import cfg
from crs.secbench_adapter import SecBenchTask


@dataclass
class BuildResult:
    success: bool
    binary_path: Optional[Path]
    build_log: str


_STANDALONE_DRIVER = """\
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size);
extern "C" int LLVMFuzzerInitialize(int *argc, char ***argv) __attribute__((weak));

int main(int argc, char **argv) {
    if (LLVMFuzzerInitialize)
        LLVMFuzzerInitialize(&argc, &argv);
    FILE *f = stdin;
    if (argc > 1) {
        f = fopen(argv[1], "rb");
        if (!f) { perror("fopen"); return 1; }
    }
    size_t capacity = 65536, len = 0;
    uint8_t *buf = (uint8_t *)malloc(capacity);
    if (!buf) { perror("malloc"); return 1; }
    while (1) {
        size_t n = fread(buf + len, 1, capacity - len, f);
        len += n;
        if (n == 0) break;
        if (len == capacity) {
            capacity *= 2;
            buf = (uint8_t *)realloc(buf, capacity);
            if (!buf) { perror("realloc"); return 1; }
        }
    }
    if (f != stdin) fclose(f);
    /* Shrink buffer to exact size so ASAN catches overreads */
    if (len > 0) {
        buf = (uint8_t *)realloc(buf, len);
        if (!buf) { perror("realloc-shrink"); return 1; }
    }
    LLVMFuzzerTestOneInput(buf, len);
    free(buf);
    return 0;
}
"""


def _run(cmd, timeout=cfg.BUILD_TIMEOUT, cwd=None, env=None):
    """Run a command and return the CompletedProcess."""
    return subprocess.run(
        cmd, capture_output=True, timeout=timeout,
        cwd=str(cwd) if cwd else None, env=env,
    )


def build_local_sample(task: SecBenchTask) -> BuildResult:
    """
    Build a self-contained local sample (source.c + harness.c).
    This is the simple path for our two built-in examples.
    """
    work = cfg.task_work_dir(task.task_id)
    log_parts: list[str] = []

    # Write standalone driver
    driver_path = work / "driver.cpp"
    driver_path.write_text(_STANDALONE_DRIVER, encoding="utf-8")

    # Collect source files (exclude harness — it's compiled separately)
    sources = [str(f) for f in task.source_files if f != task.harness_path]

    san_flags = cfg.SANITIZER_FLAGS
    binary = work / "fuzz_target"

    # Compile everything together
    cmd = [
        "g++", "-fpermissive",
        *san_flags.split(),
        "-include", "string.h",
        "-include", "stdint.h",
        str(driver_path),
    ]

    if task.harness_path:
        cmd.append(str(task.harness_path))

    cmd.extend(sources)
    cmd.extend(["-I", str(task.repo_path)])
    cmd.extend(["-o", str(binary)])
    cmd.extend(["-lm", "-lpthread"])

    print(f"[build] Compiling: {' '.join(cmd[-8:])}")

    try:
        r = _run(cmd, cwd=work)
        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        log_parts.append(output)

        if r.returncode != 0:
            print(f"[build] FAILED:\n{output[-2000:]}")
            return BuildResult(False, None, "\n".join(log_parts))

    except subprocess.TimeoutExpired:
        return BuildResult(False, None, "Build timed out")
    except Exception as e:
        return BuildResult(False, None, f"Build error: {e}")

    os.chmod(binary, 0o755)
    print(f"[build] SUCCESS: {binary}")
    return BuildResult(True, binary, "\n".join(log_parts))


def build_secbench_project(task: SecBenchTask) -> BuildResult:
    """
    Build a SEC-bench project inside its Docker container.
    The source is at task.repo_path (typically /repo).
    """
    repo = task.repo_path
    work = cfg.task_work_dir(task.task_id)
    log_parts: list[str] = []

    env = os.environ.copy()
    san = cfg.SANITIZER_FLAGS
    env["CFLAGS"] = san
    env["CXXFLAGS"] = san
    env["LDFLAGS"] = "-fsanitize=address,undefined"

    # Detect build system
    build_type = _detect_build_system(repo)
    print(f"[build] Build system: {build_type}")

    try:
        if build_type == "autotools":
            if (repo / "configure.ac").exists():
                r = _run(["autoreconf", "-fi"], cwd=repo, env=env)
                log_parts.append(r.stderr.decode(errors="replace"))
            if (repo / "configure").exists():
                r = _run(
                    ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
                     f"LDFLAGS=-fsanitize=address,undefined",
                     "--enable-static", "--disable-shared"],
                    cwd=repo, env=env, timeout=180,
                )
                log_parts.append(r.stderr.decode(errors="replace"))
                if r.returncode != 0:
                    r = _run(["./configure", f"CFLAGS={san}"], cwd=repo, env=env, timeout=180)
                    log_parts.append(r.stderr.decode(errors="replace"))
            r = _run(["make", "-j4"], cwd=repo, env=env, timeout=300)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                print("[build] make FAILED")
                return BuildResult(False, None, "\n".join(log_parts))

        elif build_type == "cmake":
            build_dir = work / "build"
            build_dir.mkdir(parents=True, exist_ok=True)
            r = _run(
                ["cmake", "-B", str(build_dir), "-S", str(repo),
                 f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
                 "-DBUILD_TESTING=OFF", "-DBUILD_SHARED_LIBS=OFF"],
                cwd=repo, env=env,
            )
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return BuildResult(False, None, "\n".join(log_parts))
            r = _run(["cmake", "--build", str(build_dir), "-j4"], cwd=repo, env=env, timeout=300)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return BuildResult(False, None, "\n".join(log_parts))

        else:  # plain make
            r = _run(["make", "-j4"], cwd=repo, env=env, timeout=300)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return BuildResult(False, None, "\n".join(log_parts))

        print("[build] Project build SUCCESS")

    except subprocess.TimeoutExpired:
        return BuildResult(False, None, "\n".join(log_parts) + "\nBuild timed out")
    except Exception as e:
        return BuildResult(False, None, f"\nBuild error: {e}")

    # Find static library
    static_lib = _find_static_lib(repo, work)
    if not static_lib:
        print("[build] No static library found — trying direct object linking")
        return BuildResult(False, None, "\n".join(log_parts) + "\nNo .a found")

    # Now build the fuzz target against the library
    if task.harness_path and task.harness_path.exists():
        return _link_fuzz_target(task, static_lib, work, log_parts)

    return BuildResult(False, None, "\n".join(log_parts) + "\nNo harness found")


def _detect_build_system(repo: Path) -> str:
    if (repo / "configure.ac").exists() or (repo / "configure").exists():
        return "autotools"
    if (repo / "CMakeLists.txt").exists():
        return "cmake"
    if (repo / "Makefile").exists() or (repo / "makefile").exists():
        return "make"
    # Search one level deep
    for d in sorted(repo.iterdir()):
        if d.is_dir():
            if (d / "CMakeLists.txt").exists():
                return "cmake"
            if (d / "configure.ac").exists():
                return "autotools"
    return "make"


def _find_static_lib(repo: Path, work: Path) -> Optional[Path]:
    skip = {"test", "tests", "example", "doc", "fuzz"}
    for search_root in [work / "build", repo]:
        if not search_root.exists():
            continue
        candidates = []
        for lib in sorted(search_root.rglob("*.a")):
            try:
                if {p.lower() for p in lib.parts} & skip:
                    continue
                if lib.is_symlink() and not lib.resolve().exists():
                    continue
                candidates.append(lib)
            except (OSError, ValueError):
                continue
        if candidates:
            best = max(candidates, key=lambda p: p.stat().st_size)
            print(f"[build] Found static lib: {best} ({best.stat().st_size} bytes)")
            return best
    return None


def _link_fuzz_target(
    task: SecBenchTask, static_lib: Path, work: Path, log_parts: list[str]
) -> BuildResult:
    driver_path = work / "driver.cpp"
    driver_path.write_text(_STANDALONE_DRIVER, encoding="utf-8")

    include_dirs: set[str] = set()
    for h in task.repo_path.rglob("*.h"):
        include_dirs.add(str(h.parent))
    include_dirs.add(str(task.repo_path))

    binary = work / "fuzz_target"
    san = cfg.SANITIZER_FLAGS

    cmd = [
        "g++", "-fpermissive", *san.split(),
        "-include", "string.h",
        str(driver_path), str(task.harness_path),
        "-o", str(binary), str(static_lib),
    ]
    cmd += [f"-I{d}" for d in sorted(include_dirs)]
    cmd += ["-lz", "-lm", "-lpthread"]

    try:
        r = _run(cmd, cwd=work)
        output = r.stderr.decode(errors="replace")
        log_parts.append(output)
        if r.returncode != 0:
            print(f"[build] Link FAILED:\n{output[-2000:]}")
            return BuildResult(False, None, "\n".join(log_parts))
    except subprocess.TimeoutExpired:
        return BuildResult(False, None, "\n".join(log_parts) + "\nLink timed out")

    os.chmod(binary, 0o755)
    print(f"[build] Fuzz target ready: {binary}")
    return BuildResult(True, binary, "\n".join(log_parts))
