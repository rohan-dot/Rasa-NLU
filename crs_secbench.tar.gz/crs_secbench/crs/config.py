"""
crs/config.py — Configuration for CRS (SEC-bench edition).

Inside a SEC-bench Docker container the project source lives at /repo.
The LLM is reached via vLLM (OpenAI-compatible) — no LiteLLM.
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path


def _resolve_work_dir() -> Path:
    p = Path(os.environ.get("CRS_WORK_DIR", "/tmp/crs_workdir"))
    p.mkdir(parents=True, exist_ok=True)
    return p


@dataclass
class CRSConfig:
    # — LLM backend (vLLM, no LiteLLM) ———————————————————
    LLM_BASE_URL: str = field(
        default_factory=lambda: os.environ.get(
            "OPENAI_BASE_URL",
            "http://g52lambda02.llan.ll.mit.edu:8000/v1",
        )
    )
    LLM_API_KEY: str = field(
        default_factory=lambda: os.environ.get("OPENAI_API_KEY", "EMPTY")
    )
    LLM_MODEL: str = field(
        default_factory=lambda: os.environ.get("LLM_MODEL", "gemma-3-27b-it")
    )

    MAX_TOKENS: int = 4096
    MAX_RETRIES: int = 3

    # — Build / run limits ————————————————————————————————
    BUILD_TIMEOUT: int = 180
    RUN_TIMEOUT: int = 60

    # — Filesystem ————————————————————————————————————————
    WORK_DIR: Path = field(default_factory=_resolve_work_dir)

    # — Sanitizers ————————————————————————————————————————
    USE_SANITIZERS: bool = True
    SANITIZER_FLAGS: str = "-fsanitize=address,undefined -g -O1"

    def __post_init__(self) -> None:
        self.WORK_DIR = Path(self.WORK_DIR)
        self.WORK_DIR.mkdir(parents=True, exist_ok=True)

    def task_work_dir(self, task_id: str) -> Path:
        safe = task_id.replace(":", "_").replace("/", "_").replace("__", "_")
        d = self.WORK_DIR / safe
        d.mkdir(parents=True, exist_ok=True)
        return d


cfg = CRSConfig()

# Convenience aliases
WORK_DIR = cfg.WORK_DIR
BUILD_TIMEOUT = cfg.BUILD_TIMEOUT
RUN_TIMEOUT = cfg.RUN_TIMEOUT
MAX_TOKENS = cfg.MAX_TOKENS
MAX_RETRIES = cfg.MAX_RETRIES
