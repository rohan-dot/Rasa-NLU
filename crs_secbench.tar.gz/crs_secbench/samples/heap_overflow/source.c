/*
 * vuln_parser.c — Vulnerable packet parser with heap-buffer-overflow.
 *
 * The parser reads a 4-byte length field from input, allocates a buffer
 * of that size, then copies MORE bytes than allocated when the length
 * field is larger than the remaining input but the memcpy uses the
 * length field directly without bounds checking.
 *
 * Bug: memcpy uses user-controlled length without clamping to actual
 *      available data size, causing a heap-buffer-overflow READ on the
 *      source buffer when len > remaining input.
 *
 * CVE-like: heap-buffer-overflow in parse_packet()
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* Simple packet format:
 *   [0..3]  magic:  0xDEADBEEF (little-endian)
 *   [4..5]  type:   uint16_t
 *   [6..9]  length: uint32_t  (length of payload)
 *   [10..]  payload: raw bytes
 */

typedef struct {
    uint32_t magic;
    uint16_t type;
    uint32_t payload_len;
    uint8_t *payload;
} Packet;

/*
 * BUG IS HERE: when payload_len > (input_size - 10), the memcpy reads
 * past the end of the input buffer → heap-buffer-overflow.
 */
int parse_packet(const uint8_t *data, size_t size, Packet *pkt) {
    if (size < 10) return -1;

    memcpy(&pkt->magic, data, 4);
    if (pkt->magic != 0xDEADBEEF) return -1;

    memcpy(&pkt->type, data + 4, 2);
    memcpy(&pkt->payload_len, data + 6, 4);

    if (pkt->payload_len == 0) return -1;
    if (pkt->payload_len > 1024 * 1024) return -1;  /* cap at 1MB */

    pkt->payload = (uint8_t *)malloc(pkt->payload_len);
    if (!pkt->payload) return -1;

    /*
     * VULNERABILITY: copies payload_len bytes from data+10, but does
     * NOT check if (size - 10) >= payload_len.  If the input is
     * shorter than declared, this reads past the input buffer.
     */
    memcpy(pkt->payload, data + 10, pkt->payload_len);

    return 0;
}

int process_packet(const uint8_t *data, size_t size) {
    Packet pkt;
    memset(&pkt, 0, sizeof(pkt));

    int rc = parse_packet(data, size, &pkt);
    if (rc != 0) return rc;

    /* "Process" the payload — just access it */
    uint32_t sum = 0;
    for (uint32_t i = 0; i < pkt.payload_len; i++) {
        sum += pkt.payload[i];
    }

    free(pkt.payload);
    return (int)(sum & 0xFF);
}
