/*
 * harness.c — Fuzz harness for vuln_parser.c
 */
#include <stdint.h>
#include <stddef.h>

/* Declare the function from source.c */
int process_packet(const uint8_t *data, size_t size);

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    process_packet(data, size);
    return 0;
}
