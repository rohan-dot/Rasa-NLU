/*
 * vuln_cache.c — Vulnerable cache with use-after-free.
 *
 * A simple key-value cache that supports ADD, GET, and DELETE commands.
 * The bug: after DELETE frees an entry, a subsequent GET can still
 * access the freed memory through a dangling pointer in the lookup
 * table, causing a use-after-free.
 *
 * CVE-like: heap-use-after-free in cache_get()
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define MAX_ENTRIES 16
#define MAX_KEY_LEN 32
#define MAX_VAL_LEN 128

typedef struct {
    char key[MAX_KEY_LEN];
    char *value;  /* heap-allocated */
    int active;
} CacheEntry;

/* Global cache — entries are set to NULL on delete but the slot
 * pointer can be reused before being cleared */
static CacheEntry *cache[MAX_ENTRIES];
static int cache_count = 0;

/* Command byte layout:
 *   byte 0:       command (1=ADD, 2=GET, 3=DELETE)
 *   byte 1:       slot index (0..15)
 *   byte 2:       key_len (1..31)
 *   byte 3..3+kl: key bytes
 *   next byte:    val_len (for ADD only, 1..127)
 *   next bytes:   value bytes (for ADD only)
 */

static int handle_add(const uint8_t *data, size_t size, size_t *pos) {
    if (*pos + 2 >= size) return -1;
    uint8_t slot = data[(*pos)++];
    uint8_t key_len = data[(*pos)++];

    if (slot >= MAX_ENTRIES) return -1;
    if (key_len == 0 || key_len >= MAX_KEY_LEN) return -1;
    if (*pos + key_len >= size) return -1;

    CacheEntry *e = (CacheEntry *)malloc(sizeof(CacheEntry));
    if (!e) return -1;

    memset(e, 0, sizeof(CacheEntry));
    memcpy(e->key, data + *pos, key_len);
    e->key[key_len] = '\0';
    *pos += key_len;

    if (*pos >= size) { free(e); return -1; }
    uint8_t val_len = data[(*pos)++];
    if (val_len == 0 || val_len >= MAX_VAL_LEN) { free(e); return -1; }
    if (*pos + val_len > size) { free(e); return -1; }

    e->value = (char *)malloc(val_len + 1);
    if (!e->value) { free(e); return -1; }
    memcpy(e->value, data + *pos, val_len);
    e->value[val_len] = '\0';
    *pos += val_len;

    e->active = 1;

    /* If slot already occupied, free old entry */
    if (cache[slot]) {
        free(cache[slot]->value);
        free(cache[slot]);
    }
    cache[slot] = e;
    cache_count++;
    return 0;
}

static int handle_delete(const uint8_t *data, size_t size, size_t *pos) {
    if (*pos >= size) return -1;
    uint8_t slot = data[(*pos)++];
    if (slot >= MAX_ENTRIES) return -1;

    if (cache[slot] && cache[slot]->active) {
        free(cache[slot]->value);
        cache[slot]->value = NULL;
        /*
         * BUG: We free the entry but DON'T set cache[slot] = NULL.
         * The pointer remains in the array as a dangling pointer.
         * We only set active = 0, but a GET still dereferences the
         * freed struct to check the active flag.
         */
        cache[slot]->active = 0;  /* UAF WRITE: writing to freed memory */
        free(cache[slot]);
        /* cache[slot] is NOT set to NULL here — dangling pointer! */
        cache_count--;
    }
    return 0;
}

/*
 * BUG TRIGGERED HERE: cache[slot] points to freed memory.
 * Dereferencing it to check ->active is a use-after-free READ.
 */
static int handle_get(const uint8_t *data, size_t size, size_t *pos) {
    if (*pos >= size) return -1;
    uint8_t slot = data[(*pos)++];
    if (slot >= MAX_ENTRIES) return -1;

    if (cache[slot] && cache[slot]->active) {  /* UAF READ */
        /* Access the value — also UAF if we get here */
        volatile char c = cache[slot]->key[0];
        (void)c;
    }
    return 0;
}

int process_commands(const uint8_t *data, size_t size) {
    /* Reset cache for each fuzz input */
    memset(cache, 0, sizeof(cache));
    cache_count = 0;

    size_t pos = 0;
    while (pos < size) {
        uint8_t cmd = data[pos++];
        int rc;

        switch (cmd) {
            case 1: rc = handle_add(data, size, &pos); break;
            case 2: rc = handle_get(data, size, &pos); break;
            case 3: rc = handle_delete(data, size, &pos); break;
            default: continue;
        }
        if (rc != 0) break;
    }

    /* Cleanup remaining entries */
    for (int i = 0; i < MAX_ENTRIES; i++) {
        if (cache[i]) {
            /* This might double-free if the entry was already freed
             * by DELETE — but ASAN will catch the UAF first */
        }
    }

    return 0;
}
