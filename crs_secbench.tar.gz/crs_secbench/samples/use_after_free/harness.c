/*
 * harness.c — Fuzz harness for vuln_cache.c
 */
#include <stdint.h>
#include <stddef.h>

int process_commands(const uint8_t *data, size_t size);

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    process_commands(data, size);
    return 0;
}
