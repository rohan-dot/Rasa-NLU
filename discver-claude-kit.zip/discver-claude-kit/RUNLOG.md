# discver RUNLOG — one entry per run or replay, newest at the bottom

## History (runs 1–8)

| # | Date | Symptom | Root cause | Fix (commit) |
|---|---|---|---|---|
| 1 | — | Silent skip, no patch output | No build command → patcher skipped every crash silently | loud-skip logging |
| 2 | — | "LLM request timed out" | Long RCA calls exceeded client timeout | timeout raised |
| 3 | — | "agent gave up: No task context was provided", test_calls=0 | `_crash_brief` lacked PoV paths, scratch path, tool names | 02d930f |
| 4 | — | `build_ok` never True | Rebuild from a bare source copy with the wrong `$SRC` layout | 8ec0471 — libCRS sidecar (`apply-patch-build` / `run-pov` / `run-test`); confirmed `build oracle path: SIDECAR` |
| 5 | — | 30 iterations, 0–1 test_calls, no per-turn log lines | Unparseable replies silently dropped; no fail-fast on build failure | 91cea4b — `[patch-turn]` logging, validate→repair, fail-fast, nudge-to-test |
| 6 | Sep 9 | attempts=15, test_calls=0 on both crashes | Never diagnosed: the `[patch-turn]` grep was not read before the next change shipped | — |
| 7 | Sep 10 15:16 | failed=1: `agent returned no reply (LLM timed out after retries)`, attempts=1, test_calls=0. Health WEAK: X509Fuzzer 473 execs saturated by shallow crash, cov 2043→2043; SinkFuzzer1 57.3M execs, cov 2062 flat, corpus 0→0 | Runtime LLM timeout on the patcher's first call; timeout value and prompt size were not logged | "Task B" patch-loop client change (`[llm-call]` logging, thinking off, no guided JSON, adaptive retry) — confirm it actually shipped in run 8 |
| 8 | Sep 10 20:57 (id 1789065189…) | failed=2, reasons unread. **`LLM-generated seeds: 0`** (regression). Health DEAD: X509Fuzzer 475 execs, corpus 0→0, peak coverage 0; GenFuzzer0 51.7M execs, cov 0; SinkFuzzer1 47.5M execs, cov 0; GenFuzzer1 / SinkFuzzer0 HEALTHY, cov ~1350, corpus 0→2. Strategy rounds 20; cross_file_audit 203s and 169s for 0 findings; LLM analysis findings 1 (arbiter-overruled). Unreproduced hash c7e15e8aac14 listed twice | UNKNOWN — read patch_index.json and grep seeds first | — |

## Open questions (answer these before any new change)
1. Run 8 `patches/patch_index.json`: the two `reason` strings, attempts, test_calls.
2. Why `LLM-generated seeds: 0` in run 8 when run 7 had seeds. Did the patch-loop client change leak into `pb_seeds.py`'s calls? Did the runtime LLM time out or error on seed generation? (`grep -niE "seed" orchestrator.log`)
3. Are `[llm-call]` lines present in run 8's orchestrator.log? If not, the Task B code did not ship.
4. Runtime LLM latency measured directly: `/v1/models`, a 1-token completion, a ~4k-token prompt, with and without thinking.
5. Why X509Fuzzer coverage reads 0 in run 8 vs 2043 in run 7 with the same ~475 execs: no initial corpus (seeds=0), or a stats-parsing change?
6. The exact command to run `patch_replay` inside the discver container (compose run vs exec).
7. Why the unreproduced entry `c7e15e8aac14` is listed twice (dedup of unreproduced records).

## Entry template
### <run-id or replay-<timestamp>> — <date>
- Change under test: <commit> — <one line>
- Oracle: <tests | patch_replay | full run> — command: `<cmd>`
- Result (verbatim key lines: patch_index reasons, [llm-call] lines, health verdict):
- Verdict: <hypothesis confirmed / refuted> → next change:
