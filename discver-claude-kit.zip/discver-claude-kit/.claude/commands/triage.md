Run the `log-analyst` subagent on this run directory: $ARGUMENTS

If no directory was given, use the newest run under `.oss-crs-workdir/` (find it with `ls -t`) and say which one you chose.

Append the analyst's report verbatim to RUNLOG.md under a new `###` heading with the run id and date.

Then answer in three lines, no more:
1. the single most likely cause of the patch failure, with the log line that supports it
2. the cause of `LLM-generated seeds: 0`, if present
3. the one change to test next, and which oracle proves it (tests / patch_replay / full run)
