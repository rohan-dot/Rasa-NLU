Preflight before spending a full run. Answer each with evidence, and refuse to start the run if any answer is no:
1. Which single change is under test, and which commit?
2. Did `patch_replay` pass on that commit? Paste the patch_index entry from the replay dir.
3. Did `python -m py_compile src/*.py` and the full suite pass? Paste the last lines.
4. Is there a RUNLOG.md entry for the replay?
5. Is the runtime LLM endpoint up (`/v1/models`) and answering a 1-token request in seconds? Paste the timing.

Then start the full run with the command in CLAUDE.md, record the start time and run id in RUNLOG.md, wait for it to finish, and run `/triage` on the new run dir.
