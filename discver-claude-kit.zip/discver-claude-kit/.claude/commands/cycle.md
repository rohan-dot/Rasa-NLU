Hypothesis to test: $ARGUMENTS

Execute exactly one cycle as defined in CLAUDE.md:
1. Restate the hypothesis, the single behavioural change that tests it, and the oracle that will prove or refute it (tests / patch_replay / full run).
2. Delegate to `patch-engineer` (patch loop, builder wiring, replay) or `fuzz-engineer` (seeds, harnesses, health). One of them, not both.
3. Run `reviewer` on the resulting diff. If BLOCK, fix and re-review before continuing.
4. Run the oracle: `python -m py_compile src/*.py`, the full test suite, and `patch_replay` on the run dir named in RUNLOG.md. Paste the outputs.
5. Commit on `claude/discver-fix`.
6. Append an entry to RUNLOG.md using the template, including the oracle output and the verdict (confirmed / refuted) and the next change.

Stop and report if any step fails. Do not begin a second change in this cycle.
