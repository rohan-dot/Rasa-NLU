Ask the `reference-reader` subagent: $ARGUMENTS

Return its answer in its format (MECHANISM / WHERE / ASSUMPTIONS THEY MAKE / DISCVER GAP / ONE-CYCLE PORT / LICENSE NOTE).

Then propose at most one `/cycle` hypothesis derived from it — or say plainly why nothing transfers to discver under GLM-5 on vLLM.
