# How to run — your paths, copy-paste

Everything runs from `/exp/FY26/aim/ro31337/AIA` (the folder that holds `lora_review_agents/` and the deck).
Two launchers have your paths built in, so there is nothing long to paste:

| What | Command |
|---|---|
| Fine-tuned vs base model, both with agentic retrieval | `bash lora_review_agents/run_rag.sh` |
| **Plain RAG vs agentic RAG**, for both models (includes the line above) | `bash lora_review_agents/run_plain_vs_agentic.sh` |
| October — audit report + architecture | `bash lora_review_agents/run_audit.sh` |

## 0. Once

```bash
cd /exp/FY26/aim/ro31337/AIA
unzip -o lora_review_agents.zip                     # use the name your browser gave the download
cp lora_review_agents/env.sh.example lora_review_agents/env.sh
nano lora_review_agents/env.sh                      # LiteLLM URL, key, your gpt-5.6 model name, CA bundle
```

Both launchers read `env.sh` by themselves. If you already export `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`
and `LLM_CA_BUNDLE` in your shell, skip `env.sh`.

## 1. Fine-tuned vs base model inside agentic RAG

```bash
cd /exp/FY26/aim/ro31337/AIA
bash lora_review_agents/run_rag.sh --check       # 1. runner endpoint, GPU stack, paths — seconds, changes nothing
bash lora_review_agents/run_rag.sh --limit 5     # 2. five questions through every stage — minutes
bash lora_review_agents/run_rag.sh               # 3. the real run: 200 sampled questions (--limit 0 = all)
```

After step 2 read two short files before starting step 3:

- `rag_outputs/setup_notes.md` — which adapter, base model and question file the runner picked, and why
- `rag_outputs/sample_prompts.md` — the first prompt of each model, exactly as sent. The fine-tuned model's
  prompt must look like the training text in `train_sft.py`.

If either is wrong, fix it and go again — only the affected answers are regenerated:

```bash
bash lora_review_agents/run_rag.sh --limit 5 --adapter /path/to/adapter_dir      # or --eval-file FILE, --base-model PATH
nano rag_outputs/rag_config.json                                                  # prompt templates, max_new_tokens, stop strings
bash lora_review_agents/run_rag.sh --limit 5 --redo setup                         # let the runner read the project again
```

The result is `rag_outputs/comparison.md`; the headline is also printed at the end of the run.
A winner is only named from 30 questions up. `--limit 5` tests the plumbing, and its report says
`too few questions to call` — that is expected.

What step 3 does, in order (each stage keeps its output, so re-running the same command continues where it stopped):

| Stage | Who | Output in `rag_outputs/` |
|---|---|---|
| setup | runner (GPT-5.6) reads `train.sh`, `train_sft.py`, the adapter, the data | `rag_config.json`, `setup_notes.md` |
| index | this code (BM25 over `af_epubs`) | `index/` |
| retrieve | runner searches, rewrites the query, picks passages — once per question | `evidence.jsonl` |
| generate | the fine-tuned model, then the base model, on the **same** passages (GPU) | `predictions_*.jsonl`, `sample_prompts.md` |
| judge | runner scores each answer against the reference, not knowing which model wrote it | `judgments.jsonl` |
| report | this code: metrics, paired statistics, examples | `comparison.md`, `per_example.csv` |

Useful additions:

```bash
bash lora_review_agents/run_rag.sh --with-closed-book      # also answer WITHOUT retrieval: shows what retrieval itself adds
bash lora_review_agents/run_rag.sh --limit 0               # the whole evaluation set
bash lora_review_agents/run_rag.sh --retrieval single      # one plain BM25 query instead of the agentic loop
OUT_DIR=rag_outputs_v2 bash lora_review_agents/run_rag.sh  # a separate output folder
```

**If `--check` says torch / transformers / peft are missing:** only the generate stage needs them. Run it in the
environment the adapter was trained in (`setup_notes.md` quotes how `train.sh` sets that up), then come back.
Keep any extra flags (such as `--limit 5`) the same in all three commands:

```bash
bash lora_review_agents/run_rag.sh                      # here: stops at generate and says so; everything before it is saved
# ...in the training environment, same folder:
bash lora_review_agents/run_rag.sh --stages generate
# ...back here:
bash lora_review_agents/run_rag.sh                      # judges and writes the report
```

## 2. Plain RAG vs agentic RAG

```bash
cd /exp/FY26/aim/ro31337/AIA
bash lora_review_agents/run_plain_vs_agentic.sh --limit 5     # plumbing test; reuses the agentic answers you already have
bash lora_review_agents/run_plain_vs_agentic.sh               # the real run: 200 sampled questions
```

What the two words mean in this code:

| | Who chooses the passages |
|---|---|
| **Plain RAG** | nobody: one search with the question as written, the top 5 hits go to the model |
| **Agentic RAG** | GPT-5.6: it searches, reads the hits, rewrites the query, searches again (up to 4 times), then picks up to 5 passages |

In both, your model writes the answer from the passages (the fine-tuned one, then the base one) and GPT-5.6
grades it without knowing which run or model it came from.

The command does three things, and re-running it continues where it stopped:

1. agentic RAG → `rag_outputs/` — exactly what `run_rag.sh` does; anything already finished there is reused
2. plain RAG → `rag_outputs_plain/` — same adapter, base model, questions and prompts
3. one table → `rag_outputs/plain_vs_agentic.md` (the headline is also printed)

| | Plain RAG | Agentic RAG |
|---|---|---|
| Base model | · | · |
| Fine-tuned (LoRA) | · | · |

Across a row is what the agentic approach adds; down a column is what fine-tuning adds. Every difference comes
with a 95% interval, and a winner is named only from 30 questions up. The file also shows whether the agent
actually found better passages, and the questions where the two runs differ most.

Two limits: "agentic" here is agent-driven retrieval (the answering model does not use tools, and nothing
re-checks its answer), and plain RAG is this code's keyword search over the same EPUBs, not the RAG code on LLSC.

**Third column: improved agentic RAG.** Add `--plus` to the same command:

```bash
bash lora_review_agents/run_plain_vs_agentic.sh --plus
```

It adds a third run in `rag_outputs_plus/` and a third column in the same report. Improved agentic RAG is
agentic RAG with three changes:

1. the agent's own passage picks stay first, and the spare slots (up to 5) are filled with the next-best hits;
2. the fine-tuned model first answers from memory, and GPT-5.6 uses that draft's vocabulary for its searches
   (the draft is never shown to the answering model);
3. after the model answers, GPT-5.6 checks the answers against the passages; where they are not supported it
   searches again and the model answers that question once more with the new passages.

**The fine-tuned model on its own.** Add `--with-closed-book` to the same command. Both models then also answer
every question from memory with no passages (for the fine-tuned one, that is the fine-tuning as it was built), and
the report gains a section "The models on their own vs with retrieval" that compares that with each retrieval
column on the same questions. Finished runs are reused; only the from-memory answers are generated and judged.

Both models still get the same passages for every question. The third run loads the model three times (draft,
answer, second answer), and it needs the runner and the GPU libraries in the same environment.

If torch / transformers / peft live in another environment, it is the same three passes as in section 1:
this command here, this command plus `--stages generate` in the training environment, this command here again.

## 3. Audit report + architecture (the October pipeline)

```bash
cd /exp/FY26/aim/ro31337/AIA
bash lora_review_agents/run_audit.sh                         # explores quanta/, lora/, corpus/ and the deck
bash lora_review_agents/run_audit.sh --report-from-notes     # if agent_outputs/report_notes.md exists: skip the 20-minute exploration
```

Output: `agent_outputs/report.md`, `agent_outputs/ARCHITECTURE.md`, `agent_outputs/scaffold/`.

## 4. When something goes wrong

| You see | Do this |
|---|---|
| a lone `>` and nothing happens | the shell is waiting for the rest of a command: Ctrl-C and run it again (the launchers avoid this) |
| `CERTIFICATE_VERIFY_FAILED` | set `LLM_CA_BUNDLE` in `env.sh` to the lab CA bundle (try `/etc/pki/tls/certs/ca-bundle.crt`) |
| `No model given` | `LLM_MODEL` is not set — fill in `env.sh` |
| `the generate stage needs torch + transformers + peft` | see "If `--check` says torch … are missing" above |
| `no CUDA GPU is visible` | run the generate stage on a GPU node; pick one GPU with `export CUDA_VISIBLE_DEVICES=0` |
| `GPU out of memory` | it halves the batch size by itself; if it still fails add `--load-in-4bit` or `--ctx-k 3` |
| `the setup agent did not arrive at a usable configuration` | nothing was run. The message shows what the runner proposed and why it was rejected. Usual fix: append `--root data=<folder of the question file>`, or give `--adapter DIR --base-model PATH --eval-file FILE` yourself |
| `eval file … is outside the directories given` | the message names the folder: append `--root data=<that folder>` |
| `the tokenizer's chat template could not be applied` | in that environment: `pip install -U 'jinja2>=3.1'`; or append `--base-prompt same` to prompt the base model in the adapter's format |
| the report says `No usable answers for …` | the saved answers were made with a different adapter or settings: run the same command again without `--stages`, it regenerates only those |
| `could not load … --base-model /local/path` | the base model is not in the local Hugging Face cache: append `--base-model /path/to/the/base/model/folder` |
| the runner seems slow | `--workers 10` (parallel runner calls); reasoning effort is already `low` |
| stopped half-way / lost connection | run the same command again — every stage resumes |
| `not finished yet` from `run_plain_vs_agentic.sh` | one of its two runs stopped; its own message is a few lines above. Fix that, run the same command again |

`python lora_review_agents/rag_compare.py --help` lists every flag; `README.md` explains how it works.
