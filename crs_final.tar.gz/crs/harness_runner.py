"""
crs/harness_runner.py — Build the fuzz target and run PoC bytes against it.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from crs.byte_strategies import PoCBytes
from crs.code_intelligence import CodeContext
from crs.config import BUILD_TIMEOUT, RUN_TIMEOUT, cfg
from crs.data_loader import CyberGymTask
from crs.harness_finder import HarnessInfo


@dataclass
class FuzzTargetBuild:
    success: bool
    binary_path: Optional[Path]
    build_log: str


@dataclass
class RunResult:
    poc: PoCBytes
    triggered: bool
    crash_type: str
    sanitizer_output: str
    return_code: int
    run_log: str


_STANDALONE_DRIVER = """\
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size);
extern "C" int LLVMFuzzerInitialize(int *argc, char ***argv) __attribute__((weak));

int main(int argc, char **argv) {
    if (LLVMFuzzerInitialize) {
        LLVMFuzzerInitialize(&argc, &argv);
    }
    FILE *f = stdin;
    if (argc > 1) {
        f = fopen(argv[1], "rb");
        if (!f) { perror("fopen"); return 1; }
    }
    size_t capacity = 65536, len = 0;
    uint8_t *buf = (uint8_t *)malloc(capacity);
    if (!buf) { perror("malloc"); return 1; }
    while (1) {
        size_t n = fread(buf + len, 1, capacity - len, f);
        len += n;
        if (n == 0) break;
        if (len == capacity) {
            capacity *= 2;
            buf = (uint8_t *)realloc(buf, capacity);
            if (!buf) { perror("realloc"); return 1; }
        }
    }
    if (f != stdin) fclose(f);
    LLVMFuzzerTestOneInput(buf, len);
    free(buf);
    return 0;
}
"""


def _run_cmd(cmd, timeout=BUILD_TIMEOUT, cwd=None, env=None):
    return subprocess.run(cmd, capture_output=True, timeout=timeout,
                          cwd=str(cwd) if cwd else None, env=env)


# ── Sanitizer detection ───────────────────────────────────────────────────

def is_triggered(return_code: int, output: str) -> Tuple[bool, str]:
    for pat in [r"AddressSanitizer", r"ERROR: AddressSanitizer",
                r"heap-buffer-overflow", r"stack-buffer-overflow",
                r"heap-use-after-free", r"SUMMARY: AddressSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            m = re.search(r"ERROR: AddressSanitizer: (\S+)", output)
            return True, m.group(1) if m else "asan"
    for pat in [r"runtime error:", r"UndefinedBehaviorSanitizer",
                r"SUMMARY: UndefinedBehaviorSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "ubsan"
    for pat in [r"MemorySanitizer", r"use-of-uninitialized-value",
                r"SUMMARY: MemorySanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "msan"
    for pat in [r"Segmentation fault", r"Aborted", r"double free"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "crash"
    if return_code not in (0, 1) and return_code < 0:
        return True, f"signal_{abs(return_code)}"
    return False, ""


# ── Build project ─────────────────────────────────────────────────────────

def _find_project_dir(repo: Path, build_type: str) -> Path:
    """Find the actual project directory containing the build files.

    Prefer files CLOSEST to the repo root (shortest path) — the main
    project's configure.ac is almost always shallower than subdirectory
    ones like TclMagick/configure.ac.
    """
    if build_type == "autotools":
        # Sort by depth (number of path parts), then alphabetically
        candidates = sorted(repo.rglob("configure.ac"),
                            key=lambda p: (len(p.parts), str(p)))
        if candidates:
            print(f"[build] Found {len(candidates)} configure.ac file(s), "
                  f"using shallowest: {candidates[0].parent}")
            return candidates[0].parent
        candidates = sorted(repo.rglob("configure"),
                            key=lambda p: (len(p.parts), str(p)))
        for sub in candidates:
            if sub.is_file():
                return sub.parent
    elif build_type == "cmake":
        candidates = sorted(repo.rglob("CMakeLists.txt"),
                            key=lambda p: (len(p.parts), str(p)))
        if candidates:
            return candidates[0].parent
    elif build_type == "make":
        candidates = sorted(repo.rglob("Makefile"),
                            key=lambda p: (len(p.parts), str(p)))
        for sub in candidates:
            if not any(x in str(sub).lower() for x in ["test", "doc", "example"]):
                return sub.parent
    return repo


def _build_project(repo: Path, build_info: dict, work: Path) -> Tuple[bool, str]:
    """Build the project with ASAN using its native build system."""
    build_type = build_info.get("type", "unknown")
    log_parts: list[str] = []
    env = os.environ.copy()
    san = "-fsanitize=address,undefined -g -O1"
    env["CFLAGS"] = san
    env["CXXFLAGS"] = san
    env["LDFLAGS"] = "-fsanitize=address,undefined"

    project_dir = _find_project_dir(repo, build_type)
    print(f"[build] Project dir: {project_dir}")
    print(f"[build] Build type: {build_type}")

    try:
        if build_type == "autotools":
            has_configure = (project_dir / "configure").exists()

            if (project_dir / "configure.ac").exists():
                print("[build] autoreconf -fi")
                r = _run_cmd(["autoreconf", "-fi"], cwd=project_dir, env=env,
                             timeout=120)
                autoreconf_ok = (r.returncode == 0)
                log_parts.append(r.stderr.decode(errors="replace"))
                if not autoreconf_ok:
                    if has_configure:
                        print("[build] autoreconf failed but configure exists, continuing...")
                    else:
                        print("[build] autoreconf failed and no configure script found")
                        return False, "\n".join(log_parts)

            if (project_dir / "configure").exists():
                print("[build] ./configure")
                # First try: disable optional features to minimize dependencies.
                # For fuzz targets we only need the core library + codecs, not
                # X11 display, WMF, DPS, FPX, PERL, etc.
                configure_disable = [
                    "--without-x", "--without-xml", "--without-wmf",
                    "--without-dps", "--without-fpx", "--without-perl",
                    "--without-trio", "--without-jbig", "--without-jp2",
                    "--without-lcms2", "--without-lzma", "--without-zstd",
                    "--without-webp", "--without-ttf",
                    "--disable-openmp",
                ]
                r = _run_cmd(
                    ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
                     f"LDFLAGS=-fsanitize=address,undefined",
                     "--enable-static", "--disable-shared"] + configure_disable,
                    cwd=project_dir, env=env, timeout=300,
                )
                log_parts.append(r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace"))
                if r.returncode != 0:
                    # Retry without the --without flags (some projects don't support them)
                    print("[build] Retrying configure without --without flags...")
                    r = _run_cmd(
                        ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
                         f"LDFLAGS=-fsanitize=address,undefined",
                         "--enable-static", "--disable-shared"],
                        cwd=project_dir, env=env, timeout=300,
                    )
                    log_parts.append(r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace"))
                    if r.returncode != 0:
                        # Last resort: minimal flags
                        print("[build] Retrying configure with minimal flags...")
                        r = _run_cmd(
                            ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}"],
                            cwd=project_dir, env=env, timeout=300,
                        )
                        log_parts.append(r.stderr.decode(errors="replace"))
                        if r.returncode != 0:
                            print("[build] configure FAILED")
                            print("\n".join(log_parts)[-1500:])
                            return False, "\n".join(log_parts)

            print("[build] make -j4")
            r = _run_cmd(["make", "-j4"], cwd=project_dir, env=env, timeout=600)
            out = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
            log_parts.append(out)
            if r.returncode != 0:
                # Check if static libs were produced despite the error.
                # GraphicsMagick's make fails on utilities/gm (needs xmlNanoFTP
                # from libxml2) but the core .a libraries are already built.
                partial_libs = list(project_dir.rglob("*.a"))
                partial_libs = [l for l in partial_libs
                                if l.stat().st_size > 10000
                                and "CMakeFiles" not in str(l)]
                if partial_libs:
                    print(f"[build] make failed but found {len(partial_libs)} "
                          f"static lib(s) — treating as partial success")
                    for pl in partial_libs[:5]:
                        print(f"[build]   {pl.name} ({pl.stat().st_size} bytes)")
                else:
                    print(f"[build] make FAILED (no .a libs produced):")
                    print(out[-1500:])
                    return False, "\n".join(log_parts)

        elif build_type == "cmake":
            build_dir = work / "build"
            build_dir.mkdir(parents=True, exist_ok=True)
            cmake_source = _find_project_dir(repo, "cmake")
            print(f"[build] cmake -B build -S {cmake_source}")

            # Common cmake flags to force static libraries
            cmake_flags = [
                "-B", str(build_dir), "-S", str(cmake_source),
                f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
                "-DBUILD_TESTING=OFF", "-DBUILD_SHARED_LIBS=OFF",
                # Project-specific static lib flags (harmless if unsupported)
                "-DWITH_STATIC_LIBRARIES=ON",   # Mosquitto
                "-DWITH_STATIC=ON",             # generic
                "-DENABLE_STATIC=ON",           # generic
                "-DWITH_TLS=OFF",               # Mosquitto: avoid openssl dep
                "-DWITH_CJSON=OFF",             # Mosquitto: avoid cjson dep
                "-DDOCUMENTATION=OFF",          # skip docs
            ]

            r = _run_cmd(["cmake"] + cmake_flags, cwd=cmake_source, env=env)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                # Retry with minimal flags
                print("[build] cmake configure failed, retrying minimal...")
                cmake_flags_min = [
                    "-B", str(build_dir), "-S", str(cmake_source),
                    f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
                    "-DBUILD_SHARED_LIBS=OFF",
                ]
                r = _run_cmd(["cmake"] + cmake_flags_min, cwd=cmake_source, env=env)
                log_parts.append(r.stderr.decode(errors="replace"))
                if r.returncode != 0:
                    print("[build] cmake configure FAILED")
                    return False, "\n".join(log_parts)

            r = _run_cmd(["cmake", "--build", str(build_dir), "-j4"],
                         cwd=cmake_source, env=env, timeout=600)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                # Check for partial success like autotools
                partial_libs = [l for l in build_dir.rglob("*.a")
                                if l.stat().st_size > 10000
                                and "CMakeFiles" not in str(l)]
                if partial_libs:
                    print(f"[build] cmake build failed but found {len(partial_libs)} "
                          f"static lib(s) — treating as partial success")
                else:
                    print("[build] cmake build FAILED")
                    return False, "\n".join(log_parts)
        else:
            makefile_dir = _find_project_dir(repo, "make")
            print(f"[build] make -j4 in {makefile_dir}")
            r = _run_cmd(["make", "-j4"], cwd=makefile_dir, env=env, timeout=300)
            log_parts.append(r.stderr.decode(errors="replace"))
            if r.returncode != 0:
                return False, "\n".join(log_parts)

        print("[build] Project build SUCCESS")
        return True, "\n".join(log_parts)

    except subprocess.TimeoutExpired:
        return False, "\n".join(log_parts) + "\nBuild timed out"
    except Exception as e:
        return False, "\n".join(log_parts) + f"\nBuild error: {e}"


def _find_static_lib(repo: Path, work: Path) -> Optional[Path]:
    """Find the main .a static library (legacy — returns biggest)."""
    libs = _find_all_static_libs(repo, work)
    return libs[0] if libs else None


def _find_all_static_libs(repo: Path, work: Path) -> List[Path]:
    """Find ALL .a static libraries needed for linking.

    Projects like GraphicsMagick produce multiple .a files
    (libGraphicsMagick++.a, libGraphicsMagick.a, libpng.a) and the
    fuzz harness needs all of them.
    """
    skip = {"test", "tests", "example", "doc", "fuzz", "CMakeFiles"}
    all_libs: list[Path] = []
    seen: set[str] = set()

    for search in [work / "build", repo]:
        if not search.exists():
            continue
        for lib in sorted(search.rglob("*.a")):
            # Verify the file actually exists (might be stale from previous build)
            try:
                if not lib.is_file():
                    continue
            except OSError:
                continue
            # Skip test/doc directories
            if {p.lower() for p in lib.parts} & skip:
                continue
            # Skip duplicates by filename
            if lib.name in seen:
                continue
            seen.add(lib.name)
            all_libs.append(lib)

    # Sort: largest first (main project lib usually biggest)
    # Wrap stat in try/except for robustness against disappearing files
    def _safe_size(p: Path) -> int:
        try:
            return p.stat().st_size
        except OSError:
            return 0

    all_libs = [l for l in all_libs if _safe_size(l) > 0]
    all_libs.sort(key=_safe_size, reverse=True)

    for lib in all_libs:
        print(f"[build] Found static lib: {lib} ({lib.stat().st_size} bytes)")

    return all_libs


def _copy_data_files(repo: Path, target_dir: Path):
    """Copy data files the fuzz target needs (magic.mgc, .dict, etc.)."""
    for pattern in ["magic.mgc", "*.dict"]:
        for f in repo.rglob(pattern):
            dest = target_dir / f.name
            if not dest.exists():
                try:
                    shutil.copy2(f, dest)
                    print(f"[build] Copied: {f.name}")
                except Exception:
                    pass


def _create_archive_from_objects(repo: Path, work: Path) -> List[Path]:
    """Fallback for projects that only build shared libs (e.g. Mosquitto).

    Collects all .o object files from the cmake build directory and
    bundles them into a static archive (.a) so the fuzz target can link.
    """
    build_dir = work / "build"
    if not build_dir.exists():
        return []

    # Find all .o files, excluding test/example objects
    skip_patterns = {"test", "tests", "example", "CMakeFiles/CompilerIdC",
                     "CMakeFiles/CompilerIdCXX"}
    obj_files: list[Path] = []
    for o in sorted(build_dir.rglob("*.o")):
        o_str = str(o).lower()
        if any(skip in o_str for skip in skip_patterns):
            continue
        obj_files.append(o)

    if not obj_files:
        # Also check the repo itself (some builds put .o next to .c)
        for o in sorted(repo.rglob("*.o")):
            obj_files.append(o)

    if not obj_files:
        print("[build] No .o object files found to create archive")
        return []

    print(f"[build] Creating static archive from {len(obj_files)} object file(s)...")

    archive_path = work / "libproject_combined.a"
    try:
        cmd = ["ar", "rcs", str(archive_path)] + [str(o) for o in obj_files]
        r = subprocess.run(cmd, capture_output=True, timeout=60)
        if r.returncode == 0 and archive_path.exists():
            size = archive_path.stat().st_size
            print(f"[build] Created {archive_path.name} ({size} bytes) "
                  f"from {len(obj_files)} objects")
            return [archive_path]
        else:
            err = r.stderr.decode(errors="replace")
            print(f"[build] ar failed: {err[:500]}")
    except Exception as e:
        print(f"[build] Archive creation failed: {e}")

    return []


def _extract_la_deps(repo: Path, work: Path) -> list[str]:
    """Extract dependency flags from libtool .la archive files.

    After autotools builds, .la files contain a 'dependency_libs' field
    listing exactly which system libraries are needed.  This is far more
    reliable than guessing.
    """
    dep_flags: list[str] = []
    seen: set[str] = set()

    for search in [repo, work]:
        if not search.exists():
            continue
        for la in sorted(search.rglob("*.la")):
            try:
                text = la.read_text(encoding="utf-8", errors="replace")
                for line in text.splitlines():
                    if line.startswith("dependency_libs="):
                        # dependency_libs=' -L/usr/lib -ljpeg -lz -lm'
                        val = line.split("=", 1)[1].strip().strip("'\"")
                        for token in val.split():
                            if token.startswith("-l") and token not in seen:
                                seen.add(token)
                                dep_flags.append(token)
                            elif token.startswith("-L") and token not in seen:
                                seen.add(token)
                                dep_flags.append(token)
            except Exception:
                continue

    return dep_flags


def _detect_harness_defines(harness: HarnessInfo, description: str) -> list[str]:
    """Detect compile-time macros the harness needs and infer their values.

    Many fuzz harnesses (e.g. GraphicsMagick's coder_fuzzer.cc, ImageMagick's
    encoder_fuzzer.cc) use a compile-time macro to select which codec to test:

        #define FUZZ_CODER FUZZ_CODER_STRING_LITERAL_X(FUZZ_GRAPHICSMAGICK_CODER)

    The macro value (e.g. MNG, PNG, TIFF) must be set via -D at compile time.
    We extract it from the vulnerability description by looking for function
    names like ReadMNGImage -> MNG, ReadPNGImage -> PNG, etc.

    This is task-agnostic: works for any project with this pattern.
    """
    defines: list[str] = []
    code = harness.harness_code

    # Find FUZZ_*_CODER macros that need to be defined
    # Pattern: FUZZ_GRAPHICSMAGICK_CODER, FUZZ_IMAGEMAGICK_CODER, etc.
    macro_matches = re.findall(r'\b(FUZZ_\w+_CODER)\b', code)
    if not macro_matches:
        return defines

    # Extract the coder/format name from the vulnerability description
    # Look for patterns like: ReadMNGImage, ReadPNGImage, WriteTIFFImage,
    # MNG_LOOP, png_read, tiff_decode, etc.
    coder_name = None

    # Pattern 1: Read<FORMAT>Image or Write<FORMAT>Image
    m = re.search(r'(?:Read|Write)(\w+?)Image', description)
    if m:
        coder_name = m.group(1).upper()

    # Pattern 2: format name in lowercase with underscore (mng_LOOP -> MNG)
    if not coder_name:
        m = re.search(r'\b(mng|png|tiff|jpeg|gif|bmp|webp|svg|pdf|eps|ico)_',
                      description, re.IGNORECASE)
        if m:
            coder_name = m.group(1).upper()

    # Pattern 3: explicit format mention
    if not coder_name:
        for fmt in ["MNG", "PNG", "TIFF", "JPEG", "GIF", "BMP", "WEBP",
                     "SVG", "PDF", "EPS", "ICO", "PNM", "TGA", "DPX",
                     "JP2", "JXL", "HEIF", "AVIF"]:
            if fmt.lower() in description.lower():
                coder_name = fmt
                break

    if coder_name:
        for macro in set(macro_matches):
            defines.append(f"-D{macro}={coder_name}")
            print(f"[build] Setting {macro}={coder_name} (from vuln description)")

    return defines


# ── Build fuzz target ──────────────────────────────────────────────────────

def build_fuzz_target(
    task: CyberGymTask,
    harness: HarnessInfo,
    context: CodeContext,
) -> FuzzTargetBuild:
    repo = Path(task.repo_path).resolve()
    work = cfg.task_work_dir(task.task_id)
    log_parts: list[str] = []

    # Clean stale build artifacts from previous runs (e.g. old cmake build/ dir)
    stale_build = work / "build"
    if stale_build.exists():
        print(f"[build] Removing stale build dir: {stale_build}")
        shutil.rmtree(stale_build, ignore_errors=True)

    # Step 1: Build project
    print(f"\n[build] Building project...")
    build_ok, build_log = _build_project(repo, context.build_info, work)
    log_parts.append(build_log)

    static_libs = _find_all_static_libs(repo, work)
    if not static_libs:
        # Fallback: some projects (e.g. Mosquitto) only build .so files.
        # Create a .a archive from the .o object files cmake produced.
        static_libs = _create_archive_from_objects(repo, work)
    if not static_libs:
        print("[build] No static library found and no .o files to archive")
        return FuzzTargetBuild(False, None, "\n".join(log_parts))

    # Step 2: Write driver
    driver_path = work / "standalone_driver.cpp"
    driver_path.write_text(_STANDALONE_DRIVER, encoding="utf-8")

    # Step 3: Collect includes
    include_dirs: set[str] = set()
    for h in repo.rglob("*.h"):
        include_dirs.add(str(h.parent))
        # Also add PARENT of the header's directory — needed for includes
        # like <magick/magick_config.h> where the -I must point to the
        # grandparent (graphicsmagick/) not the direct parent (magick/)
        if h.parent.parent != repo:
            include_dirs.add(str(h.parent.parent))
    include_dirs.add(str(repo))
    # Add the build system's source directory (where configure ran)
    source_dir = context.build_info.get("source_dir")
    if source_dir:
        include_dirs.add(source_dir)
    for name in ["include", "src", "lib"]:
        for d in repo.rglob(name):
            if d.is_dir():
                include_dirs.add(str(d))
    # Add all immediate subdirectories of repo (covers graphicsmagick/ under src-vul/)
    for d in repo.iterdir():
        if d.is_dir() and not d.name.startswith("."):
            include_dirs.add(str(d))

    # Step 3b: Collect library search paths (.libs dirs from autotools)
    lib_dirs: set[str] = set()
    for d in repo.rglob(".libs"):
        if d.is_dir():
            lib_dirs.add(str(d))
    for lib in static_libs:
        lib_dirs.add(str(lib.parent))

    # Step 3c: Extract dependency libs from .la files (libtool archives)
    # These files list exactly which system libraries the project needs.
    la_dep_flags: list[str] = _extract_la_deps(repo, work)
    if la_dep_flags:
        print(f"[build] Extracted {len(la_dep_flags)} dep flags from .la files: "
              f"{la_dep_flags[:10]}...")

    # Step 3d: Detect compile-time macros needed by the harness
    # e.g. coder_fuzzer.cc uses FUZZ_GRAPHICSMAGICK_CODER to pick the codec
    harness_defines = _detect_harness_defines(harness, context.description)
    if harness_defines:
        print(f"[build] Detected harness compile-time defines: {harness_defines}")

    # Step 4: Compile — link ALL static libs, not just one
    fuzz_binary = work / "fuzz_target"
    cmd = ["g++", "-fsanitize=address,undefined", "-g", "-O1", "-fpermissive",
           "-include", "string.h"]
    cmd += harness_defines  # e.g. ["-DFUZZ_GRAPHICSMAGICK_CODER=MNG"]
    cmd += [str(driver_path), str(harness.harness_path),
            "-o", str(fuzz_binary)]

    # Add all static libraries (order matters: C++ wrappers before C core)
    cpp_libs = [l for l in static_libs if "++" in l.name]
    c_libs   = [l for l in static_libs if "++" not in l.name]
    for lib in cpp_libs + c_libs:
        cmd.append(str(lib))

    cmd += [f"-I{d}" for d in sorted(include_dirs)]
    cmd += [f"-L{d}" for d in sorted(lib_dirs)]

    # Use extracted deps from .la files if available, otherwise fall back
    if la_dep_flags:
        cmd += la_dep_flags
    # Always include these essentials (harmless if duplicated)
    cmd += ["-lz", "-lm", "-lpthread", "-ldl", "-lstdc++"]

    print(f"[build] Compiling fuzz target...")
    print(f"[build] Linking {len(static_libs)} static lib(s): "
          f"{[l.name for l in static_libs]}")
    try:
        r = _run_cmd(cmd, timeout=BUILD_TIMEOUT, cwd=work)
        clog = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        log_parts.append(clog)
        if r.returncode != 0:
            # Retry with a comprehensive brute-force set of libraries
            print(f"[build] First attempt failed, retrying with comprehensive libs...")
            cmd_brute = [x for x in cmd if not x.startswith("-l")]
            cmd_brute += [
                # Core
                "-lz", "-lm", "-lpthread", "-ldl", "-lrt", "-lstdc++",
                # OpenMP
                "-fopenmp", "-lgomp",
                # X11 (if project uses display functions)
                "-lX11", "-lXext", "-lXt", "-lSM", "-lICE",
                "-lxcb", "-lXau", "-lXdmcp",
                # Image formats
                "-ljpeg", "-lpng", "-ltiff", "-lwebp", "-ljbig",
                # Fonts
                "-lfreetype", "-lfontconfig",
                # Compression
                "-lbz2", "-llzma", "-lzstd",
                # XML
                "-lxml2", "-lexpat",
                # Color management
                "-llcms2",
                # Libtool
                "-lltdl",
            ]
            r = _run_cmd(cmd_brute, timeout=BUILD_TIMEOUT, cwd=work)
            clog2 = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
            log_parts.append(clog2)
            if r.returncode != 0:
                print(f"[build] Compile FAILED:")
                print(clog2[-2000:])
                return FuzzTargetBuild(False, None, "\n".join(log_parts))
    except subprocess.TimeoutExpired:
        return FuzzTargetBuild(False, None, "\n".join(log_parts) + "\nCompile timed out")

    # Step 5: Copy data files
    _copy_data_files(repo, work)
    os.chmod(fuzz_binary, 0o755)

    print(f"[build] ✓ Fuzz target ready: {fuzz_binary}")
    return FuzzTargetBuild(True, fuzz_binary, "\n".join(log_parts))


# ── Run bytes ──────────────────────────────────────────────────────────────

def run_poc_bytes(poc: PoCBytes, fuzz_binary: Path) -> RunResult:
    print(f"[run] Feeding {len(poc.data)} bytes to {fuzz_binary.name}")
    try:
        r = subprocess.run(
            [str(fuzz_binary)], input=poc.data, capture_output=True,
            timeout=RUN_TIMEOUT, cwd=str(fuzz_binary.parent),
        )
        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        triggered, crash_type = is_triggered(r.returncode, output)
        status = "TRIGGERED" if triggered else "no trigger"
        print(f"[run] Result: {status}  rc={r.returncode}  crash_type={crash_type}")
        if triggered:
            for line in output.split("\n"):
                if "ERROR:" in line or "SUMMARY:" in line:
                    print(f"[run]   {line.strip()}")
        return RunResult(poc=poc, triggered=triggered, crash_type=crash_type,
                        sanitizer_output=output[:8000], return_code=r.returncode,
                        run_log=output[:4000])
    except subprocess.TimeoutExpired:
        return RunResult(poc=poc, triggered=False, crash_type="timeout",
                        sanitizer_output="", return_code=-1, run_log="Timed out")
    except Exception as e:
        return RunResult(poc=poc, triggered=False, crash_type="error",
                        sanitizer_output="", return_code=-1, run_log=str(e))


def execute_pipeline(fuzz_binary: Path, poc_candidates: list[PoCBytes]) -> list[RunResult]:
    results: list[RunResult] = []
    print(f"\n  [Pipeline] Testing {len(poc_candidates)} PoC candidate(s)")
    for idx, poc in enumerate(poc_candidates):
        print(f"\n  [PoC {idx}] {poc.strategy_name} ({len(poc.data)} bytes)")
        result = run_poc_bytes(poc, fuzz_binary)
        results.append(result)
        if result.triggered:
            print(f"\n  *** PoC {idx} TRIGGERED: {result.crash_type} ***")
            break
    return results
