"""
crs/verifier.py — Verify PoCs by running them against project binaries.

No harness needed. Tries multiple ways to feed input to a binary:
  1. File argument:  ./binary poc.bin
  2. Stdin:          ./binary < poc.bin
  3. With flags:     ./binary -i poc.bin / ./binary --input poc.bin

Checks for ASAN/MSAN/UBSAN output, segfaults, aborts, etc.
"""
from __future__ import annotations

import os
import re
import subprocess
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from crs.llm_router import LLMRouter


@dataclass
class VerifyResult:
    triggered: bool
    crash_type: str           # "heap-buffer-overflow", "signal_6", etc.
    binary_path: Path
    invocation: str           # how the binary was called
    output: str               # sanitizer output (truncated)
    return_code: int
    poc_path: Path


# ── ASAN detection (reused from harness_runner.py) ─────────────────────────

def _check_crash(return_code: int, output: str) -> Tuple[bool, str]:
    """Check if output indicates an ASAN/MSAN/UBSAN crash."""
    for pat in [r"AddressSanitizer", r"ERROR: AddressSanitizer",
                r"heap-buffer-overflow", r"stack-buffer-overflow",
                r"heap-use-after-free", r"SUMMARY: AddressSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            m = re.search(r"ERROR: AddressSanitizer: (\S+)", output)
            return True, m.group(1) if m else "asan"
    for pat in [r"runtime error:", r"UndefinedBehaviorSanitizer",
                r"SUMMARY: UndefinedBehaviorSanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "ubsan"
    for pat in [r"MemorySanitizer", r"use-of-uninitialized-value",
                r"SUMMARY: MemorySanitizer"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "msan"
    for pat in [r"Segmentation fault", r"double free"]:
        if re.search(pat, output, re.IGNORECASE):
            return True, "crash"
    if "Aborted" in output:
        return True, "abort"
    if return_code not in (0, 1) and return_code < 0:
        return True, f"signal_{abs(return_code)}"
    return False, ""


# ── Core verification ──────────────────────────────────────────────────────

def verify_poc(
    poc_path: Path,
    binary: Path,
    timeout: int = 30,
    extra_args: Optional[list] = None,
) -> VerifyResult:
    """Try multiple invocation methods to feed PoC to binary."""
    poc_path = Path(poc_path)
    binary = Path(binary)

    strategies = _build_invocation_strategies(binary, poc_path, extra_args)

    for desc, cmd, use_stdin in strategies:
        result = _try_invocation(poc_path, binary, cmd, use_stdin, desc, timeout)
        if result.triggered:
            return result

    # None triggered — return the last result
    if strategies:
        return _try_invocation(poc_path, binary,
                               strategies[0][1], strategies[0][2],
                               strategies[0][0], timeout)

    return VerifyResult(
        triggered=False, crash_type="", binary_path=binary,
        invocation="none", output="No invocation strategy worked",
        return_code=-1, poc_path=poc_path)


def verify_poc_against_all(
    poc_path: Path,
    binaries: List[Path],
    timeout: int = 30,
    router: Optional[LLMRouter] = None,
    project_info: Optional[dict] = None,
) -> VerifyResult:
    """Try a PoC against multiple binaries until one triggers.

    If a router is provided, asks the LLM which binary to try first
    and how to invoke it.
    """
    poc_path = Path(poc_path)

    # If we have an LLM, ask it which binary to use
    if router and binaries:
        llm_suggestion = _ask_llm_invocation(router, binaries, poc_path, project_info)
        if llm_suggestion:
            binary, extra_args = llm_suggestion
            result = verify_poc(poc_path, binary, timeout, extra_args)
            if result.triggered:
                return result

    # Try each binary
    for binary in binaries[:5]:  # limit to top 5
        result = verify_poc(poc_path, binary, timeout)
        if result.triggered:
            return result

    # Nothing triggered
    return VerifyResult(
        triggered=False, crash_type="",
        binary_path=binaries[0] if binaries else Path("none"),
        invocation="none", output="No binary triggered",
        return_code=0, poc_path=poc_path)


# ── Invocation strategies ──────────────────────────────────────────────────

def _build_invocation_strategies(
    binary: Path, poc_path: Path, extra_args: Optional[list] = None,
) -> list[tuple[str, list[str], bool]]:
    """Build a list of (description, command, use_stdin) to try.

    Returns multiple strategies for feeding input to the binary.
    """
    strategies: list[tuple[str, list[str], bool]] = []
    b = str(binary)
    p = str(poc_path)

    # Custom args from LLM suggestion
    if extra_args:
        strategies.append(
            (f"{binary.name} {' '.join(extra_args)} {poc_path.name}",
             [b] + extra_args + [p], False))

    # Strategy 1: file as argument
    strategies.append((f"{binary.name} <file>", [b, p], False))

    # Strategy 2: stdin
    strategies.append((f"{binary.name} < <file>", [b], True))

    # Strategy 3: common flag patterns
    for flag in ["-i", "--input", "-f", "--file", "-"]:
        if flag == "-":
            strategies.append((f"{binary.name} -", [b, "-"], True))
        else:
            strategies.append((f"{binary.name} {flag} <file>",
                              [b, flag, p], False))

    return strategies


def _try_invocation(
    poc_path: Path, binary: Path,
    cmd: list[str], use_stdin: bool,
    description: str, timeout: int,
) -> VerifyResult:
    """Execute a single invocation and check for crash."""
    try:
        stdin_data = None
        if use_stdin:
            stdin_data = poc_path.read_bytes()

        env = os.environ.copy()
        # Set ASAN options for cleaner output
        env["ASAN_OPTIONS"] = "detect_leaks=0:print_stacktrace=1:symbolize=1"

        r = subprocess.run(
            cmd, input=stdin_data, capture_output=True,
            timeout=timeout, cwd=str(binary.parent), env=env)

        output = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        triggered, crash_type = _check_crash(r.returncode, output)

        return VerifyResult(
            triggered=triggered, crash_type=crash_type,
            binary_path=binary, invocation=description,
            output=output[:4000], return_code=r.returncode,
            poc_path=poc_path)

    except subprocess.TimeoutExpired:
        return VerifyResult(
            triggered=False, crash_type="timeout",
            binary_path=binary, invocation=description,
            output="Timed out", return_code=-1, poc_path=poc_path)
    except Exception as e:
        return VerifyResult(
            triggered=False, crash_type="error",
            binary_path=binary, invocation=description,
            output=str(e), return_code=-1, poc_path=poc_path)


# ── LLM-guided invocation ─────────────────────────────────────────────────

SYS_INVOKE = """\
You are a C/C++ developer. Given a list of binaries from a project build,
determine which one processes external input and how to invoke it with a file.

Output ONLY JSON:
{"binary":"binary_name","args":["arg1","arg2"],"note":"why this binary"}

Example: {"binary":"gm","args":["convert","INPUT_FILE","/dev/null"],"note":"GraphicsMagick CLI"}
Example: {"binary":"xmllint","args":["INPUT_FILE"],"note":"libxml2 CLI parser"}
Example: {"binary":"ffmpeg","args":["-i","INPUT_FILE","-f","null","-"],"note":"FFmpeg"}

Use INPUT_FILE as placeholder for the PoC file path.
If no binary processes files, output: {"binary":"none","args":[],"note":"no CLI tool found"}
"""


def _ask_llm_invocation(
    router: LLMRouter,
    binaries: List[Path],
    poc_path: Path,
    project_info: Optional[dict] = None,
) -> Optional[Tuple[Path, list]]:
    """Ask the LLM which binary to use and how to invoke it."""
    import json

    bin_list = "\n".join(f"  {b.name} ({_safe_size(b)} bytes, in {b.parent.name}/)"
                         for b in binaries[:10])

    context = ""
    if project_info:
        context = (f"Project: {project_info.get('project_type', 'unknown')}. "
                   f"Formats: {project_info.get('input_formats', [])}.")

    prompt = (
        f"{context}\n\n"
        f"## Available binaries\n{bin_list}\n\n"
        f"## PoC file: {poc_path.name} ({_safe_size(poc_path)} bytes)\n\n"
        f"Which binary should I feed this file to, and with what arguments?\n"
    )

    try:
        raw = router.chat(SYS_INVOKE, prompt, max_tokens=300, temperature=0.1)
        if not raw:
            return None

        # Parse JSON
        cleaned = re.sub(r"```json\s*", "", raw)
        cleaned = re.sub(r"```\s*", "", cleaned).strip()
        data = json.loads(cleaned) if cleaned.startswith("{") else None
        if not data:
            m = re.search(r'\{[^{}]+\}', raw)
            if m:
                data = json.loads(m.group())

        if not data or data.get("binary") == "none":
            return None

        target_name = data["binary"]
        args = data.get("args", [])

        # Find the binary
        for b in binaries:
            if b.name == target_name:
                # Replace INPUT_FILE placeholder
                real_args = [str(poc_path) if a == "INPUT_FILE" else a for a in args]
                print(f"[verify] LLM suggests: {target_name} {' '.join(args)}")
                return b, real_args

    except Exception as e:
        print(f"[verify] LLM invocation suggestion failed: {e}")

    return None


def _safe_size(p: Path) -> int:
    try:
        return p.stat().st_size
    except OSError:
        return 0
