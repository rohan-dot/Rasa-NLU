"""
crs/static_analyzer.py — LLM-powered static vulnerability analysis.

No harness. No fuzzer. No compilation. Just code reading.

Pipeline:
  1. Ingest repo → find source files → rank by risk
  2. Per-file LLM scan → identify candidate vulnerabilities
  3. Cross-file context gathering → follow function calls, includes, data types
  4. Deep LLM analysis → confirm bugs with full context
  5. Output: ranked VulnCandidate list with synthetic descriptions

Inspired by Team Atlanta's approach from AIxCC/OSS-CRS:
  LLM reads code → identifies patterns → traces data flow → confirms exploitability
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from crs.config import cfg

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from crs.llm_router import LLMRouter

import logging
logger = logging.getLogger(__name__)


# ── Data structures ────────────────────────────────────────────────────────

@dataclass
class VulnCandidate:
    function_name: str
    file_path: str
    line_number: int
    vuln_type: str
    description: str
    confidence: float
    code_snippet: str
    attack_input_hint: str
    entry_point: str = ""       # how external input reaches the bug
    root_cause: str = ""        # the specific missing check / bad logic
    format_hint: str = ""       # what file/protocol format triggers it


@dataclass
class RepoContext:
    """Everything we know about a repository — built without compiling."""
    repo_path: Path
    source_files: List[Path]
    header_files: List[Path]
    entry_points: List[Path]         # files with main(), fuzz harness, etc.
    parser_files: List[Path]         # files that parse input
    include_graph: Dict[str, List[str]]  # file → [files it includes]
    function_index: Dict[str, str]   # function_name → file_path
    file_risk_scores: List[Tuple[Path, float]]


# ── Prompts (kept short for small-context models) ──────────────────────────

SYS_SCAN = """\
You are a C/C++ security auditor. Find exploitable memory safety bugs.

Look for: buffer overflow, heap overflow, use-after-free, null deref,
integer overflow, missing length validation, off-by-one, uninit reads,
format string bugs, double-free.

Focus on code that processes EXTERNAL INPUT (files, network, user data).
Ignore theoretical issues — only report bugs with a clear trigger path.

Output ONLY a JSON array. Empty if no bugs: []
Each entry: {"function":"name","file":"file.c","line":123,
"type":"buffer_overflow","description":"Precise 2-sentence description",
"confidence":0.8,"input_hint":"What input triggers it",
"root_cause":"What check is missing"}
"""

SYS_DEEP = """\
You are a C/C++ exploit researcher. You are given a function and its context.

Determine:
1. Is this a REAL exploitable bug? (not a false positive)
2. What external input reaches this code? (file format, protocol, API)
3. What is the EXACT root cause? (missing check, wrong comparison, etc.)
4. What input would trigger it? (specific values, sizes, field contents)

Output ONLY JSON:
{"exploitable":true/false,"function":"name","vuln_type":"type",
"description":"Full description for PoC generation. Name the function,
the exact line, what check is missing, what the input must look like,
and what memory corruption occurs.",
"entry_point":"How external input reaches this function",
"format":"What file/protocol format (MNG, PNG, MQTT, ELF, etc.)",
"trigger":"Exact input values/structure that triggers the bug",
"root_cause":"The specific check that is missing or wrong"}
"""

SYS_ENTRY_POINTS = """\
You are analyzing a C/C++ project. Given the file listing and a few key
source files, identify:
1. What does this project DO? (image parser, network server, crypto lib, etc.)
2. What INPUT FORMATS does it process? (file types, protocols, data formats)
3. What are the main ENTRY POINTS for external data? (which functions/files)

Output ONLY JSON:
{"project_type":"image processing library",
"input_formats":["PNG","MNG","TIFF","JPEG"],
"entry_files":["coders/png.c","coders/tiff.c"],
"entry_functions":["ReadPNGImage","ReadMNGImage"],
"notes":"any useful context"}
"""


# ── Repo ingestion (no compilation) ────────────────────────────────────────

_SOURCE_EXT = {".c", ".cpp", ".cc", ".cxx", ".h", ".hpp"}
_RISKY_NAMES = ["parse", "read", "decode", "process", "handle", "load",
                "recv", "input", "packet", "message", "coder", "codec",
                "format", "deserializ", "write", "send", "encode"]
_UNSAFE_APIS = ["memcpy", "strcpy", "sprintf", "gets", "scanf", "strcat",
                "memmove", "malloc", "realloc", "free", "calloc",
                "strncpy", "strncat", "sscanf", "fscanf", "fread"]


def ingest_repo(repo_path: Path) -> RepoContext:
    """Scan a repo without compiling. Build a rich context for LLM analysis."""
    repo = Path(repo_path).resolve()
    print(f"[static] Ingesting repo: {repo}")

    # Find all source and header files
    source_files: list[Path] = []
    header_files: list[Path] = []
    for f in sorted(repo.rglob("*")):
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        if ext in {".c", ".cpp", ".cc", ".cxx"}:
            source_files.append(f)
        elif ext in {".h", ".hpp"}:
            header_files.append(f)

    print(f"[static] Found {len(source_files)} source + {len(header_files)} header files")

    # Find entry points
    entry_points = _find_entry_points(source_files)

    # Find parser/input-handling files
    parser_files = _find_parser_files(source_files)

    # Build include graph (which file includes which)
    include_graph = _build_include_graph(source_files + header_files)

    # Build function index (function_name → file_path)
    function_index = _build_function_index(source_files)

    # Score files by risk
    file_risk = _score_files(source_files)

    ctx = RepoContext(
        repo_path=repo,
        source_files=source_files,
        header_files=header_files,
        entry_points=entry_points,
        parser_files=parser_files,
        include_graph=include_graph,
        function_index=function_index,
        file_risk_scores=file_risk,
    )

    print(f"[static] Entry points: {[f.name for f in entry_points[:5]]}")
    print(f"[static] Parser files: {[f.name for f in parser_files[:5]]}")
    print(f"[static] Top risk files: {[f.name for f, _ in file_risk[:5]]}")

    return ctx


def _find_entry_points(files: List[Path]) -> List[Path]:
    """Find files containing main(), LLVMFuzzerTestOneInput, or similar."""
    entries: list[Path] = []
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            if re.search(r'\bint\s+main\s*\(', text):
                entries.append(f)
            elif "LLVMFuzzerTestOneInput" in text:
                entries.append(f)
        except Exception:
            pass
    return entries


def _find_parser_files(files: List[Path]) -> List[Path]:
    """Find files that likely parse external input."""
    parsers: list[Path] = []
    for f in files:
        fname = f.name.lower()
        if any(kw in fname for kw in _RISKY_NAMES):
            parsers.append(f)
    return parsers


def _build_include_graph(files: List[Path]) -> Dict[str, List[str]]:
    """Map each file to the headers it includes."""
    graph: dict[str, list[str]] = {}
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            includes = re.findall(r'#include\s*[<"]([^>"]+)[>"]', text)
            graph[f.name] = includes
        except Exception:
            pass
    return graph


def _build_function_index(files: List[Path]) -> Dict[str, str]:
    """Map function names to the files that define them."""
    index: dict[str, str] = {}
    for f in files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            # Match function definitions (not declarations — look for opening brace)
            for m in re.finditer(
                r'^(?:static\s+)?(?:(?:inline|unsigned|signed|const|volatile|extern)\s+)*'
                r'(?:[\w*]+\s+)+(\w+)\s*\([^)]*\)\s*\{',
                text, re.MULTILINE
            ):
                name = m.group(1)
                if name not in ("if", "for", "while", "switch", "return"):
                    index[name] = str(f)
        except Exception:
            pass
    return index


def _score_files(files: List[Path]) -> List[Tuple[Path, float]]:
    """Risk-score each file. Higher = more likely to contain bugs."""
    scored: list[tuple[Path, float]] = []
    for f in files:
        score = 0.0
        fname = f.name.lower()
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            text_lower = text.lower()

            # Filename risk
            for kw in _RISKY_NAMES:
                if kw in fname:
                    score += 3.0

            # Unsafe API count
            for api in _UNSAFE_APIS:
                score += text_lower.count(api) * 0.3

            # Input handling patterns
            for pat in ["length", "size", "chunk", "header", "buffer",
                        "offset", "packet", "field", "parse"]:
                score += text_lower.count(pat) * 0.05

            # File size (more code = more attack surface)
            score += min(len(text) / 5000, 5.0)

        except Exception:
            pass
        scored.append((f, score))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored


# ── LLM analysis phases ───────────────────────────────────────────────────

def analyze_repo(
    ctx: RepoContext,
    router: LLMRouter,
    max_candidates: int = 10,
) -> List[VulnCandidate]:
    """Full static analysis pipeline. No compilation needed.

    Phase 1: Understand the project (what does it do, what input does it take)
    Phase 2: Scan high-risk files for vulnerabilities
    Phase 3: Gather cross-file context for each candidate
    Phase 4: Deep analysis to confirm exploitability
    """

    # Phase 1: Understand the project
    print(f"\n[static] Phase 1: Understanding project...")
    project_info = _understand_project(ctx, router)
    if project_info:
        print(f"  Project type: {project_info.get('project_type', 'unknown')}")
        print(f"  Input formats: {project_info.get('input_formats', [])}")
        print(f"  Entry functions: {project_info.get('entry_functions', [])}")

    # Phase 2: Scan high-risk files
    print(f"\n[static] Phase 2: Scanning high-risk files...")
    candidates = _scan_phase(ctx, router, project_info)
    print(f"  Found {len(candidates)} raw candidate(s)")

    if not candidates:
        return []

    # Phase 3: Gather context for each candidate
    print(f"\n[static] Phase 3: Gathering cross-file context...")
    enriched = _enrich_candidates(ctx, candidates)

    # Phase 4: Deep analysis
    print(f"\n[static] Phase 4: Deep analysis of {len(enriched)} candidate(s)...")
    confirmed = _deep_analysis(ctx, router, enriched, project_info)
    print(f"  Confirmed {len(confirmed)} exploitable bug(s)")

    confirmed.sort(key=lambda c: c.confidence, reverse=True)
    return confirmed[:max_candidates]


def _understand_project(
    ctx: RepoContext, router: LLMRouter
) -> Optional[dict]:
    """Ask the LLM to understand what the project does."""
    # Build a brief overview: file listing + a few key files
    file_list = "\n".join(f.name for f in ctx.source_files[:50])

    # Include the first ~100 lines of a few key files
    key_snippets: list[str] = []
    key_files = (ctx.entry_points + ctx.parser_files)[:3]
    if not key_files:
        key_files = [f for f, _ in ctx.file_risk_scores[:3]]
    for f in key_files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            key_snippets.append(f"// {f.name}\n{text[:1500]}")
        except Exception:
            pass

    prompt = (
        f"## Source files ({len(ctx.source_files)} total)\n{file_list}\n\n"
        f"## Key files\n```c\n{''.join(key_snippets[:3000])}\n```\n"
    )

    try:
        raw = router.chat(SYS_ENTRY_POINTS, prompt, max_tokens=500, temperature=0.1)
        if raw:
            return _parse_json(raw)
    except Exception as e:
        print(f"  Project understanding failed: {e}")
    return None


def _scan_phase(
    ctx: RepoContext,
    router: LLMRouter,
    project_info: Optional[dict],
) -> List[VulnCandidate]:
    """Scan high-risk files one at a time."""
    all_candidates: list[VulnCandidate] = []

    # Determine which files to scan: parser files first, then by risk score
    files_to_scan: list[Path] = []
    seen: set[str] = set()

    # Priority 1: files mentioned by the project understanding phase
    if project_info:
        for name in project_info.get("entry_files", []):
            for f in ctx.source_files:
                if name in str(f) and str(f) not in seen:
                    files_to_scan.append(f)
                    seen.add(str(f))

    # Priority 2: parser files
    for f in ctx.parser_files:
        if str(f) not in seen:
            files_to_scan.append(f)
            seen.add(str(f))

    # Priority 3: top risk-scored files
    for f, score in ctx.file_risk_scores:
        if str(f) not in seen:
            files_to_scan.append(f)
            seen.add(str(f))

    max_files = 10
    files_to_scan = files_to_scan[:max_files]

    for idx, path in enumerate(files_to_scan):
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            if len(content) > 6000:
                content = _extract_risky_sections(content)
            content = content[:6000]
        except Exception:
            continue

        rel_path = _rel_path(path, ctx.repo_path)
        print(f"  [{idx+1}/{len(files_to_scan)}] {rel_path} ({len(content)} chars)")

        context_note = ""
        if project_info:
            context_note = (
                f"Project type: {project_info.get('project_type', 'unknown')}. "
                f"Input formats: {project_info.get('input_formats', [])}. "
            )

        prompt = (
            f"{context_note}\n"
            f"## File: {rel_path}\n```c\n{content}\n```\n\n"
            f"Find exploitable vulnerabilities. Output JSON array.\n"
        )

        try:
            raw = router.chat(SYS_SCAN, prompt, max_tokens=1500, temperature=0.1)
            if raw:
                cands = _parse_candidates_json(raw)
                for c in cands:
                    if c.file_path == "unknown" or c.file_path == "file.c":
                        c.file_path = rel_path
                all_candidates.extend(cands)
                if cands:
                    print(f"    → {len(cands)} candidate(s)")
                else:
                    print(f"    → 0 (response: {raw[:100]}...)")
        except Exception as e:
            print(f"    → error: {e}")

    return all_candidates


def _enrich_candidates(
    ctx: RepoContext,
    candidates: List[VulnCandidate],
) -> List[VulnCandidate]:
    """Gather cross-file context for each candidate.

    Find the actual function source, callers, callees, struct definitions.
    This gives the deep analysis phase enough context to confirm the bug.
    """
    for cand in candidates:
        # Find the function source
        func_src = _find_function(ctx, cand.function_name)
        if func_src:
            cand.code_snippet = func_src[:3000]

        # Find related functions (callers of this function)
        callers = _find_callers(ctx, cand.function_name)
        if callers:
            cand.entry_point = f"Called by: {', '.join(callers[:5])}"

    return candidates


def _deep_analysis(
    ctx: RepoContext,
    router: LLMRouter,
    candidates: List[VulnCandidate],
    project_info: Optional[dict],
) -> List[VulnCandidate]:
    """Confirm each candidate with deep LLM analysis."""
    confirmed: list[VulnCandidate] = []

    for idx, cand in enumerate(candidates):
        if not cand.code_snippet:
            # No source found — still include high-confidence ones
            if cand.confidence >= 0.8:
                confirmed.append(cand)
            continue

        context_note = ""
        if project_info:
            context_note = f"Project: {project_info.get('project_type', '')}. "
            context_note += f"Formats: {project_info.get('input_formats', [])}. "

        prompt = (
            f"{context_note}\n"
            f"## Function: {cand.function_name} ({cand.file_path})\n"
            f"## Suspected bug: {cand.vuln_type} — {cand.root_cause or cand.description}\n"
            f"## Called by: {cand.entry_point}\n\n"
            f"```c\n{cand.code_snippet}\n```\n\n"
            f"Is this a real exploitable bug? What exact input triggers it?\n"
        )

        print(f"  [{idx+1}/{len(candidates)}] Analyzing {cand.function_name}...")

        try:
            raw = router.chat(SYS_DEEP, prompt, max_tokens=1500, temperature=0.1)
            if raw:
                result = _parse_json(raw)
                if result and result.get("exploitable"):
                    cand.description = result.get("description", cand.description)
                    cand.entry_point = result.get("entry_point", cand.entry_point)
                    cand.format_hint = result.get("format", "")
                    cand.attack_input_hint = result.get("trigger", cand.attack_input_hint)
                    cand.root_cause = result.get("root_cause", cand.root_cause)
                    cand.confidence = min(cand.confidence + 0.15, 1.0)
                    confirmed.append(cand)
                    print(f"    ✓ CONFIRMED: {cand.vuln_type}")
                else:
                    print(f"    ✗ Not exploitable")
        except Exception as e:
            print(f"    Error: {e}")
            # Still include high-confidence ones
            if cand.confidence >= 0.7:
                confirmed.append(cand)

    return confirmed


# ── Helpers ────────────────────────────────────────────────────────────────

def _extract_risky_sections(content: str) -> str:
    """From a large file, extract sections around risky API calls."""
    lines = content.splitlines()
    risky_lines: set[int] = set()
    for i, line in enumerate(lines):
        line_lower = line.lower()
        for api in _UNSAFE_APIS + ["length", "chunk", "parse", "read"]:
            if api in line_lower:
                risky_lines.add(i)
                break

    if not risky_lines:
        return content[:6000]

    parts: list[str] = []
    total = 0
    for ln in sorted(risky_lines):
        start = max(0, ln - 10)
        end = min(len(lines), ln + 10)
        section = "\n".join(f"{i+1}: {lines[i]}" for i in range(start, end))
        if total + len(section) > 6000:
            break
        parts.append(section)
        total += len(section)

    return "\n...\n".join(parts)


def _find_function(ctx: RepoContext, func_name: str) -> Optional[str]:
    """Find a function's source code in the repo."""
    # Check function index first
    file_path = ctx.function_index.get(func_name)
    files_to_check: list[Path] = []
    if file_path:
        files_to_check.append(Path(file_path))
    # Also search all source files
    files_to_check.extend(ctx.source_files)

    for f in files_to_check:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            pattern = rf'(?:static\s+)?(?:[\w*]+\s+)+{re.escape(func_name)}\s*\('
            m = re.search(pattern, text)
            if not m:
                continue
            start = m.start()
            brace = text.find("{", m.end())
            if brace == -1:
                continue
            # Match braces
            depth = 0
            pos = brace
            while pos < len(text):
                if text[pos] == "{":
                    depth += 1
                elif text[pos] == "}":
                    depth -= 1
                    if depth == 0:
                        # Include some context before the function
                        ctx_start = max(0, start - 200)
                        return text[ctx_start:pos + 1]
                pos += 1
        except Exception:
            continue
    return None


def _find_callers(ctx: RepoContext, func_name: str) -> List[str]:
    """Find functions that call the given function."""
    callers: list[str] = []
    pattern = re.compile(rf'\b{re.escape(func_name)}\s*\(')
    for f in ctx.source_files:
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            if func_name not in text:
                continue
            # Find function definitions that contain calls to func_name
            for m in re.finditer(
                r'^(?:[\w*]+\s+)+(\w+)\s*\([^)]*\)\s*\{',
                text, re.MULTILINE
            ):
                caller_name = m.group(1)
                if caller_name == func_name:
                    continue
                # Check if the call happens inside this function
                brace_start = text.find("{", m.end() - 1)
                if brace_start == -1:
                    continue
                # Quick check: is func_name mentioned after the opening brace?
                next_1000 = text[brace_start:brace_start + 5000]
                if pattern.search(next_1000):
                    callers.append(caller_name)
        except Exception:
            pass
    return list(dict.fromkeys(callers))  # dedupe preserving order


def _rel_path(path: Path, repo: Path) -> str:
    """Get a relative path for display."""
    try:
        return str(path.relative_to(repo))
    except ValueError:
        return path.name


def _parse_json(raw: str) -> Optional[dict]:
    """Parse JSON from LLM response."""
    import json
    cleaned = re.sub(r"```json\s*", "", raw)
    cleaned = re.sub(r"```\s*", "", cleaned).strip()
    try:
        result = json.loads(cleaned)
        return result if isinstance(result, dict) else None
    except Exception:
        m = re.search(r'\{[^{}]*\}', raw, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except Exception:
                pass
    return None


def _parse_candidates_json(raw: str) -> List[VulnCandidate]:
    """Parse LLM scan output into VulnCandidate list."""
    import json
    cleaned = re.sub(r"```json\s*", "", raw)
    cleaned = re.sub(r"```\s*", "", cleaned).strip()

    candidates: list[VulnCandidate] = []
    items: list[dict] = []

    try:
        data = json.loads(cleaned)
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = [data]
    except json.JSONDecodeError:
        for m in re.finditer(r'\{[^{}]+\}', raw):
            try:
                items.append(json.loads(m.group()))
            except Exception:
                pass

    for item in items:
        if not isinstance(item, dict):
            continue
        candidates.append(VulnCandidate(
            function_name=item.get("function", "unknown"),
            file_path=item.get("file", "unknown"),
            line_number=int(item.get("line", 0)),
            vuln_type=item.get("type", "other"),
            description=item.get("description", ""),
            confidence=float(item.get("confidence", 0.5)),
            code_snippet="",
            attack_input_hint=item.get("input_hint", ""),
            root_cause=item.get("root_cause", ""),
        ))

    return candidates
