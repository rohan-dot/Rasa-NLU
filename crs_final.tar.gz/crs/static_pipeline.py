"""
crs/static_pipeline.py — Complete CRS pipeline for any C/C++ repo.

No pre-existing harness required. No project-specific configuration.

Pipeline:
  1. Ingest repo (scan source files, no compilation)
  2. LLM static analysis (find vulnerabilities)
  3. Build project with ASAN (autotools/cmake/make — auto-detected)
  4. LLM generates PoC bytes
  5. Verify: feed PoC to project CLI binary, check for ASAN crash
  6. Optionally submit to CyberGym server

Usage:
  # Any repo
  python -m crs.static_pipeline --repo-dir /path/to/project --model gpt-oss-120b ...

  # CyberGym task
  python -m crs.static_pipeline --task-dir ./data/arvo/10400 --model gemma-3-27b-it ...

  # With submission
  python -m crs.static_pipeline --task-dir ./data/arvo/10400 \\
      --cybergym-server http://SERVER:8666 --task-id arvo:10400 ...
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import List, Optional

from crs.config import cfg


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="CRS — Works on any C/C++ repo. No harness needed."
    )
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--repo-dir", help="Path to any C/C++ repo")
    g.add_argument("--task-dir", help="CyberGym task dir (repo-vul.tar.gz)")

    p.add_argument("--output-dir", default="./crs_results")
    p.add_argument("--model", default=cfg.LLM_MODEL)
    p.add_argument("--base-url", default=cfg.LLM_BASE_URL)
    p.add_argument("--api-key", default=cfg.LLM_API_KEY)
    p.add_argument("--max-candidates", type=int, default=5)
    p.add_argument("--skip-build", action="store_true",
                   help="Skip building — pure static analysis only")
    p.add_argument("--description", default=None)
    p.add_argument("--cybergym-server", default=None)
    p.add_argument("--task-id", default=None)
    return p.parse_args(argv)


def run(argv=None):
    args = parse_args(argv)

    print("\033[96m")
    print("  " + "=" * 55)
    print("  CRS — Cyber Reasoning System")
    print("  Any repo | Auto-build | LLM analysis | PoC verify")
    print("  " + "=" * 55)
    print("\033[0m")
    print(f"  Model  : {args.model}")
    print(f"  URL    : {args.base_url}")

    from crs.llm_router import LLMRouter
    router = LLMRouter(args.model, args.base_url, args.api_key)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    # ── Resolve repo path ──────────────────────────────────────────────
    description = args.description or ""
    task_id = args.task_id or "unknown"
    project_name = "unknown"

    if args.task_dir:
        task_dir = Path(args.task_dir).resolve()
        task_id = args.task_id or task_dir.name
        tarball = task_dir / "repo-vul.tar.gz"
        if tarball.exists():
            from crs.data_loader import load_task_from_local
            task = load_task_from_local(task_dir)
            repo_path = Path(task.repo_path)
            description = description or task.vulnerability_description
            project_name = task.project_name
        else:
            print(f"  ERROR: No repo-vul.tar.gz in {task_dir}")
            return
    else:
        repo_path = Path(args.repo_dir).resolve()
        project_name = repo_path.name

    print(f"  Repo   : {repo_path}")
    print(f"  Task   : {task_id}")
    if description:
        print(f"  Desc   : {description[:80]}...")
    else:
        print(f"  Mode   : Level 0 (no description)")

    # ==================================================================
    #  STEP 1: Ingest repo
    # ==================================================================
    _step_header(1, "Ingesting repository")
    from crs.static_analyzer import ingest_repo, analyze_repo
    ctx = ingest_repo(repo_path)

    # ==================================================================
    #  STEP 2: Static analysis
    # ==================================================================
    _step_header(2, "LLM vulnerability analysis")

    if description:
        from crs.static_analyzer import VulnCandidate
        print(f"  Using provided description (Level 1+)")
        candidates = [VulnCandidate(
            function_name=_extract_func_name(description),
            file_path="unknown", line_number=0,
            vuln_type=_classify_vuln(description),
            description=description, confidence=0.9,
            code_snippet="", attack_input_hint="",
            format_hint=_extract_format(description),
        )]
        try:
            llm_candidates = analyze_repo(ctx, router, max_candidates=3)
            candidates.extend(llm_candidates)
        except Exception as e:
            print(f"  LLM scan error (continuing with description): {e}")
    else:
        candidates = analyze_repo(ctx, router, max_candidates=args.max_candidates)

    if not candidates:
        print(f"\n  X No vulnerabilities found")
        _save_report(output_dir, task_id, project_name, [], [], [], time.time() - t0)
        router.log_stats()
        return

    print(f"\n  Found {len(candidates)} vulnerability candidate(s):")
    for i, c in enumerate(candidates):
        print(f"    [{i}] {c.function_name} ({c.vuln_type}) conf={c.confidence:.2f}")
        print(f"        {c.description[:80]}...")

    # ==================================================================
    #  STEP 3: Build project with ASAN
    # ==================================================================
    build_result = None
    if not args.skip_build:
        _step_header(3, "Building project with ASAN")
        from crs.auto_builder import build_project
        work_dir = cfg.task_work_dir(task_id)
        build_result = build_project(repo_path, work_dir)

        if build_result.success:
            print(f"\n  Build succeeded: {len(build_result.binaries)} binaries, "
                  f"{len(build_result.static_libs)} libs")
        else:
            print(f"\n  Build failed — PoCs still generated for server submission")
    else:
        print(f"\n  [Skipping build]")

    # ==================================================================
    #  STEP 4: Generate PoC bytes
    # ==================================================================
    _step_header(4, "Generating PoC inputs")
    from crs.poc_writer import generate_pocs, PoC
    all_pocs: list[PoC] = []

    for i, cand in enumerate(candidates):
        if not cand.code_snippet:
            from crs.static_analyzer import _find_function
            src = _find_function(ctx, cand.function_name)
            if src:
                cand.code_snippet = src[:3000]

        print(f"\n  [{i}] {cand.function_name}...")
        try:
            pocs = generate_pocs(cand, router, task_id)
            all_pocs.extend(pocs)
        except Exception as e:
            print(f"    PoC generation failed: {e}")

    if not all_pocs:
        print(f"\n  X No PoCs generated")
        _save_report(output_dir, task_id, project_name, candidates, [], [],
                     time.time() - t0)
        router.log_stats()
        return

    print(f"\n  Generated {len(all_pocs)} PoC(s)")

    # ==================================================================
    #  STEP 5: Verify PoCs
    # ==================================================================
    verify_results = []
    triggered_pocs: list[PoC] = []

    if build_result and build_result.binaries:
        _step_header(5, f"Verifying against {len(build_result.binaries)} binary(ies)")
        from crs.verifier import verify_poc_against_all

        for i, poc in enumerate(all_pocs):
            print(f"\n  [{i}] {poc.name} ({len(poc.data)} bytes)")
            result = verify_poc_against_all(
                poc.path, build_result.binaries,
                timeout=30, router=router)
            verify_results.append(result)

            if result.triggered:
                print(f"  >>> TRIGGERED: {result.crash_type} via {result.invocation}")
                for line in result.output.split("\n"):
                    if any(kw in line for kw in ["ERROR:", "SUMMARY:"]):
                        print(f"      {line.strip()}")
                triggered_pocs.append(poc)
                break
            else:
                print(f"    no trigger (rc={result.return_code})")

        if triggered_pocs:
            print(f"\n  SUCCESS — {len(triggered_pocs)} PoC(s) triggered!")
        else:
            print(f"\n  No local trigger — PoCs may work on CyberGym server")
    else:
        print(f"\n  [No binaries to verify against]")

    # ==================================================================
    #  STEP 6: CyberGym submission
    # ==================================================================
    if args.cybergym_server:
        _step_header(6, "Submitting to CyberGym")
        full_task_id = task_id if ":" in task_id else f"arvo:{task_id}"
        from crs.cybergym_submit import submit_all_pocs
        work = cfg.task_work_dir(task_id)
        sub_results = submit_all_pocs(args.cybergym_server, full_task_id, work)
        accepted = [r for r in sub_results if r.success]
        if accepted:
            print(f"\n  ACCEPTED: {accepted[0].poc_path.name}")
        else:
            print(f"\n  No PoC accepted by server")

    # ==================================================================
    #  REPORT
    # ==================================================================
    elapsed = time.time() - t0
    _save_report(output_dir, task_id, project_name,
                 candidates, all_pocs, verify_results, elapsed)

    print(f"\n{'='*60}")
    built_str = "yes" if (build_result and build_result.success) else "no"
    triggered_str = (f"\033[92m{len(triggered_pocs)} TRIGGERED\033[0m"
                     if triggered_pocs else "0")
    print(f"  {task_id} | {project_name} | built={built_str} | "
          f"candidates={len(candidates)} | pocs={len(all_pocs)} | "
          f"triggered={triggered_str} | {elapsed:.1f}s")
    print(f"{'='*60}\n")
    router.log_stats()


# ── Helpers ────────────────────────────────────────────────────────────────

def _step_header(n: int, title: str):
    print(f"\n{'='*60}")
    print(f"  STEP {n}: {title}")
    print(f"{'='*60}")


def _extract_func_name(desc: str) -> str:
    import re
    m = re.search(r'\b([A-Za-z_]\w{4,})\s*\(', desc)
    return m.group(1) if m else "unknown"


def _classify_vuln(desc: str) -> str:
    d = desc.lower()
    for kw, typ in [("overflow", "buffer_overflow"), ("use after free", "use_after_free"),
                    ("use-after-free", "use_after_free"), ("null", "null_deref"),
                    ("integer", "integer_overflow"), ("uninit", "uninit_memory"),
                    ("double free", "double_free"), ("double-free", "double_free")]:
        if kw in d:
            return typ
    return "other"


def _extract_format(desc: str) -> str:
    import re
    m = re.search(r'(?:Read|Write)(\w+?)Image', desc)
    if m:
        return m.group(1)
    for fmt in ["MNG", "PNG", "TIFF", "JPEG", "GIF", "ELF", "PDF",
                "XML", "JSON", "MQTT", "HTTP"]:
        if fmt.lower() in desc.lower():
            return fmt
    return ""


def _save_report(output_dir, task_id, project, candidates, pocs, verify_results, elapsed):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    result = {
        "task_id": task_id, "project": project, "time_elapsed": elapsed,
        "candidates": [{"function": c.function_name, "file": c.file_path,
                        "type": c.vuln_type, "confidence": c.confidence,
                        "description": c.description} for c in candidates],
        "pocs": [{"name": p.name, "size": len(p.data), "path": str(p.path)}
                 for p in pocs],
        "verified": [{"triggered": v.triggered, "crash_type": v.crash_type,
                      "binary": v.binary_path.name, "invocation": v.invocation}
                     for v in verify_results],
    }

    (output_dir / "results.json").write_text(json.dumps(result, indent=2))
    triggered = sum(1 for v in verify_results if v.triggered)
    md = (f"# CRS Results: {project}\n\nTask: {task_id} | Time: {elapsed:.1f}s\n"
          f"Triggered: {triggered}/{len(pocs)}\n\n"
          + "\n".join(f"## {c.function_name} ({c.vuln_type})\n{c.description}\n"
                      for c in candidates))
    (output_dir / "results.md").write_text(md)
    print(f"  Results saved to {output_dir}/")


if __name__ == "__main__":
    run()
