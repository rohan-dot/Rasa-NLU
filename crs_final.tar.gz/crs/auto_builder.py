"""
crs/auto_builder.py — Build any C/C++ project with ASAN and find binaries.

No harness required. Just point at a repo and it:
  1. Detects the build system (autotools/cmake/make/meson)
  2. Configures with ASAN and minimal features
  3. Builds (tolerates partial failures)
  4. Finds all produced executables and libraries

Extracted from harness_runner.py — battle-tested on GraphicsMagick,
Mosquitto, libmagic, and others.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple


@dataclass
class ProjectBuild:
    success: bool
    repo_path: Path
    work_dir: Path
    binaries: List[Path] = field(default_factory=list)    # ELF executables
    static_libs: List[Path] = field(default_factory=list)  # .a files
    build_log: str = ""
    build_system: str = "unknown"


# ── Public API ─────────────────────────────────────────────────────────────

def build_project(repo_path: Path, work_dir: Path) -> ProjectBuild:
    """Build any C/C++ project with ASAN instrumentation.

    Tries autotools → cmake → make → meson, in order.
    Returns a ProjectBuild with all discovered binaries and libraries.
    """
    repo = Path(repo_path).resolve()
    work = Path(work_dir)
    work.mkdir(parents=True, exist_ok=True)

    # Clean stale build dir
    stale = work / "build"
    if stale.exists():
        shutil.rmtree(stale, ignore_errors=True)

    result = ProjectBuild(success=False, repo_path=repo, work_dir=work)

    # Detect build system
    build_type = _detect_build_system(repo)
    result.build_system = build_type
    print(f"[build] Build system: {build_type}")
    print(f"[build] Repo: {repo}")

    # Build
    ok, log = _do_build(repo, work, build_type)
    result.build_log = log

    # Find artifacts regardless of build success (partial builds produce useful .a files)
    result.static_libs = _find_static_libs(repo, work)
    result.binaries = _find_binaries(repo, work)

    if result.static_libs or result.binaries:
        result.success = True
        print(f"[build] Found {len(result.binaries)} binary(ies), "
              f"{len(result.static_libs)} static lib(s)")
    elif ok:
        result.success = True
        print(f"[build] Build succeeded but no .a files or binaries found")
    else:
        print(f"[build] Build failed")

    return result


# ── Build system detection ─────────────────────────────────────────────────

def _detect_build_system(repo: Path) -> str:
    """Detect build system. Prefers autotools over cmake (root-anchored)."""

    def _find_shallowest(name: str) -> Optional[Path]:
        candidates = sorted(repo.rglob(name),
                            key=lambda p: (len(p.parts), str(p)))
        return candidates[0] if candidates else None

    # Check autotools first (many projects have cmake only in subdirs)
    at = _find_shallowest("configure.ac") or _find_shallowest("configure")
    if at:
        return "autotools"

    if _find_shallowest("CMakeLists.txt"):
        return "cmake"

    if _find_shallowest("meson.build"):
        return "meson"

    if _find_shallowest("Makefile") or _find_shallowest("makefile"):
        return "make"

    return "unknown"


def _find_project_dir(repo: Path, build_type: str) -> Path:
    """Find the shallowest directory containing build files."""
    names = {
        "autotools": ["configure.ac", "configure"],
        "cmake": ["CMakeLists.txt"],
        "make": ["Makefile", "makefile"],
        "meson": ["meson.build"],
    }
    for name in names.get(build_type, []):
        candidates = sorted(repo.rglob(name),
                            key=lambda p: (len(p.parts), str(p)))
        if candidates:
            return candidates[0].parent
    return repo


# ── Build implementations ──────────────────────────────────────────────────

def _run(cmd, timeout=300, cwd=None, env=None):
    """Run a command, return (success, stdout+stderr)."""
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout,
                           cwd=str(cwd) if cwd else None, env=env)
        out = r.stdout.decode(errors="replace") + r.stderr.decode(errors="replace")
        return r.returncode == 0, out
    except subprocess.TimeoutExpired:
        return False, "Timed out"
    except Exception as e:
        return False, str(e)


def _make_env():
    """Create environment with ASAN flags."""
    env = os.environ.copy()
    san = "-fsanitize=address,undefined -g -O1"
    env["CFLAGS"] = san
    env["CXXFLAGS"] = san
    env["LDFLAGS"] = "-fsanitize=address,undefined"
    return env, san


def _do_build(repo: Path, work: Path, build_type: str) -> Tuple[bool, str]:
    """Dispatch to the right build method."""
    env, san = _make_env()
    project_dir = _find_project_dir(repo, build_type)
    log_parts: list[str] = []

    print(f"[build] Project dir: {project_dir}")

    try:
        if build_type == "autotools":
            return _build_autotools(project_dir, work, env, san, log_parts)
        elif build_type == "cmake":
            return _build_cmake(project_dir, work, env, san, log_parts)
        elif build_type == "meson":
            return _build_meson(project_dir, work, env, san, log_parts)
        elif build_type == "make":
            return _build_make(project_dir, work, env, san, log_parts)
        else:
            return False, "Unknown build system"
    except Exception as e:
        return False, "\n".join(log_parts) + f"\nException: {e}"


def _build_autotools(
    project_dir: Path, work: Path, env: dict, san: str, log: list
) -> Tuple[bool, str]:
    """Build autotools project with minimal features."""

    # autoreconf
    if (project_dir / "configure.ac").exists():
        print("[build] autoreconf -fi")
        ok, out = _run(["autoreconf", "-fi"], cwd=project_dir, env=env, timeout=120)
        log.append(out)
        if not ok and not (project_dir / "configure").exists():
            return False, "\n".join(log)

    # configure — disable unnecessary features to minimize deps
    if (project_dir / "configure").exists():
        disable_flags = [
            "--without-x", "--without-xml", "--without-wmf",
            "--without-dps", "--without-fpx", "--without-perl",
            "--without-trio", "--without-jbig", "--without-jp2",
            "--without-lcms2", "--without-lzma", "--without-zstd",
            "--without-webp", "--without-ttf",
            "--disable-openmp",
        ]
        print("[build] ./configure (with feature disables)")
        ok, out = _run(
            ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
             f"LDFLAGS=-fsanitize=address,undefined",
             "--enable-static", "--disable-shared"] + disable_flags,
            cwd=project_dir, env=env, timeout=300)
        log.append(out)
        if not ok:
            print("[build] Retrying configure without --without flags...")
            ok, out = _run(
                ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}",
                 f"LDFLAGS=-fsanitize=address,undefined",
                 "--enable-static", "--disable-shared"],
                cwd=project_dir, env=env, timeout=300)
            log.append(out)
            if not ok:
                print("[build] Retrying configure with minimal flags...")
                ok, out = _run(
                    ["./configure", f"CFLAGS={san}", f"CXXFLAGS={san}"],
                    cwd=project_dir, env=env, timeout=300)
                log.append(out)
                if not ok:
                    return False, "\n".join(log)

    # make
    print("[build] make -j4")
    ok, out = _run(["make", "-j4"], cwd=project_dir, env=env, timeout=600)
    log.append(out)
    if not ok:
        # Check for partial success
        libs = list(project_dir.rglob("*.a"))
        libs = [l for l in libs if _safe_size(l) > 10000 and "CMakeFiles" not in str(l)]
        if libs:
            print(f"[build] make failed but found {len(libs)} lib(s) — partial success")
            return True, "\n".join(log)
        return False, "\n".join(log)

    return True, "\n".join(log)


def _build_cmake(
    project_dir: Path, work: Path, env: dict, san: str, log: list
) -> Tuple[bool, str]:
    """Build cmake project."""
    build_dir = work / "build"
    build_dir.mkdir(parents=True, exist_ok=True)

    cmake_flags = [
        "-B", str(build_dir), "-S", str(project_dir),
        f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
        "-DBUILD_TESTING=OFF", "-DBUILD_SHARED_LIBS=OFF",
        "-DWITH_STATIC_LIBRARIES=ON", "-DWITH_STATIC=ON",
        "-DENABLE_STATIC=ON", "-DWITH_TLS=OFF", "-DWITH_CJSON=OFF",
        "-DDOCUMENTATION=OFF",
    ]

    print("[build] cmake configure")
    ok, out = _run(["cmake"] + cmake_flags, cwd=project_dir, env=env)
    log.append(out)
    if not ok:
        # Retry minimal
        ok, out = _run(["cmake", "-B", str(build_dir), "-S", str(project_dir),
                        f"-DCMAKE_C_FLAGS={san}", f"-DCMAKE_CXX_FLAGS={san}",
                        "-DBUILD_SHARED_LIBS=OFF"],
                       cwd=project_dir, env=env)
        log.append(out)
        if not ok:
            return False, "\n".join(log)

    print("[build] cmake --build")
    ok, out = _run(["cmake", "--build", str(build_dir), "-j4"],
                   cwd=project_dir, env=env, timeout=600)
    log.append(out)
    if not ok:
        # Check partial success
        libs = [l for l in build_dir.rglob("*.a")
                if _safe_size(l) > 10000 and "CMakeFiles" not in str(l)]
        if libs:
            print(f"[build] cmake build failed but found {len(libs)} lib(s)")
            return True, "\n".join(log)
        return False, "\n".join(log)

    return True, "\n".join(log)


def _build_meson(
    project_dir: Path, work: Path, env: dict, san: str, log: list
) -> Tuple[bool, str]:
    """Build meson project."""
    build_dir = work / "build"
    print("[build] meson setup")
    ok, out = _run(["meson", "setup", str(build_dir),
                    f"-Dc_args={san}", f"-Dcpp_args={san}",
                    "-Ddefault_library=static"],
                   cwd=project_dir, env=env)
    log.append(out)
    if not ok:
        return False, "\n".join(log)

    print("[build] meson compile")
    ok, out = _run(["meson", "compile", "-C", str(build_dir)],
                   cwd=project_dir, env=env, timeout=600)
    log.append(out)
    return ok, "\n".join(log)


def _build_make(
    project_dir: Path, work: Path, env: dict, san: str, log: list
) -> Tuple[bool, str]:
    """Build plain Makefile project."""
    print("[build] make -j4")
    ok, out = _run(["make", "-j4"], cwd=project_dir, env=env, timeout=600)
    log.append(out)
    return ok, "\n".join(log)


# ── Artifact discovery ─────────────────────────────────────────────────────

def _safe_size(p: Path) -> int:
    try:
        return p.stat().st_size if p.is_file() else 0
    except OSError:
        return 0


def _find_static_libs(repo: Path, work: Path) -> List[Path]:
    """Find all .a static libraries."""
    skip = {"test", "tests", "example", "doc", "fuzz", "CMakeFiles"}
    libs: list[Path] = []
    seen: set[str] = set()

    for search in [work / "build", repo]:
        if not search.exists():
            continue
        for lib in sorted(search.rglob("*.a")):
            try:
                if not lib.is_file() or _safe_size(lib) < 1000:
                    continue
            except OSError:
                continue
            if {p.lower() for p in lib.parts} & skip:
                continue
            if lib.name in seen:
                continue
            seen.add(lib.name)
            libs.append(lib)

    libs.sort(key=_safe_size, reverse=True)
    for lib in libs[:5]:
        print(f"[build] Static lib: {lib.name} ({_safe_size(lib)} bytes)")
    return libs


def _find_binaries(repo: Path, work: Path) -> List[Path]:
    """Find all ELF executables produced by the build."""
    skip_dirs = {"test", "tests", "example", "doc", ".git", "CMakeFiles"}
    skip_names = {"conftest", "config.guess", "config.sub", "libtool",
                  "compile", "depcomp", "install-sh", "missing", "mkinstalldirs"}
    binaries: list[Path] = []
    seen: set[str] = set()

    for search in [work / "build", repo]:
        if not search.exists():
            continue
        for f in sorted(search.rglob("*")):
            try:
                if not f.is_file():
                    continue
                if not os.access(str(f), os.X_OK):
                    continue
                # Skip directories
                if {p.lower() for p in f.parts} & skip_dirs:
                    continue
                # Skip known non-binaries
                if f.name in skip_names:
                    continue
                if f.suffix in {".sh", ".py", ".pl", ".rb", ".la", ".o", ".a", ".so"}:
                    continue
                # Check if it's actually an ELF binary
                if not _is_elf(f):
                    continue
                if f.name in seen:
                    continue
                seen.add(f.name)
                binaries.append(f)
            except OSError:
                continue

    # Sort: prefer binaries in standard locations and with meaningful names
    def _score(p: Path) -> float:
        s = 0.0
        name = p.name.lower()
        path_str = str(p).lower()
        # Prefer binaries in bin/ or src/
        if "/bin/" in path_str or "/.libs/" in path_str:
            s += 5.0
        if "/src/" in path_str:
            s += 3.0
        # Penalize test binaries
        if "test" in name or "bench" in name:
            s -= 5.0
        # Prefer larger binaries (more functionality)
        s += min(_safe_size(p) / 100000, 5.0)
        return s

    binaries.sort(key=_score, reverse=True)
    for b in binaries[:5]:
        print(f"[build] Binary: {b.name} ({_safe_size(b)} bytes) [{b.parent.name}/]")
    return binaries


def _is_elf(path: Path) -> bool:
    """Check if a file is an ELF binary."""
    try:
        with open(path, "rb") as f:
            magic = f.read(4)
            return magic == b"\x7fELF"
    except Exception:
        return False
