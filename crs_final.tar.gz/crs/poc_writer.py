"""
crs/poc_writer.py — Generate PoC exploits from vulnerability descriptions.

No harness needed. No fuzz target needed. Two output modes:
  1. Raw input bytes (for file parsers / network protocols)
  2. Standalone C program (for library bugs without clear input format)

The CyberGym server has its own fuzz target — we just need the bytes.
"""
from __future__ import annotations

import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from crs.config import cfg
from crs.static_analyzer import VulnCandidate

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from crs.llm_router import LLMRouter


@dataclass
class PoC:
    name: str
    data: bytes
    path: Path
    confidence: float
    notes: str
    script: str = ""
    candidate: Optional[VulnCandidate] = None


# ── Prompts ────────────────────────────────────────────────────────────────

SYS_BYTE_GEN = """\
You write Python scripts that generate crafted input to trigger C/C++ bugs.

RULES:
1. Output ONLY a Python script in ```python ... ```
2. Script writes bytes to stdout: sys.stdout.buffer.write(...)
3. Use ONLY standard library: struct, sys, zlib, os
4. Start with the CORRECT file format signature:
   - MNG: b"\\x8a\\x4d\\x4e\\x47\\x0d\\x0a\\x1a\\x0a"
   - PNG: b"\\x89\\x50\\x4e\\x47\\x0d\\x0a\\x1a\\x0a"
   - ELF: b"\\x7fELF"
   - TIFF LE: b"II\\x2a\\x00"  TIFF BE: b"MM\\x00\\x2a"
   - PDF: b"%PDF-"
   - For chunk-based formats: [4B length][4B type][data][4B CRC]
   - Calculate CRCs with zlib.crc32() for PNG/MNG chunks
5. Build STRUCTURALLY VALID input, malform ONLY the triggering field
6. Comment every section: what bytes, why this value
"""

SYS_MULTI_GEN = """\
You write Python scripts generating MULTIPLE crafted input variants.

Script takes output dir as sys.argv[1]. Write variant_0.bin through variant_4.bin.
Each variant tries a different approach to trigger the same bug.

RULES: same as byte generation — correct format signature, valid structure,
malform only the triggering field. Use struct, zlib for CRCs.
Output ONLY the script in ```python ... ```
"""


# ── Generator ──────────────────────────────────────────────────────────────

def generate_pocs(
    candidate: VulnCandidate,
    router: LLMRouter,
    task_id: str = "unknown",
) -> List[PoC]:
    """Generate PoC inputs for a vulnerability candidate."""
    results: list[PoC] = []

    # Strategy 1: Direct byte generation
    print(f"  [poc] Generating bytes for {candidate.function_name}...")
    direct = _generate_direct(candidate, router, task_id)
    results.extend(direct)

    # Strategy 2: Multi-variant generation
    print(f"  [poc] Generating variants...")
    variants = _generate_variants(candidate, router, task_id)
    results.extend(variants)

    print(f"  [poc] Total: {len(results)} PoC(s)")
    return results


def _build_vuln_prompt(candidate: VulnCandidate) -> str:
    """Build a context prompt from a VulnCandidate."""
    parts = [
        f"## Vulnerability\n{candidate.description}\n",
        f"## Type: {candidate.vuln_type}\n",
        f"## Function: {candidate.function_name} in {candidate.file_path}:{candidate.line_number}\n",
    ]
    if candidate.root_cause:
        parts.append(f"## Root cause: {candidate.root_cause}\n")
    if candidate.format_hint:
        parts.append(f"## Input format: {candidate.format_hint}\n")
    if candidate.attack_input_hint:
        parts.append(f"## Trigger: {candidate.attack_input_hint}\n")
    if candidate.entry_point:
        parts.append(f"## Entry point: {candidate.entry_point}\n")
    if candidate.code_snippet:
        parts.append(f"## Vulnerable code\n```c\n{candidate.code_snippet[:2000]}\n```\n")
    return "\n".join(parts)


def _generate_direct(
    candidate: VulnCandidate, router: LLMRouter, task_id: str
) -> List[PoC]:
    """Single-shot byte generation."""
    results: list[PoC] = []
    ctx = _build_vuln_prompt(candidate)

    prompt = (
        ctx +
        "\n## TASK\n"
        "Write a Python script that generates the EXACT bytes to trigger this bug.\n"
        "Use sys.stdout.buffer.write() to output.\n"
        "Get the file format signature RIGHT or the parser rejects the input.\n"
    )

    try:
        raw = router.chat(SYS_BYTE_GEN, prompt, max_tokens=2000, temperature=0.2)
        if not raw:
            return results
        script = _extract_python(raw)
        if not script:
            return results
        data = _run_script(script)
        if data and len(data) > 0:
            path = _save(data, task_id, "direct")
            results.append(PoC("direct", data, path, 0.7,
                f"{len(data)} bytes", script, candidate))
            print(f"    direct: {len(data)} bytes")
    except Exception as e:
        print(f"    direct failed: {e}")

    return results


def _generate_variants(
    candidate: VulnCandidate, router: LLMRouter, task_id: str
) -> List[PoC]:
    """Multi-variant generation."""
    results: list[PoC] = []
    ctx = _build_vuln_prompt(candidate)

    prompt = (
        ctx +
        "\n## TASK\n"
        "Write a Python script that generates 5 variant input files.\n"
        "Output dir is sys.argv[1]. Write variant_0.bin through variant_4.bin.\n"
        "Each variant tries a different angle to trigger the same bug.\n"
    )

    try:
        raw = router.chat(SYS_MULTI_GEN, prompt, max_tokens=2000, temperature=0.3)
        if not raw:
            return results
        script = _extract_python(raw)
        if not script:
            return results

        work = cfg.task_work_dir(task_id)
        vdir = work / "variants"
        vdir.mkdir(parents=True, exist_ok=True)
        _run_script(script, args=[str(vdir)])

        for vf in sorted(vdir.glob("variant_*.bin")):
            try:
                data = vf.read_bytes()
                if len(data) > 0:
                    path = _save(data, task_id, f"variant_{vf.stem}")
                    results.append(PoC(f"variant_{vf.stem}", data, path,
                        0.5, f"{len(data)} bytes", script, candidate))
            except Exception:
                pass
        if results:
            print(f"    variants: {len(results)} files")
    except Exception as e:
        print(f"    variants failed: {e}")

    return results


# ── Helpers ────────────────────────────────────────────────────────────────

def _extract_python(response: str) -> Optional[str]:
    m = re.search(r"```python\s*\n(.*?)```", response, re.DOTALL | re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r"```\w*\s*\n(.*?)```", response, re.DOTALL)
    if m:
        return m.group(1).strip()
    return None


def _run_script(script: str, timeout: int = 30, args: list = None) -> Optional[bytes]:
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False, dir="/tmp") as f:
        f.write(script)
        tmp = f.name
    try:
        cmd = ["python3", tmp] + (args or [])
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        if r.returncode != 0:
            print(f"    Script error: {r.stderr.decode(errors='replace')[:300]}")
            return None
        return r.stdout
    except subprocess.TimeoutExpired:
        return None
    finally:
        try:
            os.unlink(tmp)
        except Exception:
            pass


def _save(data: bytes, task_id: str, name: str) -> Path:
    safe_id = re.sub(r"[^a-zA-Z0-9_\-]", "_", str(task_id))
    safe_name = re.sub(r"[^a-zA-Z0-9_\-]", "_", name)
    work = cfg.task_work_dir(safe_id)
    path = work / f"poc_{safe_name}.bin"
    path.write_bytes(data)
    return path
