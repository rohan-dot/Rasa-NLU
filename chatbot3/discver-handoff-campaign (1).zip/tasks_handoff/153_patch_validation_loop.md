# Task 153 — validate, choose and iterate: every candidate built and replayed through the oracle, regressions and tests checked, the best one chosen, feedback driving the next round

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
A candidate is worth nothing until it is shown to build, to stop the crash, not to introduce another one, and not to break the
project's tests. End state: for each reproduced finding (highest severity first, within the time the scheduler and deadline allow),
the patch loop generates candidates (152), validates each through the oracle (151), picks the best validated one, and when none
validates, iterates with concrete feedback; every candidate and its validation log is persisted; validated patches are submitted per
the existing policy in the existing format.

## Precondition — check before editing
The oracle interface (151) and the candidate modules (152) exist. If either is missing, implement the loop against whatever exists
(today's builder path and today's candidate generation) behind the same function signatures, and say so in finish().

## Study first
The current patch loop, persistence of candidates, post-patch re-fuzzing, submission policy and tiers (MAP.md); the oracle (151);
candidate generation (152); the scheduler (144) and deadline helpers (135); the report model (134).

## Change
1. `src/core/patch_loop.py` — `patch_finding(ctx, finding) -> PatchOutcome`:
   - baseline: the oracle reproduces the finding on the unpatched build (151); otherwise outcome `not_reproducible_by_oracle`.
   - round r (≤ R, default 3): k candidates (152); for each applicable candidate: `build` → `run_pov` (fixed = the finding's
     signature no longer appears) → replay of the other known reproducers of the same harness (a new crash = `regressed`, with its trace)
     → `run_tests` compared with the cached unpatched baseline (newly failing tests = `tests_regressed`) → optional short re-fuzz of the
     patched harness when the run has a post-patch re-fuzz step and time allows.
   - status per candidate: `validated` (PoV fixed, no regression, tests ran without new failures), `validated_no_tests` (same, but no
     test command exists — stated in the report), or the first failing stage (`apply_failed`, `compile_error`, `link_error`, `still_crashes`,
     `regressed`, `tests_regressed`, `edit_mismatch`, `out_of_scope`, `refused`).
   - choice: the first round with a validated candidate stops; among validated, fewest changed lines wins. Nothing validated → the next
     round's context carries feedback for each failed candidate (stage, compiler output / new trace / failing tests, trimmed).
   - outcome: `validated | validated_no_tests | failed (<best stage reached>) | refused | oracle_unavailable | not_reproducible_by_oracle
     | out_of_time`.
2. Every candidate is persisted under the existing patches output location: diff, rationale, per-stage results and logs; an index file
   lists them with status.
3. The validated patch is submitted with the existing policy and format (unchanged thresholds); `validated_no_tests` follows the policy's
   rule for unverified tests (if the policy has none, it is submitted at the lower tier and the report says why).
4. Time: each round asks `can_start` (135) with its expected duration; the scheduler (144) decides which findings get patching time.
5. `[patch] <finding>: round <r> — <k> candidates: <statuses>; chosen <id> (<status>)` and the outcome line; all in the report.

## Tests (tests/test_patch_loop.py) — fake oracle with scripted stage results, fake candidates, fixture findings
- candidate validated in round 1 → chosen, persisted, submitted in the existing format; two validated → fewer lines wins.
- still crashing / regressed / tests regressed → each status recorded; round 2 receives the feedback text; validated in round 2.
- no tests → `validated_no_tests` with the report wording; oracle cannot reproduce baseline → `not_reproducible_by_oracle`, no LLM call.
- out of time → `out_of_time` without starting a round that cannot finish.
- tests/e2e passes.

## Acceptance
```
python -m pytest -q tests/test_patch_loop.py
```

## Do not touch
Submission thresholds and format; sidecar internals; crash_dedup._get_crash_signature.
