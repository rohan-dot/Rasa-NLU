# Task 162 — move the findings, patching and reporting phases out of the main module; remove dead code and settings; the main module becomes a short, readable entry

max_turns: 220
allow_test_removal: yes

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Last of the three moves (160, 161): group C — findings, reproduction, triage, submission, patching, reporting. Then the cleanup a
handoff needs: code nobody reaches is removed, duplicate implementations of a stage are collapsed into the one the pipeline uses,
deprecated settings stay accepted (warning) but their dead code paths go, and the main module ends as a short entry (target: under
~300 lines) that builds the context and the phase list.

## Precondition — check before editing
`tests/e2e` passes and the main flow is cut into `phase_*` functions (133). If not, call finish() with no edits.

## Study first
docs/ARCHITECTURE.md; MAP.md EXTRACTION PLAN group C and STRUCTURE (modules not on the run path, duplicate stages); for every removal
candidate prove it is unreachable: `grep -rn "<name>" src/ tests/ scripts/` and any launcher/compose/Docker file (`run` with grep over
the repo), plus dynamic references (string-based imports, getattr, entry points).

## Change
1. `src/core/phases/findings_and_patching.py` and `src/core/phases/reporting.py` — move group C; re-export names tests import, listed
   in finish().
2. **Dead code**: delete modules/functions proven unreachable (evidence per item in finish(): the greps you ran and their empty results);
   delete tests that test only deleted code (and nothing else) — each removed test listed with the deleted code it covered.
3. **Duplicates**: where two implementations of the same stage exist (MAP.md STRUCTURE), keep the one the pipeline calls, delete the
   other, point any caller to the survivor.
4. **Main module**: only argument parsing for the OSS-CRS entry, context construction, the phase list and the call to the runner.
5. docs/ARCHITECTURE.md: final module table and pipeline table; a "Removed in this release" list (module/function → reason).

## Tests
Full suite and tests/e2e pass (no golden regeneration). `tests/test_module_layout.py` extended: main module under the line target;
every phase importable from its module; no module in src/ that nothing imports (except entry points and the CLI — allowlist in the test).

## Acceptance
```
python -m pytest -q tests/test_module_layout.py tests/e2e
```

## Do not touch
Behaviour of anything reachable; log text; settings operators use (deprecated ones keep warning); the OSS-CRS entry's arguments;
crash_dedup._get_crash_signature; sidecar internals.
