# Task 190 — verify the whole tree one last time and write docs/HANDOFF.md: what discver is now, what is proven and how, what is not, and what the next owner should do first

max_turns: 160

## Writable
- docs/
- README.md

## Goal
The author is leaving. The person who inherits discver needs one honest page: the state of every capability with the evidence behind
it, what was verified in this campaign and what still needs a real run, the known limitations, the open problems in priority order,
and a first-week plan. Nothing in it may be claimed without a test name, a command output or a campaign verdict behind it.

## Study first
`../CAMPAIGN.md` (every verdict of this campaign and earlier ones: `grep -nE "^### |PASS|FAIL|NO_EDITS|INFRA_FAIL" ../CAMPAIGN.md | tail -200`);
docs/ARCHITECTURE.md, OPERATOR.md, TROUBLESHOOTING.md, EVALUATION.md, INSTALL.md, KB.md, SELFTEST.md as they exist; EVIDENCE.md
PATTERNS (which are now addressed, by which module and test, and which are not).

## Change
1. Run and record (paste outputs into finish()): `python -m pytest -q tests 2>&1 | tail -5`; `python -m pytest -q tests/e2e 2>&1 | tail -3`;
   `scripts/discver doctor --offline` (or the CLI equivalent); `scripts/discver selftest --no-llm --budget 2m` if the toolchains exist on this
   box, else the doctor line showing why not.
2. `docs/HANDOFF.md`:
   - **discver in one paragraph**, and what changed in this release (link the module table).
   - **Capability status** — table: capability · status (works / partial / missing) · evidence (test names, e2e, selftest, campaign
     verdict) · notes. Cover: each language's build, discovery, generation, fuzzing, crash parsing, patching; standalone and OSS-CRS modes;
     LLM layer; scheduler and targets; reproducer verification; oracle (sidecar and local); reports; doctor; selftest; KB; docs.
   - **Verified how** — what the fakes prove, what the e2e proves, what selftest proves, and what has NOT been proven on a real run since
     this campaign (be explicit: the first real runs are the remaining verification).
   - **Known limitations** and **open problems**, ranked (EVIDENCE.md patterns not addressed; FAIL/NO_EDITS tasks; partial capabilities).
   - **First week for the new owner**: doctor → selftest → a known target in standalone mode → the same through OSS-CRS → a benchmark
     slice; what to compare against (docs/EVALUATION.md); where to look when something fails (TROUBLESHOOTING.md).
   - **How to keep changing it**: DEVELOPER.md, AGENT.md, the campaign kit; the rule that every change keeps tests/e2e green.
   - **Contacts and access**: placeholders the author fills in (gateway, run hosts, benchmark owner, KB location).
3. README.md "For maintainers" points to HANDOFF.md.

## Tests
None new (docs task); the full suite must still pass.

## Acceptance
```
python -m pytest -q tests/e2e
```

## Do not touch
Code; other docs except links to HANDOFF.md.
