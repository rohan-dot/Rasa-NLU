# Task 145 — spend LLM effort where fuzzing is stuck: directed seeds for unreached targets, then a harness that enters closer, then boundary values for reached code — each step bounded and logged

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Task 143 makes targets and their reach explicit; task 144 queues work for them. This task is the work. For an unreached target the
run escalates through three steps, each bounded, logged and reported: directed seeds → a harness entering closer to the target →
(once reached, no crash yet) boundary values for the conditions that guard it. Every step degrades cleanly: a refused or failed LLM
call leaves 143's static dictionary in place and the next step on schedule.

## Precondition — check before editing
The target set and reach from task 143 exist (`output/targets.json`, `[targets]` code). If not, call finish() with no edits and say so.

## Study first
Task 143's targets/reach/dictionary code; the scheduler queue (144) if present; seed screening (142); the harness generators and the
boundary-harness path if present (`grep -rnE "boundary|generate_harness|harness-gen" src/`); the call graph API; the LLM client (132).

## Change
1. **Directed seeds** (target unreached after R rounds of dictionary fuzzing, default 2): one LLM request per target (site
   `directed_seeds`, schema: list of inputs as base64 or escaped strings) with, under 4 KB: the harness entry and input format, the
   call-graph path from entry to target with the branch conditions on it, the target's source (delta: the diff hunk). Outputs go through
   seed screening (142). `[targets] seeds <harness> → <target>: <k> generated, <m> kept`.
2. **Closer harness** (still unreached after M more rounds, default 3): one request through the existing generation path (the boundary
   path when the target sits behind an input boundary) for a harness whose entry is the nearest caller of the target that the call graph
   says is constructible; same build, probe, gate and reach checks as any generated harness.
   `[targets] harness for <target>: entry <caller> → <name> (<gate result>)`. At most one per target per run.
3. **Boundary values** (target reached, no crash after M rounds): for each comparison guarding or inside the target (delta: changed
   conditions first) add dictionary tokens N−1, N, N+1, 0, −1 and the type's max for numeric bounds; empty, one-byte and bound-length
   strings for length checks; then one request for inputs hitting those values in the input format.
   `[targets] boundary <target>: +<n> tokens, <k> seeds`.
4. **Bounds**: per-target cap on LLM calls (default 6); jobs come from the scheduler queue when 144 exists, otherwise from a simple
   per-round loop; the report gets per target: steps taken, reached (round), crashes.
5. Every non-ok LLM outcome → the client's fallback line; the step counts as attempted; the ladder continues.

## Tests (tests/test_directed_inputs.py) — fake LLM, fake reach probe, fake screening, fake generator; fixture targets with generic names
- unreached after R rounds → exactly one directed-seed request per target, containing the path conditions (and the diff hunk in delta
  mode); outputs passed to screening; the line.
- still unreached after M rounds → one closer-harness request, entry = nearest constructible caller; never a second.
- reached without crash → tokens for `if (len > 64)` include 63, 64, 65 and a 65-byte string; one boundary request.
- refusal at step 1 → step 2 still on schedule; dictionary untouched. Cap reached → no more requests for that target.
- no targets / 143 absent → no requests (golden on the request log).

## Acceptance
```
python -m pytest -q tests/test_directed_inputs.py
```

## Do not touch
The gate and static check; the non-target text of generator prompts (golden); seed screening internals (call them);
crash_dedup._get_crash_signature; sidecar internals.
