# Task 150 — reproducers: verified locally before any effort is spent, one published per signature, non-crash classes kept out of the crash path

max_turns: 170

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: in a benchmark, well under half of the raw submissions were verified; one project's variants produced every
unintended crash; candidates that never reproduced in a clean room consumed LLM triage and oracle runs first. Raw counts made the
run look better than it was and cost precision. Rules, for any language: (1) a candidate reproducer is re-run locally — twice, fresh
process, the run's harness binary and sanitizer options — before any LLM work, oracle call or publication; (2) at most one published
reproducer per crash signature (the smallest); (3) timeout / OOM / leak-only signatures stay in their own finding class (hang handling)
and are never published as crash reproducers; (4) the report shows raw → reproduced → flaky → duplicate → published per harness, so a
raw count is never the headline.

## Study first
Where candidate reproducers come from (fuzzer crashes, crashing seeds, LLM-generated inputs), where they are triaged, sent to the
oracle and published (`grep -rnE "\[submit|publish|run-pov|clean-room|SUBMIT_DIR" src/`); `crash_dedup._get_crash_signature` (use, do
not change); hang/timeout classification; the report model (134); docs/ARCHITECTURE.md.

## Change
1. **Local prevalidation first**: every candidate is run twice through the local harness (single-input mode, fresh process, the run's
   sanitizer options and timeout); signature via `_get_crash_signature`. 0 of 2 → `[repro] <id>: did not reproduce locally — dropped`
   (no LLM, no oracle, not published); 1 of 2 → `flaky`, ranked last; 2 of 2 → proceeds unchanged into triage/oracle/publication.
2. **Dedup before publishing**: a signature already published → counted `duplicate`, not published (if the submission interface can
   replace an entry, a strictly smaller reproducer replaces it; otherwise skip).
3. **Non-crash classes** (timeout, OOM, leak-only) → the hang/resource finding class; never published as crash reproducers; listed in the
   report with their own counts.
4. **Report**: per harness — candidates, reproduced, flaky, dropped, duplicates, published, non-crash; REPORT.md summary uses published
   and reproduced counts, never raw.

## Tests (tests/test_reproducer_prevalidation.py) — fake harness runner with scripted signatures, fake LLM, fake oracle
- 56 candidates: 30 non-reproducing, 20 reproducing in 3 families, 6 timeouts → exactly 3 published (smallest per family), 6 in the
  non-crash class, 30 dropped with zero LLM and zero oracle calls for them (assert the fakes' call counts).
- 1-of-2 → flaky, ranked after 2-of-2; duplicates counted; report counts and REPORT.md wording.
- tests/e2e passes (the fake engine reproduces deterministically).

## Acceptance
```
python -m pytest -q tests/test_reproducer_prevalidation.py
```

## Do not touch
crash_dedup._get_crash_signature; sidecar internals and oracle commands; the submission file format; non-LLM fuzzing budgets.
