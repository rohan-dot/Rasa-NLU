# Task 131 — one configuration registry: every setting defined once with its default and meaning; defaults are the intended behaviour; nothing must be set by hand

max_turns: 200

## Writable
- src/
- tests/
- docs/
- scripts/

## Goal
Settings are read ad hoc across the codebase (MAP.md CONFIG). Some defaults switch off capabilities discver is supposed to have,
so an operator has to know which variables to set — exactly the hand-tuning a system handed to other people cannot rely on.
Some settings are dead, some duplicated, none documented in one place. End state: one registry is the only reader of
configuration; every setting has a type, a default chosen for an unknown repository, a one-line description and the phase that
uses it; the effective configuration is printed at startup and can be printed on demand; the reference documentation is
generated from the registry so it cannot drift; settings operators already use keep working.

This task also seeds `docs/ARCHITECTURE.md` (the living structure document every later task updates).

## Study first
MAP.md CONFIG (every setting, ** marks, dead ones), ENTRY POINTS (CLI arguments of the OSS-CRS entry), STRUCTURE (where a new
package fits; import convention used by the main module). `grep -rnE "os\.environ|os\.getenv" src/ | wc -l` before you start.

## Change
1. **Location and conventions.** Create the package `src/core/` (if `src/core.py` already exists use `src/discver_core/`) with
   `config.py`. Create `docs/ARCHITECTURE.md` with: a "Conventions" section (new infrastructure lives in `src/core/`; import style
   as used by the main module; log lines are `[<tag>] <message>`; settings come from the registry; LLM calls go through the LLM
   client; tests use fakes; the e2e test in tests/e2e guards the whole run), and a "Modules" table (module · purpose ·
   owner phase) seeded from MAP.md STRUCTURE. Later tasks keep both current.
2. **Registry.** `Setting(name, env, cli, type, default, description, phase, choices=None, deprecated=None)`; one module-level
   registry holding EVERY setting from MAP.md CONFIG, plus the standard build-layout inputs the run reads (`OUT`, `SRC`, `WORK`
   and the like) registered as inputs. API: `get(name)`, `effective() -> {name: (value, source)}` with source
   default/env/cli/deprecated-alias, `apply_cli(namespace)`, `to_markdown()`. Typed parsing (bool accepts 1/0/true/false/yes/no/on/off;
   int; float; duration like `90s`, `15m`, `2h`; list comma-separated); a bad value fails at startup with the setting name and the
   accepted forms.
3. **Migrate every read.** Every `os.environ[...]`/`os.environ.get(...)`/`os.getenv(...)` of a configuration key in src/ goes
   through the registry. Passing an environment to a child process (`env=dict(os.environ, …)`) is not a read and stays.
4. **Defaults policy.** The default is the best behaviour for a repository discver has never seen. For every ** setting in MAP.md:
   flip it to the intended default (capabilities on; auto-detection where availability varies) unless the code documents a reason
   not to — list every flip with its reason in finish(). Settings that exist only to force something detection should decide
   (e.g. forcing harness compilation, forcing structured-output request fields) become `deprecated`: accepted, ignored or mapped,
   with one warning line naming the replacement. Dead settings are removed from the code and listed as deprecated no-ops.
5. **Startup line and printing.** At startup: `[config] <n> settings — non-default: <k=v, …>; deprecated in use: <…>; unknown
   DISCVER_* variables: <…>` (unknown ones are warned, never fatal). The main entry gains `--print-config` (prints the effective
   table: name, value, source, description; exit 0). Existing CLI arguments unchanged.
6. **Generated reference.** `docs/CONFIGURATION.md` is produced by `python3 scripts/gen_docs.py config` (create the script; it
   imports the registry and writes the file: one table per phase, columns setting · env · default · description). The test fails
   when the committed file differs from the generated one.

## Tests (tests/test_config_registry.py)
- parsing of each type, durations, bad values (message names the setting); precedence default < env < CLI.
- `effective()` sources; deprecated alias maps and warns once; unknown `DISCVER_*` variable warned, run continues.
- static check: no `os.environ`/`os.getenv` read of a string-literal key anywhere in src/ outside the registry module (parse with
  `ast`; allow building child environments).
- every setting has a non-empty description and a phase; CONFIGURATION.md is up to date.
- the e2e test (tests/e2e) still passes; if the startup `[config]` line changes the phase golden, regenerate with
  `UPDATE_GOLDEN=1` and say so in finish().

## Acceptance
```
python -m pytest -q tests/test_config_registry.py
```

## Do not touch
Names of environment variables and CLI arguments operators already use (they keep working); crash_dedup._get_crash_signature;
sidecar internals.
