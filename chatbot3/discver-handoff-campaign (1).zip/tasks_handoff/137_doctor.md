# Task 137 — `discver doctor`: one command that tells a new operator whether this box can run discver, per language, and exactly what to fix

max_turns: 160

## Writable
- src/
- tests/
- scripts/
- docs/ARCHITECTURE.md

## Goal
Every failed first run so far started with something the operator could not see: a toolchain missing for one language, a
gateway that rejects request fields, a knowledge base not mounted, a sidecar absent, too little disk. A coworker taking over needs
one command that checks all of it before spending hours. End state: `discver doctor` prints a table of checks with ok/warn/fail and
a concrete fix for each problem, `--json` for scripts, and an exit code (0 ok, 1 warnings, 2 failures). It reuses what exists: the
language adapters' capabilities, the tool manifest / `--check-tools` (MAP.md PACKAGING), the LLM client (132), the registry (131).

## Study first
MAP.md LANGUAGES, PACKAGING (tool manifest, setup script, `--check-tools`), CONFIG (KB location, model, gateway URL settings);
the CLI registry (136); the LLM client (132).

## Change
1. `discver doctor [--language L ...] [--offline] [--json]` registered in the CLI. Checks, each `ok | warn | fail` + detail + fix:
   - **toolchains per language**, from the adapters and the tool manifest (one source of truth — if both exist, the manifest
     wins and the adapters declare which manifest entries they need): compiler/runtime present and version (clang + libFuzzer runtime
     for C/C++; JDK, Maven/Gradle, Jazzer for JVM; Go; Rust + cargo-fuzz; Python + atheris), sanitizer runtimes; per language a
     summary line "<lang>: can build+fuzz | can fuzz prebuilt only | unavailable (<missing>)". Fold the existing `--check-tools` into
     this (keep the old flag working, printing the same table).
   - **static scanners** listed in the manifest: present or not (warn only).
   - **LLM** (skipped with `--offline`): gateway reachable; one tiny completion through the client (site `doctor`); backend detected;
     request fields rejected; latency; a refusal on the probe is reported as `warn: probe refused (<source>)`.
   - **knowledge base**: found where (search order), size, manifest/version if present (task 171 adds the manifest), readable.
   - **OSS-CRS sidecar**: environment present → reachable; absent → `info: standalone mode (local oracle)`.
   - **resources**: CPU count, memory, free disk in work/output dirs (warn under 20 GB, fail under 5 GB), writable dirs, `ulimit -n`.
   - **configuration**: unknown `DISCVER_*` variables, deprecated settings in use (from the registry).
2. Table output aligned; final line `doctor: <n> ok, <w> warnings, <f> failures`; `--json` prints the same as a list of objects.
3. docs/ARCHITECTURE.md: row for the doctor module.

## Tests (tests/test_doctor.py) — fake PATH dirs with stub executables printing versions, fake LLM server, temp KB dirs
- all tools present → ok per language; one missing → that language "unavailable (<tool>)" with a fix line naming the install step.
- `--offline` skips the LLM check; LLM down → fail with reason; rejected field reported; probe refused → warn.
- KB found/missing; disk thresholds (fake statvfs); exit codes 0/1/2; `--json` schema; old `--check-tools` still works.

## Acceptance
```
python -m pytest -q tests/test_doctor.py
```

## Do not touch
The tool manifest's existing entries (extend only); the OSS-CRS entry; crash_dedup._get_crash_signature; sidecar internals.
