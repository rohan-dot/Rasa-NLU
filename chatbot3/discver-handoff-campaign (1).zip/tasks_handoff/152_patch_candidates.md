# Task 152 — patch candidates for any language: context built from the crash itself, several diverse candidates as exact search/replace edits, scope rules, a unified diff per candidate

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Patching is the part of discver that has produced the least (EVIDENCE.md). This task rebuilds how candidate patches are made so it
does not depend on the language or on a fragile agent loop; task 153 rebuilds how they are validated and chosen. End state: for a
reproduced finding, a context builder assembles what a good engineer would look at (the crash class, the project frames of the stack,
the code around them, the callers, the reproducer); the LLM returns k diverse candidates as exact search/replace edits with a
rationale; edits are applied to a scratch copy and turned into a unified diff; edits outside the project or into harness/test code are
rejected by rule. Keep what works today (MAP.md patch pipeline: persistence, scope check, refusal handling, relative paths) — move it
behind the new structure instead of re-inventing it.

## Study first
MAP.md LLM CALL SITES and the patch pipeline (agent loop, read_source/apply_edit, prompt builder, parser, attempts, scope check,
persistence); each adapter's crash parser (stack frames, file:line); the call graph; the knowledge base's playbooks/exemplars if
present; the LLM client (132) with schemas; the oracle (151); docs/ARCHITECTURE.md.

## Change
1. `src/core/patch_context.py` — `build_patch_context(ctx, finding) -> PatchContext` (≤ 12 KB rendered): crash class and sanitizer /
   exception message; stack frames, with PROJECT frames (files inside the project tree, not harness, not dependency) marked; source
   windows ±40 lines around the top 3 project frames; the full body of the top project function; up to 2 callers of it (call graph);
   the reproducer summary (size, hex head, printable strings); the relevant knowledge-base playbook lines for the crash class when a KB is
   present; feedback from earlier attempts on this finding (filled by 153). Language-agnostic: frame parsing comes from the adapters.
2. `src/core/patch_candidates.py` — one LLM call per candidate (site `patch_candidate`, schema `{rationale, edits: [{file, search,
   replace}]}`), k = 3 by default (registry): candidate i is told the approaches of candidates 1..i−1 and asked for a different one.
   Edits apply as exact matches on the scratch copy: `search` must occur exactly once in `file`; a miss or multiple matches → one
   corrective request quoting the actual surrounding lines, then the candidate is `edit_mismatch`.
3. **Scope rules** (reuse the existing scope check): no edits outside the project tree, to harness sources, to tests, to build files
   unless the crash is a build-configuration issue; no deletion of the crashing function or of input validation; violations →
   candidate `out_of_scope` with the rule.
4. Each applied candidate → a unified diff (git format, paths relative to the project root) via difflib against the original;
   `PatchCandidate(id, finding, rationale, diff, files, status)`. Refused LLM call → outcome `refused` for that candidate (no rewording);
   the remaining candidates still run.
5. The old candidate-generation path is replaced by these two modules (the patch loop calls them); code that becomes unused is removed or
   left with a pointer for task 162.

## Tests (tests/test_patch_candidates.py) — fake LLM, fixture source trees (C and Java, generic names), recorded crash reports
- context: project frames marked, windows and function body present, harness/dependency frames excluded, size budget respected,
  KB lines included only when a KB fixture is present.
- three candidates, the 2nd and 3rd prompts name the earlier approaches; edits applied exactly; diff paths relative and applicable with
  `git apply --check` on a copy.
- `search` missing → one corrective request with the real lines → fixed; still missing → `edit_mismatch`.
- edits to a harness file or outside the tree → `out_of_scope`; refusal → `refused`, other candidates continue.
- tests/e2e passes.

## Acceptance
```
python -m pytest -q tests/test_patch_candidates.py
```

## Do not touch
The oracle and sidecar internals; crash_dedup._get_crash_signature; the submission format; submission thresholds.
