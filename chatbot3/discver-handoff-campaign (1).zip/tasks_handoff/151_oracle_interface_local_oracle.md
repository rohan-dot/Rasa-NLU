# Task 151 — an oracle interface with two implementations: the existing sidecar for OSS-CRS, and a local oracle so patches can be built, replayed and tested anywhere discver can build

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Patch validation needs three things: build the project with the patch, replay the reproducer, run the project's tests. Today only
the OSS-CRS sidecar does that (MAP.md ORACLE). Outside OSS-CRS — exactly how coworkers will point discver at repositories in the wild
— there is nothing, so the patch chain stops before it starts (EVIDENCE.md: a run whose PoV log stayed empty and which produced no
patch). End state: an `Oracle` interface the patch pipeline uses; `SidecarOracle` wraps today's sidecar calls unchanged;
`LocalOracle` does the same work with the local build-from-path machinery; selection is automatic and logged; before patching any
finding, the oracle must reproduce it on the unpatched build — a finding the oracle cannot reproduce is reported as such, not patched.

## Study first
MAP.md ORACLE (every sidecar/ContainerPatchBuilder call, how results are parsed); the build-from-path module (component builds,
recorded compile/link recipes from task 141); single-input reproduction in the fuzzer wrapper; how each build system runs its tests;
the context (133) and report (134); docs/ARCHITECTURE.md.

## Change
1. `src/core/oracle.py` — `Oracle` protocol: `name`; `available() -> (bool, reason)`; `build(patch: str | None) -> BuildResult(ok, kind,
   log_tail, out_dir)` with `kind` in `ok | apply_failed | compile_error | link_error | harness_not_produced | timeout | oracle_error`;
   `run_pov(harness, input_path, build) -> PovResult(crashed, signature, log_tail)`; `run_tests(build) -> TestResult(ran, passed,
   failed, failed_ids, command, log_tail, reason_if_not_ran)`. A patch is a unified diff (git format, paths relative to the project
   root) — the same format submissions use.
2. `SidecarOracle` — adapter around today's sidecar calls: same commands, same parsing; only the return types are mapped.
3. `LocalOracle` — per call: a scratch copy of the component source (hard-link copy when on the same filesystem, else a copy; one per
   candidate; cleaned up); `git apply --check` then `git apply` (fallback `patch -p1`), failure → `apply_failed` with the rejected hunk;
   rebuild with the recipe the run used for that component (same flags and sanitizers; time-bounded); `run_pov` = the rebuilt harness on
   the input in single-input mode with the run's sanitizer options, signature via `_get_crash_signature`; `run_tests` = the project's own
   tests, detected per build system — CMake/ctest when tests are registered, `make check`/`make test` when the target exists, Maven
   (offline when dependencies are cached), Gradle (offline), `go test ./...`, `cargo test`, `pytest` when a test dir exists — with a time
   limit; none detected → `ran=False, reason="no test command detected"`.
4. **Selection** `select_oracle(ctx)`: sidecar environment present and reachable → SidecarOracle; else a local build recipe exists →
   LocalOracle; else `NoOracle(reason)`. `[oracle] using <name> (<reason>)`; stored on the context and in the report.
5. **Baseline reproduction**: before patching a finding, `run_pov` on the unpatched build must crash with the finding's signature;
   otherwise the finding is marked `not_reproducible_by_oracle` with the oracle's output tail, and patching skips it with that reason.
   The baseline test run (unpatched) is cached per component so patched runs can be compared with it.

## Tests (tests/test_oracle.py) — fake build commands, the e2e fake engine as harness, fake test commands, fixture trees
- LocalOracle: clean patch → build ok → PoV replay of the fixed build no longer crashes (fake engine variant keyed on a patched file) →
  tests ran; bad hunk → `apply_failed` with the hunk; compile error → `compile_error` with tail; no test command → `ran=False` + reason.
- SidecarOracle: maps today's sidecar responses (recorded fixtures from existing tests) to the new types, same commands invoked.
- selection with/without sidecar env / recipe; baseline reproduction failure → `not_reproducible_by_oracle`.
- tests/e2e passes.

## Acceptance
```
python -m pytest -q tests/test_oracle.py
```

## Do not touch
Sidecar commands and their parsing (wrapped, not changed); crash_dedup._get_crash_signature; the submission format.
