# Task 132 — one LLM client for every call: backend-correct requests, one classified outcome per call, refusals final, structured output by validation, accounting per call site

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md shows the LLM layer costing findings in three ways: request fields that only a vLLM server accepts were sent to a
hosted model and rejected with HTTP 400 in every trial (one field was learned per run, another was rediscovered every trial);
refusals (`finish_reason=content_filter`) hit seed generation, triage, reproducer construction and patching, and nothing counted
them per site; there was no usage accounting at all. MAP.md LLM CALL SITES shows how many separate client implementations exist.
End state: one client module; every call site goes through it with a site name; a request carries only fields its backend accepts;
every call ends in one classified outcome; a refusal is final for that call and the site takes a declared fallback; structured
output works on any backend (prompt + validation + one format repair); tokens, latency and outcomes are counted per site and end
up in the run report.

## Study first
MAP.md LLM CALL SITES (every site, client, extras, parser, error/refusal handling) and CONFIG (model settings). EVIDENCE.md
PATTERNS for LLM errors (which parameters, how often, which sites refused). docs/ARCHITECTURE.md (conventions). The registry from
task 131 (register new settings there if it exists).

## Change
1. **Client** `src/core/llm.py` (or make the best existing client this module and remove the others):
   `complete(site, messages, *, schema=None, max_tokens=None, timeout=None, temperature=None) -> LLMResult` with `outcome`
   (`ok | refused | rejected_param | truncated | parse_error | http_error | timeout`), `text`, `data` (parsed + validated JSON when
   `schema` is given), `usage {in, out}`, `latency_s`, `model`, `finish_reason`, `refusal_source` (`model | gateway | unknown`).
2. **Backend-correct requests.** Backend = registry setting `llm_backend` (`auto | vllm | hosted`, default auto); auto → hosted when
   the model name contains a hosted family token (`claude`, `anthropic`, `gpt`, `o1`, `o3`, `gemini`), else vllm. vLLM-only fields
   (structured-decoding fields such as `guided_json`/`guided_regex`/`guided_choice`, `chat_template_kwargs`, and any other vLLM-only
   extra found in MAP.md) are attached only for vllm. Any 400 naming a request field as not permitted / unknown / unsupported →
   strip that field, retry once, remember it for the run, record it in `output/llm_capabilities.json`; ship
   `src/core/llm_capabilities_default.json` with the fields known to be rejected by hosted backends so a fresh container never pays
   the first 400. Startup line: `[llm] backend=<…> (<reason>) model=<…> — request extras: <list|none>`.
3. **Refusals are final.** `finish_reason` `content_filter` or a refusal stop reason (or an empty completion carrying one) →
   `refused`, returned immediately: no resend, no rewording. `refusal_source=gateway` when the response shape shows a proxy-side
   filter (an error body naming a guardrail/moderation/policy) rather than a model completion; else `model`; else `unknown`.
4. **Structured output on any backend.** With `schema`: the prompt carries the schema instruction; the reply's JSON (first object or
   fenced block) is validated with a small built-in validator (required keys, types, enums, nested objects/arrays — standard library
   only); on failure, ONE format-repair request quoting the validation error; still failing → `parse_error`. Refused calls are never
   "repaired".
5. **Retries** only for 429/5xx/connection errors/timeouts, with backoff, never past the run deadline when the context has one.
6. **Every call site migrated** (all of MAP.md LLM CALL SITES): `complete(site="<name>", …)`; each site handles every non-ok outcome
   with a declared fallback and one line `[llm] <site>: <outcome> — fallback: <what>` (seed generation → static seeds/dictionary
   only; triage → rule-based score from the finding class, no LLM verdict; harness generation → candidate skipped; patching →
   attempt outcome recorded, next finding; others as fits). Prompt text unchanged except the schema instruction where JSON was
   previously requested via vLLM-only fields. Remove the replaced client implementations.
7. **Accounting.** Per site: calls, each outcome, tokens in/out, latency; exposed as `llm_stats()` and written into health.json
   (`llm` block) and a REPORT.md table "LLM calls by site"; refusal rate over 10 % at a site is listed as a caveat in the report.
8. docs/ARCHITECTURE.md: the LLM client row and a short "LLM calls" section (sites, outcomes, fallbacks).

## Tests (tests/test_llm_client.py) — a fake HTTP server, no network
- payload gating per backend; auto detection; override; startup line.
- 400 naming a field → stripped, retried once, remembered, file written; default capabilities file honoured with no prior run;
  unrelated 400 → `http_error`, not learned.
- `content_filter` → `refused`, exactly one HTTP request; gateway-shaped refusal → `refusal_source=gateway`.
- schema: valid JSON → `data`; invalid → one repair request → ok; invalid twice → `parse_error`; fenced JSON accepted.
- 429 then 200 → ok after backoff; deadline respected.
- accounting per site; health/report block.
- static: no other module in src/ sends HTTP requests to a chat-completions endpoint (grep for `chat/completions`).
- golden: each migrated site's prompt text for a fixed input is byte-identical to before (apart from an added schema instruction,
  shown in the test as an explicit expected diff).
- tests/e2e still passes (its fake LLM is at the HTTP level).

## Acceptance
```
python -m pytest -q tests/test_llm_client.py
```

## Do not touch
Prompt content beyond the schema instruction; crash_dedup._get_crash_signature; sidecar internals.
