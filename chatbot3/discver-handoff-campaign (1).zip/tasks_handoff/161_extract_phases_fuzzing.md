# Task 161 — move the seed, fuzzing, health, hang, target and scheduling phases out of the main module, unchanged in behaviour

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
Second of three moves (see task 160): group B — seed generation and screening, dictionaries, fuzzing rounds, stats and health,
hang handling, target set and reach, the scheduler hook, strategy rounds.

## Precondition — check before editing
`tests/e2e` passes and the main flow is cut into `phase_*` functions (133). Task 160 may or may not have landed; either way do not
move group-A code. If the precondition fails, call finish() with no edits and say which part.

## Study first
docs/ARCHITECTURE.md; MAP.md EXTRACTION PLAN group B; tests that patch names in the main module.

## Change
1. `src/core/phases/fuzzing.py` (and `common.py` for shared helpers) — move group-B phase functions and the helpers only they use.
2. The main module imports them for the phase list; names imported by tests or other modules are re-exported with the compatibility
   comment and listed in finish().
3. No logic changes; imports fixed everywhere.
4. docs/ARCHITECTURE.md updated.

## Tests
Full suite and tests/e2e pass unchanged (no golden regeneration). Extend `tests/test_module_layout.py` for group B.

## Acceptance
```
python -m pytest -q tests/test_module_layout.py tests/e2e
```

## Do not touch
Behaviour; log text; fuzz argv; crash_dedup._get_crash_signature; sidecar internals.
