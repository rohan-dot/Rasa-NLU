# Task 181 — docs/OPERATOR.md and docs/TROUBLESHOOTING.md: how to run discver well, read what it produced, and fix what went wrong — written from real evidence

max_turns: 180

## Writable
- docs/
- tests/

## Goal
The people taking over will run discver on repositories nobody has tried before. They need two documents: an operator guide that
covers every way of running it and how to read the outputs, and a troubleshooting guide organised by SYMPTOM — the line they see in
the log or report — leading to the cause and the fix. EVIDENCE.md is the source for troubleshooting: every pattern there that an
operator could meet becomes an entry, written generally (mechanisms, not targets).

## Study first
docs/ARCHITECTURE.md; the CLI help texts; the registry (`--print-config`); the run-report model (what REPORT.md and health.json
contain); EVIDENCE.md PATTERNS and WHAT WORKED; MAP.md GAPS; log tags in src (`grep -rhoE "\[[a-z_-]+\]" src/ | sort | uniq -c | sort -rn`).

## Change
1. `docs/OPERATOR.md`:
   - before a run: install (link INSTALL.md), `doctor`, `selftest`, the knowledge base, LLM gateway settings, resources per language.
   - running: standalone (`discver run` options, choosing budgets, delta vs full, components in monorepos, `--no-patch`), inside OSS-CRS
     (what the operator sets and nothing else; outputs location; the KB mount), benchmark campaigns (outer timeout vs shutdown reserve,
     staged diffs, collecting outputs).
   - watching a run: the key log lines per phase (a table: phase → lines that show it is healthy → lines that show trouble).
   - reading the outputs: REPORT.md section by section; health.json fields that matter; report.json for scripts; patches folder; the
     "Why no patch" section; caveats and what each means for trust in the result.
   - costs and limits: LLM usage table, budgets, what discver does when the LLM refuses or is down, disk use.
   - safety: it builds and executes untrusted code — run it in a container or an isolated machine; never with credentials mounted.
2. `docs/TROUBLESHOOTING.md`: entries `### <symptom as seen>` → **What you see** (log/report line pattern) → **What it means** →
   **What discver already does about it** → **What to check / do**. At least one entry per EVIDENCE.md pattern an operator can meet
   (e.g. no harness-shaped executable; generated harness fails to compile or link; every fuzz child times out on its first input;
   hang/timeout storms; a harness marked WEAK/slow; refusals at a site; request fields rejected by the gateway; seeds unscreened;
   many raw reproducers but few verified; findings not reproducible by the oracle; no patch — follow the chain; run killed before
   final reports; KB not found; component cannot be built; empty sidecar logs), plus entries for doctor failures.
3. Both documents general: no target, project, harness or benchmark names.
4. `tests/test_docs_operator.py`: every `discver` command and option mentioned exists (CLI registry / argparse); every setting name
   mentioned exists in the registry; every log tag quoted exists in src; relative links resolve.

## Acceptance
```
python -m pytest -q tests/test_docs_operator.py
```

## Do not touch
Code (docs task); the operator's workflow.
