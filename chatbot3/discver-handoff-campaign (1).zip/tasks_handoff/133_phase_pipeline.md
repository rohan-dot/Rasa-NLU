# Task 133 — the run becomes an explicit pipeline of named phases over one shared context: isolated failures, timing, a phase list anyone can read

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
MAP.md MAIN ANATOMY: the whole run lives in one very large main module whose flow is implicit — state passes through locals and
globals, a failure in one stage can abort or silently skip the rest, and a new engineer cannot see the stages. End state: a
`Context` object carries everything the run shares; the run is an ordered list of `Phase`s executed by one runner that logs each
phase's start/end/outcome/duration, isolates failures (a non-critical phase failing does not end the run; a critical one ends it
with a stated reason; report phases always run), and records a phase table the report shows. This task does NOT move code to other
modules (task 160–162 do that): it cuts the existing main flow into phase functions in place.

## Precondition — check before editing
`python -m pytest -q tests/e2e` passes (task 110). If tests/e2e does not exist or does not pass, implement only Change 1–2 (runner
and context, with unit tests) and wire the existing main flow as ONE phase; say so in finish(). Do not restructure the main flow
without the end-to-end test guarding it.

## Study first
MAP.md MAIN ANATOMY (numbered phase list with file:line, cross-phase variables, globals) and EXTRACTION PLAN; docs/ARCHITECTURE.md.

## Change
1. `src/core/context.py` — `Context` dataclass: `config` (registry view), `run_id`, `mode` (`oss-crs | standalone`), `paths`
   (source, build output, work, output dirs), `target` (name, languages, components), `budget` (start, total, deadline — task 135
   fills the deadline), `llm` (client), `oracle` (None until task 151), `report` (the run-report object once task 134 lands; a dict
   until then), `state` (harnesses, corpora, findings, patches, targets — typed sub-objects or dicts, named after the cross-phase
   variables in MAP.md), `stop_requested` flag.
2. `src/core/pipeline.py` — `Phase(name, fn, critical=False, always=False)`; `PhaseResult(status: ok|skipped|failed|stopped,
   summary, metrics)`; `run_pipeline(ctx, phases)`: for each phase logs `[phase] <name> start` and
   `[phase] <name> <status> in <s>s — <summary>`; an exception in a non-critical phase → `failed` with the exception and a traceback
   in the log, run continues; in a critical phase → remaining non-`always` phases are `skipped (<critical phase> failed: <reason>)`;
   `always` phases (final reporting) run regardless; `ctx.stop_requested` → remaining non-`always` phases `stopped`. The phase table
   (name, status, seconds, summary) is stored on the context for the report.
3. **Cut the main flow into phases**, in the main module: each block of MAP.md's phase list becomes `def phase_<name>(ctx) -> PhaseResult`;
   locals that cross phase boundaries move onto `ctx.state`; globals that are really run state move onto the context (globals that
   are constants stay). The OSS-CRS entry builds the Context from its arguments and calls `run_pipeline` with the list. Behaviour
   is unchanged: same order, same work, same outputs; the only new log lines are the `[phase]` lines. Critical phases: those
   without which nothing later can work (e.g. build for the only component); everything else non-critical; final reporting `always`.
4. docs/ARCHITECTURE.md: a "Pipeline" section — table of phases in order: name · function · reads · writes · critical/always ·
   what it does in one line.

## Tests (tests/test_pipeline_runner.py)
- order; result recording; exception isolation (non-critical failure → later phases still run); critical failure → later
  non-always skipped with reason, always still runs; stop flag; timing recorded; log lines exact.
- context construction from the OSS-CRS arguments used by tests/e2e.
- tests/e2e passes; the phase golden changes only by the added `[phase]` tag — regenerate with `UPDATE_GOLDEN=1` and state the
  exact golden diff in finish().

## Acceptance
```
python -m pytest -q tests/test_pipeline_runner.py tests/e2e
```

## Do not touch
What each phase does (only where its code sits and how state is passed); the OSS-CRS entry's arguments; output locations;
crash_dedup._get_crash_signature; sidecar internals.
