# Task 142 — seed screening: batched in one engine process, bounded per input, crashing seeds become findings, and an unscreened seed never enters the corpus

max_turns: 170

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: in every trial of a JVM project, seeds were kept unscreened after the fixed screening budget expired, admitting slow
and hanging inputs into the starting corpus — and timeout/OOM noise followed. On a JVM target one process per seed spends the budget
on start-up. Rules, for every engine: screening runs inputs in batches inside one engine process with per-input time and memory
limits; it keeps inputs that ran cleanly and add coverage; an input that crashes the target is a finding routed to crash handling,
not a discarded seed; an input not screened when the budget ends is not added.

## Study first
`grep -rnE "screen|unscreened|retain" src/` (the screening function, how it runs seeds, its budget, the branch retaining unscreened
seeds); how each adapter builds engine argv (libFuzzer-family engines incl. Jazzer, atheris and cargo-fuzz share libFuzzer flags; Go
native fuzzing does not); the crash-handling entry point; registry settings for budgets.

## Change
1. **Batch screening with the engine's crash-resilient merge** for libFuzzer-family engines:
   `<harness> -merge=1 -merge_control_file=<f> -timeout=<t> -rss_limit_mb=<m> <kept_dir> <chunk_dir>` per chunk. Merge restarts the
   inner process when an input crashes or times out and continues; what it keeps ran cleanly and adds coverage. `t` = min(the harness's
   fuzzing timeout, 10 s); `m` = the harness's rss limit.
2. Inputs the inner process died on are identified from the merge control file (started without a completion record) and re-run
   individually once: crash → normal crash handling (`[seeds] <h>: seed <hash> crashes — routed to crash handling`); timeout/OOM →
   dropped and counted.
3. **Bounded**: chunks of up to 200 inputs, in parallel up to the CPU allowance; a per-chunk wall limit; a chunk over its limit is split
   once, then dropped. Screening budget = max(90 s, 0.5 s × seeds) capped at 5 % of the run budget (registry settings). At the end of the
   budget, unprocessed inputs are moved to `output/seeds_unscreened/<harness>/` and counted — never added. The retain-unscreened branch
   is removed.
4. Engines without merge: per-input runs with the same limits, in parallel, same budget, same never-retain rule.
5. `[seeds] <h>: screened <k>/<n> in <s>s — kept <m> (adds coverage), <c> crash → findings, <x> timeout/oom dropped, <q> unscreened (budget)`;
   the same counts in the report's harness entry.

## Tests (tests/test_seed_screening.py) — fake engine runner with scripted merge control files and per-input outcomes
- 200 seeds (120 non-novel, 70 novel, 1 crasher, 9 timeouts) → kept 70; crasher handed to the crash handler; 9 dropped; summary line.
- budget exhausted after two of four chunks → the rest in `seeds_unscreened/`, none in the corpus; counted.
- chunk over its wall limit → split once, then dropped; JVM-style harness → one process per chunk, never per seed (assert call count).
- engine without merge → per-input path, same rules.
- tests/e2e passes (the fake engine supports `-merge=1`; extend it if needed).

## Acceptance
```
python -m pytest -q tests/test_seed_screening.py
```

## Do not touch
Seed generation prompts; crash handling (only called); crash_dedup._get_crash_signature; sidecar internals.
