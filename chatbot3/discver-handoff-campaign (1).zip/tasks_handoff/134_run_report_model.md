# Task 134 — one run-report model: built up during the run, written atomically after every phase, rendered to report.json, health.json and a REPORT.md a stranger can read

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
MAP.md REPORTS: several writers produce overlapping files, mostly at the end of the run — EVIDENCE.md shows runs killed by an
outer timeout that left no health file at all, and reports from which nobody could tell why there was no patch or which harness
reached what. End state: one `RunReport` object that every phase updates; `report.json` is its complete serialization, `health.json`
keeps every key it has today (consumers depend on them) plus the new blocks, and `REPORT.md` reads top-down for someone who has
never seen discver: one summary table, then per component, harnesses, targets, findings, patches (and why not), LLM usage, caveats,
timeline. All three are rewritten atomically after every phase and on every new finding, so a run killed at any moment leaves a
complete, current report.

## Study first
MAP.md REPORTS (every writer, keys, when written); the current health.json/report.json keys (record them before changing anything:
they become a backward-compatibility test); docs/ARCHITECTURE.md; the runner from task 133 (hook point after each phase).

## Change
1. `src/core/run_report.py` — `RunReport` with sections: `run` (id, mode, target, start/end, budget, config summary — non-default
   settings only), `components` (path, language, build system, built?, reason), `harnesses` (name, origin provided|generated|boundary,
   component, build/probe/gate/reach status with reasons, execs, exec/s, coverage start→end, corpus, health verdict + reason, hang
   summary), `targets` (id, function, source delta|strategy, reached?, round), `findings` (id, class, signature, reproducer path,
   reproduced locally/oracle, flaky, duplicates, triage verdict + confidence + evidence, submitted tier), `patches` (per finding:
   candidates, status, stopping link + reason), `llm` (from the client's stats), `phases` (from the runner), `caveats` (strings),
   `errors` (every `[<module>] failed:` with count). Methods to update each section; `to_json()`, `to_health()`, `to_markdown()`.
2. `write(ctx, final=False)`: writes all three files via temp file + rename; non-final snapshots carry `"final": false, "as_of": <ts>`.
   Called by the runner after each phase and by whatever records a new finding; the last call (in the `always` report phase) sets
   `final: true`.
3. **One writer.** Every existing writer of these files becomes a call into the model (or is removed when the model covers it).
   `report_run_*.md` and other existing outputs keep their names and locations, generated from the model if they had different content.
4. **REPORT.md layout:** title + one-paragraph verdict ("N components, M built, K harnesses fuzzed, F findings verified, P patches
   validated"); summary table per component (language · built · harnesses · reach of targets · findings · patches); then the
   sections above; "Caveats" lists anything that limits trust (no input boundary found, reach unknown, a harness WEAK, refusals over
   10 % at a site, tests unavailable for patch validation, report not final).
5. `python3 -m <module> render <output_dir>` re-renders health.json/REPORT.md from report.json.
6. docs/ARCHITECTURE.md: row + a "Reports" section listing the three files and who writes what.

## Tests (tests/test_run_report.py)
- backward compatibility: every key present in health.json/report.json before this task (recorded from the e2e fixture output or
  existing tests) is still present with the same type.
- atomic write: an interrupted write (simulate by raising between temp write and rename) leaves the previous complete file.
- `final` flag; as_of; re-render equals original.
- REPORT.md contains the summary table and every section header; caveats appear when their condition holds.
- tests/e2e passes; artifact golden updated only for added keys/sections (`UPDATE_GOLDEN=1`, diff stated in finish()).

## Acceptance
```
python -m pytest -q tests/test_run_report.py
```

## Do not touch
Existing report keys and file locations (extend, never rename); the submission format; crash_dedup._get_crash_signature;
sidecar internals.
