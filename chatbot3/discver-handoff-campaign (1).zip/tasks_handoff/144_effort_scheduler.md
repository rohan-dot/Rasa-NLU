# Task 144 — an effort scheduler: each round, fuzz time and LLM work go where the run is making progress or where it is stuck on code that matters — decided from signals, logged, reported

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md shows effort going to the wrong places in four ways: harness groups fuzzing at full speed for hours on code that never
reached the targets; LLM generation continuing to produce inputs for a crash family already found (most raw reproducers duplicated
known signatures); hang storms eating the budget; LLM jobs at sites that were mostly refused. Today allocation is fixed or ad hoc
(MAP.md MAIN ANATOMY: the round loop). End state: one scheduler module decides, every round, (a) the share of fuzz time per harness
and (b) the ordered queue of LLM jobs, from observed signals; every decision is logged with its reason and summarized in the report;
if the scheduler fails, the previous allocation runs and the failure is logged.

## Study first
The fuzz-round loop and how it allocates time and LLM work today; health verdicts and stats parsing; findings and signatures;
the target set and reach (task 143); LLM stats per site (132); registry (131); report model (134); docs/ARCHITECTURE.md.
Look at how the reference CRSs in the ref roots schedule harnesses and LLM work (`grep -rniE "schedul|bandit|allocat|priority" <refs> --include=*.py | head`).

## Change
1. `src/core/scheduler.py` — pure, deterministic planning functions plus a small stateful `Scheduler` holding the signal history.
   **Signals per harness**: coverage growth over the last window, new targets reached, new distinct signatures, exec/s, health verdict,
   hang counts, generation failures. **Per target**: reached?, rounds unreached, LLM jobs spent. **Per LLM site**: recent refusal rate.
2. **Fuzz shares**: `weight = 1 + a·coverage_growth + b·(unreached targets reachable from this harness by the call graph) + c·recent_new_signature
   − d·saturation` (saturation = no new coverage and no new signature for T minutes); DEAD → 0; WEAK → floor only; every healthy harness
   keeps a floor (exploration, default 10 %); shares normalized. Coefficients and T are registry settings with sensible defaults.
3. **Crash families**: a family is saturated when ≥ 5 consecutive reproducers of a harness map to already-found signatures or no new
   signature appears for 20 min (scaled by budget/6 h). Then: LLM prompts for that harness carry an "already found — aim elsewhere" block
   with each found family's top three project frames (prompt byte-identical to today when no family is known); that harness's LLM share
   drops to the floor; the released share goes to harnesses with zero findings and to unreached targets.
4. **LLM job queue** (highest first, each type capped): triage/verification of new findings → patching of verified findings (when
   enabled) → directed work for unreached top-ranked targets (task 145) → boundary values for reached targets without a crash (145) →
   generic seeds for harnesses with flat coverage. Per-target cap (default 6 calls); a site whose recent refusal rate is above 50 % gets
   fewer jobs (logged; never reworded — static fallbacks continue).
5. **Integration**: the round loop asks `plan_round(ctx)` for `{fuzz_shares, llm_jobs}` and executes it; on exception →
   `[scheduler] failed: <error>` with traceback and the previous allocation for that round.
6. Logging: `[scheduler] round <n>: fuzz <h> <p>% (<reason>), …; llm: <counts by job type>; saturated: <families>`; the report gets a
   per-harness total (fuzz seconds, LLM jobs by type) and the list of redirects.

## Tests (tests/test_scheduler.py) — synthetic signal histories, fake loop
- coverage growth raises a share; saturation drops to the floor; DEAD excluded; WEAK at floor; shares sum to 1; deterministic.
- unreached targets reachable only from harness H → H boosted.
- 5 known-family reproducers → saturation, redirect line, exclusion block in the next prompt, share moved; no family → prompt golden.
- queue order and caps; refusal-heavy site deprioritized with a log line.
- scheduler raising → previous allocation used and the failure logged.
- tests/e2e passes (goldens updated for `[scheduler]` lines with `UPDATE_GOLDEN=1`, stated in finish()).

## Acceptance
```
python -m pytest -q tests/test_scheduler.py
```

## Do not touch
Engine argv except per-harness time; crash_dedup._get_crash_signature; sidecar internals.
