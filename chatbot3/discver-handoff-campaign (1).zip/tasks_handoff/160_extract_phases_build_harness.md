# Task 160 — move the setup, build and harness phases out of the main module into their own module, unchanged in behaviour

max_turns: 220

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
After task 133 the run is a list of phase functions — but they still live in one very large main module, which is the first thing a
new maintainer has to get past. This task and the next two move the phases into small modules by group, with no behaviour change;
afterwards the main module only builds the context and the phase list. This task: group A — setup, configuration, language and
component detection, build, harness discovery, input-boundary discovery, harness generation, repair, probe and gate.

## Precondition — check before editing
`tests/e2e` exists and passes, and the main flow is cut into `phase_*` functions (task 133 — see docs/ARCHITECTURE.md "Pipeline").
If either is not true, call finish() with no edits and say which.

## Study first
docs/ARCHITECTURE.md (Pipeline, Modules, Conventions); MAP.md EXTRACTION PLAN group A (functions, ranges, shared state, risks); every
test that patches names in the main module (`grep -rn "monkeypatch.setattr\|mock.patch" tests/ | grep -i main`) — moved names must stay
patchable where tests expect them.

## Change
1. Create `src/core/phases/__init__.py` and `src/core/phases/build_and_harness.py` (names per ARCHITECTURE.md conventions). Move the
   group-A phase functions and the helpers only they use; helpers shared with other groups move to the module of their main user or to
   `src/core/phases/common.py`.
2. The main module imports the moved phases for its phase list. Names that tests or other modules import from the main module are
   re-exported from it (explicit `from … import name` lines with a comment `# re-export for compatibility`) — every such name is listed
   in finish().
3. No logic changes: same statements, same order, same log lines. Imports fixed everywhere (`grep -rn` for each moved name).
4. docs/ARCHITECTURE.md: Pipeline table points to the new module; Modules table updated.

## Tests
No new behaviour, so no new feature tests: the full suite and tests/e2e must pass unchanged (no golden regeneration — if a golden
changes, something moved incorrectly). Add `tests/test_module_layout.py` asserting the main module no longer defines the group-A
phase functions and that each phase in the list is importable from its new module.

## Acceptance
```
python -m pytest -q tests/test_module_layout.py tests/e2e
```

## Do not touch
Behaviour; log text; the OSS-CRS entry; crash_dedup._get_crash_signature; sidecar internals.
