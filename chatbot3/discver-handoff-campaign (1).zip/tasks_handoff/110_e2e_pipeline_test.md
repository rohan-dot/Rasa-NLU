# Task 110 — an end-to-end test of the whole pipeline with fake engine, fake LLM and fake oracle: the safety net for every restructuring that follows

max_turns: 220

## Writable
- tests/
- src/      (only injection points that change no behaviour — see Rules)

## Goal
The tasks after this one restructure discver: one configuration registry, one LLM client, the main flow cut into phases, a
run-report model, a new patch pipeline, and finally the phases moved into their own modules. Unit tests alone cannot show that
the run still works end to end. This task builds the test that can: discver runs for real — its own entry point, its own
process — against tiny fixture targets whose "fuzzer" is a fake engine that behaves like libFuzzer/Jazzer, with an LLM gateway
and an oracle that are fakes on the outside of discver. The test pins down WHAT the run does today (phases reached, findings
recorded, artifacts written) so a later change that breaks the run fails here, in the campaign, not on the operator's box.

## Study first
- MAP.md: ENTRY POINTS (how a run starts and what it needs), MAIN ANATOMY (the phases), LLM CALL SITES (every prompt the run
  sends and the reply shape each parser accepts), ORACLE (what the run calls for PoV/patch validation and what happens without a
  sidecar), REPORTS (what is written where), TESTS (fakes that already exist — reuse them).
- How the fuzzer wrapper launches a harness (argv it passes: `-help=1` probe, `-runs`, `-max_total_time`, `-artifact_prefix`,
  `-dict`, `-fork`, `-merge=1`, corpus dirs) and how it parses output (stats lines, crash detection, artifact paths, sanitizer and
  Jazzer report parsing). The fake engine must satisfy exactly these parsers.

## Change
1. `tests/e2e/fakes/fake_engine.py` — a standalone executable Python script that behaves like a libFuzzer-family fuzz target
   (it contains the string `LLVMFuzzerTestOneInput` in a comment so harness discovery treats it as one):
   - `-help=1` → a short libFuzzer-style help text, exit 0.
   - fuzzing (corpus dirs given, no single input): prints `INFO:` lines and periodic stats lines in libFuzzer format
     (`#<n>\tNEW    cov: <c> ft: <f> corp: <k>/<b>b exec/s: <r> rss: <m>Mb`), honours `-max_total_time`/`-runs`; after
     `FAKE_ENGINE_CRASH_AFTER` seconds (default 3) it writes `<artifact_prefix>crash-<sha1>` whose content is the trigger bytes,
     prints a crash report and exits 1 — report style from `FAKE_ENGINE_STYLE`: `asan` (AddressSanitizer heap-buffer-overflow with a
     3-frame stack into the fixture's source file and line, SUMMARY line) or `jazzer` (`== Java Exception: java.lang.ArrayIndexOutOfBoundsException`
     with `at` frames into the fixture's Java class, and a `DEDUP_TOKEN` line) — whatever the existing parsers need.
   - single-input reproduction (file arguments, `-runs=N`): crashes with the same report when the file contains the trigger bytes,
     otherwise runs cleanly; `-merge=1` → copies inputs to the first dir and prints merge lines.
2. `tests/e2e/fakes/fake_llm.py` — an OpenAI-compatible `/v1/chat/completions` server on a free localhost port, started by a
   fixture. Responses are routed by regex on the prompt to a canned, well-formed reply for every call site listed in MAP.md (seed
   generation, triage, harness generation, strategy, patching, …), shaped exactly as that site's parser accepts. Unknown prompts get
   HTTP 500 with body `fake-llm: unrouted prompt` so an unmodelled site shows up as an error the run must survive. Every request is
   recorded (site guess, model, request extras, prompt length) to a JSON file the test can assert on.
3. Oracle: if the run calls an external sidecar/oracle command, provide `tests/e2e/fakes/` stand-ins on PATH that record calls and
   return scripted results; if the run has a local path without a sidecar, use that. State which in the test module docstring.
4. Fixtures `tests/e2e/fixtures/native/` and `tests/e2e/fixtures/jvm/`: a tiny source tree (the files and line numbers the fake
   crash report points to) and a prebuilt output layout (`$OUT`-style dir) holding the fake engine as the harness executable
   (copied and chmod +x at test time), a `.dict` and a small seed corpus — whatever the entry point expects for a prebuilt target.
5. `tests/e2e/test_pipeline_e2e.py` — for each fixture: temp dirs; environment pointing the LLM client at the fake server; run
   discver through its real entry point in a subprocess with the smallest budget and timeouts that still let every phase run
   (use existing settings; total wall time ≤ 120 s per fixture). Assert:
   (a) exit code 0; (b) the run's report files exist and parse; (c) the fake crash is recorded as a finding with a reproducer file
   whose bytes contain the trigger; (d) no `Traceback` in the log, or only the ones listed in the golden as known;
   (e) PHASE GOLDEN: the ordered list of distinct `[tag]` prefixes at first appearance in the log, normalized, equals
   `tests/e2e/golden/<fixture>.phases`; (f) ARTIFACT GOLDEN: the sorted top-level keys of health.json and report.json (and the
   `## ` headings of REPORT.md) equal `tests/e2e/golden/<fixture>.artifacts`; (g) the fake LLM saw at least one request per
   modelled site that the run reached.
   `UPDATE_GOLDEN=1 python -m pytest tests/e2e` rewrites the golden files; `tests/e2e/README.md` explains the fakes, the
   goldens, and when updating them is legitimate (a task that intentionally changes the phase sequence or report shape must say so).
6. Register a `e2e` pytest marker (tests/conftest.py); the e2e tests run in the normal suite (they are the gate), and each fixture
   is skipped with a clear reason only if the entry point genuinely needs something unavailable (e.g. docker) — then the test
   still runs every phase that does not, and the skip reason names the phase.

## Rules for src/ edits
Only an injection point that changes no behaviour when unused (e.g. honouring an already-existing env var in one more place, or
making a hard-coded binary path come from an existing setting). Each such edit is listed in finish() with why it was unavoidable.
No behaviour change, no new default.

## Tests
The e2e module itself, plus `tests/e2e/test_fakes.py`: the fake engine's help/fuzz/reproduce/merge modes produce output the
discver parsers accept (call the real parser functions on the fake's output); the fake LLM routes, records and returns 500 for
unknown prompts.

## Acceptance
```
python -m pytest -q tests/e2e
```

## Do not touch
Any behaviour of discver (this task only observes it); crash_dedup._get_crash_signature; sidecar internals.
