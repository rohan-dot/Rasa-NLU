# Task 182 — docs/ARCHITECTURE.md finished and docs/DEVELOPER.md written: how discver is built, why, and exactly how to extend it — plus AGENT.md for AI coding assistants working on the repo

max_turns: 200

## Writable
- docs/
- AGENT.md
- CLAUDE.md
- tests/

## Goal
A maintainer who inherits discver must be able to answer, from the docs alone: where does X happen, what does phase Y read and
write, how do I add a language, a phase, a setting, an LLM call site, an oracle — and how do I test it without a toolchain or an
LLM. ARCHITECTURE.md has been kept current by every task of this campaign; this task turns it into a complete design document and
writes the developer guide. Many coworkers will use AI coding assistants on this repo; AGENT.md gives those assistants the repo's
conventions and boundaries so they extend it the same way.

## Study first
docs/ARCHITECTURE.md as it stands; the code of every core module (`src/core/`), the phase modules, the adapters' interface; the test
layout (unit, tests/e2e and its fakes, selftest); the campaign kit layout (this campaign's tasks are evidence of how changes are made —
read ../tasks_handoff/*.md headings); the existing AGENT.md/CLAUDE.md (conflict markers included).

## Change
1. `docs/ARCHITECTURE.md` — complete it: system overview diagram; design principles (zero configuration, general by detection, fail
   loud, refusals final, reports always written); the Context; the pipeline table (phase · module · reads · writes · critical/always);
   core services (configuration registry, LLM client, oracle, run report, scheduler, targets, deadline); language adapters (interface,
   what each method must do, capability matrix pointer); the harness lifecycle (provided / generated / boundary → build → probe → gate →
   reach); fuzzing (engines, argv per language, health and hang handling, seeds and dictionaries); findings (classes, signatures,
   prevalidation, dedup, triage, submission); patching (context, candidates, oracle validation, choice, chain); the knowledge base;
   outputs on disk (tree); extension points. Every module mentioned exists (test).
2. `docs/DEVELOPER.md` — setup for development; running tests (unit, e2e, selftest; what the fakes are and how to extend them; the
   goldens and when regenerating them is legitimate); step-by-step recipes with the files to touch and the tests to add: add a language
   adapter; add a phase; add a setting; add an LLM call site (site name, schema, fallback, accounting); add an oracle; add a doctor check;
   add a selftest fixture; logging conventions; error-handling conventions; how to make a release (image, KB, version); how changes were
   made in this repo with the campaign kit (task files, writable paths, gate) and when to use it.
3. `AGENT.md` (and `CLAUDE.md` if the repo has one — same content or a pointer): for AI coding assistants: what discver is in five
   lines; where to read first; conventions (core package, registry, LLM client, report model, log tags, tests with fakes, e2e gate);
   hard boundaries (no target names in code/tests/docs, the signature function and sidecar internals untouched, OSS-CRS entry
   compatibility, refusals never re-sent reworded, no flags required for intended behaviour); how to run the checks before finishing.
   Resolve any conflict markers.
4. `tests/test_docs_architecture.py`: every module path and every function referenced in ARCHITECTURE.md/DEVELOPER.md exists; every
   phase in the pipeline table matches the runtime phase list; no conflict markers in any markdown in the repo root and docs/.

## Acceptance
```
python -m pytest -q tests/test_docs_architecture.py
```

## Do not touch
Code (docs task); test-target folders' own READMEs.
