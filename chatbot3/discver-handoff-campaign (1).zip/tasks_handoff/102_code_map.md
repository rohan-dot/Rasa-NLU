# Task 102 — map the current code for a restructuring: every module, the main flow, every setting, every LLM and oracle call, every doc, how it is packaged and launched

output: MAP.md
max_turns: 220

## Map
This task makes NO edits. Its finish() summary becomes MAP.md, handed to every later task as the CODE MAP. The tasks after it
restructure discver (a phase pipeline, one configuration registry, one LLM client, an oracle interface, a run-report model),
extend it, package it and document it — so this map must let an engineer who has never seen the code find anything by file:line.
- file:line for every claim; nothing from memory; `not determined — <what would answer it>` instead of guesses.
- EVIDENCE.md (from task 101, above as RUN EVIDENCE) holds what real runs did. Use it in GAPS; do not re-derive it.
- Ignore "make the edit" nudges. Size: under ~9,000 words. Tables and file:line, not prose; never paste code.

## Study first (root=repo; use `run` for wc/grep/find; read only the functions you need)
1. STRUCTURE: `find src -name '*.py' | xargs wc -l | sort -n` ; for each module: one-line purpose (from its docstring/top),
   who imports it (`grep -rn "import <mod>\|from <mod>" src/`), whether anything on the run path reaches it.
2. ENTRY POINTS: how a run starts in OSS-CRS mode (the command the CRS runs — look in oss-crs/, Docker*, compose*, *.sh,
   scripts/, setup/pyproject files via `run` since some dirs are hidden from list_files), its arguments and the environment it
   reads; any standalone entry (`--project-dir`, `local_build.py`); any other CLI.
3. MAIN ANATOMY: in the main module, every function with its line range and role; module-level state and globals; the call
   order of the run from start to final report, as a numbered list of phases with file:line of where each begins and ends;
   which local variables cross phase boundaries (they will become context fields).
4. EXTRACTION PLAN: group the phases into 3 modules — A: setup / language detection / build / harness discovery, boundary
   discovery and generation; B: seeds, fuzzing rounds, health, hangs, strategy/targets, effort allocation; C: findings,
   triage, submission, patching, reporting. For each group: functions and line ranges, shared state it reads/writes, imports it
   needs, and the risks of moving it (module-level side effects, monkeypatched names in tests: `grep -rn "monkeypatch.setattr\|mock.patch" tests/`).
5. CONFIG INVENTORY: `grep -rnE "os\.environ|os\.getenv|argparse|add_argument" src/` → table: name | default | type | file:line |
   effect | read where. Mark ** every setting whose DEFAULT disables a capability or must be set by the operator to get the
   intended behaviour, and every setting that is dead (read but unused, or never read).
6. LLM CALL SITES: every place an LLM is called — which client class/function, model selection, request extras
   (guided_json, chat_template_kwargs, …), purpose, prompt builder file:line, reply parser, what happens on error / refusal / bad
   JSON. Count the distinct client implementations.
7. ORACLE CALL SITES: every call into the sidecar / ContainerPatchBuilder / apply-patch-build / run-pov / run-test, and what
   standalone mode does instead (or that it has nothing).
8. REPORTS: every writer of health.json, REPORT.md, report.json, report_run_*.md and other outputs — file:line, keys/sections,
   when they are written (end only? incrementally?).
9. LANGUAGE ADAPTERS: `src/lang/*` — the interface, the registry, and a capability table language × (detect, build-from-path,
   harness discovery, entry ranking, boundary discovery, harness generation, compile/link of generated harnesses, reach probe,
   crash parsing, patch context, static scanners, seeds/dict) → supported (file:line) / partial / missing.
10. DOCS INVENTORY: every markdown file in the repo (`find . -name '*.md' -not -path './.git/*'`): path, size, topic, whether it
    is general or tied to specific targets/runs, outdated statements, conflict markers (`grep -rn '^<<<<<<<\|^>>>>>>>' --include=*.md .`).
11. PACKAGING: Dockerfiles, compose files, setup scripts, requirements/pyproject, tool manifests, KB location logic — what each
    does and who uses it (the operator's OSS-CRS path must keep working unchanged).
12. TESTS: `python -m pytest -q tests 2>&1 | tail -20` (baseline; fix nothing) — counts, failing test ids, slowest files
    (`python -m pytest -q tests --durations=15 2>&1 | tail -20`), the fakes that exist (fake LLM, fake fuzzer, fake sidecar,
    fixtures) with file:line, whether any test runs the whole pipeline.
13. CAMPAIGN STATE: `grep -nE "^### |: (PASS|FAIL|NO_EDITS|MAPPED)" ../CAMPAIGN.md | tail -120` — the verdict of every earlier task
    and, for each FAIL/NO_EDITS, whether its module exists anyway.

## Deliverable (finish summary — this exact structure)
```
STRUCTURE           module | lines | purpose | imported by | on run path?
ENTRY POINTS        OSS-CRS: command, args, env (file:line) | standalone: … | other CLIs: …
MAIN ANATOMY        function | lines | role ; globals ; numbered phase list with file:line ; cross-phase variables
EXTRACTION PLAN     group A/B/C: functions + ranges | shared state | imports | risks
CONFIG              name | default | type | file:line | effect | ** / dead
LLM CALL SITES      site | client | extras sent | purpose | prompt file:line | parser | on error | on refusal | on bad JSON ; client count
ORACLE              call sites ; standalone behaviour
REPORTS             writer | file | keys/sections | when written
LANGUAGES           capability table
DOCS                path | size | general/specific | problems
PACKAGING           file | purpose | used by
TESTS               baseline counts + failing ids ; slow files ; fakes available ; whole-pipeline test? (yes/no)
CAMPAIGN            task | verdict | module present?
GAPS (ranked by impact on findings and patches, then on maintainability)
n. <gap> — evidence: EVIDENCE.md pattern <n> / log line — code: file:line — fix shape in one line
```
