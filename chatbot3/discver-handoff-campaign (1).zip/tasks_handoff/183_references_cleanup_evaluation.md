# Task 183 — generated references (configuration, log lines), the evaluation history in one place, and every outdated or target-specific document cleaned up — guarded by consistency tests

max_turns: 200
allow_test_removal: yes

## Writable
- docs/
- scripts/
- tests/
- README.md
- *.md

## Goal
Docs drift unless they are generated or tested. End state: configuration and log-line references are generated from the code; the
history of real runs and benchmarks lives in ONE document (the only place target names may appear); every other markdown file in the
repo is either current and general, merged into the new docs, or deleted; tests fail when docs and code disagree.

## Study first
MAP.md DOCS (every markdown file, which are target-specific, outdated, conflicted); the docs generator (`scripts/gen_docs.py`);
the registry; log tags in src; EVIDENCE.md (RUNS, BENCHMARK, PATTERNS, WHAT WORKED); docs/ as it stands.

## Change
1. **Configuration reference**: regenerate `docs/CONFIGURATION.md` from the registry (`gen_docs.py config`).
2. **Log reference**: `gen_docs.py logs` scans src for log lines with a `[tag]` prefix (string literals and f-strings) and writes
   `docs/LOG_REFERENCE.md`: tag · emitted by (modules) · meaning · typical lines · what to do when it signals trouble; meanings live in
   `docs/log_tags.json` (curated, one entry per tag — write them from the code). A tag in src without an entry fails the test.
3. **Evaluation history**: `docs/EVALUATION.md` from EVIDENCE.md — per run/benchmark: date, target, mode, budget, results (findings,
   verified, patches), what it revealed, what changed in discver because of it; a "Targets" table listing every target name used. This
   is the only document allowed to name targets.
4. **Cleanup** (only discver's own documentation — repo root, docs/, src/; never READMEs inside test-target or fixture folders): for
   every markdown file in MAP.md DOCS → keep (current and general), merge (move what is still true into the right new doc, then delete),
   or delete (obsolete or target-specific; anything worth keeping about a run goes to EVALUATION.md). Fix conflict markers. List every
   file with its fate in finish(). Tests that only checked deleted docs are removed with them (listed).
5. `docs/README.md`: an index of all docs with one line each.
6. `tests/test_docs_consistency.py`: every registry setting appears in CONFIGURATION.md and CONFIGURATION.md is current; every log tag in
   src has an entry and LOG_REFERENCE.md is current; every relative link in every doc resolves; every `src/...` path mentioned exists;
   no conflict markers; NO document except EVALUATION.md contains any name from EVALUATION.md's Targets table (the test reads that
   table, so no name is hard-coded in tests).

## Acceptance
```
python -m pytest -q tests/test_docs_consistency.py
```

## Do not touch
Code; READMEs of test-target and fixture folders; the operator's workflow.
