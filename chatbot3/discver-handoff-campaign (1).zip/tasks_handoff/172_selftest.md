# Task 172 — `discver selftest`: tiny bundled projects in each language with a known bug, run end to end with the real toolchains, so anyone can prove an install works in minutes

max_turns: 220

## Writable
- selftest/
- src/
- tests/
- scripts/
- docs/

## Goal
The unit and e2e tests use fakes on purpose; they cannot show that a real box with real toolchains finds and patches a real bug. A
coworker needs one command that does: build a small project, find its planted bug, reproduce it, and (with an LLM available) produce
a validated patch — per language, in minutes, with a clear table at the end. This is also the first thing to run after any change.

## Study first
The CLI (136), doctor (137), toolchain manifest (170), build-from-path builders (what project layouts they accept per language), the
local oracle (151), the patch loop (153); docs/ARCHITECTURE.md.

## Change
1. `selftest/<lang>/` — for C (CMake library + libFuzzer harness), C++ (CMake, a small span-based packet parser), Java (Maven +
   Jazzer harness), Go (native fuzz test), Rust (cargo-fuzz target), Python (atheris harness): each a minimal project (≤ ~80 lines of
   code) in exactly the layout the builders accept, with ONE planted, documented memory-safety or input-validation bug reachable through
   the harness behind a short magic prefix (out-of-bounds read on a length field, missing index check, division by a parsed zero, a slice
   past its end), a seed corpus and a dictionary containing the prefix so the bug is found within seconds, and the project's own tiny unit
   test (so patch validation runs tests). `selftest/README.md` lists each bug (file, line, class) and the expected fix.
2. `discver selftest [--language L …] [--budget 3m] [--no-llm] [--keep]`: runs `doctor --offline` for the selected languages, skips
   languages whose toolchain is unavailable (reason shown), then for each remaining fixture runs `discver run --repo selftest/<lang>` in a
   temp output dir with the small budget and reports per language: built · harness found · crash found · reproduced by oracle · patch
   validated (skipped with `--no-llm` or when the LLM check fails) · minutes. Exit code 0 when every non-skipped language reached
   "reproduced" (and "patch validated" when the LLM was used), else 1.
3. The test suite must not need the toolchains: `tests/test_selftest.py` covers the orchestration with fakes (fake doctor results, fake
   `run` outcomes) and checks each fixture's structure (files present, harness marker, dictionary contains the prefix). A real-toolchain
   smoke test is marked and skipped automatically when the toolchain is absent.
4. `docs/SELFTEST.md`: what it proves, how to read the table, what each failure stage usually means.

## Acceptance
```
python -m pytest -q tests/test_selftest.py
```

## Do not touch
Build-from-path detection rules (the fixtures follow them); crash_dedup._get_crash_signature; sidecar internals.
