# Task 171 — the knowledge base: small, reproducible, self-describing, found automatically — no repository clones or git history shipped with it

max_turns: 170

## Writable
- src/
- tests/
- scripts/
- docs/

## Goal
The knowledge base (KB) that grounds strategy and triage is built from public vulnerability datasets (OSV advisories for fuzzing
findings, fuzzing project metadata, and similar). The shipped artifact turned out large because the source clones — thousands of
advisory YAML files and their `.git` pack files — travelled with it, and reviewers asked whether those packed repositories were needed
or whether pinned references would do. They are not needed at runtime: discver reads only the built KB files. End state: the KB build
reads plain source trees (no git required), writes only the KB files plus a MANIFEST that pins each source by URL and commit; a fetch
script recreates the sources from the manifest; discver finds the KB automatically, checks its version, and reports what it loaded.

## Study first
The KB builder and retrieval (`grep -rn "build_kb\|recipes.jsonl\|cwe_playbooks\|index.json\|DISCVER_KB\|/opt/discver/kb" src/`); how
the KB is located at runtime; the registry (131); the CLI (136); docs/ARCHITECTURE.md.

## Change
1. **Build**: `discver kb build --source <name>=<dir> … --out <kb_dir>` (wrapping the existing builder): works on plain directory trees;
   never copies source files or `.git` into the KB; writes `MANIFEST.json`: schema version, discver version, built_at, for each source
   `{name, url, commit}` (read from the source tree's git metadata when present, else from `--pin <name>=<url>@<commit>`), file counts,
   record counts per file, total size, sha256 per KB file.
2. **Fetch**: `scripts/fetch_kb_sources.sh <MANIFEST.json> <dest>` — shallow-fetches each source at its pinned commit (`git init`,
   `git fetch --depth 1 <url> <commit>`, checkout), so the KB can be rebuilt anywhere without shipping clones.
3. **Info / verify**: `discver kb info [<kb_dir>]` (manifest summary, sizes, sources), `discver kb verify` (hashes, schema version
   compatible with this discver).
4. **Runtime discovery** in order: the registry setting (existing env var keeps working) → the standard install path used by the
   operator's image → `<repo>/kb` → the user data dir. Startup line: `[kb] <path>: <n> records, schema <v>, built <date>, sources: <names@short-commits>`
   or `[kb] none found (searched: <paths>) — strategy and triage run without historical grounding` (a report caveat). An incompatible
   schema → warning and the KB is not used.
5. `docs/KB.md`: what the KB contains and does not (no vulnerable code, no repositories — references by advisory id and fix commit),
   size, how to build, ship (the KB folder only), update, and pin; why git history is not needed.

## Tests (tests/test_kb_packaging.py) — tiny fixture source trees (with and without .git metadata)
- build writes KB files + MANIFEST with pins, counts and hashes; no `.git`, no source copies in the output (walk the dir).
- pins from git metadata vs `--pin`; verify detects a modified file; incompatible schema refused at runtime with the warning.
- discovery order and the startup lines; existing env var still honoured.
- fetch script: `--dry-run` prints the git commands for each pinned source.

## Acceptance
```
python -m pytest -q tests/test_kb_packaging.py
```

## Do not touch
KB record formats consumed by retrieval (extend only); the operator's KB mount path; crash_dedup._get_crash_signature.
