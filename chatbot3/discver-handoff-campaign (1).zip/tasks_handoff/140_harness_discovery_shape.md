# Task 140 — harness discovery: only harness-shaped executables are candidates, in every language; never fall back to "every executable"

max_turns: 150

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: when the libFuzzer probe matched none of the executables in a build tree, discovery used all of them unfiltered —
git hooks, documentation helpers and utility scripts were treated as harnesses in every trial of one benchmark project. Noise in
the harness list wastes budget, pollutes the report and hides the real problem (no harness was found). Rule, for every language:
a file is a candidate only if it is harness-shaped by the markers the OSS-Fuzz infrastructure itself uses, or the project/CRS
declares it; when nothing qualifies, discover says so once and continues with the requested/provided harness.

## Study first
MAP.md / docs/ARCHITECTURE.md for the discovery function and the `-help=1` probe; the branch that admits all executables when the
probe matches nothing (`grep -rnE "harness-discovery|-help=1|X_OK|os\.access|st_mode" src/`); how the requested harness and
per-component output dirs enter discovery; each language adapter's fuzz-target notion.

## Change
1. **Candidates**: executable regular files in the build output dir(s) (and per-component output dirs), top level plus one level
   down, never under `.git/`, `doc/`, `docs/`, `man/`, source trees or test-data dirs, that satisfy one marker: (a) contain the bytes
   `LLVMFuzzerTestOneInput` (native targets carry the symbol, JVM/Python launcher scripts carry the marker comment); (b) a JVM launcher
   script referencing both the Jazzer driver and `--target_class`; (c) the language adapter's own fuzz-target rule (cargo-fuzz target,
   atheris launcher, Go fuzz binary); (d) a name declared by the project or CRS (requested harness, provided-harness list, project
   metadata). Always excluded: engine/driver binaries and runtime files (Jazzer driver and agent jar, `llvm-symbolizer`, `*.jar`,
   `*.so`, `*.a`), `*.sample`, `*.dict`, `*.options`, `*_seed_corpus.zip`.
2. The probe runs on candidates only; a failed probe skips the candidate with its reason (never "fuzz it anyway").
3. Nothing harness-shaped → one line, run continues:
   `[harness-discovery] no harness-shaped executable in <dirs> (<n> rejected: git-hook ×a, no-marker ×b, docs ×c, driver ×d) — using provided/requested harness(es) only`;
   the report gets a caveat. The all-executables fallback is removed.
4. The requested harness is always kept when it exists, even without a marker, with a warning line.
5. Summary line: `[harness-discovery] <n> executables, <k> harness-shaped: [<names>]`; per-file reasons at debug level; the
   report's harness section shows origin and discovery reason.

## Tests (tests/test_harness_discovery_shape.py) — fixture output dirs (generic names), fake probe
- native layout: one marked fuzzer, a data file, a dict, an executable `.git/hooks/pre-commit.sample` → exactly the fuzzer.
- JVM layout: one launcher (marker + driver + `--target_class`), the driver binary (contains the marker string), the agent jar,
  executable `docs/build.sh` and `utils/run.sh` → exactly the launcher.
- per-component subdirectories found one level down; nothing qualifying → the line, requested harness kept, run continues;
  unmarked requested harness → kept with warning; failed probe → skipped with reason.
- tests/e2e passes (its fake engine carries the marker).

## Acceptance
```
python -m pytest -q tests/test_harness_discovery_shape.py
```

## Do not touch
Provided-harness compilation; the gate and static check; crash_dedup._get_crash_signature; sidecar internals.
