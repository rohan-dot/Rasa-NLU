# Task 136 — one command for people: `discver run --repo <git-url|path>` takes any repository from clone to report, through the same pipeline as OSS-CRS mode

max_turns: 200

## Writable
- src/
- tests/
- scripts/
- docs/ARCHITECTURE.md

## Goal
Today discver runs in two ways that share little: inside OSS-CRS (the operator's workflow, which must not change) and a partial
standalone path (MAP.md ENTRY POINTS). A coworker who wants to point discver at a repository — a git URL, a monorepo with
submodules, a local checkout, a diff to focus on — has no single, documented command. End state: a `discver` command with
subcommands; `discver run` clones or takes a path, builds every supported component (build-from-path: old task 68, re-run in this
campaign as 128 if it had not landed — see MAP.md), and runs
the SAME pipeline as OSS-CRS mode in `standalone` mode, writing the same reports into an output folder of its own. Other
subcommands are added by later tasks into the same registry (`doctor` 137, `kb` 171, `selftest` 172).

## Study first
MAP.md ENTRY POINTS, CONFIG, PACKAGING (is there a pyproject/setup with console scripts? how is the package imported?); the
build-from-path module (`grep -rn "def .*build\|components.json\|--project-dir\|--check-tools" src/`); the pipeline (133) and
context; docs/ARCHITECTURE.md.

## Change
1. `src/cli.py` (or under `src/core/` per ARCHITECTURE.md conventions) — subcommand registry (`register(name, help, add_args, run)`),
   `discver --version`, `discver <cmd> --help`. Launcher `scripts/discver` (bash: resolves its own location, runs the CLI module
   with the right Python path; executable). If the repo has packaging metadata, add a console entry point there too.
2. `discver run`:
   - target: `--repo <git-url|path>` (required); `--ref <branch|tag|commit>`; git URLs are cloned shallow with submodules
     (`git clone --depth 1 --recurse-submodules --shallow-submodules`, then checkout of `--ref` if given) into `<out>/src/`; a failed
     clone says why (network, auth, ref) in one line.
   - focus: `--diff <file>` (delta mode with that diff) or `--base-ref <ref>` (diff computed with git between base and head;
     requires enough history — fetch it when shallow); none → full mode.
   - `--budget <duration>` (default from the registry), `--out <dir>` (default `./discver-out/<repo-name>-<timestamp>`),
     `--component <path>` (repeatable; default all supported), `--language <lang>`, `--no-patch`, `--model <name>`.
   - flow: resolve source → build-from-path into `<out>/build/` (per component) → Context with `mode=standalone`, paths pointing
     into `<out>` → `run_pipeline` with the same phase list as OSS-CRS mode → print the location of REPORT.md and the one-line
     verdict. Phases that need an OSS-CRS sidecar use whatever standalone fallback exists (task 151 adds a local oracle); none →
     the phase records `unavailable in standalone mode: <reason>` (never a crash).
   - if build-from-path does not exist in this tree: `--prebuilt <dir>` (an `$OUT`-style folder) plus `--repo <path>` is supported
     and `run` without it says build-from-path is unavailable.
3. `discver config [--markdown]` — prints the effective configuration (registry from 131).
4. `discver report <output_dir>` — re-renders REPORT.md/health.json from report.json (134).
5. The OSS-CRS entry is unchanged and calls the same pipeline; both entries share one function that builds the phase list.
6. docs/ARCHITECTURE.md: "Entry points" section (OSS-CRS entry, `discver` CLI, how both reach `run_pipeline`).

## Tests (tests/test_cli.py) — fakes for git, build and pipeline
- parsing of every option, duration formats, defaults; `--help` for each subcommand exits 0.
- git URL → fake clone called with shallow+submodule flags and the ref; path → no clone; clone failure → one-line reason, exit 2.
- `--base-ref` → diff computed via (fake) git; `--diff` → delta mode in the context.
- standalone flow calls build-from-path then `run_pipeline` with `mode=standalone` and the phase list identical to OSS-CRS mode.
- `scripts/discver --version` runs (subprocess).
- tests/e2e passes.

## Acceptance
```
python -m pytest -q tests/test_cli.py
```

## Do not touch
The OSS-CRS entry's arguments and behaviour; output locations in OSS-CRS mode; crash_dedup._get_crash_signature; sidecar internals.
