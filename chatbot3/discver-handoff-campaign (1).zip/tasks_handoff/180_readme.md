# Task 180 — README.md for people who have never seen discver: what it is, what it can do per language, how to install, verify and run it on any repository, and where to go next

max_turns: 160

## Writable
- README.md
- docs/
- scripts/
- tests/

## Goal
MAP.md DOCS: the existing README and docs describe particular runs and targets and are partly outdated. The README is the first
thing a coworker reads; it must describe the system as it now is, for repositories in the wild, accurately — every command shown
must exist, every capability claimed must be true of the code, and nothing may be tied to a specific target. Depth over length: a
precise, scannable README that links to the detailed docs.

## Study first
docs/ARCHITECTURE.md (current structure, pipeline, entry points); the CLI (`scripts/discver --help` and each subcommand's `--help`);
the registry (`--print-config`); language adapters' capabilities; doctor, selftest, KB and install docs if they exist; EVIDENCE.md
WHAT WORKED and PATTERNS (to state limitations honestly). Read the current README fully before replacing it.

## Change
1. `README.md`, in this order:
   - **What discver is** — two short paragraphs: an automated vulnerability discovery, triage and patching system for source
     repositories; what goes in (a repository, optionally a diff) and what comes out (verified findings with reproducers, validated
     patches, a report).
   - **How it works** — the pipeline in one diagram (mermaid flowchart or ASCII) and one sentence per phase, matching the phase list.
   - **Languages and capabilities** — a table generated from the adapters between `<!-- BEGIN capabilities -->` and
     `<!-- END capabilities -->` by `python3 scripts/gen_docs.py capabilities` (extend the docs generator from task 131; create it if missing).
   - **Quick start** — install (container or setup script, linking docs/INSTALL.md), `discver doctor`, `discver selftest`,
     `discver run --repo https://github.com/<org>/<repo>`; where the report appears and how to read its first table.
   - **Modes** — standalone (`discver run`), inside OSS-CRS (unchanged operator workflow; link to docs/OPERATOR.md), benchmark runs
     (diffs, budgets, the shutdown reserve).
   - **Outputs** — the output folder tree and what each file is for.
   - **Configuration** — zero-configuration principle; how to see and change settings; link to docs/CONFIGURATION.md.
   - **LLM** — what discver uses the model for, which backends work, how refusals and rejected request fields are handled, where usage
     is reported.
   - **Limitations** — honest, general statements drawn from EVIDENCE.md and the code (e.g. languages with partial support, what needs
     a buildable project, that it runs untrusted code and belongs in an isolated environment).
   - **Documentation map** — table linking every doc in docs/ with one line each.
   - **For maintainers** — pointer to docs/DEVELOPER.md and docs/HANDOFF.md.
2. No target, project, harness or benchmark names; examples use placeholders.
3. `tests/test_readme.py`: every `discver <subcommand>` shown in README exists in the CLI registry; every relative link resolves; the
   capabilities block equals the generator's output; no conflict markers.

## Acceptance
```
python -m pytest -q tests/test_readme.py
```

## Do not touch
Code behaviour (docs task: src/ is not writable); the operator's workflow.
