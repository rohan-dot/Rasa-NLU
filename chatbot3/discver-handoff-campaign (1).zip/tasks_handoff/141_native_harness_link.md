# Task 141 — generated native harnesses link exactly like the project's own fuzz targets; a missing symbol is resolved by search, never by a hard-coded library list

max_turns: 170

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: on a C project, generated exploration harnesses failed to link because compression-library symbols were missing from
the generated link command; other generated sources had syntax errors. The project's own fuzzers linked fine — the generator simply
did not know how the project links. Every LLM-proposed exploration path that never compiles is wasted effort. Rule, for C/C++ (and
any language whose adapter links native code): the link recipe for a generated harness comes from how the project links its own fuzz
targets; when that is missing or incomplete, undefined symbols are resolved by searching the libraries present on the box.

## Precondition — check before editing
Where generated C/C++ harnesses are compiled and linked today (`grep -rnE "LIB_FUZZING_ENGINE|-fsanitize=fuzzer|link_harness|undefined reference" src/`).
Extend that path (the build-from-path link step if it exists); never add a second link path.

## Change
1. **Recipe from the project**, in order: (a) when discver built the component itself: run the build with `CC`/`CXX` pointing at a
   small recording wrapper (appends `{argv, cwd}` as a JSON line to `<work>/compile_log.jsonl`, then execs the real compiler) and take
   the command that produced a provided fuzz target (`-o <…>/<target>`); (b) `compile_commands.json`; (c) the project's build script:
   the command producing a provided fuzz target — its archives, `-l`/`-l:` libraries, `-L` dirs, `-Wl,` flags, include dirs, defines;
   (d) `readelf -d` of a provided fuzz target → needed shared libraries. Line: `[harness-link] <name>: recipe from <source> (<k> libs)`.
2. **Resolver**: on `undefined reference to '<sym>'` (or the lld equivalent), look the symbols up in an index of defined globals built
   once per run (`nm -g --defined-only` over static archives in the build tree and the standard library dirs; `nm -D --defined-only`
   over shared libraries there); add the providers; relink; at most two rounds.
   `[harness-link] <name>: resolved <k> symbols → +<libs>`; unresolved ones named in the skip line.
3. **Routing**: link errors go to the resolver, never to the LLM repair pass; compile (syntax) errors go to the existing repair pass with
   the compiler output; still failing → `harness-gen: <name>: compile failed — skipped (<tail>)`; an unbuilt harness is never fuzzed.
4. The final compile and link command of every generated native harness is logged at info and stored in the report's harness entry.

## Tests (tests/test_native_harness_link.py) — fake compiler, fake nm/readelf, fixture trees with generic names
- a build script whose provided target links a project archive plus `-l:libz.a -l:liblzma.a -l:libbz2.a -l:libzstd.a` → the generated
  harness's link command contains the archive and all four; `compile_commands.json` preferred over the script; recorded log preferred
  over both.
- no recipe; fake linker fails on two symbols; fake index maps them to two archives → relinked, resolver line; an unknown symbol → two
  rounds, skip line naming it, fuzzer never called.
- syntax error → repair pass gets the stderr; link error → repair pass not called before the resolver.

## Acceptance
```
python -m pytest -q tests/test_native_harness_link.py
```

## Do not touch
Provided-harness builds; build-system detection; the gate; crash_dedup._get_crash_signature; sidecar internals.
