# Task 143 — know whether fuzzing reaches the code that matters, and give the fuzzer the constants that guard that code — without needing the LLM

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: in a delta benchmark, most harness groups fuzzed "healthily" for hours and found nothing — coverage and throughput
never bridged the conditions guarding the vulnerable code. discver had identified the changed functions and never checked whether
any input reached them. On full (non-delta) runs the same holds for the strategy phase's ranked targets. Healthy exec/s on the
wrong code is the most expensive failure there is, and today it is invisible. Rules, for every language with a way to measure reach:
(1) every run has an explicit TARGET SET — changed functions in delta mode, the strategy phase's top-ranked targets in full mode;
(2) reach of every target is measured periodically from the live corpus, logged and reported; (3) every target gets a dictionary of
the literal values compared on the call-graph paths to it — computed statically, so it works when the LLM refuses or is down;
(4) unreached targets drive effort (task 144 schedules on them; task 145 acts on them).

## Study first
Delta mode (how changed functions are found: `grep -rnE "\[delta\]|changed func|ref.diff" src/`), the strategy phase's ranked targets,
the reach probe used by the harness gate (`harness_reach` — what it measures, per language, how), each adapter's call graph, how a
harness's dictionary is written and passed (`-dict=`), the fuzz-round loop; docs/ARCHITECTURE.md; the report model (134).

## Change
1. **Target set** `src/core/targets.py`: `output/targets.json` = `[{id, function, file, lines, source: delta|strategy, rank}]`
   (delta: every changed function; full: top k from the strategy ranking, default 10, registry setting).
   `[targets] <n> targets (<source>): <first 5>`; stored in the run report.
2. **Reach measurement**, after the probe window and then every 3 rounds (settings), per harness, over the current corpus: the
   existing reach probe when it supports the language; otherwise the engine's function coverage from a corpus replay — native
   libFuzzer: `-runs=0 -print_coverage=1 <corpus>` (`COVERED_FUNC` lines); Jazzer: `-runs=0 --coverage_report=<file> <corpus>`;
   otherwise `reach: unknown` for that language (logged once; listed as a report caveat). Line:
   `[targets] reach <harness>: <k>/<n> reached; unreached: <names>`; per-target `reached_by`, `first_reached_round` in the report.
3. **Path dictionary (static, LLM-free).** For each target: the call-graph paths from each harness entry (depth ≤ 6, ≤ 20 paths); from
   the functions on those paths and the target itself (delta mode: the diff's added lines first) collect literals used in comparisons and
   branch selection. Per-language patterns live in the adapters: C/C++ `memcmp/strcmp/strncmp/strcasecmp(…, "lit")`, `== 'c'`,
   `== 0x…`, `case …:`, `#define` constants used in comparisons; Java `.equals/.equalsIgnoreCase/.startsWith/.endsWith/.contains("lit")`,
   string `switch` cases, char/int constants in `==`; Python `== "lit"`, `in (…)`, `.startswith`; Go `== "lit"`, `bytes.Equal(…, []byte("lit"))`,
   `strings.HasPrefix`; Rust `== b"lit"`, `starts_with(b"…")`, literal match arms. Numbers as decimal text and as little-endian bytes of
   the smallest width that holds them. Appended to the harness's dictionary in libFuzzer syntax (escaped, de-duplicated, ≤ 1,000 entries,
   path order); a dictionary is created and passed when the harness had none. `[targets] dict <harness>: +<n> tokens from <k> targets`.
4. **Value profiling**: native libFuzzer harnesses with unreached targets after the probe window are restarted once with
   `-use_value_profile=1` (logged). Jazzer already hooks Java comparisons.

## Tests (tests/test_targets_reach.py) — fixture projects with generic names, fake reach probe, fake engine output
- C fixture: entry → parse → `if (memcmp(buf, "MAGC", 4) == 0 && hdr.ver == 7) decode_ext()`; target `decode_ext` (delta) → dictionary
  has `"MAGC"` and the encodings of 7; reach 0/1 line → after a replay listing `COVERED_FUNC: … decode_ext` → 1/1.
- Java fixture: `cmd.equals("import")` and a string `switch` with `case "merge":` on the path → both tokens.
- full mode: targets from a fake strategy ranking; same pipeline. Language without a probe → `reach: unknown` once, caveat in report.
- unreached native harness → restarted once with `-use_value_profile=1`.
- empty target set → fuzz argv unchanged (golden).
- tests/e2e passes (update goldens for the new `[targets]` lines with `UPDATE_GOLDEN=1`, diff stated in finish()).

## Acceptance
```
python -m pytest -q tests/test_targets_reach.py
```

## Do not touch
The gate and static-check logic (reuse the probe); fuzz argv beyond `-dict=` and `-use_value_profile=1`;
crash_dedup._get_crash_signature; sidecar internals.
