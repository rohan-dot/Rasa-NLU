# Task 154 — "why no patch?" is answered by every run: one line per link of the patch chain, a report section, and an end-to-end test that drives a crash all the way to a validated patch

max_turns: 200

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
After many patch-related fixes, nobody could say from a run's output why it produced no patch (EVIDENCE.md). End state: for every
finding, each link of the chain — found → reproduced → triaged → eligible → oracle baseline → candidates → built → PoV fixed →
no regression → tests → persisted → submitted — is logged as proceed or stop with a reason; REPORT.md has a "Why no patch" section;
and an end-to-end test proves the whole chain is wired, in standalone mode with the local oracle and in the sidecar shape.

## Study first
The patch loop (153), candidates (152), oracle (151), triage/eligibility, submission; the e2e fakes (tests/e2e); the report model (134).

## Change
1. **Chain trace**: `[patch-chain] <finding>: <link> → proceed | stop (<reason>)` for each link reached; `output/patch_chain.json`;
   REPORT.md "Why no patch": per finding the stopping link and reason, plus one line when no finding reached the patch loop
   (`no finding reached patching: <counts by stopping link>`). Tracing never changes a decision.
2. **Eligibility made explicit**: a finding that reproduces is eligible in every language; anything that makes a finding ineligible
   (class excluded by policy, duplicate, out of time, patching disabled) is a stop reason, never a silent skip.
3. **End-to-end patch test** `tests/e2e/test_patch_e2e.py`: a native fixture and a JVM fixture whose fake engine crashes only while a
   marker line is present in a source file; the fake LLM returns a candidate edit that removes the marker (a correct fix) — run discver
   in standalone mode (local oracle with fake build commands that copy the fake engine and honour the marker) → the chain reaches
   `submitted`, the patch is persisted as a valid unified diff, the report says `validated` (or `validated_no_tests` when the fixture has
   no tests — include one fixture with a fake test command). Then, one variant per stage, scripted failures produce the matching
   `stop (<reason>)` line and "Why no patch" entry.
4. If the run can be driven in the sidecar shape with existing fakes, add the same happy-path test for it; otherwise state why not.

## Tests
As in Change 3, plus: no eligible findings → the single explicit line and the report section; refused candidate call →
`candidates → stop (refused)` and the next finding proceeds.

## Acceptance
```
python -m pytest -q tests/e2e
```

## Do not touch
Patch decisions (only observed and reported); sidecar internals; crash_dedup._get_crash_signature; the submission format.
