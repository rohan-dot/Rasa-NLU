# Task 135 — finish on time, every time: an internal deadline with a reserve, phases that respect it, clean shutdown on SIGTERM/SIGINT, exit code 0 with final reports

max_turns: 160

## Writable
- src/
- tests/
- docs/ARCHITECTURE.md

## Goal
EVIDENCE.md: benchmark trials hit the outer timeout while discver was still working — the harness killed it, the run exited
non-zero, and no final health file was written even though findings existed. The cause is structural: discver's budgets do not
leave room for wrapping up, and nothing stops new work when time runs out. End state, in every mode: discver computes an internal
deadline that leaves a reserve, phases do not start work they cannot finish, fuzzers are stopped in time, and SIGTERM/SIGINT end the
run cleanly with final reports and exit code 0. The live reports from task 134 cover a hard kill.

## Study first
MAP.md MAIN ANATOMY and CONFIG (budget settings, per-phase timeouts, fuzzer `-max_total_time`); the runner (133) and report model
(134); existing signal handling (`grep -rn "signal\." src/`); how fuzzer subprocesses are started and stopped.

## Change
1. Settings (registry): `outer_timeout` (default: unset → the configured budget), `shutdown_reserve` (default `max(300 s, 3 % of the
   budget)`). `ctx.budget.deadline = start + min(budget, outer_timeout) − reserve`. Startup line:
   `[budget] internal deadline in <e>s (budget <b>s, outer <o>s, reserve <r>s)`.
2. A helper `time_left(ctx)` and `can_start(ctx, expected_s)`; every phase and every LLM job/fuzz slice checks it before starting
   work whose expected duration (its timeout) exceeds the time left — logged once per kind: `[budget] skipping <what>: <need>s > <left>s left`.
   Fuzzer runs get `-max_total_time` clipped to the time left.
3. At the deadline: `ctx.stop_requested = True`; running fuzzers get SIGINT (libFuzzer prints final stats), then SIGKILL after 30 s;
   the runner marks remaining non-always phases `stopped`; the report phase writes `final: true`; exit 0.
4. Signals: SIGTERM/SIGINT → the same path as the deadline; a second signal → immediate final report write and exit.
5. Exit codes: 0 when the run ended by completion, deadline or signal with reports written; non-zero only for a failure before the
   pipeline could start (bad configuration, missing inputs) — with the reason as the last log line.
6. docs/ARCHITECTURE.md: a "Time and shutdown" paragraph.

## Tests (tests/test_deadline_shutdown.py) — fake clock, fake fuzzer processes
- deadline arithmetic with and without outer timeout; reserve default and override; startup line.
- `can_start` refuses work longer than the time left (logged once); `-max_total_time` clipping.
- deadline reached mid-phase → stop flag, fuzzers SIGINT then killed, final report written with `final: true`, exit 0.
- SIGTERM to a subprocess running a fake pipeline → final reports, exit 0; second signal → immediate exit with reports.
- tests/e2e passes.

## Acceptance
```
python -m pytest -q tests/test_deadline_shutdown.py
```

## Do not touch
Fuzzer argv other than `-max_total_time`; the OSS-CRS entry's arguments; crash_dedup._get_crash_signature; sidecar internals.
