# Task 170 — one toolchain manifest that drives the setup script, the container image and `discver doctor`, so a coworker can install discver for all six languages in one step

max_turns: 180

## Writable
- src/
- tests/
- scripts/
- docker/
- Dockerfile.standalone
- docs/

## Goal
discver needs a different toolchain per language (C/C++: clang with libFuzzer and sanitizers; JVM: JDK, Maven/Gradle, Jazzer; Go;
Rust with cargo-fuzz; Python with atheris; plus optional static scanners). Today that knowledge is spread over task notes, a manifest
and setup script from an earlier task (if it landed), doctor checks and the operator's memory. End state: ONE manifest is the source
of truth; a setup script installs exactly what it lists on a bare Debian/Ubuntu box; a standalone container image is built by running
that same script; `discver doctor` checks exactly the manifest; a test keeps the three consistent. The operator's existing OSS-CRS image
is not modified.

## Study first
MAP.md PACKAGING (Dockerfiles, compose files, tool manifest, setup script, `--check-tools`, how the OSS-CRS image is built); the doctor
(137); language adapters' tool needs; docs/ARCHITECTURE.md. Look at how the reference CRSs in the ref roots install per-language tooling
(`grep -rlniE "jazzer|cargo-fuzz|atheris|libfuzzer" <refs> --include=Dockerfile* | head`).

## Change
1. **Manifest** (reuse the existing one if present, else create `src/core/toolchains.json` or the format already used): per tool —
   `name`, `languages`, `required | optional`, `check` (command + version regex), `min_version`, `install` (apt package or script step,
   e.g. a pinned download for Jazzer/cargo-fuzz), `notes`.
2. **Setup script** `scripts/setup_toolchains.sh` (or extend the existing setup script): idempotent; `--languages c,cpp,java,…` (default
   all); installs from the manifest's `install` entries; prints a summary and finishes by running `discver doctor --offline`. No secrets,
   no proxies hard-coded (honours the standard proxy variables).
3. **Image** `docker/Dockerfile.standalone` (new): a public Debian/Ubuntu base, copies the repo, runs the setup script, sets the
   `discver` launcher as entrypoint, `WORKDIR /work`, a volume for outputs, the knowledge base path from the registry; a `.dockerignore`
   if missing. Build/run instructions as comments at the top. The OSS-CRS Dockerfile(s) are not touched.
4. **Consistency test** `tests/test_toolchains_consistency.py`: every manifest tool has a check and an install entry; the setup script
   installs every required tool of every language (parse the script/manifest usage); the Dockerfile runs the setup script; the doctor
   checks every manifest tool (no tool the doctor checks is missing from the manifest); adapters' declared needs ⊆ manifest.
5. `docs/INSTALL.md`: bare-metal install (setup script), container install (build + run with mounts), verifying with doctor and selftest
   (task 172), resource guidance per language (CPU, RAM, disk), upgrading toolchains (edit the manifest → script → image).

## Tests
The consistency test; a dry-run mode of the setup script (`--dry-run` prints the commands it would run) exercised in a test.

## Acceptance
```
python -m pytest -q tests/test_toolchains_consistency.py
bash scripts/setup_toolchains.sh --dry-run --languages c,java,python
```

## Do not touch
The OSS-CRS Dockerfile(s), compose files and the operator's workflow; crash_dedup._get_crash_signature; sidecar internals.
