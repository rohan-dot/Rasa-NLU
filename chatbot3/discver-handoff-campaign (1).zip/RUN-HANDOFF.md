# discver handoff campaign — one unattended run that restructures, extends, packages and documents discver

Everything is done by the agents, including the "manual" parts: configuration defaults, Docker/setup scripts, the knowledge-base
packaging, README and docs. Your part is the steps below — about 20 minutes, then it runs on its own for roughly two days.

All commands from `campaign_work` (the folder with `campaign.py`, `discver/`, `results/`, `refs/`), in the same shell setup as earlier
campaigns (LITELLM_BASE_URL, LITELLM_API_KEY, AGENT_MODEL=claude-opus-5-5, AGENT_CA_BUNDLE or AGENT_TLS_VERIFY). Recommended:
`export AGENT_REASONING_EFFORT=high`.

## 0. What this box needs (no Docker, no fuzzers, no compilers)
Python 3 with pytest and discver's Python dependencies, git, and network access to the LLM gateway — the same as earlier campaigns.
Every test the agents write uses fakes (a Python fake fuzzer, a fake model server, a fake patch validator); anything that needs a real
toolchain is skipped automatically. Real builds, fuzzing and the Docker image are verified afterwards on a machine that has them
(`scripts/discver doctor` and `scripts/discver selftest`).

To start from the latest code in git instead of the current tree:
```
mv discver discver-before-handoff
git clone <discver repo url> discver
diff -rq discver-before-handoff/src discver/src | grep "^Only in discver-before-handoff" | head -30
```
Anything listed by the last command is work that exists only in the old tree (never pushed). Copy those files into `discver/` or keep
the old tree — modules from the earlier 62–69 tasks do not matter here, step 3 re-runs them when missing.

## 1. Install (overwrites the kit; keeps your tree and history)
```
cp campaign.py campaign.py.v1 && cp microagent.py microagent.py.v1 && cp MAP.md MAP-before-handoff.md 2>/dev/null
unzip -o discver-handoff-campaign.zip
chmod +x stage_evidence.sh
python3 campaign.py --version          # campaign 2.0
```

## 2. Stage the evidence (the agents read all of it; any folder layout works)
```
bash stage_evidence.sh crsbench-nov20 /path/to/the/benchmark/output/folder /path/to/the/full/RESULTS/report.md
bash stage_evidence.sh other-runs /path/to/any/other/run/folders
```
Text files (logs, reports, json, csv) are copied, everything else is listed. `results/latest/` stays as it is.

## 3. Re-run whichever earlier capability tasks (62–69) are not in this tree
Decided from the tree itself (the task's test file is present and passes), so it is right even if `discver/` was just replaced by a
fresh git checkout:
```
for f in redo/*.md; do b=$(basename "$f"); t=$(awk '/^## Acceptance/{a=1} a' "$f" | grep -oE "tests/test_[a-z0-9_]+\.py" | head -1); if [ -f "discver/$t" ] && (cd discver && python -m pytest -q "$t" >/dev/null 2>&1); then echo "skip $b ($t passes)"; else cp "$f" tasks_handoff/ && echo "redo $b"; fi; done
```

## 4. Check the gateway, then launch
```
python3 microagent.py --verify
setsid nohup python3 campaign.py --work . --tasks tasks_handoff > runs/handoff.out 2>&1 < /dev/null &
```

## 5. While it runs
```
python3 campaign.py --work . --status          # every task: PASS / FAIL / RUNNING / pending
tail -f runs/handoff.out
```
- Gateway outages are handled: the task is restored, the campaign waits for the gateway and re-runs it (no FAIL).
- Box rebooted or the process killed: `setsid nohup python3 campaign.py --work . --resume > runs/handoff-resume.out 2>&1 < /dev/null &`
  (stops any orphaned agent, restores the interrupted task, continues). No manual restore steps any more.
- To stop it yourself: `kill <pid of campaign.py>` — it restores the running task and exits cleanly; `--resume` continues later.

## 6. After
```
grep -E "^- [0-9]+_" CAMPAIGN.md | tail -45      # the summary of this run
```
- Any FAIL: re-run those once — `python3 campaign.py --work . --tasks tasks_handoff --only <n>,<n>`.
- The deliverable is `discver-handoff.zip` (the whole repository: code, tests, docs, scripts, selftest projects). That is what
  coworkers and the operator get. `docs/HANDOFF.md` inside it is the page to read first.
- First real verification on a run box: `scripts/discver doctor` → `scripts/discver selftest` → a target that worked before, standalone
  → the same through OSS-CRS (operator workflow unchanged) → a benchmark slice. Compare with `docs/EVALUATION.md`.

## If you must hand off before it finishes
Stop it (`kill <pid>`), run the documentation tasks on the current state, hand off, and let the new owner continue:
```
python3 campaign.py --work . --tasks tasks_handoff --only 180,181,182,183,190
python3 campaign.py --work . --tasks tasks_handoff --from <first task number not yet done>     # later, by the new owner
```

## What changed in the kit, and why every earlier campaign came out incremental
The old agent prompt said "One behavioural change… No refactors" and "Edits only under src/ and tests/ — never docs, scripts".
That is why nothing structural or documentation-level ever happened. Kit 2.0 (tested end to end against a fake gateway):
- per-task writable paths (`## Writable` in each task: src, tests, docs, README.md, scripts, docker, selftest …) and per-task turn
  budgets (`max_turns:`); a new language-agnostic agent prompt that allows restructuring when a task asks for it and enforces
  generality (no target names in code, tests or docs), zero configuration and backward compatibility with the operator's workflow;
- an identity-based test gate (no test that passed may fail; tests may not silently disappear) instead of comparing counts;
- crash-proof state: a snapshot on disk per task, `--resume`, `--status`, orphaned-agent cleanup, stale-bytecode purge after restores;
- gateway outages wait and retry instead of failing task after task;
- named outputs for read-only tasks (EVIDENCE.md and MAP.md both reach every later task);
- `discver-handoff.zip` (full repository) at the end.

## The tasks
| # | What the handoff gets |
|---|---|
| 101 | EVIDENCE.md — every run and benchmark log/report read, failures stated as mechanisms, ranked |
| 102 | MAP.md — every module, the main flow, settings, LLM and oracle calls, docs, packaging, an extraction plan |
| 110 | an end-to-end test of the real run with a fake engine, fake LLM and fake oracle — the safety net for everything after |
| 122–129 | the earlier capability tasks that never passed (Java harness compile, hang storms, calibration, input boundaries, boundary harnesses, build from path, C/C++ service shape) |
| 131 | one configuration registry; defaults = intended behaviour; generated configuration reference |
| 132 | one LLM client: backend-correct requests, outcomes, refusals final with fallbacks, structured output, usage per site |
| 133 | the run as an explicit pipeline of phases over one context |
| 134 | one run-report model; reports rewritten after every phase; a REPORT.md a stranger can read |
| 135 | internal deadline with reserve, clean shutdown, reports always written |
| 136 | `discver run --repo <git-url or path>` — any repository, same pipeline as OSS-CRS mode |
| 137 | `discver doctor` — per-language readiness and exact fixes |
| 140–145 | harness discovery by shape; native link recipes; bounded seed screening; target reach + path dictionaries; effort scheduler; directed inputs for unreached code |
| 150–154 | reproducer prevalidation and dedup; oracle interface + local oracle (patching outside OSS-CRS); language-agnostic patch candidates; validation loop; "why no patch" + end-to-end patch test |
| 160–162 | phases moved out of the main module; dead code and duplicates removed |
| 170–172 | one toolchain manifest → setup script, standalone image, doctor; slim pinned knowledge base; `discver selftest` with planted-bug projects in six languages |
| 180–183 | README; operator guide and troubleshooting from evidence; architecture, developer guide, AGENT.md; generated references, evaluation history, cleanup |
| 190 | final verification and docs/HANDOFF.md |
