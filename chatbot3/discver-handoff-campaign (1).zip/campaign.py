#!/usr/bin/env python3
"""
campaign.py v2 — runs task files in order with microagent.py, verifies each with tests, keeps the tree green,
and survives crashes, reboots and gateway outages without manual restore steps.

Per task:  snapshot (in memory AND runs/<ts>/<task>/pre.zip) → agent (writable paths + turn budget from the task file)
           → compile check (compileall src) → acceptance command(s) → full suite, identity-based: no test that passed
           in the last green state may fail, and the passed count may not drop unless the task allows test removal
           → one repair pass on failure → still failing: restore, FAIL, continue with the next task.
           An agent that died on an LLM/network error is NOT a FAIL: the tree is restored, the campaign waits until
           the gateway answers again, and the task is re-run (up to 3 times).
Map tasks ("## Map") are read-only; their summary is written to the file named by `output:` (default MAP.md).
MAP.md is given to every later task as the code map and EVIDENCE.md as the run evidence.
At the end: CAMPAIGN.md summary, changed_files.txt, patch.diff, discver-fix.zip (changed files) and
discver-handoff.zip (the whole repo minus caches — what you hand over).

Task file metadata (all optional, anywhere in the file):
  max_turns: 150                      turn budget for this task (default --max-turns)
  output: EVIDENCE.md                 map tasks: where the summary is written (default MAP.md)
  allow_test_removal: yes             the passed count may drop (cleanup tasks that delete dead code with its tests)
  ## Writable                         list of repo paths the agent may edit — directories, files or globs
  - src/                              (default when the section is absent: src/ and tests/; map tasks: nothing)
  - docs/
  - README.md

Usage:
  python3 campaign.py --work . --tasks tasks_handoff                   # every task in the folder, in order
  python3 campaign.py --work . --tasks tasks_handoff --only 112,130    # some of them
  python3 campaign.py --work . --tasks tasks_handoff --from 130        # from a number on
  python3 campaign.py --work . --resume                                # continue the last run after a crash or reboot
  python3 campaign.py --work . --status                                # what the last run did so far
Env: LITELLM_BASE_URL LITELLM_API_KEY AGENT_MODEL (+ AGENT_TLS_VERIFY / AGENT_CA_BUNDLE / AGENT_REASONING_EFFORT)
"""
from __future__ import annotations

import argparse
import difflib
import json
import os
import re
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERSION = "campaign 2.0"
IGNORE_DIRS = {".git", ".microagent", ".microagent-team", ".crew", "node_modules", "__pycache__", ".venv", "venv",
               ".mypy_cache", ".pytest_cache", "dist", "build", ".idea", "output", "oss-crs"}
BINARY_SUFFIXES = (".pyc", ".zip", ".jar", ".class", ".png", ".jpg", ".jpeg", ".gz", ".tgz", ".tar", ".so", ".bin", ".pdf", ".whl")
HANDOFF_SKIP_DIRS = {".git", ".microagent", ".microagent-team", ".crew", "node_modules", "__pycache__", ".venv", "venv",
                     ".mypy_cache", ".pytest_cache", ".idea", "output"}
INFRA_MARKERS = ("LLM error", "LLM call failed", "agent produced no result.json", "model returned three empty replies",
                 "URLError", "Connection", "timed out", "Temporary failure", "Name or service not known")
INFRA_RETRIES = 3


def log(msg: str) -> None:
    print(f"{datetime.now().strftime('%H:%M:%S')} {msg}", flush=True)


def now() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def write_json(path: Path, data: dict) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, path)


# ----------------------------------------------------------------------------- snapshot / diff (no git needed)
def snapshot(repo: Path) -> dict[str, bytes]:
    out = {}
    for directory, dirs, names in os.walk(repo):
        d = Path(directory)
        dirs[:] = [x for x in dirs if x not in IGNORE_DIRS]
        for name in names:
            p = d / name
            if name.endswith(BINARY_SUFFIXES) or p.is_symlink():
                continue
            try:
                out[p.relative_to(repo).as_posix()] = p.read_bytes()
            except OSError:
                continue
    return out


def save_snapshot(snap: dict[str, bytes], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, data in snap.items():
            z.writestr(rel, data)
    os.replace(tmp, path)


def load_snapshot(path: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(path) as z:
        return {n: z.read(n) for n in z.namelist()}


def changed(before: dict[str, bytes], after: dict[str, bytes]) -> list[str]:
    return sorted(set(k for k in after if before.get(k) != after[k]) | set(k for k in before if k not in after))


def purge_bytecode(repo: Path) -> None:
    """Stale .pyc files survive a restore when the restored source has the same size and second-resolution mtime as the
    bad one — Python would then keep running the reverted code. Remove every __pycache__ after a restore."""
    for directory, dirs, _names in os.walk(repo):
        dirs[:] = [x for x in dirs if x not in (".git", "node_modules", ".venv", "venv")]
        if Path(directory).name == "__pycache__":
            for f in Path(directory).glob("*.pyc"):
                f.unlink(missing_ok=True)


def restore(repo: Path, snap: dict[str, bytes], current: dict[str, bytes]) -> None:
    for rel, data in snap.items():
        p = repo / rel
        if not p.exists() or p.read_bytes() != data:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
    for rel in set(current) - set(snap):
        (repo / rel).unlink(missing_ok=True)
    purge_bytecode(repo)


def unified(before: dict[str, bytes], after: dict[str, bytes]) -> str:
    chunks = []
    for rel in changed(before, after):
        a = before.get(rel, b"").decode("utf-8", errors="replace").splitlines(True)
        b = after.get(rel, b"").decode("utf-8", errors="replace").splitlines(True)
        chunks.extend(difflib.unified_diff(a, b, fromfile=f"a/{rel}", tofile=f"b/{rel}"))
        if chunks and not chunks[-1].endswith("\n"):
            chunks.append("\n\\ No newline at end of file\n")
    return "".join(chunks) or "(no changes)\n"


# ----------------------------------------------------------------------------- tests
def sh(cmd: str, cwd: Path, timeout: int = 3600) -> tuple[int, str]:
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    try:
        r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        return r.returncode, (r.stdout + "\n" + r.stderr).strip()
    except subprocess.TimeoutExpired:
        return 124, f"TIMEOUT after {timeout}s: {cmd}"


def pytest_counts(output: str) -> dict[str, int]:
    counts = {"passed": 0, "failed": 0, "error": 0}
    tail = "\n".join(output.splitlines()[-15:])
    for key, pat in (("passed", r"(\d+) passed"), ("failed", r"(\d+) failed"), ("error", r"(\d+) errors?")):
        m = re.search(pat, tail)
        if m:
            counts[key] = int(m.group(1))
    return counts


def parse_junit(path: Path) -> dict | None:
    try:
        root = ET.parse(path).getroot()
    except Exception:
        return None
    passed, failed, skipped = set(), set(), set()
    for tc in root.iter("testcase"):
        tid = f"{tc.get('classname', '')}::{tc.get('name', '')}"
        tags = {child.tag for child in tc}
        if tags & {"failure", "error"}:
            failed.add(tid)
        elif "skipped" in tags:
            skipped.add(tid)
        else:
            passed.add(tid)
    return {"passed": passed, "failed": failed, "skipped": skipped}


def run_suite(repo: Path, test_cmd: str, junit: Path) -> dict:
    cmd = test_cmd
    if "pytest" in test_cmd and "--junitxml" not in test_cmd:
        cmd = f"{test_cmd} --junitxml={junit} -p no:cacheprovider"
    junit.parent.mkdir(parents=True, exist_ok=True)
    junit.unlink(missing_ok=True)
    rc, out = sh(cmd, repo)
    j = parse_junit(junit) if junit.is_file() else None
    counts = pytest_counts(out)
    if j:
        return {"rc": rc, "passed": len(j["passed"]), "failed_ids": sorted(j["failed"]), "counts": counts, "junit": True, "out": out}
    return {"rc": rc, "passed": counts["passed"], "failed_ids": None, "counts": counts, "junit": False, "out": out}


def regression(now_: dict, green: dict, allow_removal: bool) -> str | None:
    """None when the suite is at least as healthy as the last green state, else the reason."""
    if now_["failed_ids"] is not None and green.get("failed_ids") is not None:
        new = sorted(set(now_["failed_ids"]) - set(green["failed_ids"]))
        if new:
            return f"{len(new)} test(s) fail that did not fail in the last green state: " + ", ".join(new[:15])
    else:
        c, g = now_["counts"], green["counts"]
        if c["failed"] + c["error"] > g["failed"] + g["error"]:
            return f"failed+error grew from {g['failed'] + g['error']} to {c['failed'] + c['error']}"
    if now_["passed"] < green["passed"] and not allow_removal:
        return f"passed count dropped from {green['passed']} to {now_['passed']} (tests removed or newly skipped)"
    if now_["rc"] not in (0, 1) and green["rc"] in (0, 1):
        return f"pytest exit code {now_['rc']} (collection/usage error)"
    return None


def acceptance_commands(task_text: str) -> list[str]:
    m = re.search(r"^##\s*Acceptance.*?\n```[a-z]*\n(.*?)```", task_text, re.S | re.M)
    if not m:
        return []
    return [ln.strip() for ln in m.group(1).splitlines() if ln.strip() and not ln.strip().startswith("#")]


def task_kind(task_text: str) -> str:
    return "map" if re.search(r"^##\s*Map\b", task_text, re.M) or re.search(r"^kind:\s*map", task_text, re.M) else "change"


def task_meta(task_text: str, kind: str) -> dict:
    meta = {"max_turns": None, "output": "MAP.md", "allow_test_removal": False, "writable": ["src", "tests"]}
    m = re.search(r"^max_turns:\s*(\d+)\s*$", task_text, re.M)
    if m:
        meta["max_turns"] = int(m.group(1))
    m = re.search(r"^output:\s*([A-Za-z0-9_.-]+\.md)\s*$", task_text, re.M)
    if m:
        meta["output"] = m.group(1)
    meta["allow_test_removal"] = bool(re.search(r"^allow_test_removal:\s*(yes|true|1)\s*$", task_text, re.M | re.I))
    m = re.search(r"^##\s*Writable[^\n]*\n(.*?)(?=^##\s|\Z)", task_text, re.S | re.M)
    if m:
        items = []
        for ln in m.group(1).splitlines():
            ln = ln.strip()
            if ln.startswith(("-", "*")):
                rest = ln.lstrip("-*").strip()
                tok = rest.split()[0].strip("`") if rest else ""
                if tok:
                    items.append(tok)
        if items:
            meta["writable"] = items
    if kind == "map":
        meta["writable"] = []
    return meta


# ----------------------------------------------------------------------------- agent
CURRENT_AGENT: subprocess.Popen | None = None


def run_agent(args, work: Path, task_file: Path, meta: dict, out_dir: Path, extra_task: str | None = None) -> dict:
    global CURRENT_AGENT
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(HERE / "microagent.py"), "--repo", str(work / "discver"), "--out", str(out_dir),
           "--model", args.model, "--max-turns", str(meta["max_turns"] or args.max_turns), "--bash-timeout", str(args.bash_timeout),
           "--writable", *meta["writable"]]
    if (work / "results").is_dir():
        cmd += ["--results", str(work / "results")]
    refs = work / "refs"
    if refs.is_dir():
        for d in sorted(refs.iterdir()):
            if d.is_dir() and not d.name.startswith("."):
                cmd += ["--ref", f"{d.name}={d}"]
    if (work / "MAP.md").is_file():
        cmd += ["--context", str(work / "MAP.md")]
    if (work / "EVIDENCE.md").is_file():
        cmd += ["--results-hint", str(work / "EVIDENCE.md")]
    task_path = task_file
    if extra_task:
        task_path = out_dir / "task.md"
        task_path.write_text(task_file.read_text(encoding="utf-8") + "\n\n" + extra_task, encoding="utf-8")
    cmd += ["--task-file", str(task_path)]
    (out_dir / "result.json").unlink(missing_ok=True)
    log(f"[campaign] agent: {task_file.name} (writable: {', '.join(meta['writable']) or 'none'}; "
        f"max_turns {meta['max_turns'] or args.max_turns}) -> {out_dir}")
    CURRENT_AGENT = subprocess.Popen(cmd, start_new_session=True)
    (out_dir / "agent.pid").write_text(str(CURRENT_AGENT.pid), encoding="utf-8")
    try:
        CURRENT_AGENT.wait()
    except BaseException:
        kill_agent()          # interrupted: stop the agent before anyone restores the tree
        raise
    finally:
        CURRENT_AGENT = None
    rj = out_dir / "result.json"
    return json.loads(rj.read_text(encoding="utf-8")) if rj.is_file() else {"status": "error", "edits": [], "summary": "agent produced no result.json"}


def kill_agent() -> None:
    p = CURRENT_AGENT
    if p and p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGTERM)
            p.wait(timeout=20)
        except Exception:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except Exception:
                pass


def kill_orphans(task_dir: Path) -> None:
    """After a hard crash the agent of the interrupted task may still be running (it has its own session) and would keep
    editing the tree. Stop every agent recorded under the task's run folder before restoring."""
    for pidfile in task_dir.rglob("agent.pid"):
        try:
            pid = int(pidfile.read_text().strip())
            cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().decode(errors="replace")
        except (OSError, ValueError):
            continue
        if "microagent.py" in cmdline:
            log(f"[campaign] stopping orphaned agent pid {pid}")
            try:
                os.killpg(pid, signal.SIGTERM)
                time.sleep(5)
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except Exception as exc:
                log(f"[campaign] could not stop pid {pid}: {exc}")


def is_infra_failure(res: dict) -> bool:
    if res.get("status") != "error":
        return False
    s = res.get("summary") or ""
    return any(m in s for m in INFRA_MARKERS)


def wait_for_gateway(args) -> bool:
    """Probe the gateway with microagent --verify until it answers; give up after ~6 hours."""
    delay, waited = 120, 0
    while waited < 6 * 3600:
        try:
            rc = subprocess.run([sys.executable, str(HERE / "microagent.py"), "--verify", "--model", args.model],
                                capture_output=True, text=True, timeout=900).returncode
        except subprocess.TimeoutExpired:
            rc = 1
        if rc == 0:
            log("[campaign] gateway answers again — retrying the task")
            return True
        log(f"[campaign] gateway still unavailable — next probe in {delay}s (waited {waited // 60} min)")
        time.sleep(delay)
        waited += delay
        delay = min(1800, delay * 2)
    return False


def verify_task(repo: Path, task_text: str, meta: dict, test_cmd: str, green: dict, junit: Path) -> tuple[bool, str, dict | None]:
    report = []
    rc, out = sh("python -c \"import pathlib,sys; bad=[]\n"
                 "for p in sorted(pathlib.Path('src').rglob('*.py')):\n"
                 "    try: compile(p.read_text(encoding='utf-8', errors='replace'), str(p), 'exec')\n"
                 "    except SyntaxError as e: bad.append(f'{p}:{e.lineno}: {e.msg}')\n"
                 "print('\\n'.join(bad)); sys.exit(1 if bad else 0)\"", repo)
    report.append(f"syntax check src/**/*.py: exit {rc}" + ("" if rc == 0 else "\n" + out[-2500:]))
    if rc != 0:
        return False, "\n".join(report), None
    for cmd in acceptance_commands(task_text):
        rc, out = sh(cmd, repo)
        report.append(f"acceptance `{cmd}`: exit {rc}\n" + "\n".join(out.splitlines()[-30:]))
        if rc != 0:
            return False, "\n".join(report), None
    res = run_suite(repo, test_cmd, junit)
    nf = len(res["failed_ids"]) if res["failed_ids"] is not None else res["counts"]
    gf = len(green["failed_ids"]) if green.get("failed_ids") is not None else green["counts"]
    report.append(f"full suite: exit {res['rc']} passed={res['passed']} failed={nf} (last green: passed={green['passed']} failed={gf})")
    why = regression(res, green, meta["allow_test_removal"])
    if why:
        report.append("REGRESSION: " + why)
        report.append("\n".join(res["out"].splitlines()[-60:]))
        return False, "\n".join(report), res
    return True, "\n".join(report), res


# ----------------------------------------------------------------------------- state
def latest_run(work: Path) -> Path | None:
    runs = sorted((work / "runs").glob("*/state.json"))
    return runs[-1].parent if runs else None


def show_status(work: Path) -> None:
    run = latest_run(work)
    if not run:
        print("no campaign state found under runs/")
        return
    st = json.loads((run / "state.json").read_text(encoding="utf-8"))
    print(f"run {run.name}: {st.get('phase')}  tasks dir {st.get('tasks_dir')}")
    for name in st["tasks"]:
        v = st["done"].get(name) or ("RUNNING" if st.get("running") == name else "pending")
        print(f"  {name:60s} {v}")


def make_handoff_zip(repo: Path, dest: Path) -> int:
    n = 0
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for directory, dirs, names in os.walk(repo):
            d = Path(directory)
            dirs[:] = sorted(x for x in dirs if x not in HANDOFF_SKIP_DIRS)
            for name in sorted(names):
                p = d / name
                if p.is_symlink() or name.endswith(".pyc"):
                    continue
                z.write(p, Path("discver") / p.relative_to(repo))
                n += 1
    return n


# ----------------------------------------------------------------------------- main
def main() -> None:
    ap = argparse.ArgumentParser(description="run the discver task campaign")
    ap.add_argument("--work", required=True)
    ap.add_argument("--tasks", help="task dir (default <work>/tasks)")
    ap.add_argument("--only", help="comma-separated task number prefixes, e.g. 110,112")
    ap.add_argument("--from", dest="from_", help="start at this task number")
    ap.add_argument("--test-cmd", default="python -m pytest -q tests")
    ap.add_argument("--model", default=os.environ.get("AGENT_MODEL", ""))
    ap.add_argument("--max-turns", type=int, default=120)
    ap.add_argument("--bash-timeout", type=int, default=1500)
    ap.add_argument("--no-repair", action="store_true")
    ap.add_argument("--resume", action="store_true", help="continue the most recent run (restores an interrupted task first)")
    ap.add_argument("--status", action="store_true", help="print the state of the most recent run and exit")
    ap.add_argument("--version", action="version", version=VERSION)
    a = ap.parse_args()
    work = Path(a.work).expanduser().resolve()
    if a.status:
        show_status(work)
        return
    if "," in a.model:
        a.model = a.model.split(",")[0].strip()
    if not a.model:
        sys.exit("set AGENT_MODEL or pass --model")
    repo = work / "discver"
    if not (repo / "src").is_dir():
        sys.exit(f"missing discver/src under {work}")

    if a.resume:
        runs = latest_run(work)
        if not runs:
            sys.exit("nothing to resume: no runs/*/state.json")
        st = json.loads((runs / "state.json").read_text(encoding="utf-8"))
        tasks_dir = Path(st["tasks_dir"])
        if st.get("running"):
            kill_orphans(runs / Path(st["running"]).stem)
            pre = runs / Path(st["running"]).stem / "pre.zip"
            if pre.is_file():
                restore(repo, load_snapshot(pre), snapshot(repo))
                log(f"[campaign] resume: {st['running']} was interrupted — tree restored to its pre-task snapshot")
            st["running"] = None
        tasks = [tasks_dir / n for n in st["tasks"] if n not in st["done"] and (tasks_dir / n).is_file()]
        origin = load_snapshot(runs / "origin.zip")
        green = st["green"]
        st["phase"] = "running"
        write_json(runs / "state.json", st)
        log(f"[campaign] resume {runs.name}: {len(st['done'])} done, {len(tasks)} to go")
        if not tasks:
            log("[campaign] nothing left to run")
    else:
        tasks_dir = Path(a.tasks).resolve() if a.tasks else work / "tasks"
        if not tasks_dir.is_dir():
            sys.exit(f"missing task dir {tasks_dir}")
        tasks = [t for t in tasks_dir.glob("*.md") if re.match(r"^\d+_", t.name)]
        tasks.sort(key=lambda t: (int(t.name.split("_")[0]), t.name))
        if a.only:
            wanted = {x.strip() for x in a.only.split(",") if x.strip()}
            tasks = [t for t in tasks if t.name.split("_")[0] in wanted]
        if a.from_:
            tasks = [t for t in tasks if int(t.name.split("_")[0]) >= int(a.from_)]
        if not tasks:
            sys.exit("no tasks selected")
        runs = work / "runs" / now()
        runs.mkdir(parents=True, exist_ok=True)
        origin = snapshot(repo)
        save_snapshot(origin, runs / "origin.zip")
        base = run_suite(repo, a.test_cmd, runs / "baseline-junit.xml")
        green = {k: base[k] for k in ("rc", "passed", "failed_ids", "counts")}
        log(f"[campaign] baseline suite: exit {base['rc']} passed={base['passed']} "
            f"failed={len(base['failed_ids']) if base['failed_ids'] is not None else base['counts']}")
        if base["rc"] != 0:
            (work / "BASELINE_FAILURES.txt").write_text(base["out"], encoding="utf-8")
        st = {"version": VERSION, "tasks_dir": str(tasks_dir), "tasks": [t.name for t in tasks], "done": {}, "running": None,
              "green": green, "phase": "running", "started": now()}
        write_json(runs / "state.json", st)
        with (work / "CAMPAIGN.md").open("a", encoding="utf-8") as f:
            f.write(f"## run {runs.name} ({VERSION}) — baseline exit {base['rc']} passed={base['passed']}\n\n")

    log(f"[campaign] {VERSION} work={work}\n[campaign] model={a.model} tasks={[t.name for t in tasks]}\n[campaign] runs -> {runs}")

    def on_signal(signum, _frame):
        raise KeyboardInterrupt(f"signal {signum}")
    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGHUP, on_signal)

    results = []
    for task_file in tasks:
        text = task_file.read_text(encoding="utf-8")
        kind = task_kind(text)
        meta = task_meta(text, kind)
        out_dir = runs / task_file.stem
        before = snapshot(repo)
        save_snapshot(before, out_dir / "pre.zip")
        st["running"] = task_file.name
        write_json(runs / "state.json", st)
        t0 = time.time()
        res: dict = {}
        try:
            res = run_agent(a, work, task_file, meta, out_dir)
            infra = 0
            while is_infra_failure(res) and infra < INFRA_RETRIES:
                infra += 1
                restore(repo, before, snapshot(repo))
                log(f"[campaign] {task_file.name}: agent stopped on an LLM/network error — tree restored; waiting for the gateway")
                if not wait_for_gateway(a):
                    break
                res = run_agent(a, work, task_file, meta, out_dir / f"retry{infra}")
            verdict, detail = "", ""
            if is_infra_failure(res):
                verdict, detail = "INFRA_FAIL", (res.get("summary") or "")[:1500]
                restore(repo, before, snapshot(repo))
            elif kind == "map":
                if res.get("status") in ("finished", "no_edits") and res.get("summary"):
                    (work / meta["output"]).write_text(res["summary"], encoding="utf-8")
                    verdict, detail = "MAPPED", f"{meta['output']} written ({len(res['summary'])} chars)"
                else:
                    verdict, detail = "FAIL", f"mapping task {res.get('status')}: {(res.get('summary') or '')[:500]}"
                after = snapshot(repo)
                if changed(before, after):
                    restore(repo, before, after)
                    detail += " — mapping task edited files; reverted"
            else:
                ok, detail, sres = verify_task(repo, text, meta, a.test_cmd, green, out_dir / "junit.xml")
                if ok and res.get("edits"):
                    verdict = "PASS"
                elif not res.get("edits"):
                    verdict, detail = "NO_EDITS", (res.get("summary") or "")[:1500]
                else:
                    if not a.no_repair:
                        log(f"[campaign] {task_file.name}: verification failed — repair pass")
                        repair = ("\n\n## REPAIR PASS\nYour previous attempt made these edits: " + ", ".join(res.get("edits", [])) +
                                  ".\nVerification FAILED with this output:\n```\n" + detail[-7000:] + "\n```\nFix the failure without "
                                  "reverting the feature. A test that passed before must pass again (restore removed tests). If a failure is "
                                  "pre-existing and unrelated to your change, say so in finish() with evidence.")
                        res2 = run_agent(a, work, task_file, meta, out_dir / "repair", extra_task=repair)
                        ok, detail, sres = verify_task(repo, text, meta, a.test_cmd, green, out_dir / "junit-repair.xml")
                        res["edits"] = sorted(set(res.get("edits", [])) | set(res2.get("edits", [])))
                        res["summary"] = (res.get("summary") or "") + "\n\nREPAIR PASS:\n" + (res2.get("summary") or "")
                    verdict = "PASS" if ok else "FAIL"
                if verdict == "PASS" and sres:
                    green = {k: sres[k] for k in ("rc", "passed", "failed_ids", "counts")}
                    st["green"] = green
                if verdict not in ("PASS", "NO_EDITS"):
                    restore(repo, before, snapshot(repo))
                    log(f"[campaign] {task_file.name}: {verdict} — repo restored to the state before this task")
        except KeyboardInterrupt as exc:
            kill_agent()
            restore(repo, before, snapshot(repo))
            st["running"] = None
            st["phase"] = f"interrupted at {task_file.name}"
            write_json(runs / "state.json", st)
            log(f"[campaign] interrupted ({exc}) — {task_file.name} restored; continue later with: python3 campaign.py --work {work} --resume")
            sys.exit(130)
        files = changed(before, snapshot(repo))
        minutes = (time.time() - t0) / 60
        results.append((task_file.name, verdict, files, res))
        st["done"][task_file.name] = verdict
        st["running"] = None
        write_json(runs / "state.json", st)
        (out_dir / "pre.zip").unlink(missing_ok=True)
        log(f"[campaign] {task_file.name}: {verdict} ({len(files)} file(s) kept, {minutes:.0f} min)")
        with (work / "CAMPAIGN.md").open("a", encoding="utf-8") as f:
            f.write(f"### {task_file.name} — {verdict}\n\nFiles kept: {', '.join(files) or '(none)'} ({minutes:.0f} min)\n\n"
                    f"Verification:\n```\n{detail[-3000:]}\n```\n\nAgent summary:\n\n{(res.get('summary') or '')[:4000]}\n\n")

    final = snapshot(repo)
    files = changed(origin, final)
    (work / "changed_files.txt").write_text("\n".join(files) + ("\n" if files else ""), encoding="utf-8")
    (work / "patch.diff").write_text(unified(origin, final), encoding="utf-8")
    if files:
        with zipfile.ZipFile(work / "discver-fix.zip", "w", zipfile.ZIP_DEFLATED) as z:
            for f in files:
                if (repo / f).exists():
                    z.write(repo / f, f)
            z.write(work / "patch.diff", "patch.diff")
            z.write(work / "CAMPAIGN.md", "CAMPAIGN.md")
    n = make_handoff_zip(repo, work / "discver-handoff.zip")
    st["phase"] = "finished"
    write_json(runs / "state.json", st)
    summary = "\n".join(f"- {n_}: {v}" + (f" ({', '.join(fs)})" if fs else "") for n_, v, fs, _ in results)
    with (work / "CAMPAIGN.md").open("a", encoding="utf-8") as f:
        f.write(f"## summary {runs.name}\n\n{summary}\n\n")
    log("[campaign] summary:\n" + summary)
    log(f"[campaign] done. CAMPAIGN.md, patch.diff, discver-fix.zip, discver-handoff.zip ({n} files) in {work}")


if __name__ == "__main__":
    main()
