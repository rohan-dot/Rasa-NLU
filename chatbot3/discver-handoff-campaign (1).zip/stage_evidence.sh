#!/usr/bin/env bash
# stage_evidence.sh <name> <path> [<path> ...]
#   Copies run / benchmark evidence into results/evidence/<name>/ so the campaign's evidence task (101) can read it.
#   Run it from campaign_work. Each <path> may be a file or a folder (a run output dir, a benchmark result dir, a report).
#   Text files only (logs, md, json, csv, yaml, txt, xml, diffs) up to MAXMB each (default 300); everything is listed in
#   <name>/<folder>_listing.txt with size and date, so the agent knows what existed even when it was not copied.
#   Any folder layout is fine — the evidence task inventories whatever it finds.
set -euo pipefail
NAME=${1:?usage: stage_evidence.sh <name> <path> [<path> ...]}; shift
[ $# -ge 1 ] || { echo "usage: stage_evidence.sh <name> <path> [<path> ...]"; exit 2; }
DEST="results/evidence/$NAME"; MAXMB=${MAXMB:-300}
mkdir -p "$DEST"
for SRC in "$@"; do
  [ -e "$SRC" ] || { echo "skip (not found): $SRC"; continue; }
  if [ -f "$SRC" ]; then cp -p "$SRC" "$DEST/"; echo "file: $SRC"; continue; fi
  SRC=$(cd "$SRC" && pwd); base=$(basename "$SRC")
  find "$SRC" -type f -printf '%s\t%TY-%Tm-%Td %TH:%TM\t%P\n' | sort -k3 > "$DEST/${base}_listing.txt"
  n=0
  while IFS= read -r -d '' f; do
    rel=${f#"$SRC"/}; mkdir -p "$DEST/$base/$(dirname "$rel")"; cp -p "$f" "$DEST/$base/$rel"; n=$((n+1))
  done < <(find "$SRC" -type f -size -"${MAXMB}"M \( -name '*.log' -o -name '*.md' -o -name '*.json' -o -name '*.jsonl' \
             -o -name '*.csv' -o -name '*.tsv' -o -name '*.yaml' -o -name '*.yml' -o -name '*.txt' -o -name '*.xml' \
             -o -name '*.out' -o -name '*.diff' -o -name '*.patch' -o -name '*.html' \) -print0)
  echo "folder: $SRC — $n text files copied, full listing in $DEST/${base}_listing.txt"
done
du -sh "$DEST" | awk '{print "staged " $1 " into " $2}'
