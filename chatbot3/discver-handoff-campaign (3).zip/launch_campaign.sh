#!/usr/bin/env bash
# launch_campaign.sh — start or resume the handoff campaign fully detached from your terminal.
# It keeps running on this machine after you close the terminal, log out, disconnect, or switch off your PC.
#
#   bash launch_campaign.sh            # start the campaign (tasks_handoff/)
#   bash launch_campaign.sh resume     # continue after a reboot / kill / crash (restores the interrupted task first)
#   bash launch_campaign.sh status     # what is done, running, pending
#   bash launch_campaign.sh stop       # stop cleanly (the running task is restored; resume later)
#
# Needs in the environment (export them first, or put the exports at the top of this file):
#   LITELLM_BASE_URL  LITELLM_API_KEY  AGENT_MODEL  and AGENT_CA_BUNDLE=<pem> or AGENT_TLS_VERIFY=false
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
mode=${1:-start}
pidfile=runs/campaign.pid

pid_of()  { [ -f "$pidfile" ] && awk '{print $1}' "$pidfile"; }
host_of() { [ -f "$pidfile" ] && awk '{print $2}' "$pidfile"; }
running() { [ -f "$pidfile" ] && [ "$(host_of)" = "$(hostname)" ] && kill -0 "$(pid_of)" 2>/dev/null; }
elsewhere() { [ -f "$pidfile" ] && [ -n "$(host_of)" ] && [ "$(host_of)" != "$(hostname)" ]; }

case "$mode" in
  status)
    if elsewhere; then echo "campaign was started on $(host_of) (pid $(pid_of)) — log into $(host_of) to check the process; progress below"
    elif running; then echo "campaign running (pid $(pid_of))"; else echo "campaign not running"; fi
    python3 campaign.py --work . --status
    exit 0 ;;
  stop)
    if elsewhere; then echo "campaign runs on $(host_of) (pid $(pid_of)) — log into $(host_of) and run: bash launch_campaign.sh stop"; exit 1; fi
    if running; then kill -TERM "$(pid_of)"; echo "stop requested (pid $(pid_of)) — it restores the running task and exits"; else echo "campaign not running"; fi
    exit 0 ;;
  start|resume) ;;
  *) echo "usage: bash launch_campaign.sh [start|resume|status|stop]"; exit 2 ;;
esac

if running; then echo "already running (pid $(pid_of)) — use: bash launch_campaign.sh status"; exit 1; fi
if elsewhere && [ "${FORCE:-0}" != 1 ]; then
  echo "a campaign was started on $(host_of) (pid $(pid_of)). Two campaigns on one tree corrupt it."
  echo "Log into $(host_of) and use status/stop there. Only if $(host_of) was rebooted or that process is gone: FORCE=1 bash launch_campaign.sh $mode"
  exit 1
fi
: "${LITELLM_BASE_URL:?export LITELLM_BASE_URL first}"
: "${LITELLM_API_KEY:?export LITELLM_API_KEY first}"
: "${AGENT_MODEL:?export AGENT_MODEL first (e.g. claude-opus-5-5)}"
export AGENT_REASONING_EFFORT=${AGENT_REASONING_EFFORT:-high}

python3 microagent.py --verify            # stops here if the gateway or the model does not answer
mkdir -p runs
stamp=$(date +%m%d-%H%M)
if [ "$mode" = resume ]; then
  log=runs/handoff-resume-$stamp.out; args=(--resume)
else
  [ -d tasks_handoff ] || { echo "tasks_handoff/ missing — unzip discver-handoff-campaign.zip here first"; exit 1; }
  log=runs/handoff-$stamp.out; args=(--tasks tasks_handoff)
fi
setsid nohup python3 campaign.py --work . "${args[@]}" > "$log" 2>&1 < /dev/null &
for _ in 1 2 3 4 5 6 7 8 9 10; do sleep 1; [ -f "$pidfile" ] && break; done
if running; then
  echo "campaign $mode: running as pid $(pid_of) on $(hostname), detached — safe to close this terminal and switch off your PC"
else
  echo "campaign $mode: started; it is measuring the baseline test suite first (pid file appears when that is done)"
fi
echo "log:    tail -f $log"
echo "status: bash launch_campaign.sh status"
