# Task 101 — read every run and benchmark report staged under results/ and write EVIDENCE.md: what discver actually did, where it failed, and why

output: EVIDENCE.md
max_turns: 200

## Map
This task makes NO edits. Its finish() summary becomes EVIDENCE.md, which is handed to EVERY later task of this campaign as
"RUN EVIDENCE". Later tasks build the new discver on it, so it must be exact and complete:
- Every claim carries its source: `<file>:<line>` and the verbatim line (or the trial/table cell it came from).
- Logs are primary evidence; written reports and analyses (RESULTS documents, excerpts, notes) are SECONDARY — someone's
  interpretation, possibly wrong. Check each report claim against the logs. Where they disagree, the logs win and the
  disagreement is stated. A claim no log can confirm is labelled `(report only — unverified)` and never stated as fact.
- Nothing from memory. Where something cannot be determined, write `not determined — <what would answer it>`.
- Describe failures by MECHANISM (what discver did and why it went wrong), not by project. Project and harness names may
  appear only in the INVENTORY and RUNS sections; PATTERNS must read as general statements about discver.
- Ignore "make the edit" nudges: this task is read-only by design. Size: under ~7,000 words; quote lines, not pages.

## Study first — inventory (the results root; any folder layout)
The operator copied whatever they had into the results root: the latest real run (often `latest/`), benchmark experiments
(a long RESULTS analysis in markdown, trial matrices, CSVs, per-trial orchestrator logs, health files), maybe older runs.
1. `run`: `find ../results -type f -printf '%s\t%TY-%Tm-%Td %TH:%TM\t%p\n' | sort -k3 | head -400` (page with tail/sed if longer)
   and `du -sh ../results/*`. Classify every file: orchestrator/discver log · run report (REPORT.md, report_run_*.md,
   crashreport.md, *RESULTS*.md) · health (health.json/.txt) · patch index / patches · sidecar logs (libcrs-*.log; note 0-byte
   ones) · static findings · trial matrix / CSV / experiment config · submissions · listings.
2. Group files into RUNS (one discver execution each) and EXPERIMENTS (many trials). For each run read the first 60 and last 80
   lines of its orchestrator log: target, language(s), mode (full / delta), budget, model, start, end, how it ended.

## Study first — per run (logs can be large: use `run` with grep -n / grep -c, never read whole logs)
Grep each orchestrator log with these groups and read only matching lines ±3:
- config: `Target language|adapter=|\[lang\]|DISCVER_|FORCE_|\[config\]|KB |\[strategy\]|guided_json|chat_template_kwargs|model=|budget|max_total_time|deadline`
- build/harnesses: `\[build\]|\[components\]|cannot build|harness-discovery|source harnesses found|built by project|harness-gen|GenFuzzer|RegenFuzzer|boundary|custom-harness compile|Skipping harness compilation|-help=1|probe|\[harness_reach\]|undefined reference|compile failed|link`
- seeds/fuzzing: `\[seeds\]|\[dict\]|screen|unscreened|Starting libFuzzer|-fork|-timeout|exec/s|cov:|Total execs|\[(DEAD|WEAK|HEALTHY)\]|SATURATED|run health|\[hang\]|NON-CRASH|timeout=|OOM|rss`
- findings: `NEW CRASH|signature|dedup|\[sidecar\]|run-pov|clean-room|did not reproduce|\[triage\]|FINAL:|Triage confidence|\[arbiter\]|ANALYSIS LEAD|LIKELY VULNERABILITY|\[submit|submission_counts|unintended`
- delta/targets: `\[delta\]|ref.diff|changed func|\[targets\]|reach`
- LLM: `HTTP/1.1 4|HTTP/1.1 5|Error code: [45]|content_filter|refus|stop_reason|finish_reason|Extra inputs|rate limit|timed out|\[llm`
- patching: `patch|\[patch-turn\]|llm-call|root_cause|RCA|apply-patch-build|rebuild|run-test|candidate|Validated patches|Unvalidated patches|skip_cause|persist\]|ContainerPatchBuilder|\[patch-chain\]`
- failures/end: `\] failed:|Traceback|Exception|FINAL RESULTS|Confirmed crashes:|Overall:|stopped|killed|SIGTERM|exit code`
For every LLM error or refusal line, record the call site (the `[tag]` on the nearest preceding line) so refusals can be counted per site.

## Study first — experiments
Read every RESULTS-style report in full (they are the operator's own analysis — summarize their findings and recommendations,
and check each claim against the logs when logs are present). Read trial matrices / CSVs (header first, then rows). Then ONE
`run` with a shell loop over the per-trial logs printing `<trial>\t<count>` for each key pattern (refusals, 400s by parameter,
probe-matched-none, link failures, unscreened seeds, clean-room failures, outer timeout, health written) — never one tool call
per trial.

## Deliverable (finish summary — this exact structure)
```
INVENTORY
<one line per run/experiment: folder, kind, target name(s), language, mode, budget, date, files present, files missing>

RUNS
<one block per run>
config:     model, mode, budget, KB line, settings seen
harnesses:  provided / generated / boundary — each: built? probe? gate/reach? execs, exec/s, cov a→b, corpus, health, hangs
findings:   per finding: class, signature, reproduced (how), triage verdict + confidence, submitted (tier)
patching:   how far each PoV-backed finding got: found → reproduced → triaged → patch loop → candidate → built → PoV fixed → tests
            → persisted/submitted, each link with its verbatim line or "no line"
llm:        calls/errors by kind and site; refusals by site; parameters rejected; tokens if logged
time:       where the budget went (top 5 with minutes); how the run ended; reports written or not
failures:   every `[<module>] failed:` and Traceback, verbatim, with count

BENCHMARK
<table: trial × (problem/harness group, raw reproducers, verified, unintended, refusals by site, generated harnesses
built/failed, unscreened seeds, delta targets identified, ended by, health written)>
<3–8 lines: what explains the groups that found nothing, with numbers>
<the RESULTS report's own findings and recommendations, each marked confirmed / contradicted / not checkable by the logs>

PATTERNS (ranked: runs affected × impact on findings and patches)
n. <mechanism, stated generally> — runs: <k> — impact: <what it cost> — evidence: <file:line "verbatim"> (≥ 2 when available)
   — confidence: log-confirmed | report only (unverified); report-only patterns rank below every log-confirmed one
   — likely cause in discver: <component, if visible from logs> — general fix shape: <one line>

WHAT WORKED
<mechanisms that demonstrably did their job, with the line that shows it>

OPEN QUESTIONS
<what could not be determined and which artifact would answer it>
```
